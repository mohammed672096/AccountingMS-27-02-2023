﻿namespace PosFinalCost
{
    partial class ReportEndUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.Utils.SuperToolTip superToolTip1 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem1 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem1 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip2 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem2 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem2 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip3 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem3 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem3 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip4 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem4 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem4 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip5 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem5 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem5 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip6 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem6 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem6 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip7 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem7 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem7 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip8 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem8 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem8 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip9 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem9 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem9 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip10 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem10 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem10 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip11 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem11 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem11 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip12 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem12 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem12 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip13 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem13 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem13 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip14 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem14 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem14 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip15 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem15 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem15 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip16 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem16 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem16 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip17 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem17 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem17 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip18 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem18 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem18 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip19 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem19 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem19 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip20 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem20 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem20 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip21 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem21 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem21 = new DevExpress.Utils.ToolTipItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReportEndUserForm));
            DevExpress.Utils.SuperToolTip superToolTip22 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem22 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem22 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip23 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem23 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem23 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip24 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem24 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem24 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip25 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem25 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem25 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip26 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem26 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem26 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip27 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem27 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem27 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip28 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem28 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem28 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip29 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem29 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem29 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip30 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem30 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem30 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip31 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem31 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem31 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip32 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem32 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem32 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip33 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem33 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem33 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip34 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem34 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem34 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip35 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem35 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem35 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip36 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem36 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem36 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip37 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem37 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem37 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip38 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem38 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem38 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip39 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem39 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem39 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip40 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem40 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem40 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip41 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem41 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem41 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip42 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem42 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem42 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip43 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem43 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem43 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip44 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem44 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem44 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip45 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem45 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem45 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip46 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem46 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem46 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip47 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem47 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem47 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip48 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem48 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem48 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip49 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem49 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem49 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip50 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem50 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem50 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip51 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem51 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem51 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip52 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem52 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem52 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip53 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem53 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem53 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip54 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem54 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem54 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip55 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem55 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem55 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip56 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem56 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem56 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip57 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem57 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem57 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip58 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem58 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem58 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip59 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem59 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem59 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip60 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem60 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem60 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip61 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem61 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem61 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip62 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem62 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem62 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip63 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem63 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem63 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip64 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem64 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem64 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip65 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem65 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem65 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip66 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem66 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem66 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip67 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem67 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem67 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip68 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem68 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem68 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip69 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem69 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem69 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip70 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem70 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem70 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip71 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem71 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem71 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip72 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem72 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem72 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip73 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem73 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem73 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip74 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem74 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem74 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip75 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem75 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem75 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip76 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem76 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem76 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip77 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem77 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem77 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip78 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem78 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem78 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip79 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem79 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem79 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip80 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem80 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem80 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip81 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem81 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem81 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip82 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem82 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem82 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip83 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem83 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem83 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip84 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem84 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem84 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip85 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem85 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem85 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip86 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem86 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem86 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip87 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem87 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem87 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip88 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem88 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem88 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip89 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem89 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem89 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip90 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem90 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem90 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip91 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem91 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem91 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip92 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem92 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem92 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip93 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem93 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem93 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip94 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem94 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem94 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip95 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem95 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem95 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip96 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem96 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem96 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip97 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem97 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem97 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip98 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem98 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem98 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip99 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem99 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem99 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip100 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem100 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem100 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip101 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem101 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem101 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip102 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem102 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem102 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip103 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem103 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem103 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip104 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem104 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem104 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip105 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem105 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem105 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip106 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem106 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem106 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip107 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem107 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem107 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip108 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem108 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem108 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip109 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem109 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem109 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip110 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem110 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem110 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip111 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem111 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem111 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip112 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem112 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem112 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip113 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem113 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem113 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip114 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem114 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem114 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip115 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem115 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem115 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip116 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem116 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem116 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip117 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem117 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem117 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip118 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem118 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem118 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip119 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem119 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem119 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip120 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem120 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem120 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip121 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem121 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem121 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip122 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem122 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem122 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip123 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem123 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem123 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip124 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem124 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem124 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip125 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem125 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem125 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip126 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem126 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem126 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip127 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem127 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem127 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip128 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem128 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem128 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip129 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem129 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem129 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip130 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem130 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem130 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip131 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem131 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem131 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip132 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem132 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem132 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip133 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem133 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem133 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip134 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem134 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem134 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip135 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem135 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem135 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip136 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem136 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem136 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip137 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem137 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem137 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip138 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem138 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem138 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip139 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem139 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem139 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip140 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem140 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem140 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip141 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem141 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem141 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip142 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem142 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem142 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip143 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem143 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem143 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip144 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem144 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem144 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip145 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem145 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem145 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip146 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem146 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem146 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip147 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem147 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem147 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip148 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem148 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem148 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip149 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem149 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem149 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip150 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem150 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem150 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip151 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem151 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem151 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip152 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem152 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem152 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip153 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem153 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem153 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip154 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem154 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem154 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip155 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem155 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem155 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip156 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem156 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem156 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip157 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem157 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem157 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip158 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem158 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem158 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip159 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem159 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem159 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip160 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem160 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem160 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip161 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem161 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem161 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip162 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem162 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem162 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip163 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem163 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem163 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip164 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem164 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem164 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip165 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem165 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem165 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip166 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem166 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem166 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip167 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem167 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem167 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip168 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem168 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem168 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip169 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem169 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem169 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip170 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem170 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem170 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip171 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem171 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem171 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip172 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem172 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem172 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip173 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem173 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem173 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip174 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem174 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem174 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip175 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem175 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem175 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip176 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem176 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem176 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip177 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem177 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem177 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip178 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem178 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem178 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip179 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem179 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem179 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip180 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem180 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem180 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip181 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem181 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem181 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip182 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem182 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem182 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip183 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem183 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem183 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip184 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem184 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem184 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip185 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem185 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem185 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip186 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem186 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem186 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip187 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem187 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem187 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip188 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem188 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem188 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip189 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem189 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem189 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip190 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem190 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem190 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip191 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem191 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem191 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip192 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem192 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem192 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip193 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem193 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem193 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip194 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem194 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem194 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip195 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem195 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem195 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip196 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem196 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem196 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip197 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem197 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem197 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip198 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem198 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem198 = new DevExpress.Utils.ToolTipItem();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener1 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener2 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener3 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener4 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener5 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener6 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener7 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener8 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            this.xrDesignRibbonController1 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonController(this.components);
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.applicationMenu1 = new DevExpress.XtraBars.Ribbon.ApplicationMenu(this.components);
            this.commandBarItem6 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem9 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem7 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem8 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem125 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem126 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem1 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem2 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem3 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem4 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem5 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem10 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem11 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem12 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem13 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem14 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem15 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem16 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.recentlyUsedItemsComboBox1 = new DevExpress.XtraReports.UserDesigner.RecentlyUsedItemsComboBox();
            this.barEditItem2 = new DevExpress.XtraBars.BarEditItem();
            this.designRepositoryItemComboBox1 = new DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox();
            this.barDockPanelsListItem1 = new DevExpress.XtraReports.UserDesigner.BarDockPanelsListItem();
            this.xrDesignDockManager1 = new DevExpress.XtraReports.UserDesigner.XRDesignDockManager(this.components);
            this.hideContainerBottom = new DevExpress.XtraBars.Docking.AutoHideContainer();
            this.errorListDockPanel1 = new DevExpress.XtraReports.UserDesigner.ErrorListDockPanel();
            this.errorListDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.groupAndSortDockPanel1 = new DevExpress.XtraReports.UserDesigner.GroupAndSortDockPanel();
            this.groupAndSortDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.panelContainer1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.panelContainer2 = new DevExpress.XtraBars.Docking.DockPanel();
            this.reportExplorerDockPanel1 = new DevExpress.XtraReports.UserDesigner.ReportExplorerDockPanel();
            this.reportExplorerDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.fieldListDockPanel1 = new DevExpress.XtraReports.UserDesigner.FieldListDockPanel();
            this.fieldListDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.panelContainer3 = new DevExpress.XtraBars.Docking.DockPanel();
            this.propertyGridDockPanel1 = new DevExpress.XtraReports.UserDesigner.PropertyGridDockPanel();
            this.propertyGridDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.reportGalleryDockPanel1 = new DevExpress.XtraReports.UserDesigner.ReportGalleryDockPanel();
            this.reportGalleryDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.commandBarItem17 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem18 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem19 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandColorBarItem1 = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.commandColorBarItem2 = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.commandBarItem20 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem21 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem22 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem23 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem24 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem25 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem26 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem27 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem28 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem29 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem30 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem31 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem32 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem33 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem34 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem35 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem36 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem37 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandColorBarItem3 = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.commandBarItem38 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem39 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem40 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem41 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem42 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem43 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem44 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem45 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem46 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem47 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem48 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem49 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem50 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem51 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem52 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem53 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem54 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem55 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem56 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem57 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem58 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem59 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem60 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem61 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarCheckItem1 = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarCheckItem2 = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarItem62 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem63 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem64 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem65 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandColorBarItem4 = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.commandBarItem66 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem67 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem68 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem69 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem70 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem71 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem72 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem73 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem74 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandGalleryBarItem1 = new DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem();
            this.commandGalleryBarItem2 = new DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem();
            this.commandGalleryBarItem3 = new DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem();
            this.commandGalleryBarItem4 = new DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem();
            this.commandGalleryBarItem5 = new DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem();
            this.commandGalleryBarItem6 = new DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem();
            this.commandBarEditItem1 = new DevExpress.XtraReports.UserDesigner.CommandBarEditItem();
            this.repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.commandBarEditItem2 = new DevExpress.XtraReports.UserDesigner.CommandBarEditItem();
            this.repositoryItemSpinEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.commandBarEditItem3 = new DevExpress.XtraReports.UserDesigner.CommandBarEditItem();
            this.repositoryItemSpinEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.commandBarEditItem4 = new DevExpress.XtraReports.UserDesigner.CommandBarEditItem();
            this.repositoryItemSpinEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.commandBarEditItem5 = new DevExpress.XtraReports.UserDesigner.CommandBarEditItem();
            this.repositoryItemImageComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox();
            this.commandBarEditItem6 = new DevExpress.XtraReports.UserDesigner.CommandBarEditItem();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.commandBarEditItem7 = new DevExpress.XtraReports.UserDesigner.CommandBarEditItem();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.commandBarItem75 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem76 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem77 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem78 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem79 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem80 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem81 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem82 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem83 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem84 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem85 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem86 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem87 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem88 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem89 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem90 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem91 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem92 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem93 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem94 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem95 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem96 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem97 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem98 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem99 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem100 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem101 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem102 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem103 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem104 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem105 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem106 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem107 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem108 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem109 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem110 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem111 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem112 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem113 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem114 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem115 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem116 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem117 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem118 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem119 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem120 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarCheckItem3 = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarCheckItem4 = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarCheckItem5 = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarCheckItem6 = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarCheckItem7 = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarCheckItem8 = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarItem121 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem122 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem123 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem124 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.xrDesignBarButtonGroup1 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup2 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup3 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup4 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup5 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup6 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup7 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup8 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup9 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup10 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup11 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup12 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup13 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup14 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.printPreviewBarItem1 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem2 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem3 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem4 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem5 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem7 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem8 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem9 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem11 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem12 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem13 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem14 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem15 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem16 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem17 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem18 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem19 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem20 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem21 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem22 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem23 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem24 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem25 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem26 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem27 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem28 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem29 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem30 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem31 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem32 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem33 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem34 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem35 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem36 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem37 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem38 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem39 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem40 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem41 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem42 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem43 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem44 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem45 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem46 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem47 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem48 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem49 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem50 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem51 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewStaticItem1 = new DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem();
            this.progressBarEditItem1 = new DevExpress.XtraPrinting.Preview.ProgressBarEditItem();
            this.repositoryItemProgressBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemProgressBar();
            this.printPreviewBarItem52 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewStaticItem2 = new DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem();
            this.zoomTrackBarEditItem1 = new DevExpress.XtraPrinting.Preview.ZoomTrackBarEditItem();
            this.repositoryItemZoomTrackBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar();
            this.btnOpenDefaultRprt = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPageCategory1 = new DevExpress.XtraReports.UserDesigner.XRCharacterCombRibbonPageCategory();
            this.ribbonPage6 = new DevExpress.XtraReports.UserDesigner.XRCharacterCombDesignContextRibbonPage();
            this.xrDesignRibbonPageGroup18 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPageCategory2 = new DevExpress.XtraReports.UserDesigner.XRTableRibbonPageCategory();
            this.ribbonPage7 = new DevExpress.XtraReports.UserDesigner.XRTableDesignContextRibbonPage();
            this.xrDesignRibbonPageGroup19 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup20 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup21 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup22 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup23 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPageCategory3 = new DevExpress.XtraReports.UserDesigner.XRChartRibbonPageCategory();
            this.ribbonPage8 = new DevExpress.XtraReports.UserDesigner.XRChartDesignContextRibbonPage();
            this.xrDesignRibbonPageGroup24 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup25 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup26 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup27 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup28 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPageCategory4 = new DevExpress.XtraReports.UserDesigner.XRPivotGridRibbonPageCategory();
            this.ribbonPage9 = new DevExpress.XtraReports.UserDesigner.XRPivotGridDesignContextRibbonPage();
            this.xrDesignRibbonPageGroup29 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup30 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup31 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup32 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPageCategory5 = new DevExpress.XtraReports.UserDesigner.XRBarCodeRibbonPageCategory();
            this.ribbonPage10 = new DevExpress.XtraReports.UserDesigner.XRBarcodeDesignContextRibbonPage();
            this.xrDesignRibbonPageGroup33 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup34 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPageCategory6 = new DevExpress.XtraReports.UserDesigner.XRGaugeRibbonPageCategory();
            this.ribbonPage11 = new DevExpress.XtraReports.UserDesigner.XRGaugeDesignContextRibbonPage();
            this.xrDesignRibbonPageGroup35 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup36 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPageCategory7 = new DevExpress.XtraReports.UserDesigner.XRSparklineRibbonPageCategory();
            this.ribbonPage12 = new DevExpress.XtraReports.UserDesigner.XRSparklineDesignContextRibbonPage();
            this.xrDesignRibbonPageGroup37 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup38 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPageCategory8 = new DevExpress.XtraReports.UserDesigner.XRShapeRibbonPageCategory();
            this.ribbonPage13 = new DevExpress.XtraReports.UserDesigner.XRShapeDesignContextRibbonPage();
            this.xrDesignRibbonPageGroup39 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPageCategory9 = new DevExpress.XtraReports.UserDesigner.XRLabelRibbonPageCategory();
            this.ribbonPage14 = new DevExpress.XtraReports.UserDesigner.XRLabelTextContextRibbonPage();
            this.xrDesignRibbonPageGroup40 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup41 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPage1 = new DevExpress.XtraReports.UserDesigner.XRHomeRibbonPage();
            this.xrDesignRibbonPageGroup1 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup2 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup3 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup4 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup5 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup6 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup7 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPage2 = new DevExpress.XtraReports.UserDesigner.XRLayoutRibbonPage();
            this.xrDesignRibbonPageGroup8 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup9 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup10 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup11 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPage3 = new DevExpress.XtraReports.UserDesigner.XRPageRibbonPage();
            this.xrDesignRibbonPageGroup12 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup13 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPage4 = new DevExpress.XtraReports.UserDesigner.XRViewRibbonPage();
            this.xrDesignRibbonPageGroup14 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup15 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup16 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPage5 = new DevExpress.XtraReports.UserDesigner.XRScriptsRibbonPage();
            this.xrDesignRibbonPageGroup17 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPage15 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage();
            this.printPreviewRibbonPageGroup1 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup2 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup3 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup4 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup5 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup6 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup7 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup8 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.ribbonPage16 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage17 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar1 = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.reportDesigner1 = new DevExpress.XtraReports.UserDesigner.XRDesignMdiController(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignRibbonController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.recentlyUsedItemsComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignDockManager1)).BeginInit();
            this.hideContainerBottom.SuspendLayout();
            this.errorListDockPanel1.SuspendLayout();
            this.groupAndSortDockPanel1.SuspendLayout();
            this.panelContainer1.SuspendLayout();
            this.panelContainer2.SuspendLayout();
            this.reportExplorerDockPanel1.SuspendLayout();
            this.fieldListDockPanel1.SuspendLayout();
            this.panelContainer3.SuspendLayout();
            this.propertyGridDockPanel1.SuspendLayout();
            this.reportGalleryDockPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemImageComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemZoomTrackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportDesigner1)).BeginInit();
            this.SuspendLayout();
            // 
            // xrDesignRibbonController1
            // 
            this.xrDesignRibbonController1.RibbonControl = this.ribbonControl1;
            this.xrDesignRibbonController1.RibbonStatusBar = this.ribbonStatusBar1;
            this.xrDesignRibbonController1.XRDesignDockManager = this.xrDesignDockManager1;
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ApplicationButtonDropDownControl = this.applicationMenu1;
            this.ribbonControl1.AutoHideEmptyItems = true;
            this.ribbonControl1.AutoSizeItems = true;
            this.ribbonControl1.EmptyAreaImageOptions.ImagePadding = new System.Windows.Forms.Padding(30, 35, 30, 35);
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.ribbonControl1.SearchEditItem,
            this.commandBarItem1,
            this.commandBarItem2,
            this.commandBarItem3,
            this.commandBarItem4,
            this.commandBarItem5,
            this.commandBarItem6,
            this.commandBarItem7,
            this.commandBarItem8,
            this.commandBarItem9,
            this.commandBarItem10,
            this.commandBarItem11,
            this.commandBarItem12,
            this.commandBarItem13,
            this.commandBarItem14,
            this.commandBarItem15,
            this.commandBarItem16,
            this.barEditItem1,
            this.barEditItem2,
            this.barDockPanelsListItem1,
            this.commandBarItem17,
            this.commandBarItem18,
            this.commandBarItem19,
            this.commandColorBarItem1,
            this.commandColorBarItem2,
            this.commandBarItem20,
            this.commandBarItem21,
            this.commandBarItem22,
            this.commandBarItem23,
            this.commandBarItem24,
            this.commandBarItem25,
            this.commandBarItem26,
            this.commandBarItem27,
            this.commandBarItem28,
            this.commandBarItem29,
            this.commandBarItem30,
            this.commandBarItem31,
            this.commandBarItem32,
            this.commandBarItem33,
            this.commandBarItem34,
            this.commandBarItem35,
            this.commandBarItem36,
            this.commandBarItem37,
            this.commandColorBarItem3,
            this.commandBarItem38,
            this.commandBarItem39,
            this.commandBarItem40,
            this.commandBarItem41,
            this.commandBarItem42,
            this.commandBarItem43,
            this.commandBarItem44,
            this.commandBarItem45,
            this.commandBarItem46,
            this.commandBarItem47,
            this.commandBarItem48,
            this.commandBarItem49,
            this.commandBarItem50,
            this.commandBarItem51,
            this.commandBarItem52,
            this.commandBarItem53,
            this.commandBarItem54,
            this.commandBarItem55,
            this.commandBarItem56,
            this.commandBarItem57,
            this.commandBarItem58,
            this.commandBarItem59,
            this.commandBarItem60,
            this.commandBarItem61,
            this.commandBarCheckItem1,
            this.commandBarCheckItem2,
            this.commandBarItem62,
            this.commandBarItem63,
            this.commandBarItem64,
            this.commandBarItem65,
            this.commandColorBarItem4,
            this.commandBarItem66,
            this.commandBarItem67,
            this.commandBarItem68,
            this.commandBarItem69,
            this.commandBarItem70,
            this.commandBarItem71,
            this.commandBarItem72,
            this.commandBarItem73,
            this.commandBarItem74,
            this.commandGalleryBarItem1,
            this.commandGalleryBarItem2,
            this.commandGalleryBarItem3,
            this.commandGalleryBarItem4,
            this.commandGalleryBarItem5,
            this.commandGalleryBarItem6,
            this.commandBarEditItem1,
            this.commandBarEditItem2,
            this.commandBarEditItem3,
            this.commandBarEditItem4,
            this.commandBarEditItem5,
            this.commandBarEditItem6,
            this.commandBarEditItem7,
            this.commandBarItem75,
            this.commandBarItem76,
            this.commandBarItem77,
            this.commandBarItem78,
            this.commandBarItem79,
            this.commandBarItem80,
            this.commandBarItem81,
            this.commandBarItem82,
            this.commandBarItem83,
            this.commandBarItem84,
            this.commandBarItem85,
            this.commandBarItem86,
            this.commandBarItem87,
            this.commandBarItem88,
            this.commandBarItem89,
            this.commandBarItem90,
            this.commandBarItem91,
            this.commandBarItem92,
            this.commandBarItem93,
            this.commandBarItem94,
            this.commandBarItem95,
            this.commandBarItem96,
            this.commandBarItem97,
            this.commandBarItem98,
            this.commandBarItem99,
            this.commandBarItem100,
            this.commandBarItem101,
            this.commandBarItem102,
            this.commandBarItem103,
            this.commandBarItem104,
            this.commandBarItem105,
            this.commandBarItem106,
            this.commandBarItem107,
            this.commandBarItem108,
            this.commandBarItem109,
            this.commandBarItem110,
            this.commandBarItem111,
            this.commandBarItem112,
            this.commandBarItem113,
            this.commandBarItem114,
            this.commandBarItem115,
            this.commandBarItem116,
            this.commandBarItem117,
            this.commandBarItem118,
            this.commandBarItem119,
            this.commandBarItem120,
            this.commandBarCheckItem3,
            this.commandBarCheckItem4,
            this.commandBarCheckItem5,
            this.commandBarCheckItem6,
            this.commandBarCheckItem7,
            this.commandBarCheckItem8,
            this.commandBarItem121,
            this.commandBarItem122,
            this.commandBarItem123,
            this.commandBarItem124,
            this.commandBarItem125,
            this.commandBarItem126,
            this.xrDesignBarButtonGroup1,
            this.xrDesignBarButtonGroup2,
            this.xrDesignBarButtonGroup3,
            this.xrDesignBarButtonGroup4,
            this.xrDesignBarButtonGroup5,
            this.xrDesignBarButtonGroup6,
            this.xrDesignBarButtonGroup7,
            this.xrDesignBarButtonGroup8,
            this.xrDesignBarButtonGroup9,
            this.xrDesignBarButtonGroup10,
            this.xrDesignBarButtonGroup11,
            this.xrDesignBarButtonGroup12,
            this.xrDesignBarButtonGroup13,
            this.xrDesignBarButtonGroup14,
            this.printPreviewBarItem1,
            this.printPreviewBarItem2,
            this.printPreviewBarItem3,
            this.printPreviewBarItem4,
            this.printPreviewBarItem5,
            this.printPreviewBarItem7,
            this.printPreviewBarItem8,
            this.printPreviewBarItem9,
            this.printPreviewBarItem11,
            this.printPreviewBarItem12,
            this.printPreviewBarItem13,
            this.printPreviewBarItem14,
            this.printPreviewBarItem15,
            this.printPreviewBarItem16,
            this.printPreviewBarItem17,
            this.printPreviewBarItem18,
            this.printPreviewBarItem19,
            this.printPreviewBarItem20,
            this.printPreviewBarItem21,
            this.printPreviewBarItem22,
            this.printPreviewBarItem23,
            this.printPreviewBarItem24,
            this.printPreviewBarItem25,
            this.printPreviewBarItem26,
            this.printPreviewBarItem27,
            this.printPreviewBarItem28,
            this.printPreviewBarItem29,
            this.printPreviewBarItem30,
            this.printPreviewBarItem31,
            this.printPreviewBarItem32,
            this.printPreviewBarItem33,
            this.printPreviewBarItem34,
            this.printPreviewBarItem35,
            this.printPreviewBarItem36,
            this.printPreviewBarItem37,
            this.printPreviewBarItem38,
            this.printPreviewBarItem39,
            this.printPreviewBarItem40,
            this.printPreviewBarItem41,
            this.printPreviewBarItem42,
            this.printPreviewBarItem43,
            this.printPreviewBarItem44,
            this.printPreviewBarItem45,
            this.printPreviewBarItem46,
            this.printPreviewBarItem47,
            this.printPreviewBarItem48,
            this.printPreviewBarItem49,
            this.printPreviewBarItem50,
            this.printPreviewBarItem51,
            this.printPreviewStaticItem1,
            this.progressBarEditItem1,
            this.printPreviewBarItem52,
            this.printPreviewStaticItem2,
            this.zoomTrackBarEditItem1,
            this.btnOpenDefaultRprt});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ribbonControl1.MaxItemId = 226;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.PageCategories.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageCategory[] {
            this.ribbonPageCategory1,
            this.ribbonPageCategory2,
            this.ribbonPageCategory3,
            this.ribbonPageCategory4,
            this.ribbonPageCategory5,
            this.ribbonPageCategory6,
            this.ribbonPageCategory7,
            this.ribbonPageCategory8,
            this.ribbonPageCategory9});
            this.ribbonControl1.PageHeaderItemLinks.Add(this.commandBarItem1);
            this.ribbonControl1.PageHeaderItemLinks.Add(this.commandBarItem2);
            this.ribbonControl1.PageHeaderItemLinks.Add(this.commandBarItem3);
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1,
            this.ribbonPage2,
            this.ribbonPage3,
            this.ribbonPage4,
            this.ribbonPage5,
            this.ribbonPage15,
            this.ribbonPage16,
            this.ribbonPage17});
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.commandBarItem4);
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.commandBarItem5);
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.recentlyUsedItemsComboBox1,
            this.designRepositoryItemComboBox1,
            this.repositoryItemSpinEdit1,
            this.repositoryItemSpinEdit2,
            this.repositoryItemSpinEdit3,
            this.repositoryItemSpinEdit4,
            this.repositoryItemImageComboBox1,
            this.repositoryItemLookUpEdit1,
            this.repositoryItemComboBox1,
            this.repositoryItemProgressBar1,
            this.repositoryItemZoomTrackBar1});
            this.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2019;
            this.ribbonControl1.ShowItemCaptionsInPageHeader = true;
            this.ribbonControl1.Size = new System.Drawing.Size(1333, 198);
            this.ribbonControl1.StatusBar = this.ribbonStatusBar1;
            this.ribbonControl1.TransparentEditorsMode = DevExpress.Utils.DefaultBoolean.True;
            // 
            // applicationMenu1
            // 
            this.applicationMenu1.ItemLinks.Add(this.commandBarItem6);
            this.applicationMenu1.ItemLinks.Add(this.commandBarItem9);
            this.applicationMenu1.ItemLinks.Add(this.commandBarItem7);
            this.applicationMenu1.ItemLinks.Add(this.commandBarItem8);
            this.applicationMenu1.ItemLinks.Add(this.commandBarItem125, true);
            this.applicationMenu1.ItemLinks.Add(this.commandBarItem126, true);
            this.applicationMenu1.MenuDrawMode = DevExpress.XtraBars.MenuDrawMode.LargeImagesText;
            this.applicationMenu1.Name = "applicationMenu1";
            this.applicationMenu1.Ribbon = this.ribbonControl1;
            // 
            // commandBarItem6
            // 
            this.commandBarItem6.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem6.Caption = "New Report";
            this.commandBarItem6.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReport;
            this.commandBarItem6.Enabled = false;
            this.commandBarItem6.Id = 6;
            this.commandBarItem6.Name = "commandBarItem6";
            superToolTip1.FixedTooltipWidth = true;
            toolTipTitleItem1.Text = "New Blank Report";
            toolTipItem1.LeftIndent = 6;
            toolTipItem1.Text = "Create a new blank report.";
            superToolTip1.Items.Add(toolTipTitleItem1);
            superToolTip1.Items.Add(toolTipItem1);
            superToolTip1.MaxWidth = 210;
            this.commandBarItem6.SuperTip = superToolTip1;
            this.commandBarItem6.VisibleInSearchMenu = false;
            // 
            // commandBarItem9
            // 
            this.commandBarItem9.Caption = "Open...";
            this.commandBarItem9.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.OpenFile;
            this.commandBarItem9.Enabled = false;
            this.commandBarItem9.Id = 9;
            this.commandBarItem9.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O));
            this.commandBarItem9.Name = "commandBarItem9";
            superToolTip2.FixedTooltipWidth = true;
            toolTipTitleItem2.Text = "Open Report (Ctrl+O)";
            toolTipItem2.LeftIndent = 6;
            toolTipItem2.Text = "Open a report.";
            superToolTip2.Items.Add(toolTipTitleItem2);
            superToolTip2.Items.Add(toolTipItem2);
            superToolTip2.MaxWidth = 210;
            this.commandBarItem9.SuperTip = superToolTip2;
            this.commandBarItem9.VisibleInSearchMenu = false;
            // 
            // commandBarItem7
            // 
            this.commandBarItem7.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem7.Caption = "Save";
            this.commandBarItem7.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFile;
            this.commandBarItem7.Enabled = false;
            this.commandBarItem7.Id = 7;
            this.commandBarItem7.Name = "commandBarItem7";
            superToolTip3.FixedTooltipWidth = true;
            toolTipTitleItem3.Text = "Save Report";
            toolTipItem3.LeftIndent = 6;
            toolTipItem3.Text = "Save the current report.";
            superToolTip3.Items.Add(toolTipTitleItem3);
            superToolTip3.Items.Add(toolTipItem3);
            superToolTip3.MaxWidth = 210;
            this.commandBarItem7.SuperTip = superToolTip3;
            // 
            // commandBarItem8
            // 
            this.commandBarItem8.Caption = "Save All";
            this.commandBarItem8.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveAll;
            this.commandBarItem8.Enabled = false;
            this.commandBarItem8.Id = 8;
            this.commandBarItem8.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L));
            this.commandBarItem8.Name = "commandBarItem8";
            superToolTip4.FixedTooltipWidth = true;
            toolTipTitleItem4.Text = "Save All Reports (Ctrl+L)";
            toolTipItem4.LeftIndent = 6;
            toolTipItem4.Text = "Save all modified reports.";
            superToolTip4.Items.Add(toolTipTitleItem4);
            superToolTip4.Items.Add(toolTipItem4);
            superToolTip4.MaxWidth = 210;
            this.commandBarItem8.SuperTip = superToolTip4;
            // 
            // commandBarItem125
            // 
            this.commandBarItem125.Caption = "Close";
            this.commandBarItem125.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Close;
            this.commandBarItem125.Enabled = false;
            this.commandBarItem125.Id = 153;
            this.commandBarItem125.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4));
            this.commandBarItem125.Name = "commandBarItem125";
            superToolTip5.FixedTooltipWidth = true;
            toolTipTitleItem5.Text = "Close (Ctrl+F4)";
            toolTipItem5.LeftIndent = 6;
            toolTipItem5.Text = "Close the current report.";
            superToolTip5.Items.Add(toolTipTitleItem5);
            superToolTip5.Items.Add(toolTipItem5);
            superToolTip5.MaxWidth = 210;
            this.commandBarItem125.SuperTip = superToolTip5;
            // 
            // commandBarItem126
            // 
            this.commandBarItem126.Caption = "Exit";
            this.commandBarItem126.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Exit;
            this.commandBarItem126.Enabled = false;
            this.commandBarItem126.Id = 154;
            this.commandBarItem126.Name = "commandBarItem126";
            superToolTip6.FixedTooltipWidth = true;
            toolTipTitleItem6.Text = "Exit";
            toolTipItem6.LeftIndent = 6;
            toolTipItem6.Text = "Close the report designer.";
            superToolTip6.Items.Add(toolTipTitleItem6);
            superToolTip6.Items.Add(toolTipItem6);
            superToolTip6.MaxWidth = 210;
            this.commandBarItem126.SuperTip = superToolTip6;
            // 
            // commandBarItem1
            // 
            this.commandBarItem1.Caption = "Designer";
            this.commandBarItem1.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowDesignerTab;
            this.commandBarItem1.Enabled = false;
            this.commandBarItem1.Id = 1;
            this.commandBarItem1.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F4);
            this.commandBarItem1.Name = "commandBarItem1";
            superToolTip7.FixedTooltipWidth = true;
            toolTipTitleItem7.Text = "Report Designer (F4)";
            toolTipItem7.LeftIndent = 6;
            toolTipItem7.Text = "Customize the report layout or create a new layout in the feature-rich Report Des" +
    "igner.";
            superToolTip7.Items.Add(toolTipTitleItem7);
            superToolTip7.Items.Add(toolTipItem7);
            superToolTip7.MaxWidth = 210;
            this.commandBarItem1.SuperTip = superToolTip7;
            // 
            // commandBarItem2
            // 
            this.commandBarItem2.Caption = "Preview";
            this.commandBarItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowPreviewTab;
            this.commandBarItem2.Enabled = false;
            this.commandBarItem2.Id = 2;
            this.commandBarItem2.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F5);
            this.commandBarItem2.Name = "commandBarItem2";
            superToolTip8.FixedTooltipWidth = true;
            toolTipTitleItem8.Text = "Print Preview (F5)";
            toolTipItem8.LeftIndent = 6;
            toolTipItem8.Text = "Display a report populated with data and divided into pages, customize its print " +
    "settings and print or export this report.";
            superToolTip8.Items.Add(toolTipTitleItem8);
            superToolTip8.Items.Add(toolTipItem8);
            superToolTip8.MaxWidth = 210;
            this.commandBarItem2.SuperTip = superToolTip8;
            // 
            // commandBarItem3
            // 
            this.commandBarItem3.Caption = "Scripts";
            this.commandBarItem3.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowScriptsTab;
            this.commandBarItem3.Enabled = false;
            this.commandBarItem3.Id = 3;
            this.commandBarItem3.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F6);
            this.commandBarItem3.Name = "commandBarItem3";
            superToolTip9.FixedTooltipWidth = true;
            toolTipTitleItem9.Text = "Scripts (F6)";
            toolTipItem9.LeftIndent = 6;
            toolTipItem9.Text = "Perform custom calculations by handling script events.";
            superToolTip9.Items.Add(toolTipTitleItem9);
            superToolTip9.Items.Add(toolTipItem9);
            superToolTip9.MaxWidth = 210;
            this.commandBarItem3.SuperTip = superToolTip9;
            // 
            // commandBarItem4
            // 
            this.commandBarItem4.Caption = "Undo";
            this.commandBarItem4.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Undo;
            this.commandBarItem4.Enabled = false;
            this.commandBarItem4.Id = 4;
            this.commandBarItem4.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z));
            this.commandBarItem4.Name = "commandBarItem4";
            superToolTip10.FixedTooltipWidth = true;
            toolTipTitleItem10.Text = "Undo (Ctrl+Z)";
            toolTipItem10.LeftIndent = 6;
            toolTipItem10.Text = "Undo the last operation.";
            superToolTip10.Items.Add(toolTipTitleItem10);
            superToolTip10.Items.Add(toolTipItem10);
            superToolTip10.MaxWidth = 210;
            this.commandBarItem4.SuperTip = superToolTip10;
            // 
            // commandBarItem5
            // 
            this.commandBarItem5.Caption = "Redo";
            this.commandBarItem5.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Redo;
            this.commandBarItem5.Enabled = false;
            this.commandBarItem5.Id = 5;
            this.commandBarItem5.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y));
            this.commandBarItem5.Name = "commandBarItem5";
            superToolTip11.FixedTooltipWidth = true;
            toolTipTitleItem11.Text = "Redo (Ctrl+Y)";
            toolTipItem11.LeftIndent = 6;
            toolTipItem11.Text = "Redo the last operation.";
            superToolTip11.Items.Add(toolTipTitleItem11);
            superToolTip11.Items.Add(toolTipItem11);
            superToolTip11.MaxWidth = 210;
            this.commandBarItem5.SuperTip = superToolTip11;
            // 
            // commandBarItem10
            // 
            this.commandBarItem10.Caption = "New Report";
            this.commandBarItem10.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReport;
            this.commandBarItem10.Description = "Create a new blank report.";
            this.commandBarItem10.Enabled = false;
            this.commandBarItem10.Id = 10;
            this.commandBarItem10.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N));
            this.commandBarItem10.Name = "commandBarItem10";
            superToolTip12.FixedTooltipWidth = true;
            toolTipTitleItem12.Text = "New Blank Report (Ctrl+N)";
            toolTipItem12.LeftIndent = 6;
            toolTipItem12.Text = "Create a new blank report.";
            superToolTip12.Items.Add(toolTipTitleItem12);
            superToolTip12.Items.Add(toolTipItem12);
            superToolTip12.MaxWidth = 210;
            this.commandBarItem10.SuperTip = superToolTip12;
            // 
            // commandBarItem11
            // 
            this.commandBarItem11.Caption = "New Report via Wizard...";
            this.commandBarItem11.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReportWizard;
            this.commandBarItem11.Description = "Launch the report wizard to create a new report.";
            this.commandBarItem11.Enabled = false;
            this.commandBarItem11.Id = 11;
            this.commandBarItem11.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W));
            this.commandBarItem11.Name = "commandBarItem11";
            superToolTip13.FixedTooltipWidth = true;
            toolTipTitleItem13.Text = "New Report via Wizard (Ctrl+W)";
            toolTipItem13.LeftIndent = 6;
            toolTipItem13.Text = "Launch the report wizard to create a new report.";
            superToolTip13.Items.Add(toolTipTitleItem13);
            superToolTip13.Items.Add(toolTipItem13);
            superToolTip13.MaxWidth = 210;
            this.commandBarItem11.SuperTip = superToolTip13;
            // 
            // commandBarItem12
            // 
            this.commandBarItem12.Caption = "Save";
            this.commandBarItem12.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFile;
            this.commandBarItem12.Description = "Save the current report.";
            this.commandBarItem12.Enabled = false;
            this.commandBarItem12.Id = 12;
            this.commandBarItem12.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S));
            this.commandBarItem12.Name = "commandBarItem12";
            superToolTip14.FixedTooltipWidth = true;
            toolTipTitleItem14.Text = "Save Report (Ctrl+S)";
            toolTipItem14.LeftIndent = 6;
            toolTipItem14.Text = "Save the current report.";
            superToolTip14.Items.Add(toolTipTitleItem14);
            superToolTip14.Items.Add(toolTipItem14);
            superToolTip14.MaxWidth = 210;
            this.commandBarItem12.SuperTip = superToolTip14;
            // 
            // commandBarItem13
            // 
            this.commandBarItem13.Caption = "Save As...";
            this.commandBarItem13.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFileAs;
            this.commandBarItem13.Description = "Save the current report with a new name.";
            this.commandBarItem13.Enabled = false;
            this.commandBarItem13.Id = 13;
            this.commandBarItem13.Name = "commandBarItem13";
            superToolTip15.FixedTooltipWidth = true;
            toolTipTitleItem15.Text = "Save Report As";
            toolTipItem15.LeftIndent = 6;
            toolTipItem15.Text = "Save the current report with a new name.";
            superToolTip15.Items.Add(toolTipTitleItem15);
            superToolTip15.Items.Add(toolTipItem15);
            superToolTip15.MaxWidth = 210;
            this.commandBarItem13.SuperTip = superToolTip15;
            // 
            // commandBarItem14
            // 
            this.commandBarItem14.Caption = "Paste";
            this.commandBarItem14.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Paste;
            this.commandBarItem14.Enabled = false;
            this.commandBarItem14.Id = 14;
            this.commandBarItem14.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V));
            this.commandBarItem14.Name = "commandBarItem14";
            superToolTip16.FixedTooltipWidth = true;
            toolTipTitleItem16.Text = "Paste (Ctrl+V)";
            toolTipItem16.LeftIndent = 6;
            toolTipItem16.Text = "Paste the contents of the Clipboard.";
            superToolTip16.Items.Add(toolTipTitleItem16);
            superToolTip16.Items.Add(toolTipItem16);
            superToolTip16.MaxWidth = 210;
            this.commandBarItem14.SuperTip = superToolTip16;
            // 
            // commandBarItem15
            // 
            this.commandBarItem15.Caption = "Cut";
            this.commandBarItem15.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Cut;
            this.commandBarItem15.Enabled = false;
            this.commandBarItem15.Id = 15;
            this.commandBarItem15.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X));
            this.commandBarItem15.Name = "commandBarItem15";
            this.commandBarItem15.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip17.FixedTooltipWidth = true;
            toolTipTitleItem17.Text = "Cut (Ctrl+X)";
            toolTipItem17.LeftIndent = 6;
            toolTipItem17.Text = "Cut the selected controls from the report and put them on the Clipboard.";
            superToolTip17.Items.Add(toolTipTitleItem17);
            superToolTip17.Items.Add(toolTipItem17);
            superToolTip17.MaxWidth = 210;
            this.commandBarItem15.SuperTip = superToolTip17;
            // 
            // commandBarItem16
            // 
            this.commandBarItem16.Caption = "Copy";
            this.commandBarItem16.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Copy;
            this.commandBarItem16.Enabled = false;
            this.commandBarItem16.Id = 16;
            this.commandBarItem16.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C));
            this.commandBarItem16.Name = "commandBarItem16";
            this.commandBarItem16.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip18.FixedTooltipWidth = true;
            toolTipTitleItem18.Text = "Copy (Ctrl+C)";
            toolTipItem18.LeftIndent = 6;
            toolTipItem18.Text = "Copy the selected controls and put them on the Clipboard.";
            superToolTip18.Items.Add(toolTipTitleItem18);
            superToolTip18.Items.Add(toolTipItem18);
            superToolTip18.MaxWidth = 210;
            this.commandBarItem16.SuperTip = superToolTip18;
            // 
            // barEditItem1
            // 
            this.barEditItem1.Edit = this.recentlyUsedItemsComboBox1;
            this.barEditItem1.EditWidth = 140;
            this.barEditItem1.Id = 17;
            this.barEditItem1.Name = "barEditItem1";
            superToolTip19.FixedTooltipWidth = true;
            toolTipTitleItem19.Text = "Font";
            toolTipItem19.LeftIndent = 6;
            toolTipItem19.Text = "Change the font face.";
            superToolTip19.Items.Add(toolTipTitleItem19);
            superToolTip19.Items.Add(toolTipItem19);
            superToolTip19.MaxWidth = 210;
            this.barEditItem1.SuperTip = superToolTip19;
            // 
            // recentlyUsedItemsComboBox1
            // 
            this.recentlyUsedItemsComboBox1.AppearanceDropDown.Font = new System.Drawing.Font("Tahoma", 11.25F);
            this.recentlyUsedItemsComboBox1.AppearanceDropDown.Options.UseFont = true;
            this.recentlyUsedItemsComboBox1.AutoHeight = false;
            this.recentlyUsedItemsComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.recentlyUsedItemsComboBox1.Name = "recentlyUsedItemsComboBox1";
            // 
            // barEditItem2
            // 
            this.barEditItem2.Edit = this.designRepositoryItemComboBox1;
            this.barEditItem2.EditWidth = 55;
            this.barEditItem2.Id = 18;
            this.barEditItem2.Name = "barEditItem2";
            superToolTip20.FixedTooltipWidth = true;
            toolTipTitleItem20.Text = "Font Size";
            toolTipItem20.LeftIndent = 6;
            toolTipItem20.Text = "Change the font size.";
            superToolTip20.Items.Add(toolTipTitleItem20);
            superToolTip20.Items.Add(toolTipItem20);
            superToolTip20.MaxWidth = 210;
            this.barEditItem2.SuperTip = superToolTip20;
            // 
            // designRepositoryItemComboBox1
            // 
            this.designRepositoryItemComboBox1.AutoHeight = false;
            this.designRepositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.designRepositoryItemComboBox1.Name = "designRepositoryItemComboBox1";
            // 
            // barDockPanelsListItem1
            // 
            this.barDockPanelsListItem1.Caption = "Windows";
            this.barDockPanelsListItem1.DockManager = this.xrDesignDockManager1;
            this.barDockPanelsListItem1.Id = 19;
            this.barDockPanelsListItem1.Name = "barDockPanelsListItem1";
            this.barDockPanelsListItem1.ShowCustomizationItem = false;
            this.barDockPanelsListItem1.ShowDockPanels = true;
            this.barDockPanelsListItem1.ShowToolbars = false;
            superToolTip21.FixedTooltipWidth = true;
            toolTipTitleItem21.Text = "Show/Hide Windows";
            toolTipItem21.LeftIndent = 6;
            toolTipItem21.Text = "Change the visibility of dock panels that assist in report creation.";
            superToolTip21.Items.Add(toolTipTitleItem21);
            superToolTip21.Items.Add(toolTipItem21);
            superToolTip21.MaxWidth = 210;
            this.barDockPanelsListItem1.SuperTip = superToolTip21;
            // 
            // xrDesignDockManager1
            // 
            this.xrDesignDockManager1.AutoHideContainers.AddRange(new DevExpress.XtraBars.Docking.AutoHideContainer[] {
            this.hideContainerBottom});
            this.xrDesignDockManager1.Form = this;
            this.xrDesignDockManager1.HiddenPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.groupAndSortDockPanel1});
            this.xrDesignDockManager1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("xrDesignDockManager1.ImageStream")));
            this.xrDesignDockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.panelContainer1});
            this.xrDesignDockManager1.ToolboxState = DevExpress.XtraToolbox.ToolboxState.Normal;
            this.xrDesignDockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane",
            "DevExpress.XtraBars.TabFormControl",
            "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl",
            "DevExpress.XtraBars.ToolbarForm.ToolbarFormControl",
            "DevExpress.XtraReports.UserDesigner.XRToolBoxPanel"});
            // 
            // hideContainerBottom
            // 
            this.hideContainerBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.hideContainerBottom.Controls.Add(this.errorListDockPanel1);
            this.hideContainerBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.hideContainerBottom.Location = new System.Drawing.Point(0, 705);
            this.hideContainerBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.hideContainerBottom.Name = "hideContainerBottom";
            this.hideContainerBottom.Size = new System.Drawing.Size(1333, 33);
            // 
            // errorListDockPanel1
            // 
            this.errorListDockPanel1.Controls.Add(this.errorListDockPanel1_Container);
            this.errorListDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.errorListDockPanel1.ID = new System.Guid("5a9a01fd-6e95-4e81-a8c4-ac63153d7488");
            this.errorListDockPanel1.Location = new System.Drawing.Point(0, 274);
            this.errorListDockPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.errorListDockPanel1.Name = "errorListDockPanel1";
            this.errorListDockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.errorListDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.errorListDockPanel1.SavedIndex = 1;
            this.errorListDockPanel1.Size = new System.Drawing.Size(1090, 228);
            this.errorListDockPanel1.Text = "Scripts Errors";
            this.errorListDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            // 
            // errorListDockPanel1_Container
            // 
            this.errorListDockPanel1_Container.Location = new System.Drawing.Point(0, 34);
            this.errorListDockPanel1_Container.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.errorListDockPanel1_Container.Name = "errorListDockPanel1_Container";
            this.errorListDockPanel1_Container.Size = new System.Drawing.Size(1246, 223);
            this.errorListDockPanel1_Container.TabIndex = 0;
            // 
            // groupAndSortDockPanel1
            // 
            this.groupAndSortDockPanel1.Controls.Add(this.groupAndSortDockPanel1_Container);
            this.groupAndSortDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.groupAndSortDockPanel1.ID = new System.Guid("4bab159e-c495-4d67-87dc-f4e895da443e");
            this.groupAndSortDockPanel1.Location = new System.Drawing.Point(3, 36);
            this.groupAndSortDockPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupAndSortDockPanel1.Name = "groupAndSortDockPanel1";
            this.groupAndSortDockPanel1.OriginalSize = new System.Drawing.Size(452, 136);
            this.groupAndSortDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.groupAndSortDockPanel1.SavedIndex = 0;
            this.groupAndSortDockPanel1.SavedParent = this.errorListDockPanel1;
            this.groupAndSortDockPanel1.SavedTabbed = true;
            this.groupAndSortDockPanel1.Size = new System.Drawing.Size(549, 156);
            this.groupAndSortDockPanel1.Text = "Group and Sort";
            this.groupAndSortDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // groupAndSortDockPanel1_Container
            // 
            this.groupAndSortDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.groupAndSortDockPanel1_Container.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupAndSortDockPanel1_Container.Name = "groupAndSortDockPanel1_Container";
            this.groupAndSortDockPanel1_Container.Size = new System.Drawing.Size(549, 156);
            this.groupAndSortDockPanel1_Container.TabIndex = 0;
            // 
            // panelContainer1
            // 
            this.panelContainer1.Controls.Add(this.panelContainer2);
            this.panelContainer1.Controls.Add(this.panelContainer3);
            this.panelContainer1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.panelContainer1.ID = new System.Guid("00556c40-c9ae-4843-842a-01054847b003");
            this.panelContainer1.Location = new System.Drawing.Point(958, 198);
            this.panelContainer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelContainer1.Name = "panelContainer1";
            this.panelContainer1.OriginalSize = new System.Drawing.Size(375, 200);
            this.panelContainer1.Size = new System.Drawing.Size(375, 507);
            this.panelContainer1.Text = "panelContainer1";
            // 
            // panelContainer2
            // 
            this.panelContainer2.ActiveChild = this.reportExplorerDockPanel1;
            this.panelContainer2.Controls.Add(this.reportExplorerDockPanel1);
            this.panelContainer2.Controls.Add(this.fieldListDockPanel1);
            this.panelContainer2.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.panelContainer2.ID = new System.Guid("1a53b32c-b6a6-448d-b2f2-28bd394f17a9");
            this.panelContainer2.Location = new System.Drawing.Point(0, 0);
            this.panelContainer2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelContainer2.Name = "panelContainer2";
            this.panelContainer2.OriginalSize = new System.Drawing.Size(328, 150);
            this.panelContainer2.Size = new System.Drawing.Size(375, 256);
            this.panelContainer2.Tabbed = true;
            this.panelContainer2.Text = "panelContainer2";
            // 
            // reportExplorerDockPanel1
            // 
            this.reportExplorerDockPanel1.Controls.Add(this.reportExplorerDockPanel1_Container);
            this.reportExplorerDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.reportExplorerDockPanel1.ID = new System.Guid("fb3ec6cc-3b9b-4b9c-91cf-cff78c1edbf1");
            this.reportExplorerDockPanel1.Location = new System.Drawing.Point(1, 33);
            this.reportExplorerDockPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.reportExplorerDockPanel1.Name = "reportExplorerDockPanel1";
            this.reportExplorerDockPanel1.OriginalSize = new System.Drawing.Size(327, 80);
            this.reportExplorerDockPanel1.Size = new System.Drawing.Size(374, 186);
            this.reportExplorerDockPanel1.Text = "Report Explorer";
            // 
            // reportExplorerDockPanel1_Container
            // 
            this.reportExplorerDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.reportExplorerDockPanel1_Container.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.reportExplorerDockPanel1_Container.Name = "reportExplorerDockPanel1_Container";
            this.reportExplorerDockPanel1_Container.Size = new System.Drawing.Size(374, 186);
            this.reportExplorerDockPanel1_Container.TabIndex = 0;
            // 
            // fieldListDockPanel1
            // 
            this.fieldListDockPanel1.Controls.Add(this.fieldListDockPanel1_Container);
            this.fieldListDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.fieldListDockPanel1.ID = new System.Guid("faf69838-a93f-4114-83e8-d0d09cc5ce95");
            this.fieldListDockPanel1.Location = new System.Drawing.Point(1, 33);
            this.fieldListDockPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fieldListDockPanel1.Name = "fieldListDockPanel1";
            this.fieldListDockPanel1.OriginalSize = new System.Drawing.Size(327, 80);
            this.fieldListDockPanel1.Size = new System.Drawing.Size(374, 186);
            this.fieldListDockPanel1.Text = "Field List";
            // 
            // fieldListDockPanel1_Container
            // 
            this.fieldListDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.fieldListDockPanel1_Container.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.fieldListDockPanel1_Container.Name = "fieldListDockPanel1_Container";
            this.fieldListDockPanel1_Container.Size = new System.Drawing.Size(374, 186);
            this.fieldListDockPanel1_Container.TabIndex = 0;
            // 
            // panelContainer3
            // 
            this.panelContainer3.ActiveChild = this.propertyGridDockPanel1;
            this.panelContainer3.Controls.Add(this.propertyGridDockPanel1);
            this.panelContainer3.Controls.Add(this.reportGalleryDockPanel1);
            this.panelContainer3.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.panelContainer3.ID = new System.Guid("b28bd0dc-cf80-4ba4-a719-73bfcd1e59fa");
            this.panelContainer3.Location = new System.Drawing.Point(0, 256);
            this.panelContainer3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelContainer3.Name = "panelContainer3";
            this.panelContainer3.OriginalSize = new System.Drawing.Size(328, 147);
            this.panelContainer3.Size = new System.Drawing.Size(375, 251);
            this.panelContainer3.Tabbed = true;
            this.panelContainer3.Text = "panelContainer3";
            // 
            // propertyGridDockPanel1
            // 
            this.propertyGridDockPanel1.Controls.Add(this.propertyGridDockPanel1_Container);
            this.propertyGridDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.propertyGridDockPanel1.ID = new System.Guid("b38d12c3-cd06-4dec-b93d-63a0088e495a");
            this.propertyGridDockPanel1.Location = new System.Drawing.Point(1, 34);
            this.propertyGridDockPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.propertyGridDockPanel1.Name = "propertyGridDockPanel1";
            this.propertyGridDockPanel1.OriginalSize = new System.Drawing.Size(327, 76);
            this.propertyGridDockPanel1.Size = new System.Drawing.Size(374, 180);
            this.propertyGridDockPanel1.Text = "Properties";
            this.propertyGridDockPanel1.UseOfficeInspiredView = false;
            // 
            // propertyGridDockPanel1_Container
            // 
            this.propertyGridDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.propertyGridDockPanel1_Container.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.propertyGridDockPanel1_Container.Name = "propertyGridDockPanel1_Container";
            this.propertyGridDockPanel1_Container.Size = new System.Drawing.Size(374, 180);
            this.propertyGridDockPanel1_Container.TabIndex = 0;
            // 
            // reportGalleryDockPanel1
            // 
            this.reportGalleryDockPanel1.Controls.Add(this.reportGalleryDockPanel1_Container);
            this.reportGalleryDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.reportGalleryDockPanel1.ID = new System.Guid("7cd5b1e8-63bb-46f7-af65-af61eb851a38");
            this.reportGalleryDockPanel1.Location = new System.Drawing.Point(1, 34);
            this.reportGalleryDockPanel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.reportGalleryDockPanel1.Name = "reportGalleryDockPanel1";
            this.reportGalleryDockPanel1.OriginalSize = new System.Drawing.Size(327, 76);
            this.reportGalleryDockPanel1.Size = new System.Drawing.Size(374, 180);
            this.reportGalleryDockPanel1.Text = "Report Gallery";
            // 
            // reportGalleryDockPanel1_Container
            // 
            this.reportGalleryDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.reportGalleryDockPanel1_Container.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.reportGalleryDockPanel1_Container.Name = "reportGalleryDockPanel1_Container";
            this.reportGalleryDockPanel1_Container.Size = new System.Drawing.Size(374, 180);
            this.reportGalleryDockPanel1_Container.TabIndex = 0;
            // 
            // commandBarItem17
            // 
            this.commandBarItem17.Caption = "Bold";
            this.commandBarItem17.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontBold;
            this.commandBarItem17.Enabled = false;
            this.commandBarItem17.Id = 20;
            this.commandBarItem17.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B));
            this.commandBarItem17.Name = "commandBarItem17";
            superToolTip22.FixedTooltipWidth = true;
            toolTipTitleItem22.Text = "Bold (Ctrl+B)";
            toolTipItem22.LeftIndent = 6;
            toolTipItem22.Text = "Make the selected text bold.";
            superToolTip22.Items.Add(toolTipTitleItem22);
            superToolTip22.Items.Add(toolTipItem22);
            superToolTip22.MaxWidth = 210;
            this.commandBarItem17.SuperTip = superToolTip22;
            // 
            // commandBarItem18
            // 
            this.commandBarItem18.Caption = "Italic";
            this.commandBarItem18.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontItalic;
            this.commandBarItem18.Enabled = false;
            this.commandBarItem18.Id = 21;
            this.commandBarItem18.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I));
            this.commandBarItem18.Name = "commandBarItem18";
            superToolTip23.FixedTooltipWidth = true;
            toolTipTitleItem23.Text = "Italic (Ctrl+I)";
            toolTipItem23.LeftIndent = 6;
            toolTipItem23.Text = "Italicize the text.";
            superToolTip23.Items.Add(toolTipTitleItem23);
            superToolTip23.Items.Add(toolTipItem23);
            superToolTip23.MaxWidth = 210;
            this.commandBarItem18.SuperTip = superToolTip23;
            // 
            // commandBarItem19
            // 
            this.commandBarItem19.Caption = "Underline";
            this.commandBarItem19.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontUnderline;
            this.commandBarItem19.Enabled = false;
            this.commandBarItem19.Id = 22;
            this.commandBarItem19.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U));
            this.commandBarItem19.Name = "commandBarItem19";
            superToolTip24.FixedTooltipWidth = true;
            toolTipTitleItem24.Text = "Underline (Ctrl+U)";
            toolTipItem24.LeftIndent = 6;
            toolTipItem24.Text = "Underline the selected text.";
            superToolTip24.Items.Add(toolTipTitleItem24);
            superToolTip24.Items.Add(toolTipItem24);
            superToolTip24.MaxWidth = 210;
            this.commandBarItem19.SuperTip = superToolTip24;
            // 
            // commandColorBarItem1
            // 
            this.commandColorBarItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandColorBarItem1.Caption = "Foreground Color";
            this.commandColorBarItem1.CloseSubMenuOnClickMode = DevExpress.Utils.DefaultBoolean.False;
            this.commandColorBarItem1.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ForeColor;
            this.commandColorBarItem1.Enabled = false;
            this.commandColorBarItem1.Id = 23;
            this.commandColorBarItem1.Name = "commandColorBarItem1";
            superToolTip25.FixedTooltipWidth = true;
            toolTipTitleItem25.Text = "Foreground Color";
            toolTipItem25.LeftIndent = 6;
            toolTipItem25.Text = "Change the text foreground color.";
            superToolTip25.Items.Add(toolTipTitleItem25);
            superToolTip25.Items.Add(toolTipItem25);
            superToolTip25.MaxWidth = 210;
            this.commandColorBarItem1.SuperTip = superToolTip25;
            // 
            // commandColorBarItem2
            // 
            this.commandColorBarItem2.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandColorBarItem2.Caption = "Background Color";
            this.commandColorBarItem2.CloseSubMenuOnClickMode = DevExpress.Utils.DefaultBoolean.False;
            this.commandColorBarItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BackColor;
            this.commandColorBarItem2.Enabled = false;
            this.commandColorBarItem2.Id = 24;
            this.commandColorBarItem2.Name = "commandColorBarItem2";
            superToolTip26.FixedTooltipWidth = true;
            toolTipTitleItem26.Text = "Background Color";
            toolTipItem26.LeftIndent = 6;
            toolTipItem26.Text = "Change the text background color.";
            superToolTip26.Items.Add(toolTipTitleItem26);
            superToolTip26.Items.Add(toolTipItem26);
            superToolTip26.MaxWidth = 210;
            this.commandColorBarItem2.SuperTip = superToolTip26;
            // 
            // commandBarItem20
            // 
            this.commandBarItem20.Caption = "Align Text Left";
            this.commandBarItem20.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyLeft;
            this.commandBarItem20.Enabled = false;
            this.commandBarItem20.Id = 25;
            this.commandBarItem20.Name = "commandBarItem20";
            superToolTip27.FixedTooltipWidth = true;
            toolTipTitleItem27.Text = "Align Text Left";
            toolTipItem27.LeftIndent = 6;
            toolTipItem27.Text = "Align text to the left.";
            superToolTip27.Items.Add(toolTipTitleItem27);
            superToolTip27.Items.Add(toolTipItem27);
            superToolTip27.MaxWidth = 210;
            this.commandBarItem20.SuperTip = superToolTip27;
            // 
            // commandBarItem21
            // 
            this.commandBarItem21.Caption = "Center Text";
            this.commandBarItem21.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyCenter;
            this.commandBarItem21.Enabled = false;
            this.commandBarItem21.Id = 26;
            this.commandBarItem21.Name = "commandBarItem21";
            superToolTip28.FixedTooltipWidth = true;
            toolTipTitleItem28.Text = "Center Text";
            toolTipItem28.LeftIndent = 6;
            toolTipItem28.Text = "Center text between the left and right sides.";
            superToolTip28.Items.Add(toolTipTitleItem28);
            superToolTip28.Items.Add(toolTipItem28);
            superToolTip28.MaxWidth = 210;
            this.commandBarItem21.SuperTip = superToolTip28;
            // 
            // commandBarItem22
            // 
            this.commandBarItem22.Caption = "Align Text Right";
            this.commandBarItem22.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyRight;
            this.commandBarItem22.Enabled = false;
            this.commandBarItem22.Id = 27;
            this.commandBarItem22.Name = "commandBarItem22";
            superToolTip29.FixedTooltipWidth = true;
            toolTipTitleItem29.Text = "Align Text Right";
            toolTipItem29.LeftIndent = 6;
            toolTipItem29.Text = "Align text to the right.";
            superToolTip29.Items.Add(toolTipTitleItem29);
            superToolTip29.Items.Add(toolTipItem29);
            superToolTip29.MaxWidth = 210;
            this.commandBarItem22.SuperTip = superToolTip29;
            // 
            // commandBarItem23
            // 
            this.commandBarItem23.Caption = "Justify";
            this.commandBarItem23.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyJustify;
            this.commandBarItem23.Enabled = false;
            this.commandBarItem23.Id = 28;
            this.commandBarItem23.Name = "commandBarItem23";
            superToolTip30.FixedTooltipWidth = true;
            toolTipTitleItem30.Text = "Justify";
            toolTipItem30.LeftIndent = 6;
            toolTipItem30.Text = "Distribute text evenly to the left and right sides.";
            superToolTip30.Items.Add(toolTipTitleItem30);
            superToolTip30.Items.Add(toolTipItem30);
            superToolTip30.MaxWidth = 210;
            this.commandBarItem23.SuperTip = superToolTip30;
            // 
            // commandBarItem24
            // 
            this.commandBarItem24.Caption = "Strikethrough";
            this.commandBarItem24.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontStrikeout;
            this.commandBarItem24.Enabled = false;
            this.commandBarItem24.Id = 29;
            this.commandBarItem24.Name = "commandBarItem24";
            superToolTip31.FixedTooltipWidth = true;
            toolTipTitleItem31.Text = "Strikethrough";
            toolTipItem31.LeftIndent = 6;
            toolTipItem31.Text = "Cross the selected text out by drawing a line through it.";
            superToolTip31.Items.Add(toolTipTitleItem31);
            superToolTip31.Items.Add(toolTipItem31);
            superToolTip31.MaxWidth = 210;
            this.commandBarItem24.SuperTip = superToolTip31;
            // 
            // commandBarItem25
            // 
            this.commandBarItem25.Caption = "Align Text Top";
            this.commandBarItem25.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertAlignTop;
            this.commandBarItem25.Enabled = false;
            this.commandBarItem25.Id = 30;
            this.commandBarItem25.Name = "commandBarItem25";
            superToolTip32.FixedTooltipWidth = true;
            toolTipTitleItem32.Text = "Align Text Top";
            toolTipItem32.LeftIndent = 6;
            toolTipItem32.Text = "Align text to the top.";
            superToolTip32.Items.Add(toolTipTitleItem32);
            superToolTip32.Items.Add(toolTipItem32);
            superToolTip32.MaxWidth = 210;
            this.commandBarItem25.SuperTip = superToolTip32;
            // 
            // commandBarItem26
            // 
            this.commandBarItem26.Caption = "Align Text Middle";
            this.commandBarItem26.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertAlignMiddle;
            this.commandBarItem26.Enabled = false;
            this.commandBarItem26.Id = 31;
            this.commandBarItem26.Name = "commandBarItem26";
            superToolTip33.FixedTooltipWidth = true;
            toolTipTitleItem33.Text = "Align Text Middle";
            toolTipItem33.LeftIndent = 6;
            toolTipItem33.Text = "Center text between the top and bottom.";
            superToolTip33.Items.Add(toolTipTitleItem33);
            superToolTip33.Items.Add(toolTipItem33);
            superToolTip33.MaxWidth = 210;
            this.commandBarItem26.SuperTip = superToolTip33;
            // 
            // commandBarItem27
            // 
            this.commandBarItem27.Caption = "Align Text Bottom";
            this.commandBarItem27.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertAlignBottom;
            this.commandBarItem27.Enabled = false;
            this.commandBarItem27.Id = 32;
            this.commandBarItem27.Name = "commandBarItem27";
            superToolTip34.FixedTooltipWidth = true;
            toolTipTitleItem34.Text = "Align Text Bottom";
            toolTipItem34.LeftIndent = 6;
            toolTipItem34.Text = "Align text to the bottom.";
            superToolTip34.Items.Add(toolTipTitleItem34);
            superToolTip34.Items.Add(toolTipItem34);
            superToolTip34.MaxWidth = 210;
            this.commandBarItem27.SuperTip = superToolTip34;
            // 
            // commandBarItem28
            // 
            this.commandBarItem28.Caption = "Add Calculated Field";
            this.commandBarItem28.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AddCalculatedField;
            this.commandBarItem28.Enabled = false;
            this.commandBarItem28.Id = 33;
            this.commandBarItem28.Name = "commandBarItem28";
            this.commandBarItem28.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip35.FixedTooltipWidth = true;
            toolTipTitleItem35.Text = "Add Calculated Field";
            toolTipItem35.LeftIndent = 6;
            toolTipItem35.Text = "Create a custom field whose value is evaluated using an expression based on avail" +
    "able data fields.";
            superToolTip35.Items.Add(toolTipTitleItem35);
            superToolTip35.Items.Add(toolTipItem35);
            superToolTip35.MaxWidth = 210;
            this.commandBarItem28.SuperTip = superToolTip35;
            // 
            // commandBarItem29
            // 
            this.commandBarItem29.Caption = "Add Parameter";
            this.commandBarItem29.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AddParameter;
            this.commandBarItem29.Enabled = false;
            this.commandBarItem29.Id = 34;
            this.commandBarItem29.Name = "commandBarItem29";
            this.commandBarItem29.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip36.FixedTooltipWidth = true;
            toolTipTitleItem36.Text = "Add Parameter";
            toolTipItem36.LeftIndent = 6;
            toolTipItem36.Text = "Create a new parameter to pass dynamic values to your report.";
            superToolTip36.Items.Add(toolTipTitleItem36);
            superToolTip36.Items.Add(toolTipItem36);
            superToolTip36.MaxWidth = 210;
            this.commandBarItem29.SuperTip = superToolTip36;
            // 
            // commandBarItem30
            // 
            this.commandBarItem30.Caption = "Add Data Source";
            this.commandBarItem30.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AddNewDataSource;
            this.commandBarItem30.Enabled = false;
            this.commandBarItem30.Id = 35;
            this.commandBarItem30.Name = "commandBarItem30";
            superToolTip37.FixedTooltipWidth = true;
            toolTipTitleItem37.Text = "Add Data Source";
            toolTipItem37.LeftIndent = 6;
            toolTipItem37.Text = "Create and set up a new data source for your report.";
            superToolTip37.Items.Add(toolTipTitleItem37);
            superToolTip37.Items.Add(toolTipItem37);
            superToolTip37.MaxWidth = 210;
            this.commandBarItem30.SuperTip = superToolTip37;
            // 
            // commandBarItem31
            // 
            this.commandBarItem31.Caption = "Extract Style";
            this.commandBarItem31.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ExtractStyle;
            this.commandBarItem31.Enabled = false;
            this.commandBarItem31.Id = 36;
            this.commandBarItem31.Name = "commandBarItem31";
            superToolTip38.FixedTooltipWidth = true;
            toolTipTitleItem38.Text = "Extract Style";
            toolTipItem38.LeftIndent = 6;
            toolTipItem38.Text = "Create a new style based on the selected control\'s appearance settings. Apply the" +
    " created style from the Styles gallery to other controls in your report.";
            superToolTip38.Items.Add(toolTipTitleItem38);
            superToolTip38.Items.Add(toolTipItem38);
            superToolTip38.MaxWidth = 210;
            this.commandBarItem31.SuperTip = superToolTip38;
            // 
            // commandBarItem32
            // 
            this.commandBarItem32.Caption = "All Borders";
            this.commandBarItem32.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BordersAll;
            this.commandBarItem32.Enabled = false;
            this.commandBarItem32.Id = 37;
            this.commandBarItem32.Name = "commandBarItem32";
            superToolTip39.FixedTooltipWidth = true;
            toolTipTitleItem39.Text = "All Borders";
            toolTipItem39.LeftIndent = 6;
            toolTipItem39.Text = "Add all borders to the selected controls.";
            superToolTip39.Items.Add(toolTipTitleItem39);
            superToolTip39.Items.Add(toolTipItem39);
            superToolTip39.MaxWidth = 210;
            this.commandBarItem32.SuperTip = superToolTip39;
            // 
            // commandBarItem33
            // 
            this.commandBarItem33.Caption = "No Border";
            this.commandBarItem33.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BordersNone;
            this.commandBarItem33.Enabled = false;
            this.commandBarItem33.Id = 38;
            this.commandBarItem33.Name = "commandBarItem33";
            superToolTip40.FixedTooltipWidth = true;
            toolTipTitleItem40.Text = "No Border";
            toolTipItem40.LeftIndent = 6;
            toolTipItem40.Text = "Remove borders from the selected controls.";
            superToolTip40.Items.Add(toolTipTitleItem40);
            superToolTip40.Items.Add(toolTipItem40);
            superToolTip40.MaxWidth = 210;
            this.commandBarItem33.SuperTip = superToolTip40;
            // 
            // commandBarItem34
            // 
            this.commandBarItem34.Caption = "Left Border";
            this.commandBarItem34.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BorderLeft;
            this.commandBarItem34.Enabled = false;
            this.commandBarItem34.Id = 39;
            this.commandBarItem34.Name = "commandBarItem34";
            superToolTip41.FixedTooltipWidth = true;
            toolTipTitleItem41.Text = "Left Border";
            toolTipItem41.LeftIndent = 6;
            toolTipItem41.Text = "Add the left border to the selected controls.";
            superToolTip41.Items.Add(toolTipTitleItem41);
            superToolTip41.Items.Add(toolTipItem41);
            superToolTip41.MaxWidth = 210;
            this.commandBarItem34.SuperTip = superToolTip41;
            // 
            // commandBarItem35
            // 
            this.commandBarItem35.Caption = "Top Border";
            this.commandBarItem35.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BorderTop;
            this.commandBarItem35.Enabled = false;
            this.commandBarItem35.Id = 40;
            this.commandBarItem35.Name = "commandBarItem35";
            superToolTip42.FixedTooltipWidth = true;
            toolTipTitleItem42.Text = "Top Border";
            toolTipItem42.LeftIndent = 6;
            toolTipItem42.Text = "Add the top border to the selected controls.";
            superToolTip42.Items.Add(toolTipTitleItem42);
            superToolTip42.Items.Add(toolTipItem42);
            superToolTip42.MaxWidth = 210;
            this.commandBarItem35.SuperTip = superToolTip42;
            // 
            // commandBarItem36
            // 
            this.commandBarItem36.Caption = "Right Border";
            this.commandBarItem36.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BorderRight;
            this.commandBarItem36.Enabled = false;
            this.commandBarItem36.Id = 41;
            this.commandBarItem36.Name = "commandBarItem36";
            superToolTip43.FixedTooltipWidth = true;
            toolTipTitleItem43.Text = "Right Border";
            toolTipItem43.LeftIndent = 6;
            toolTipItem43.Text = "Add the right border to the selected controls.";
            superToolTip43.Items.Add(toolTipTitleItem43);
            superToolTip43.Items.Add(toolTipItem43);
            superToolTip43.MaxWidth = 210;
            this.commandBarItem36.SuperTip = superToolTip43;
            // 
            // commandBarItem37
            // 
            this.commandBarItem37.Caption = "Bottom Border";
            this.commandBarItem37.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BorderBottom;
            this.commandBarItem37.Enabled = false;
            this.commandBarItem37.Id = 42;
            this.commandBarItem37.Name = "commandBarItem37";
            superToolTip44.FixedTooltipWidth = true;
            toolTipTitleItem44.Text = "Bottom Border";
            toolTipItem44.LeftIndent = 6;
            toolTipItem44.Text = "Add the bottom border to the selected controls.";
            superToolTip44.Items.Add(toolTipTitleItem44);
            superToolTip44.Items.Add(toolTipItem44);
            superToolTip44.MaxWidth = 210;
            this.commandBarItem37.SuperTip = superToolTip44;
            // 
            // commandColorBarItem3
            // 
            this.commandColorBarItem3.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandColorBarItem3.Caption = "Border Color";
            this.commandColorBarItem3.CloseSubMenuOnClickMode = DevExpress.Utils.DefaultBoolean.False;
            this.commandColorBarItem3.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BorderColor;
            this.commandColorBarItem3.Enabled = false;
            this.commandColorBarItem3.Id = 43;
            this.commandColorBarItem3.Name = "commandColorBarItem3";
            superToolTip45.FixedTooltipWidth = true;
            toolTipTitleItem45.Text = "Border Color";
            toolTipItem45.LeftIndent = 6;
            toolTipItem45.Text = "Change the border color.";
            superToolTip45.Items.Add(toolTipTitleItem45);
            superToolTip45.Items.Add(toolTipItem45);
            superToolTip45.MaxWidth = 210;
            this.commandColorBarItem3.SuperTip = superToolTip45;
            // 
            // commandBarItem38
            // 
            this.commandBarItem38.ActAsDropDown = true;
            this.commandBarItem38.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem38.Caption = "Border Width";
            this.commandBarItem38.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BorderWidth;
            this.commandBarItem38.Enabled = false;
            this.commandBarItem38.Id = 44;
            this.commandBarItem38.Name = "commandBarItem38";
            superToolTip46.FixedTooltipWidth = true;
            toolTipTitleItem46.Text = "Border Width";
            toolTipItem46.LeftIndent = 6;
            toolTipItem46.Text = "Change the border width.";
            superToolTip46.Items.Add(toolTipTitleItem46);
            superToolTip46.Items.Add(toolTipItem46);
            superToolTip46.MaxWidth = 210;
            this.commandBarItem38.SuperTip = superToolTip46;
            // 
            // commandBarItem39
            // 
            this.commandBarItem39.Caption = "Align to Grid";
            this.commandBarItem39.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignToGrid;
            this.commandBarItem39.Enabled = false;
            this.commandBarItem39.Id = 45;
            this.commandBarItem39.Name = "commandBarItem39";
            superToolTip47.FixedTooltipWidth = true;
            toolTipTitleItem47.Text = "Align to Grid";
            toolTipItem47.LeftIndent = 6;
            toolTipItem47.Text = "Align the positions of the selected controls to the grid.";
            superToolTip47.Items.Add(toolTipTitleItem47);
            superToolTip47.Items.Add(toolTipItem47);
            superToolTip47.MaxWidth = 210;
            this.commandBarItem39.SuperTip = superToolTip47;
            // 
            // commandBarItem40
            // 
            this.commandBarItem40.Caption = "Align Lefts";
            this.commandBarItem40.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignLeft;
            this.commandBarItem40.Enabled = false;
            this.commandBarItem40.Id = 46;
            this.commandBarItem40.Name = "commandBarItem40";
            superToolTip48.FixedTooltipWidth = true;
            toolTipTitleItem48.Text = "Align Lefts";
            toolTipItem48.LeftIndent = 6;
            toolTipItem48.Text = "Left align the selected controls.";
            superToolTip48.Items.Add(toolTipTitleItem48);
            superToolTip48.Items.Add(toolTipItem48);
            superToolTip48.MaxWidth = 210;
            this.commandBarItem40.SuperTip = superToolTip48;
            // 
            // commandBarItem41
            // 
            this.commandBarItem41.Caption = "Align Centers";
            this.commandBarItem41.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignVerticalCenters;
            this.commandBarItem41.Enabled = false;
            this.commandBarItem41.Id = 47;
            this.commandBarItem41.Name = "commandBarItem41";
            superToolTip49.FixedTooltipWidth = true;
            toolTipTitleItem49.Text = "Align Centers";
            toolTipItem49.LeftIndent = 6;
            toolTipItem49.Text = "Align the centers of the selected controls vertically.";
            superToolTip49.Items.Add(toolTipTitleItem49);
            superToolTip49.Items.Add(toolTipItem49);
            superToolTip49.MaxWidth = 210;
            this.commandBarItem41.SuperTip = superToolTip49;
            // 
            // commandBarItem42
            // 
            this.commandBarItem42.Caption = "Align Rights";
            this.commandBarItem42.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignRight;
            this.commandBarItem42.Enabled = false;
            this.commandBarItem42.Id = 48;
            this.commandBarItem42.Name = "commandBarItem42";
            superToolTip50.FixedTooltipWidth = true;
            toolTipTitleItem50.Text = "Align Rights";
            toolTipItem50.LeftIndent = 6;
            toolTipItem50.Text = "Right align the selected controls.";
            superToolTip50.Items.Add(toolTipTitleItem50);
            superToolTip50.Items.Add(toolTipItem50);
            superToolTip50.MaxWidth = 210;
            this.commandBarItem42.SuperTip = superToolTip50;
            // 
            // commandBarItem43
            // 
            this.commandBarItem43.Caption = "Align Tops";
            this.commandBarItem43.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignTop;
            this.commandBarItem43.Enabled = false;
            this.commandBarItem43.Id = 49;
            this.commandBarItem43.Name = "commandBarItem43";
            superToolTip51.FixedTooltipWidth = true;
            toolTipTitleItem51.Text = "Align Tops";
            toolTipItem51.LeftIndent = 6;
            toolTipItem51.Text = "Align the tops of the selected controls.";
            superToolTip51.Items.Add(toolTipTitleItem51);
            superToolTip51.Items.Add(toolTipItem51);
            superToolTip51.MaxWidth = 210;
            this.commandBarItem43.SuperTip = superToolTip51;
            // 
            // commandBarItem44
            // 
            this.commandBarItem44.Caption = "Align Middles";
            this.commandBarItem44.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignHorizontalCenters;
            this.commandBarItem44.Enabled = false;
            this.commandBarItem44.Id = 50;
            this.commandBarItem44.Name = "commandBarItem44";
            superToolTip52.FixedTooltipWidth = true;
            toolTipTitleItem52.Text = "Align Middles";
            toolTipItem52.LeftIndent = 6;
            toolTipItem52.Text = "Align the centers of the selected controls horizontally.";
            superToolTip52.Items.Add(toolTipTitleItem52);
            superToolTip52.Items.Add(toolTipItem52);
            superToolTip52.MaxWidth = 210;
            this.commandBarItem44.SuperTip = superToolTip52;
            // 
            // commandBarItem45
            // 
            this.commandBarItem45.Caption = "Align Bottoms";
            this.commandBarItem45.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignBottom;
            this.commandBarItem45.Enabled = false;
            this.commandBarItem45.Id = 51;
            this.commandBarItem45.Name = "commandBarItem45";
            superToolTip53.FixedTooltipWidth = true;
            toolTipTitleItem53.Text = "Align Bottoms";
            toolTipItem53.LeftIndent = 6;
            toolTipItem53.Text = "Align the bottoms of the selected controls.";
            superToolTip53.Items.Add(toolTipTitleItem53);
            superToolTip53.Items.Add(toolTipItem53);
            superToolTip53.MaxWidth = 210;
            this.commandBarItem45.SuperTip = superToolTip53;
            // 
            // commandBarItem46
            // 
            this.commandBarItem46.Caption = "Make Same Width";
            this.commandBarItem46.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControlWidth;
            this.commandBarItem46.Enabled = false;
            this.commandBarItem46.Id = 52;
            this.commandBarItem46.Name = "commandBarItem46";
            superToolTip54.FixedTooltipWidth = true;
            toolTipTitleItem54.Text = "Make Same Width";
            toolTipItem54.LeftIndent = 6;
            toolTipItem54.Text = "Make the selected controls have the same width.";
            superToolTip54.Items.Add(toolTipTitleItem54);
            superToolTip54.Items.Add(toolTipItem54);
            superToolTip54.MaxWidth = 210;
            this.commandBarItem46.SuperTip = superToolTip54;
            // 
            // commandBarItem47
            // 
            this.commandBarItem47.Caption = "Fit Bounds to Grid";
            this.commandBarItem47.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToGrid;
            this.commandBarItem47.Enabled = false;
            this.commandBarItem47.Id = 53;
            this.commandBarItem47.Name = "commandBarItem47";
            superToolTip55.FixedTooltipWidth = true;
            toolTipTitleItem55.Text = "Size to Grid";
            toolTipItem55.LeftIndent = 6;
            toolTipItem55.Text = "Adjust the size of the selected controls according to the grid size.";
            superToolTip55.Items.Add(toolTipTitleItem55);
            superToolTip55.Items.Add(toolTipItem55);
            superToolTip55.MaxWidth = 210;
            this.commandBarItem47.SuperTip = superToolTip55;
            // 
            // commandBarItem48
            // 
            this.commandBarItem48.Caption = "Make Same Height";
            this.commandBarItem48.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControlHeight;
            this.commandBarItem48.Enabled = false;
            this.commandBarItem48.Id = 54;
            this.commandBarItem48.Name = "commandBarItem48";
            superToolTip56.FixedTooltipWidth = true;
            toolTipTitleItem56.Text = "Make Same Height";
            toolTipItem56.LeftIndent = 6;
            toolTipItem56.Text = "Make the selected controls have the same height.";
            superToolTip56.Items.Add(toolTipTitleItem56);
            superToolTip56.Items.Add(toolTipItem56);
            superToolTip56.MaxWidth = 210;
            this.commandBarItem48.SuperTip = superToolTip56;
            // 
            // commandBarItem49
            // 
            this.commandBarItem49.Caption = "Make Same Size";
            this.commandBarItem49.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControl;
            this.commandBarItem49.Enabled = false;
            this.commandBarItem49.Id = 55;
            this.commandBarItem49.Name = "commandBarItem49";
            superToolTip57.FixedTooltipWidth = true;
            toolTipTitleItem57.Text = "Make Same Size";
            toolTipItem57.LeftIndent = 6;
            toolTipItem57.Text = "Make the selected controls have the same size.";
            superToolTip57.Items.Add(toolTipTitleItem57);
            superToolTip57.Items.Add(toolTipItem57);
            superToolTip57.MaxWidth = 210;
            this.commandBarItem49.SuperTip = superToolTip57;
            // 
            // commandBarItem50
            // 
            this.commandBarItem50.Caption = "Make Horizontal Spacing Equal";
            this.commandBarItem50.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceMakeEqual;
            this.commandBarItem50.Enabled = false;
            this.commandBarItem50.Id = 56;
            this.commandBarItem50.Name = "commandBarItem50";
            superToolTip58.FixedTooltipWidth = true;
            toolTipTitleItem58.Text = "Make Horizontal Spacing Equal";
            toolTipItem58.LeftIndent = 6;
            toolTipItem58.Text = "Make the horizontal spacing between the selected controls equal.";
            superToolTip58.Items.Add(toolTipTitleItem58);
            superToolTip58.Items.Add(toolTipItem58);
            superToolTip58.MaxWidth = 210;
            this.commandBarItem50.SuperTip = superToolTip58;
            // 
            // commandBarItem51
            // 
            this.commandBarItem51.Caption = "Increase Horizontal Spacing";
            this.commandBarItem51.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceIncrease;
            this.commandBarItem51.Enabled = false;
            this.commandBarItem51.Id = 57;
            this.commandBarItem51.Name = "commandBarItem51";
            superToolTip59.FixedTooltipWidth = true;
            toolTipTitleItem59.Text = "Increase Horizontal Spacing";
            toolTipItem59.LeftIndent = 6;
            toolTipItem59.Text = "Increase the horizontal spacing between the selected controls.";
            superToolTip59.Items.Add(toolTipTitleItem59);
            superToolTip59.Items.Add(toolTipItem59);
            superToolTip59.MaxWidth = 210;
            this.commandBarItem51.SuperTip = superToolTip59;
            // 
            // commandBarItem52
            // 
            this.commandBarItem52.Caption = "Decrease Horizontal Spacing";
            this.commandBarItem52.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceDecrease;
            this.commandBarItem52.Enabled = false;
            this.commandBarItem52.Id = 58;
            this.commandBarItem52.Name = "commandBarItem52";
            superToolTip60.FixedTooltipWidth = true;
            toolTipTitleItem60.Text = "Decrease Horizontal Spacing";
            toolTipItem60.LeftIndent = 6;
            toolTipItem60.Text = "Decrease the horizontal spacing between the selected controls.";
            superToolTip60.Items.Add(toolTipTitleItem60);
            superToolTip60.Items.Add(toolTipItem60);
            superToolTip60.MaxWidth = 210;
            this.commandBarItem52.SuperTip = superToolTip60;
            // 
            // commandBarItem53
            // 
            this.commandBarItem53.Caption = "Remove Horizontal Spacing";
            this.commandBarItem53.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceConcatenate;
            this.commandBarItem53.Enabled = false;
            this.commandBarItem53.Id = 59;
            this.commandBarItem53.Name = "commandBarItem53";
            superToolTip61.FixedTooltipWidth = true;
            toolTipTitleItem61.Text = "Remove Horizontal Spacing";
            toolTipItem61.LeftIndent = 6;
            toolTipItem61.Text = "Remove the horizontal spacing between the selected controls.";
            superToolTip61.Items.Add(toolTipTitleItem61);
            superToolTip61.Items.Add(toolTipItem61);
            superToolTip61.MaxWidth = 210;
            this.commandBarItem53.SuperTip = superToolTip61;
            // 
            // commandBarItem54
            // 
            this.commandBarItem54.Caption = "Make Vertical Spacing Equal";
            this.commandBarItem54.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceMakeEqual;
            this.commandBarItem54.Enabled = false;
            this.commandBarItem54.Id = 60;
            this.commandBarItem54.Name = "commandBarItem54";
            superToolTip62.FixedTooltipWidth = true;
            toolTipTitleItem62.Text = "Make Vertical Spacing Equal";
            toolTipItem62.LeftIndent = 6;
            toolTipItem62.Text = "Make the vertical spacing between the selected controls equal.";
            superToolTip62.Items.Add(toolTipTitleItem62);
            superToolTip62.Items.Add(toolTipItem62);
            superToolTip62.MaxWidth = 210;
            this.commandBarItem54.SuperTip = superToolTip62;
            // 
            // commandBarItem55
            // 
            this.commandBarItem55.Caption = "Increase Vertical Spacing";
            this.commandBarItem55.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceIncrease;
            this.commandBarItem55.Enabled = false;
            this.commandBarItem55.Id = 61;
            this.commandBarItem55.Name = "commandBarItem55";
            superToolTip63.FixedTooltipWidth = true;
            toolTipTitleItem63.Text = "Increase Vertical Spacing";
            toolTipItem63.LeftIndent = 6;
            toolTipItem63.Text = "Increase the vertical spacing between the selected controls.";
            superToolTip63.Items.Add(toolTipTitleItem63);
            superToolTip63.Items.Add(toolTipItem63);
            superToolTip63.MaxWidth = 210;
            this.commandBarItem55.SuperTip = superToolTip63;
            // 
            // commandBarItem56
            // 
            this.commandBarItem56.Caption = "Decrease Vertical Spacing";
            this.commandBarItem56.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceDecrease;
            this.commandBarItem56.Enabled = false;
            this.commandBarItem56.Id = 62;
            this.commandBarItem56.Name = "commandBarItem56";
            superToolTip64.FixedTooltipWidth = true;
            toolTipTitleItem64.Text = "Decrease Vertical Spacing";
            toolTipItem64.LeftIndent = 6;
            toolTipItem64.Text = "Decrease the vertical spacing between the selected controls.";
            superToolTip64.Items.Add(toolTipTitleItem64);
            superToolTip64.Items.Add(toolTipItem64);
            superToolTip64.MaxWidth = 210;
            this.commandBarItem56.SuperTip = superToolTip64;
            // 
            // commandBarItem57
            // 
            this.commandBarItem57.Caption = "Remove Vertical Spacing";
            this.commandBarItem57.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceConcatenate;
            this.commandBarItem57.Enabled = false;
            this.commandBarItem57.Id = 63;
            this.commandBarItem57.Name = "commandBarItem57";
            superToolTip65.FixedTooltipWidth = true;
            toolTipTitleItem65.Text = "Remove Vertical Spacing";
            toolTipItem65.LeftIndent = 6;
            toolTipItem65.Text = "Remove the vertical spacing between the selected controls.";
            superToolTip65.Items.Add(toolTipTitleItem65);
            superToolTip65.Items.Add(toolTipItem65);
            superToolTip65.MaxWidth = 210;
            this.commandBarItem57.SuperTip = superToolTip65;
            // 
            // commandBarItem58
            // 
            this.commandBarItem58.Caption = "Center Horizontally";
            this.commandBarItem58.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CenterHorizontally;
            this.commandBarItem58.Enabled = false;
            this.commandBarItem58.Id = 64;
            this.commandBarItem58.Name = "commandBarItem58";
            superToolTip66.FixedTooltipWidth = true;
            toolTipTitleItem66.Text = "Center Horizontally";
            toolTipItem66.LeftIndent = 6;
            toolTipItem66.Text = "Horizontally center the selected controls within a band.";
            superToolTip66.Items.Add(toolTipTitleItem66);
            superToolTip66.Items.Add(toolTipItem66);
            superToolTip66.MaxWidth = 210;
            this.commandBarItem58.SuperTip = superToolTip66;
            // 
            // commandBarItem59
            // 
            this.commandBarItem59.Caption = "Center Vertically";
            this.commandBarItem59.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CenterVertically;
            this.commandBarItem59.Enabled = false;
            this.commandBarItem59.Id = 65;
            this.commandBarItem59.Name = "commandBarItem59";
            superToolTip67.FixedTooltipWidth = true;
            toolTipTitleItem67.Text = "Center Vertically";
            toolTipItem67.LeftIndent = 6;
            toolTipItem67.Text = "Vertically center the selected controls within a band.";
            superToolTip67.Items.Add(toolTipTitleItem67);
            superToolTip67.Items.Add(toolTipItem67);
            superToolTip67.MaxWidth = 210;
            this.commandBarItem59.SuperTip = superToolTip67;
            // 
            // commandBarItem60
            // 
            this.commandBarItem60.Caption = "Bring to Front";
            this.commandBarItem60.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BringToFront;
            this.commandBarItem60.Enabled = false;
            this.commandBarItem60.Id = 66;
            this.commandBarItem60.Name = "commandBarItem60";
            superToolTip68.FixedTooltipWidth = true;
            toolTipTitleItem68.Text = "Bring to Front";
            toolTipItem68.LeftIndent = 6;
            toolTipItem68.Text = "Bring the selected controls to the front.";
            superToolTip68.Items.Add(toolTipTitleItem68);
            superToolTip68.Items.Add(toolTipItem68);
            superToolTip68.MaxWidth = 210;
            this.commandBarItem60.SuperTip = superToolTip68;
            // 
            // commandBarItem61
            // 
            this.commandBarItem61.Caption = "Send to Back";
            this.commandBarItem61.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SendToBack;
            this.commandBarItem61.Enabled = false;
            this.commandBarItem61.Id = 67;
            this.commandBarItem61.Name = "commandBarItem61";
            superToolTip69.FixedTooltipWidth = true;
            toolTipTitleItem69.Text = "Send to Back";
            toolTipItem69.LeftIndent = 6;
            toolTipItem69.Text = "Move the selected controls to the back.";
            superToolTip69.Items.Add(toolTipTitleItem69);
            superToolTip69.Items.Add(toolTipItem69);
            superToolTip69.MaxWidth = 210;
            this.commandBarItem61.SuperTip = superToolTip69;
            // 
            // commandBarCheckItem1
            // 
            this.commandBarCheckItem1.Caption = "Snap to Grid";
            this.commandBarCheckItem1.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.commandBarCheckItem1.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SnapToGrid;
            this.commandBarCheckItem1.Enabled = false;
            this.commandBarCheckItem1.Id = 68;
            this.commandBarCheckItem1.Name = "commandBarCheckItem1";
            superToolTip70.FixedTooltipWidth = true;
            toolTipTitleItem70.Text = "Snap to Grid";
            toolTipItem70.LeftIndent = 6;
            toolTipItem70.Text = "Enable snapping to the snap grid.";
            superToolTip70.Items.Add(toolTipTitleItem70);
            superToolTip70.Items.Add(toolTipItem70);
            superToolTip70.MaxWidth = 210;
            this.commandBarCheckItem1.SuperTip = superToolTip70;
            // 
            // commandBarCheckItem2
            // 
            this.commandBarCheckItem2.Caption = "Snap Lines";
            this.commandBarCheckItem2.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.commandBarCheckItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SnapLines;
            this.commandBarCheckItem2.Enabled = false;
            this.commandBarCheckItem2.Id = 69;
            this.commandBarCheckItem2.Name = "commandBarCheckItem2";
            superToolTip71.FixedTooltipWidth = true;
            toolTipTitleItem71.Text = "Snap Lines";
            toolTipItem71.LeftIndent = 6;
            toolTipItem71.Text = "Enable snapping to snap lines.";
            superToolTip71.Items.Add(toolTipTitleItem71);
            superToolTip71.Items.Add(toolTipItem71);
            superToolTip71.MaxWidth = 210;
            this.commandBarCheckItem2.SuperTip = superToolTip71;
            // 
            // commandBarItem62
            // 
            this.commandBarItem62.Caption = "Fit Bounds to Container";
            this.commandBarItem62.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FitBoundsToContainer;
            this.commandBarItem62.Enabled = false;
            this.commandBarItem62.Id = 70;
            this.commandBarItem62.Name = "commandBarItem62";
            superToolTip72.FixedTooltipWidth = true;
            toolTipTitleItem72.Text = "Fit Bounds To Container";
            toolTipItem72.LeftIndent = 6;
            toolTipItem72.Text = "Adjust the control size to occupy all the available container space.";
            superToolTip72.Items.Add(toolTipTitleItem72);
            superToolTip72.Items.Add(toolTipItem72);
            superToolTip72.MaxWidth = 210;
            this.commandBarItem62.SuperTip = superToolTip72;
            // 
            // commandBarItem63
            // 
            this.commandBarItem63.ActAsDropDown = true;
            this.commandBarItem63.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem63.Caption = "Size";
            this.commandBarItem63.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PageSize;
            this.commandBarItem63.Enabled = false;
            this.commandBarItem63.Id = 71;
            this.commandBarItem63.Name = "commandBarItem63";
            superToolTip73.FixedTooltipWidth = true;
            toolTipTitleItem73.Text = "Choose Page Size";
            toolTipItem73.LeftIndent = 6;
            toolTipItem73.Text = "Choose a commonly used paper size for a report or click More Paper Sizes to defin" +
    "e your own size.";
            superToolTip73.Items.Add(toolTipTitleItem73);
            superToolTip73.Items.Add(toolTipItem73);
            superToolTip73.MaxWidth = 210;
            this.commandBarItem63.SuperTip = superToolTip73;
            // 
            // commandBarItem64
            // 
            this.commandBarItem64.ActAsDropDown = true;
            this.commandBarItem64.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem64.Caption = "Orientation";
            this.commandBarItem64.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PageOrientation;
            this.commandBarItem64.Enabled = false;
            this.commandBarItem64.Id = 72;
            this.commandBarItem64.Name = "commandBarItem64";
            superToolTip74.FixedTooltipWidth = true;
            toolTipTitleItem74.Text = "Change Page Orientation";
            toolTipItem74.LeftIndent = 6;
            toolTipItem74.Text = "Switch between portrait and landscape page layouts.";
            superToolTip74.Items.Add(toolTipTitleItem74);
            superToolTip74.Items.Add(toolTipItem74);
            superToolTip74.MaxWidth = 210;
            this.commandBarItem64.SuperTip = superToolTip74;
            // 
            // commandBarItem65
            // 
            this.commandBarItem65.ActAsDropDown = true;
            this.commandBarItem65.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem65.Caption = "Margins";
            this.commandBarItem65.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PageMargins;
            this.commandBarItem65.Enabled = false;
            this.commandBarItem65.Id = 73;
            this.commandBarItem65.Name = "commandBarItem65";
            superToolTip75.FixedTooltipWidth = true;
            toolTipTitleItem75.Text = "Adjust Margins";
            toolTipItem75.LeftIndent = 6;
            toolTipItem75.Text = "Set margin sizes for a report. Choose from several commonly used formats or click" +
    " Custom Margins to define your own format.";
            superToolTip75.Items.Add(toolTipTitleItem75);
            superToolTip75.Items.Add(toolTipItem75);
            superToolTip75.MaxWidth = 210;
            this.commandBarItem65.SuperTip = superToolTip75;
            // 
            // commandColorBarItem4
            // 
            this.commandColorBarItem4.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandColorBarItem4.Caption = "Page Color";
            this.commandColorBarItem4.CloseSubMenuOnClickMode = DevExpress.Utils.DefaultBoolean.False;
            this.commandColorBarItem4.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PageColor;
            this.commandColorBarItem4.Enabled = false;
            this.commandColorBarItem4.Id = 74;
            this.commandColorBarItem4.Name = "commandColorBarItem4";
            superToolTip76.FixedTooltipWidth = true;
            toolTipTitleItem76.Text = "Choose Page Color";
            toolTipItem76.LeftIndent = 6;
            toolTipItem76.Text = "Select the background color for report pages.";
            superToolTip76.Items.Add(toolTipTitleItem76);
            superToolTip76.Items.Add(toolTipItem76);
            superToolTip76.MaxWidth = 210;
            this.commandColorBarItem4.SuperTip = superToolTip76;
            // 
            // commandBarItem66
            // 
            this.commandBarItem66.Caption = "Watermark";
            this.commandBarItem66.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PageWatermark;
            this.commandBarItem66.Enabled = false;
            this.commandBarItem66.Id = 75;
            this.commandBarItem66.Name = "commandBarItem66";
            superToolTip77.FixedTooltipWidth = true;
            toolTipTitleItem77.Text = "Add Watermark";
            toolTipItem77.LeftIndent = 6;
            toolTipItem77.Text = "Insert ghost text or image behind the page content to indicate that a report requ" +
    "ires special treatment. Use the View tab to display a watermark at design time a" +
    "nd use it as a template for a report.";
            superToolTip77.Items.Add(toolTipTitleItem77);
            superToolTip77.Items.Add(toolTipItem77);
            superToolTip77.MaxWidth = 210;
            this.commandBarItem66.SuperTip = superToolTip77;
            // 
            // commandBarItem67
            // 
            this.commandBarItem67.Caption = "Printing Warnings";
            this.commandBarItem67.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowPrintingWarnings;
            this.commandBarItem67.Enabled = false;
            this.commandBarItem67.Id = 76;
            this.commandBarItem67.Name = "commandBarItem67";
            superToolTip78.FixedTooltipWidth = true;
            toolTipTitleItem78.Text = "Show Printing Warnings";
            toolTipItem78.LeftIndent = 6;
            toolTipItem78.Text = "Highlight report controls that overrun the right page margin to warn you about ex" +
    "tra pages when printing the document.";
            superToolTip78.Items.Add(toolTipTitleItem78);
            superToolTip78.Items.Add(toolTipItem78);
            superToolTip78.MaxWidth = 210;
            this.commandBarItem67.SuperTip = superToolTip78;
            // 
            // commandBarItem68
            // 
            this.commandBarItem68.Caption = "Export Warnings";
            this.commandBarItem68.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowExportWarnings;
            this.commandBarItem68.Enabled = false;
            this.commandBarItem68.Id = 77;
            this.commandBarItem68.Name = "commandBarItem68";
            superToolTip79.FixedTooltipWidth = true;
            toolTipTitleItem79.Text = "Show Export Warnings";
            toolTipItem79.LeftIndent = 6;
            toolTipItem79.Text = "Highlight intersecting report controls to warn you about the possibility of corru" +
    "pting the document layout when exporting the document to specific formats.";
            superToolTip79.Items.Add(toolTipTitleItem79);
            superToolTip79.Items.Add(toolTipItem79);
            superToolTip79.MaxWidth = 210;
            this.commandBarItem68.SuperTip = superToolTip79;
            // 
            // commandBarItem69
            // 
            this.commandBarItem69.Caption = "Watermark";
            this.commandBarItem69.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.DrawWatermark;
            this.commandBarItem69.Enabled = false;
            this.commandBarItem69.Id = 78;
            this.commandBarItem69.Name = "commandBarItem69";
            this.commandBarItem69.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip80.FixedTooltipWidth = true;
            toolTipTitleItem80.Text = "Show Watermark";
            toolTipItem80.LeftIndent = 6;
            toolTipItem80.Text = "Display the document\'s watermark on the design surface for the better design expe" +
    "rience. Specify watermark settings in the Page tab.";
            superToolTip80.Items.Add(toolTipTitleItem80);
            superToolTip80.Items.Add(toolTipItem80);
            superToolTip80.MaxWidth = 210;
            this.commandBarItem69.SuperTip = superToolTip80;
            // 
            // commandBarItem70
            // 
            this.commandBarItem70.Caption = "Grid Lines";
            this.commandBarItem70.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.DrawGridLines;
            this.commandBarItem70.Enabled = false;
            this.commandBarItem70.Id = 79;
            this.commandBarItem70.Name = "commandBarItem70";
            this.commandBarItem70.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip81.FixedTooltipWidth = true;
            toolTipTitleItem81.Text = "Show Grid Lines";
            toolTipItem81.LeftIndent = 6;
            toolTipItem81.Text = "Show gridlines on the report surface for perfect control placement.";
            superToolTip81.Items.Add(toolTipTitleItem81);
            superToolTip81.Items.Add(toolTipItem81);
            superToolTip81.MaxWidth = 210;
            this.commandBarItem70.SuperTip = superToolTip81;
            // 
            // commandBarItem71
            // 
            this.commandBarItem71.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem71.Caption = "Zoom";
            this.commandBarItem71.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Zoom;
            this.commandBarItem71.Enabled = false;
            this.commandBarItem71.Id = 80;
            this.commandBarItem71.Name = "commandBarItem71";
            superToolTip82.FixedTooltipWidth = true;
            toolTipTitleItem82.Text = "Zoom";
            toolTipItem82.LeftIndent = 6;
            toolTipItem82.Text = "Change the zoom level of the document designer.";
            superToolTip82.Items.Add(toolTipTitleItem82);
            superToolTip82.Items.Add(toolTipItem82);
            superToolTip82.MaxWidth = 210;
            this.commandBarItem71.SuperTip = superToolTip82;
            // 
            // commandBarItem72
            // 
            this.commandBarItem72.Caption = "Zoom In";
            this.commandBarItem72.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ZoomIn;
            this.commandBarItem72.Enabled = false;
            this.commandBarItem72.Id = 81;
            this.commandBarItem72.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Add));
            this.commandBarItem72.Name = "commandBarItem72";
            superToolTip83.FixedTooltipWidth = true;
            toolTipTitleItem83.Text = "Zoom In (Ctrl+Add)";
            toolTipItem83.LeftIndent = 6;
            toolTipItem83.Text = "Zoom in to get a close-up view of the report.";
            superToolTip83.Items.Add(toolTipTitleItem83);
            superToolTip83.Items.Add(toolTipItem83);
            superToolTip83.MaxWidth = 210;
            this.commandBarItem72.SuperTip = superToolTip83;
            // 
            // commandBarItem73
            // 
            this.commandBarItem73.Caption = "Zoom Out";
            this.commandBarItem73.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ZoomOut;
            this.commandBarItem73.Enabled = false;
            this.commandBarItem73.Id = 82;
            this.commandBarItem73.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Subtract));
            this.commandBarItem73.Name = "commandBarItem73";
            superToolTip84.FixedTooltipWidth = true;
            toolTipTitleItem84.Text = "Zoom Out (Ctrl+Subtract)";
            toolTipItem84.LeftIndent = 6;
            toolTipItem84.Text = "Zoom out to see more of the report at a reduced size.";
            superToolTip84.Items.Add(toolTipTitleItem84);
            superToolTip84.Items.Add(toolTipItem84);
            superToolTip84.MaxWidth = 210;
            this.commandBarItem73.SuperTip = superToolTip84;
            // 
            // commandBarItem74
            // 
            this.commandBarItem74.Caption = "Validate";
            this.commandBarItem74.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ScriptsValidate;
            this.commandBarItem74.Enabled = false;
            this.commandBarItem74.Id = 83;
            this.commandBarItem74.Name = "commandBarItem74";
            superToolTip85.FixedTooltipWidth = true;
            toolTipTitleItem85.Text = "Validate Scripts";
            toolTipItem85.LeftIndent = 6;
            toolTipItem85.Text = "Check whether report scripts contain errors. If errors are found, they are listed" +
    " in the Scripts Errors panel.";
            superToolTip85.Items.Add(toolTipTitleItem85);
            superToolTip85.Items.Add(toolTipItem85);
            superToolTip85.MaxWidth = 210;
            this.commandBarItem74.SuperTip = superToolTip85;
            // 
            // commandGalleryBarItem1
            // 
            this.commandGalleryBarItem1.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.StyleName;
            this.commandGalleryBarItem1.Enabled = false;
            // 
            // 
            // 
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Disabled.Options.UseTextOptions = true;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Disabled.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Disabled.TextOptions.Trimming = DevExpress.Utils.Trimming.EllipsisCharacter;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Hovered.Options.UseTextOptions = true;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Hovered.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Hovered.TextOptions.Trimming = DevExpress.Utils.Trimming.EllipsisCharacter;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Normal.Options.UseTextOptions = true;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Normal.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Normal.TextOptions.Trimming = DevExpress.Utils.Trimming.EllipsisCharacter;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Pressed.Options.UseTextOptions = true;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Pressed.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.commandGalleryBarItem1.Gallery.Appearance.ItemCaptionAppearance.Pressed.TextOptions.Trimming = DevExpress.Utils.Trimming.EllipsisCharacter;
            this.commandGalleryBarItem1.Gallery.ColumnCount = 7;
            this.commandGalleryBarItem1.Gallery.ImageSize = new System.Drawing.Size(75, 35);
            this.commandGalleryBarItem1.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleCheck;
            this.commandGalleryBarItem1.Gallery.ShowItemText = true;
            this.commandGalleryBarItem1.Id = 84;
            this.commandGalleryBarItem1.Name = "commandGalleryBarItem1";
            // 
            // commandGalleryBarItem2
            // 
            this.commandGalleryBarItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BarCodeSymbology;
            this.commandGalleryBarItem2.Enabled = false;
            // 
            // 
            // 
            this.commandGalleryBarItem2.Gallery.ColumnCount = 8;
            this.commandGalleryBarItem2.Gallery.ImageSize = new System.Drawing.Size(100, 37);
            this.commandGalleryBarItem2.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            this.commandGalleryBarItem2.Gallery.ShowItemText = true;
            this.commandGalleryBarItem2.Id = 85;
            this.commandGalleryBarItem2.Name = "commandGalleryBarItem2";
            // 
            // commandGalleryBarItem3
            // 
            this.commandGalleryBarItem3.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAppearanceName;
            this.commandGalleryBarItem3.Enabled = false;
            // 
            // 
            // 
            this.commandGalleryBarItem3.Gallery.ColumnCount = 7;
            this.commandGalleryBarItem3.Gallery.ImageSize = new System.Drawing.Size(75, 52);
            this.commandGalleryBarItem3.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            this.commandGalleryBarItem3.Id = 86;
            this.commandGalleryBarItem3.Name = "commandGalleryBarItem3";
            // 
            // commandGalleryBarItem4
            // 
            this.commandGalleryBarItem4.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SparklineView;
            this.commandGalleryBarItem4.Enabled = false;
            // 
            // 
            // 
            this.commandGalleryBarItem4.Gallery.ColumnCount = 4;
            this.commandGalleryBarItem4.Gallery.ImageSize = new System.Drawing.Size(48, 55);
            this.commandGalleryBarItem4.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            this.commandGalleryBarItem4.Id = 87;
            this.commandGalleryBarItem4.Name = "commandGalleryBarItem4";
            // 
            // commandGalleryBarItem5
            // 
            this.commandGalleryBarItem5.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.GaugeViewTypeStyle;
            this.commandGalleryBarItem5.Enabled = false;
            // 
            // 
            // 
            this.commandGalleryBarItem5.Gallery.ColumnCount = 7;
            this.commandGalleryBarItem5.Gallery.ImageSize = new System.Drawing.Size(48, 55);
            this.commandGalleryBarItem5.Gallery.ItemCheckMode = DevExpress.XtraBars.Ribbon.Gallery.ItemCheckMode.SingleRadio;
            this.commandGalleryBarItem5.Id = 88;
            this.commandGalleryBarItem5.Name = "commandGalleryBarItem5";
            // 
            // commandGalleryBarItem6
            // 
            this.commandGalleryBarItem6.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ShapeType;
            this.commandGalleryBarItem6.Enabled = false;
            // 
            // 
            // 
            this.commandGalleryBarItem6.Gallery.ColumnCount = 23;
            this.commandGalleryBarItem6.Gallery.DistanceBetweenItems = 10;
            this.commandGalleryBarItem6.Gallery.ImageSize = new System.Drawing.Size(40, 40);
            this.commandGalleryBarItem6.Gallery.ScaleImages = DevExpress.Utils.DefaultBoolean.True;
            this.commandGalleryBarItem6.Id = 89;
            this.commandGalleryBarItem6.Name = "commandGalleryBarItem6";
            // 
            // commandBarEditItem1
            // 
            this.commandBarEditItem1.Caption = "Width: ";
            this.commandBarEditItem1.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CharacterCombCellWidth;
            this.commandBarEditItem1.Edit = this.repositoryItemSpinEdit1;
            this.commandBarEditItem1.EditWidth = 50;
            this.commandBarEditItem1.Enabled = false;
            this.commandBarEditItem1.Id = 90;
            this.commandBarEditItem1.Name = "commandBarEditItem1";
            superToolTip86.FixedTooltipWidth = true;
            toolTipTitleItem86.Text = "Cell Width";
            toolTipItem86.LeftIndent = 6;
            toolTipItem86.Text = "Set the cell width.";
            superToolTip86.Items.Add(toolTipTitleItem86);
            superToolTip86.Items.Add(toolTipItem86);
            superToolTip86.MaxWidth = 210;
            this.commandBarEditItem1.SuperTip = superToolTip86;
            // 
            // repositoryItemSpinEdit1
            // 
            this.repositoryItemSpinEdit1.AutoHeight = false;
            this.repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit1.MaxValue = new decimal(new int[] {
            -1,
            -1,
            -1,
            0});
            this.repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // commandBarEditItem2
            // 
            this.commandBarEditItem2.Caption = "Height: ";
            this.commandBarEditItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CharacterCombCellHeight;
            this.commandBarEditItem2.Edit = this.repositoryItemSpinEdit2;
            this.commandBarEditItem2.EditWidth = 50;
            this.commandBarEditItem2.Enabled = false;
            this.commandBarEditItem2.Id = 91;
            this.commandBarEditItem2.Name = "commandBarEditItem2";
            superToolTip87.FixedTooltipWidth = true;
            toolTipTitleItem87.Text = "Cell Height";
            toolTipItem87.LeftIndent = 6;
            toolTipItem87.Text = "Set the cell height.";
            superToolTip87.Items.Add(toolTipTitleItem87);
            superToolTip87.Items.Add(toolTipItem87);
            superToolTip87.MaxWidth = 210;
            this.commandBarEditItem2.SuperTip = superToolTip87;
            // 
            // repositoryItemSpinEdit2
            // 
            this.repositoryItemSpinEdit2.AutoHeight = false;
            this.repositoryItemSpinEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit2.MaxValue = new decimal(new int[] {
            -1,
            -1,
            -1,
            0});
            this.repositoryItemSpinEdit2.Name = "repositoryItemSpinEdit2";
            // 
            // commandBarEditItem3
            // 
            this.commandBarEditItem3.Caption = "Horizontal Spacing: ";
            this.commandBarEditItem3.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CharacterCombCellHorizontalSpacing;
            this.commandBarEditItem3.Edit = this.repositoryItemSpinEdit3;
            this.commandBarEditItem3.EditWidth = 50;
            this.commandBarEditItem3.Enabled = false;
            this.commandBarEditItem3.Id = 92;
            this.commandBarEditItem3.Name = "commandBarEditItem3";
            superToolTip88.FixedTooltipWidth = true;
            toolTipTitleItem88.Text = "Cell Horizontal Spacing";
            toolTipItem88.LeftIndent = 6;
            toolTipItem88.Text = "Set the horizontal spacing between adjacent cells.";
            superToolTip88.Items.Add(toolTipTitleItem88);
            superToolTip88.Items.Add(toolTipItem88);
            superToolTip88.MaxWidth = 210;
            this.commandBarEditItem3.SuperTip = superToolTip88;
            // 
            // repositoryItemSpinEdit3
            // 
            this.repositoryItemSpinEdit3.AutoHeight = false;
            this.repositoryItemSpinEdit3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit3.MaxValue = new decimal(new int[] {
            -1,
            -1,
            -1,
            0});
            this.repositoryItemSpinEdit3.Name = "repositoryItemSpinEdit3";
            // 
            // commandBarEditItem4
            // 
            this.commandBarEditItem4.Caption = "Vertical Spacing: ";
            this.commandBarEditItem4.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CharacterCombCellVerticalSpacing;
            this.commandBarEditItem4.Edit = this.repositoryItemSpinEdit4;
            this.commandBarEditItem4.EditWidth = 50;
            this.commandBarEditItem4.Enabled = false;
            this.commandBarEditItem4.Id = 93;
            this.commandBarEditItem4.Name = "commandBarEditItem4";
            superToolTip89.FixedTooltipWidth = true;
            toolTipTitleItem89.Text = "Cell Vertical Spacing";
            toolTipItem89.LeftIndent = 6;
            toolTipItem89.Text = "Set the vertical spacing between adjacent cells.";
            superToolTip89.Items.Add(toolTipTitleItem89);
            superToolTip89.Items.Add(toolTipItem89);
            superToolTip89.MaxWidth = 210;
            this.commandBarEditItem4.SuperTip = superToolTip89;
            // 
            // repositoryItemSpinEdit4
            // 
            this.repositoryItemSpinEdit4.AutoHeight = false;
            this.repositoryItemSpinEdit4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit4.MaxValue = new decimal(new int[] {
            -1,
            -1,
            -1,
            0});
            this.repositoryItemSpinEdit4.Name = "repositoryItemSpinEdit4";
            // 
            // commandBarEditItem5
            // 
            this.commandBarEditItem5.Caption = "Border Dash Style";
            this.commandBarEditItem5.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BorderDashStyle;
            this.commandBarEditItem5.Edit = this.repositoryItemImageComboBox1;
            this.commandBarEditItem5.EditWidth = 86;
            this.commandBarEditItem5.Enabled = false;
            this.commandBarEditItem5.Id = 94;
            this.commandBarEditItem5.Name = "commandBarEditItem5";
            superToolTip90.FixedTooltipWidth = true;
            toolTipTitleItem90.Text = "Border Dash Style";
            toolTipItem90.LeftIndent = 6;
            toolTipItem90.Text = "Change the border dash style.";
            superToolTip90.Items.Add(toolTipTitleItem90);
            superToolTip90.Items.Add(toolTipItem90);
            superToolTip90.MaxWidth = 210;
            this.commandBarEditItem5.SuperTip = superToolTip90;
            // 
            // repositoryItemImageComboBox1
            // 
            this.repositoryItemImageComboBox1.AutoHeight = false;
            this.repositoryItemImageComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemImageComboBox1.Name = "repositoryItemImageComboBox1";
            // 
            // commandBarEditItem6
            // 
            this.commandBarEditItem6.Caption = "Control: ";
            this.commandBarEditItem6.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ScriptsSelectControl;
            this.commandBarEditItem6.Edit = this.repositoryItemLookUpEdit1;
            this.commandBarEditItem6.EditWidth = 300;
            this.commandBarEditItem6.Enabled = false;
            this.commandBarEditItem6.Id = 95;
            this.commandBarEditItem6.Name = "commandBarEditItem6";
            superToolTip91.FixedTooltipWidth = true;
            toolTipTitleItem91.Text = "Control";
            toolTipItem91.LeftIndent = 6;
            toolTipItem91.Text = "Select a required control for specifying an event.";
            superToolTip91.Items.Add(toolTipTitleItem91);
            superToolTip91.Items.Add(toolTipItem91);
            superToolTip91.MaxWidth = 210;
            this.commandBarEditItem6.SuperTip = superToolTip91;
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            // 
            // commandBarEditItem7
            // 
            this.commandBarEditItem7.Caption = "Event: ";
            this.commandBarEditItem7.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ScriptsSelectEvent;
            this.commandBarEditItem7.Edit = this.repositoryItemComboBox1;
            this.commandBarEditItem7.EditWidth = 300;
            this.commandBarEditItem7.Enabled = false;
            this.commandBarEditItem7.Id = 96;
            this.commandBarEditItem7.Name = "commandBarEditItem7";
            superToolTip92.FixedTooltipWidth = true;
            toolTipTitleItem92.Text = "Event";
            toolTipItem92.LeftIndent = 6;
            toolTipItem92.Text = "Select one of the available events.";
            superToolTip92.Items.Add(toolTipTitleItem92);
            superToolTip92.Items.Add(toolTipItem92);
            superToolTip92.MaxWidth = 210;
            this.commandBarEditItem7.SuperTip = superToolTip92;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // commandBarItem75
            // 
            this.commandBarItem75.Caption = "Table";
            this.commandBarItem75.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableSelectTable;
            this.commandBarItem75.Enabled = false;
            this.commandBarItem75.Id = 97;
            this.commandBarItem75.Name = "commandBarItem75";
            superToolTip93.FixedTooltipWidth = true;
            toolTipTitleItem93.Text = "Select Table";
            toolTipItem93.LeftIndent = 6;
            toolTipItem93.Text = "Select the entire table.";
            superToolTip93.Items.Add(toolTipTitleItem93);
            superToolTip93.Items.Add(toolTipItem93);
            superToolTip93.MaxWidth = 210;
            this.commandBarItem75.SuperTip = superToolTip93;
            // 
            // commandBarItem76
            // 
            this.commandBarItem76.Caption = "Row";
            this.commandBarItem76.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableSelectRow;
            this.commandBarItem76.Enabled = false;
            this.commandBarItem76.Id = 98;
            this.commandBarItem76.Name = "commandBarItem76";
            superToolTip94.FixedTooltipWidth = true;
            toolTipTitleItem94.Text = "Select Row";
            toolTipItem94.LeftIndent = 6;
            toolTipItem94.Text = "Select the current row.";
            superToolTip94.Items.Add(toolTipTitleItem94);
            superToolTip94.Items.Add(toolTipItem94);
            superToolTip94.MaxWidth = 210;
            this.commandBarItem76.SuperTip = superToolTip94;
            // 
            // commandBarItem77
            // 
            this.commandBarItem77.Caption = "Column";
            this.commandBarItem77.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableSelectColumn;
            this.commandBarItem77.Enabled = false;
            this.commandBarItem77.Id = 99;
            this.commandBarItem77.Name = "commandBarItem77";
            superToolTip95.FixedTooltipWidth = true;
            toolTipTitleItem95.Text = "Select Column";
            toolTipItem95.LeftIndent = 6;
            toolTipItem95.Text = "Select the current column.";
            superToolTip95.Items.Add(toolTipTitleItem95);
            superToolTip95.Items.Add(toolTipItem95);
            superToolTip95.MaxWidth = 210;
            this.commandBarItem77.SuperTip = superToolTip95;
            // 
            // commandBarItem78
            // 
            this.commandBarItem78.Caption = "Cell";
            this.commandBarItem78.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableDeleteCell;
            this.commandBarItem78.Enabled = false;
            this.commandBarItem78.Id = 100;
            this.commandBarItem78.Name = "commandBarItem78";
            superToolTip96.FixedTooltipWidth = true;
            toolTipTitleItem96.Text = "Delete Cell";
            toolTipItem96.LeftIndent = 6;
            toolTipItem96.Text = "Delete the current cell.";
            superToolTip96.Items.Add(toolTipTitleItem96);
            superToolTip96.Items.Add(toolTipItem96);
            superToolTip96.MaxWidth = 210;
            this.commandBarItem78.SuperTip = superToolTip96;
            // 
            // commandBarItem79
            // 
            this.commandBarItem79.Caption = "Row";
            this.commandBarItem79.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableDeleteRow;
            this.commandBarItem79.Enabled = false;
            this.commandBarItem79.Id = 101;
            this.commandBarItem79.Name = "commandBarItem79";
            superToolTip97.FixedTooltipWidth = true;
            toolTipTitleItem97.Text = "Delete Row";
            toolTipItem97.LeftIndent = 6;
            toolTipItem97.Text = "Delete the current row.";
            superToolTip97.Items.Add(toolTipTitleItem97);
            superToolTip97.Items.Add(toolTipItem97);
            superToolTip97.MaxWidth = 210;
            this.commandBarItem79.SuperTip = superToolTip97;
            // 
            // commandBarItem80
            // 
            this.commandBarItem80.Caption = "Column";
            this.commandBarItem80.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableDeleteColumn;
            this.commandBarItem80.Enabled = false;
            this.commandBarItem80.Id = 102;
            this.commandBarItem80.Name = "commandBarItem80";
            superToolTip98.FixedTooltipWidth = true;
            toolTipTitleItem98.Text = "Delete Column";
            toolTipItem98.LeftIndent = 6;
            toolTipItem98.Text = "Delete the current column.";
            superToolTip98.Items.Add(toolTipTitleItem98);
            superToolTip98.Items.Add(toolTipItem98);
            superToolTip98.MaxWidth = 210;
            this.commandBarItem80.SuperTip = superToolTip98;
            // 
            // commandBarItem81
            // 
            this.commandBarItem81.Caption = "Table";
            this.commandBarItem81.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableDeleteTable;
            this.commandBarItem81.Enabled = false;
            this.commandBarItem81.Id = 103;
            this.commandBarItem81.Name = "commandBarItem81";
            superToolTip99.FixedTooltipWidth = true;
            toolTipTitleItem99.Text = "Delete Table";
            toolTipItem99.LeftIndent = 6;
            toolTipItem99.Text = "Delete the entire table.";
            superToolTip99.Items.Add(toolTipTitleItem99);
            superToolTip99.Items.Add(toolTipItem99);
            superToolTip99.MaxWidth = 210;
            this.commandBarItem81.SuperTip = superToolTip99;
            // 
            // commandBarItem82
            // 
            this.commandBarItem82.Caption = "Row Above";
            this.commandBarItem82.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableInsertRowAbove;
            this.commandBarItem82.Enabled = false;
            this.commandBarItem82.Id = 104;
            this.commandBarItem82.Name = "commandBarItem82";
            superToolTip100.FixedTooltipWidth = true;
            toolTipTitleItem100.Text = "Insert Row Above";
            toolTipItem100.LeftIndent = 6;
            toolTipItem100.Text = "Add a new row directly above the current row.";
            superToolTip100.Items.Add(toolTipTitleItem100);
            superToolTip100.Items.Add(toolTipItem100);
            superToolTip100.MaxWidth = 210;
            this.commandBarItem82.SuperTip = superToolTip100;
            // 
            // commandBarItem83
            // 
            this.commandBarItem83.Caption = "Row Below";
            this.commandBarItem83.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableInsertRowBelow;
            this.commandBarItem83.Enabled = false;
            this.commandBarItem83.Id = 105;
            this.commandBarItem83.Name = "commandBarItem83";
            superToolTip101.FixedTooltipWidth = true;
            toolTipTitleItem101.Text = "Insert Row Below";
            toolTipItem101.LeftIndent = 6;
            toolTipItem101.Text = "Add a new row directly below the current row.";
            superToolTip101.Items.Add(toolTipTitleItem101);
            superToolTip101.Items.Add(toolTipItem101);
            superToolTip101.MaxWidth = 210;
            this.commandBarItem83.SuperTip = superToolTip101;
            // 
            // commandBarItem84
            // 
            this.commandBarItem84.Caption = "Column to Left";
            this.commandBarItem84.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableInsertColumnToLeft;
            this.commandBarItem84.Enabled = false;
            this.commandBarItem84.Id = 106;
            this.commandBarItem84.Name = "commandBarItem84";
            superToolTip102.FixedTooltipWidth = true;
            toolTipTitleItem102.Text = "Insert Column to Left";
            toolTipItem102.LeftIndent = 6;
            toolTipItem102.Text = "Add a new column directly to the left of the current column.";
            superToolTip102.Items.Add(toolTipTitleItem102);
            superToolTip102.Items.Add(toolTipItem102);
            superToolTip102.MaxWidth = 210;
            this.commandBarItem84.SuperTip = superToolTip102;
            // 
            // commandBarItem85
            // 
            this.commandBarItem85.Caption = "Column to Right";
            this.commandBarItem85.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableInsertColumnToRight;
            this.commandBarItem85.Enabled = false;
            this.commandBarItem85.Id = 107;
            this.commandBarItem85.Name = "commandBarItem85";
            superToolTip103.FixedTooltipWidth = true;
            toolTipTitleItem103.Text = "Insert Column to Right";
            toolTipItem103.LeftIndent = 6;
            toolTipItem103.Text = "Add a new column directly to the right of the current column.";
            superToolTip103.Items.Add(toolTipTitleItem103);
            superToolTip103.Items.Add(toolTipItem103);
            superToolTip103.MaxWidth = 210;
            this.commandBarItem85.SuperTip = superToolTip103;
            // 
            // commandBarItem86
            // 
            this.commandBarItem86.Caption = "Rows";
            this.commandBarItem86.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableDistributeRowsEvenly;
            this.commandBarItem86.Enabled = false;
            this.commandBarItem86.Id = 108;
            this.commandBarItem86.Name = "commandBarItem86";
            superToolTip104.FixedTooltipWidth = true;
            toolTipTitleItem104.Text = "Distribute Rows Evenly";
            toolTipItem104.LeftIndent = 6;
            toolTipItem104.Text = "Distribute the height of the selected rows equally between them.";
            superToolTip104.Items.Add(toolTipTitleItem104);
            superToolTip104.Items.Add(toolTipItem104);
            superToolTip104.MaxWidth = 210;
            this.commandBarItem86.SuperTip = superToolTip104;
            // 
            // commandBarItem87
            // 
            this.commandBarItem87.Caption = "Columns";
            this.commandBarItem87.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableDistributeColumnsEvenly;
            this.commandBarItem87.Enabled = false;
            this.commandBarItem87.Id = 109;
            this.commandBarItem87.Name = "commandBarItem87";
            superToolTip105.FixedTooltipWidth = true;
            toolTipTitleItem105.Text = "Distribute Columns Evenly";
            toolTipItem105.LeftIndent = 6;
            toolTipItem105.Text = "Distribute the width of the selected columns equally between them.";
            superToolTip105.Items.Add(toolTipTitleItem105);
            superToolTip105.Items.Add(toolTipItem105);
            superToolTip105.MaxWidth = 210;
            this.commandBarItem87.SuperTip = superToolTip105;
            // 
            // commandBarItem88
            // 
            this.commandBarItem88.Caption = "Merge Cells";
            this.commandBarItem88.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableMergeCells;
            this.commandBarItem88.Enabled = false;
            this.commandBarItem88.Id = 110;
            this.commandBarItem88.Name = "commandBarItem88";
            superToolTip106.FixedTooltipWidth = true;
            toolTipTitleItem106.Text = "Merge Cells";
            toolTipItem106.LeftIndent = 6;
            toolTipItem106.Text = "Merge the selected cells into one cell.";
            superToolTip106.Items.Add(toolTipTitleItem106);
            superToolTip106.Items.Add(toolTipItem106);
            superToolTip106.MaxWidth = 210;
            this.commandBarItem88.SuperTip = superToolTip106;
            // 
            // commandBarItem89
            // 
            this.commandBarItem89.Caption = "Split Cells";
            this.commandBarItem89.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.TableSplitCells;
            this.commandBarItem89.Enabled = false;
            this.commandBarItem89.Id = 111;
            this.commandBarItem89.Name = "commandBarItem89";
            superToolTip107.FixedTooltipWidth = true;
            toolTipTitleItem107.Text = "Split Cells";
            toolTipItem107.LeftIndent = 6;
            toolTipItem107.Text = "Split the selected cells into the specified number of rows or columns.";
            superToolTip107.Items.Add(toolTipTitleItem107);
            superToolTip107.Items.Add(toolTipItem107);
            superToolTip107.MaxWidth = 210;
            this.commandBarItem89.SuperTip = superToolTip107;
            // 
            // commandBarItem90
            // 
            this.commandBarItem90.Caption = "Run Designer";
            this.commandBarItem90.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridRunDesigner;
            this.commandBarItem90.Enabled = false;
            this.commandBarItem90.Id = 112;
            this.commandBarItem90.Name = "commandBarItem90";
            superToolTip108.FixedTooltipWidth = true;
            toolTipTitleItem108.Text = "Run Designer";
            toolTipItem108.LeftIndent = 6;
            toolTipItem108.Text = "Run the Pivot Grid Designer that allows customizing fields, the control\'s layout," +
    " appearance settings and printing options.";
            superToolTip108.Items.Add(toolTipTitleItem108);
            superToolTip108.Items.Add(toolTipItem108);
            superToolTip108.MaxWidth = 210;
            this.commandBarItem90.SuperTip = superToolTip108;
            // 
            // commandBarItem91
            // 
            this.commandBarItem91.Caption = "Add Data Source";
            this.commandBarItem91.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridAddDataSource;
            this.commandBarItem91.Enabled = false;
            this.commandBarItem91.Id = 113;
            this.commandBarItem91.Name = "commandBarItem91";
            superToolTip109.FixedTooltipWidth = true;
            toolTipTitleItem109.Text = "Add Data Source";
            toolTipItem109.LeftIndent = 6;
            toolTipItem109.Text = "Set up a data source for a Pivot Grid.";
            superToolTip109.Items.Add(toolTipTitleItem109);
            superToolTip109.Items.Add(toolTipItem109);
            superToolTip109.MaxWidth = 210;
            this.commandBarItem91.SuperTip = superToolTip109;
            // 
            // commandBarItem92
            // 
            this.commandBarItem92.Caption = "Remove Field";
            this.commandBarItem92.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridRemoveField;
            this.commandBarItem92.Enabled = false;
            this.commandBarItem92.Id = 114;
            this.commandBarItem92.Name = "commandBarItem92";
            superToolTip110.FixedTooltipWidth = true;
            toolTipTitleItem110.Text = "Remove Field";
            toolTipItem110.LeftIndent = 6;
            toolTipItem110.Text = "Remove the selected Pivot Grid field.";
            superToolTip110.Items.Add(toolTipTitleItem110);
            superToolTip110.Items.Add(toolTipItem110);
            superToolTip110.MaxWidth = 210;
            this.commandBarItem92.SuperTip = superToolTip110;
            // 
            // commandBarItem93
            // 
            this.commandBarItem93.ActAsDropDown = true;
            this.commandBarItem93.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem93.Caption = "Add Field";
            this.commandBarItem93.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridAddField;
            this.commandBarItem93.Enabled = false;
            this.commandBarItem93.Id = 115;
            this.commandBarItem93.Name = "commandBarItem93";
            superToolTip111.FixedTooltipWidth = true;
            toolTipTitleItem111.Text = "Add Field";
            toolTipItem111.LeftIndent = 6;
            toolTipItem111.Text = "Add a new Pivot Grid field to a required header area.";
            superToolTip111.Items.Add(toolTipTitleItem111);
            superToolTip111.Items.Add(toolTipItem111);
            superToolTip111.MaxWidth = 210;
            this.commandBarItem93.SuperTip = superToolTip111;
            // 
            // commandBarItem94
            // 
            this.commandBarItem94.Caption = "Vertical Lines";
            this.commandBarItem94.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridVerticalLines;
            this.commandBarItem94.Enabled = false;
            this.commandBarItem94.Id = 116;
            this.commandBarItem94.Name = "commandBarItem94";
            superToolTip112.FixedTooltipWidth = true;
            toolTipTitleItem112.Text = "Print Vertical Lines";
            toolTipItem112.LeftIndent = 6;
            toolTipItem112.Text = "Print vertical grid lines.";
            superToolTip112.Items.Add(toolTipTitleItem112);
            superToolTip112.Items.Add(toolTipItem112);
            superToolTip112.MaxWidth = 210;
            this.commandBarItem94.SuperTip = superToolTip112;
            // 
            // commandBarItem95
            // 
            this.commandBarItem95.Caption = "Horizontal Lines";
            this.commandBarItem95.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridHorizontalLines;
            this.commandBarItem95.Enabled = false;
            this.commandBarItem95.Id = 117;
            this.commandBarItem95.Name = "commandBarItem95";
            superToolTip113.FixedTooltipWidth = true;
            toolTipTitleItem113.Text = "Print Horizontal Lines";
            toolTipItem113.LeftIndent = 6;
            toolTipItem113.Text = "Print horizontal grid lines.";
            superToolTip113.Items.Add(toolTipTitleItem113);
            superToolTip113.Items.Add(toolTipItem113);
            superToolTip113.MaxWidth = 210;
            this.commandBarItem95.SuperTip = superToolTip113;
            // 
            // commandBarItem96
            // 
            this.commandBarItem96.Caption = "Data Headers";
            this.commandBarItem96.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridDataHeaders;
            this.commandBarItem96.Enabled = false;
            this.commandBarItem96.Id = 118;
            this.commandBarItem96.Name = "commandBarItem96";
            superToolTip114.FixedTooltipWidth = true;
            toolTipTitleItem114.Text = "Print Data Headers";
            toolTipItem114.LeftIndent = 6;
            toolTipItem114.Text = "Print data field headers.";
            superToolTip114.Items.Add(toolTipTitleItem114);
            superToolTip114.Items.Add(toolTipItem114);
            superToolTip114.MaxWidth = 210;
            this.commandBarItem96.SuperTip = superToolTip114;
            // 
            // commandBarItem97
            // 
            this.commandBarItem97.Caption = "Column Headers";
            this.commandBarItem97.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridColumnHeaders;
            this.commandBarItem97.Enabled = false;
            this.commandBarItem97.Id = 119;
            this.commandBarItem97.Name = "commandBarItem97";
            superToolTip115.FixedTooltipWidth = true;
            toolTipTitleItem115.Text = "Print Column Headers";
            toolTipItem115.LeftIndent = 6;
            toolTipItem115.Text = "Print column field headers.";
            superToolTip115.Items.Add(toolTipTitleItem115);
            superToolTip115.Items.Add(toolTipItem115);
            superToolTip115.MaxWidth = 210;
            this.commandBarItem97.SuperTip = superToolTip115;
            // 
            // commandBarItem98
            // 
            this.commandBarItem98.Caption = "Row Headers";
            this.commandBarItem98.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridRowHeaders;
            this.commandBarItem98.Enabled = false;
            this.commandBarItem98.Id = 120;
            this.commandBarItem98.Name = "commandBarItem98";
            superToolTip116.FixedTooltipWidth = true;
            toolTipTitleItem116.Text = "Print Row Headers";
            toolTipItem116.LeftIndent = 6;
            toolTipItem116.Text = "Print row field headers.";
            superToolTip116.Items.Add(toolTipTitleItem116);
            superToolTip116.Items.Add(toolTipItem116);
            superToolTip116.MaxWidth = 210;
            this.commandBarItem98.SuperTip = superToolTip116;
            // 
            // commandBarItem99
            // 
            this.commandBarItem99.Caption = "Column Area On Every Page";
            this.commandBarItem99.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridColumnAreaOnEveryPage;
            this.commandBarItem99.Enabled = false;
            this.commandBarItem99.Id = 121;
            this.commandBarItem99.Name = "commandBarItem99";
            this.commandBarItem99.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip117.FixedTooltipWidth = true;
            toolTipTitleItem117.Text = "Print Column Area On Every Page";
            toolTipItem117.LeftIndent = 6;
            toolTipItem117.Text = "Print column area on every page.";
            superToolTip117.Items.Add(toolTipTitleItem117);
            superToolTip117.Items.Add(toolTipItem117);
            superToolTip117.MaxWidth = 210;
            this.commandBarItem99.SuperTip = superToolTip117;
            // 
            // commandBarItem100
            // 
            this.commandBarItem100.Caption = "Row Area On Every Page";
            this.commandBarItem100.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.PivotGridRowAreaOnEveryPage;
            this.commandBarItem100.Enabled = false;
            this.commandBarItem100.Id = 122;
            this.commandBarItem100.Name = "commandBarItem100";
            this.commandBarItem100.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip118.FixedTooltipWidth = true;
            toolTipTitleItem118.Text = "Print Row Area On Every Page";
            toolTipItem118.LeftIndent = 6;
            toolTipItem118.Text = "Print row area on every page.";
            superToolTip118.Items.Add(toolTipTitleItem118);
            superToolTip118.Items.Add(toolTipItem118);
            superToolTip118.MaxWidth = 210;
            this.commandBarItem100.SuperTip = superToolTip118;
            // 
            // commandBarItem101
            // 
            this.commandBarItem101.Caption = "Load...";
            this.commandBarItem101.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartLoad;
            this.commandBarItem101.Enabled = false;
            this.commandBarItem101.Id = 123;
            this.commandBarItem101.Name = "commandBarItem101";
            this.commandBarItem101.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip119.FixedTooltipWidth = true;
            toolTipTitleItem119.Text = "Load";
            toolTipItem119.LeftIndent = 6;
            toolTipItem119.Text = "Load a chart from an XML file.";
            superToolTip119.Items.Add(toolTipTitleItem119);
            superToolTip119.Items.Add(toolTipItem119);
            superToolTip119.MaxWidth = 210;
            this.commandBarItem101.SuperTip = superToolTip119;
            // 
            // commandBarItem102
            // 
            this.commandBarItem102.Caption = "Save...";
            this.commandBarItem102.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartSave;
            this.commandBarItem102.Enabled = false;
            this.commandBarItem102.Id = 124;
            this.commandBarItem102.Name = "commandBarItem102";
            this.commandBarItem102.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            superToolTip120.FixedTooltipWidth = true;
            toolTipTitleItem120.Text = "Save";
            toolTipItem120.LeftIndent = 6;
            toolTipItem120.Text = "Save a chart to an XML file.";
            superToolTip120.Items.Add(toolTipTitleItem120);
            superToolTip120.Items.Add(toolTipItem120);
            superToolTip120.MaxWidth = 210;
            this.commandBarItem102.SuperTip = superToolTip120;
            // 
            // commandBarItem103
            // 
            this.commandBarItem103.Caption = "Run Designer";
            this.commandBarItem103.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartRunDesigner;
            this.commandBarItem103.Enabled = false;
            this.commandBarItem103.Id = 125;
            this.commandBarItem103.Name = "commandBarItem103";
            superToolTip121.FixedTooltipWidth = true;
            toolTipTitleItem121.Text = "Run Designer";
            toolTipItem121.LeftIndent = 6;
            toolTipItem121.Text = "Run the Chart Designer that allows creating and editing properties of a chart and" +
    " its elements.";
            superToolTip121.Items.Add(toolTipTitleItem121);
            superToolTip121.Items.Add(toolTipItem121);
            superToolTip121.MaxWidth = 210;
            this.commandBarItem103.SuperTip = superToolTip121;
            // 
            // commandBarItem104
            // 
            this.commandBarItem104.Caption = "Add Data Source";
            this.commandBarItem104.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddDataSource;
            this.commandBarItem104.Enabled = false;
            this.commandBarItem104.Id = 126;
            this.commandBarItem104.Name = "commandBarItem104";
            superToolTip122.FixedTooltipWidth = true;
            toolTipTitleItem122.Text = "Add Data Source";
            toolTipItem122.LeftIndent = 6;
            toolTipItem122.Text = "Set up a data source for a chart.";
            superToolTip122.Items.Add(toolTipTitleItem122);
            superToolTip122.Items.Add(toolTipItem122);
            superToolTip122.MaxWidth = 210;
            this.commandBarItem104.SuperTip = superToolTip122;
            // 
            // commandBarItem105
            // 
            this.commandBarItem105.ActAsDropDown = true;
            this.commandBarItem105.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem105.Caption = "Palette";
            this.commandBarItem105.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartPaletteName;
            this.commandBarItem105.Enabled = false;
            this.commandBarItem105.Id = 127;
            this.commandBarItem105.Name = "commandBarItem105";
            superToolTip123.FixedTooltipWidth = true;
            toolTipTitleItem123.Text = "Palette";
            toolTipItem123.LeftIndent = 6;
            toolTipItem123.Text = "Select a palette for painting a chart\'s series.";
            superToolTip123.Items.Add(toolTipTitleItem123);
            superToolTip123.Items.Add(toolTipItem123);
            superToolTip123.MaxWidth = 210;
            this.commandBarItem105.SuperTip = superToolTip123;
            // 
            // commandBarItem106
            // 
            this.commandBarItem106.ActAsDropDown = true;
            this.commandBarItem106.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem106.Caption = "Bar";
            this.commandBarItem106.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddSeriesViewBar;
            this.commandBarItem106.Enabled = false;
            this.commandBarItem106.Id = 128;
            this.commandBarItem106.Name = "commandBarItem106";
            superToolTip124.FixedTooltipWidth = true;
            toolTipTitleItem124.Text = "Bar Series";
            toolTipItem124.LeftIndent = 6;
            toolTipItem124.Text = "Add a bar series to display values as vertical columns grouped by categories.";
            superToolTip124.Items.Add(toolTipTitleItem124);
            superToolTip124.Items.Add(toolTipItem124);
            superToolTip124.MaxWidth = 210;
            this.commandBarItem106.SuperTip = superToolTip124;
            // 
            // commandBarItem107
            // 
            this.commandBarItem107.ActAsDropDown = true;
            this.commandBarItem107.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem107.Caption = "Line";
            this.commandBarItem107.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddSeriesViewLine;
            this.commandBarItem107.Enabled = false;
            this.commandBarItem107.Id = 129;
            this.commandBarItem107.Name = "commandBarItem107";
            superToolTip125.FixedTooltipWidth = true;
            toolTipTitleItem125.Text = "Line Series";
            toolTipItem125.LeftIndent = 6;
            toolTipItem125.Text = "Add a line series to show line trends over time or categories.";
            superToolTip125.Items.Add(toolTipTitleItem125);
            superToolTip125.Items.Add(toolTipItem125);
            superToolTip125.MaxWidth = 210;
            this.commandBarItem107.SuperTip = superToolTip125;
            // 
            // commandBarItem108
            // 
            this.commandBarItem108.ActAsDropDown = true;
            this.commandBarItem108.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem108.Caption = "Area";
            this.commandBarItem108.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddSeriesViewArea;
            this.commandBarItem108.Enabled = false;
            this.commandBarItem108.Id = 130;
            this.commandBarItem108.Name = "commandBarItem108";
            superToolTip126.FixedTooltipWidth = true;
            toolTipTitleItem126.Text = "Area Series";
            toolTipItem126.LeftIndent = 6;
            toolTipItem126.Text = "Add an area series to display values as a filled area with peaks and hollows.";
            superToolTip126.Items.Add(toolTipTitleItem126);
            superToolTip126.Items.Add(toolTipItem126);
            superToolTip126.MaxWidth = 210;
            this.commandBarItem108.SuperTip = superToolTip126;
            // 
            // commandBarItem109
            // 
            this.commandBarItem109.ActAsDropDown = true;
            this.commandBarItem109.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem109.Caption = "Range";
            this.commandBarItem109.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddSeriesViewRange;
            this.commandBarItem109.Enabled = false;
            this.commandBarItem109.Id = 131;
            this.commandBarItem109.Name = "commandBarItem109";
            superToolTip127.FixedTooltipWidth = true;
            toolTipTitleItem127.Text = "Range Series";
            toolTipItem127.LeftIndent = 6;
            toolTipItem127.Text = "Add a series to display a range of values with the minimum and maximum limits. ";
            superToolTip127.Items.Add(toolTipTitleItem127);
            superToolTip127.Items.Add(toolTipItem127);
            superToolTip127.MaxWidth = 210;
            this.commandBarItem109.SuperTip = superToolTip127;
            // 
            // commandBarItem110
            // 
            this.commandBarItem110.ActAsDropDown = true;
            this.commandBarItem110.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem110.Caption = "Pie and Doughnut";
            this.commandBarItem110.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddSeriesViewPieAndDoughnut;
            this.commandBarItem110.Enabled = false;
            this.commandBarItem110.Id = 132;
            this.commandBarItem110.Name = "commandBarItem110";
            superToolTip128.FixedTooltipWidth = true;
            toolTipTitleItem128.Text = "Pie And Doughnut Series";
            toolTipItem128.LeftIndent = 6;
            toolTipItem128.Text = "Add a series to display the percentage values of different point arguments to com" +
    "pare their significance.";
            superToolTip128.Items.Add(toolTipTitleItem128);
            superToolTip128.Items.Add(toolTipItem128);
            superToolTip128.MaxWidth = 210;
            this.commandBarItem110.SuperTip = superToolTip128;
            // 
            // commandBarItem111
            // 
            this.commandBarItem111.ActAsDropDown = true;
            this.commandBarItem111.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem111.Caption = "Radar and Polar";
            this.commandBarItem111.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddSeriesViewRadarAndPolar;
            this.commandBarItem111.Enabled = false;
            this.commandBarItem111.Id = 133;
            this.commandBarItem111.Name = "commandBarItem111";
            superToolTip129.FixedTooltipWidth = true;
            toolTipTitleItem129.Text = "Radar And Polar Series";
            toolTipItem129.LeftIndent = 6;
            toolTipItem129.Text = "Add a series to display values as a circular graph.";
            superToolTip129.Items.Add(toolTipTitleItem129);
            superToolTip129.Items.Add(toolTipItem129);
            superToolTip129.MaxWidth = 210;
            this.commandBarItem111.SuperTip = superToolTip129;
            // 
            // commandBarItem112
            // 
            this.commandBarItem112.ActAsDropDown = true;
            this.commandBarItem112.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem112.Caption = "Other Series";
            this.commandBarItem112.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddSeriesViewOther;
            this.commandBarItem112.Enabled = false;
            this.commandBarItem112.Id = 134;
            this.commandBarItem112.Name = "commandBarItem112";
            superToolTip130.FixedTooltipWidth = true;
            toolTipTitleItem130.Text = "Other Series";
            toolTipItem130.LeftIndent = 6;
            toolTipItem130.Text = "Choose a chart type to display your data.";
            superToolTip130.Items.Add(toolTipTitleItem130);
            superToolTip130.Items.Add(toolTipItem130);
            superToolTip130.MaxWidth = 210;
            this.commandBarItem112.SuperTip = superToolTip130;
            // 
            // commandBarItem113
            // 
            this.commandBarItem113.Caption = "Remove Series";
            this.commandBarItem113.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartRemoveSeries;
            this.commandBarItem113.Enabled = false;
            this.commandBarItem113.Id = 135;
            this.commandBarItem113.Name = "commandBarItem113";
            superToolTip131.FixedTooltipWidth = true;
            toolTipTitleItem131.Text = "Remove Series";
            toolTipItem131.LeftIndent = 6;
            toolTipItem131.Text = "Remove the selected series.";
            superToolTip131.Items.Add(toolTipTitleItem131);
            superToolTip131.Items.Add(toolTipItem131);
            superToolTip131.MaxWidth = 210;
            this.commandBarItem113.SuperTip = superToolTip131;
            // 
            // commandBarItem114
            // 
            this.commandBarItem114.Caption = "Add Text Annotation";
            this.commandBarItem114.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddTextAnnotation;
            this.commandBarItem114.Enabled = false;
            this.commandBarItem114.Id = 136;
            this.commandBarItem114.Name = "commandBarItem114";
            superToolTip132.FixedTooltipWidth = true;
            toolTipTitleItem132.Text = "Add Text Annotation";
            toolTipItem132.LeftIndent = 6;
            toolTipItem132.Text = "Add a text annotation to a chart.";
            superToolTip132.Items.Add(toolTipTitleItem132);
            superToolTip132.Items.Add(toolTipItem132);
            superToolTip132.MaxWidth = 210;
            this.commandBarItem114.SuperTip = superToolTip132;
            // 
            // commandBarItem115
            // 
            this.commandBarItem115.Caption = "Add Image Annotation";
            this.commandBarItem115.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartAddImageAnnotation;
            this.commandBarItem115.Enabled = false;
            this.commandBarItem115.Id = 137;
            this.commandBarItem115.Name = "commandBarItem115";
            superToolTip133.FixedTooltipWidth = true;
            toolTipTitleItem133.Text = "Add Image Annotation";
            toolTipItem133.LeftIndent = 6;
            toolTipItem133.Text = "Add an image annotation to a chart.";
            superToolTip133.Items.Add(toolTipTitleItem133);
            superToolTip133.Items.Add(toolTipItem133);
            superToolTip133.MaxWidth = 210;
            this.commandBarItem115.SuperTip = superToolTip133;
            // 
            // commandBarItem116
            // 
            this.commandBarItem116.Caption = "Remove Annotation";
            this.commandBarItem116.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ChartRemoveAnnotation;
            this.commandBarItem116.Enabled = false;
            this.commandBarItem116.Id = 138;
            this.commandBarItem116.Name = "commandBarItem116";
            superToolTip134.FixedTooltipWidth = true;
            toolTipTitleItem134.Text = "Remove Annotation";
            toolTipItem134.LeftIndent = 6;
            toolTipItem134.Text = "Remove the selected annotation.";
            superToolTip134.Items.Add(toolTipTitleItem134);
            superToolTip134.Items.Add(toolTipItem134);
            superToolTip134.MaxWidth = 210;
            this.commandBarItem116.SuperTip = superToolTip134;
            // 
            // commandBarItem117
            // 
            this.commandBarItem117.Caption = "Auto Module";
            this.commandBarItem117.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BarCodeAutoModule;
            this.commandBarItem117.Enabled = false;
            this.commandBarItem117.Id = 139;
            this.commandBarItem117.Name = "commandBarItem117";
            superToolTip135.FixedTooltipWidth = true;
            toolTipTitleItem135.Text = "Auto Module";
            toolTipItem135.LeftIndent = 6;
            toolTipItem135.Text = "Automatically calculate the bar width based on bar code dimensions.";
            superToolTip135.Items.Add(toolTipTitleItem135);
            superToolTip135.Items.Add(toolTipItem135);
            superToolTip135.MaxWidth = 210;
            this.commandBarItem117.SuperTip = superToolTip135;
            // 
            // commandBarItem118
            // 
            this.commandBarItem118.Caption = "Show Text";
            this.commandBarItem118.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BarCodeShowText;
            this.commandBarItem118.Enabled = false;
            this.commandBarItem118.Id = 140;
            this.commandBarItem118.Name = "commandBarItem118";
            superToolTip136.FixedTooltipWidth = true;
            toolTipTitleItem136.Text = "Show Text";
            toolTipItem136.LeftIndent = 6;
            toolTipItem136.Text = "Display accompanying text in a bar code.";
            superToolTip136.Items.Add(toolTipTitleItem136);
            superToolTip136.Items.Add(toolTipItem136);
            superToolTip136.MaxWidth = 210;
            this.commandBarItem118.SuperTip = superToolTip136;
            // 
            // commandBarItem119
            // 
            this.commandBarItem119.Caption = "Fit Bounds To Text";
            this.commandBarItem119.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FitBoundsToText;
            this.commandBarItem119.Enabled = false;
            this.commandBarItem119.Id = 141;
            this.commandBarItem119.Name = "commandBarItem119";
            superToolTip137.FixedTooltipWidth = true;
            toolTipTitleItem137.Text = "Fit Bounds To Text";
            toolTipItem137.LeftIndent = 6;
            toolTipItem137.Text = "Adjust the size of the selected controls to fit their text.";
            superToolTip137.Items.Add(toolTipTitleItem137);
            superToolTip137.Items.Add(toolTipItem137);
            superToolTip137.MaxWidth = 210;
            this.commandBarItem119.SuperTip = superToolTip137;
            // 
            // commandBarItem120
            // 
            this.commandBarItem120.Caption = "Fit Text To Bounds";
            this.commandBarItem120.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FitTextToBounds;
            this.commandBarItem120.Enabled = false;
            this.commandBarItem120.Id = 142;
            this.commandBarItem120.Name = "commandBarItem120";
            superToolTip138.FixedTooltipWidth = true;
            toolTipTitleItem138.Text = "Fit Text To Bounds";
            toolTipItem138.LeftIndent = 6;
            toolTipItem138.Text = "Adjust the font size of the selected controls to fit their entire area.";
            superToolTip138.Items.Add(toolTipTitleItem138);
            superToolTip138.Items.Add(toolTipItem138);
            superToolTip138.MaxWidth = 210;
            this.commandBarItem120.SuperTip = superToolTip138;
            // 
            // commandBarCheckItem3
            // 
            this.commandBarCheckItem3.Caption = "Auto Width";
            this.commandBarCheckItem3.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.commandBarCheckItem3.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.LabelAutoWidth;
            this.commandBarCheckItem3.Enabled = false;
            this.commandBarCheckItem3.Id = 143;
            this.commandBarCheckItem3.Name = "commandBarCheckItem3";
            superToolTip139.FixedTooltipWidth = true;
            toolTipTitleItem139.Text = "Auto Width";
            toolTipItem139.LeftIndent = 6;
            toolTipItem139.Text = "Enable the selected controls to adjust their width to fit their content.";
            superToolTip139.Items.Add(toolTipTitleItem139);
            superToolTip139.Items.Add(toolTipItem139);
            superToolTip139.MaxWidth = 210;
            this.commandBarCheckItem3.SuperTip = superToolTip139;
            // 
            // commandBarCheckItem4
            // 
            this.commandBarCheckItem4.Caption = "Word Wrap";
            this.commandBarCheckItem4.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.commandBarCheckItem4.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.LabelWordWrap;
            this.commandBarCheckItem4.Enabled = false;
            this.commandBarCheckItem4.Id = 144;
            this.commandBarCheckItem4.Name = "commandBarCheckItem4";
            superToolTip140.FixedTooltipWidth = true;
            toolTipTitleItem140.Text = "Word Wrap";
            toolTipItem140.LeftIndent = 6;
            toolTipItem140.Text = "Enable the selected controls to wrap their text if it does not fit a line.";
            superToolTip140.Items.Add(toolTipTitleItem140);
            superToolTip140.Items.Add(toolTipItem140);
            superToolTip140.MaxWidth = 210;
            this.commandBarCheckItem4.SuperTip = superToolTip140;
            // 
            // commandBarCheckItem5
            // 
            this.commandBarCheckItem5.Caption = "Can Shrink";
            this.commandBarCheckItem5.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.commandBarCheckItem5.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.LabelCanShrink;
            this.commandBarCheckItem5.Enabled = false;
            this.commandBarCheckItem5.Id = 145;
            this.commandBarCheckItem5.Name = "commandBarCheckItem5";
            superToolTip141.FixedTooltipWidth = true;
            toolTipTitleItem141.Text = "Can Shrink";
            toolTipItem141.LeftIndent = 6;
            toolTipItem141.Text = "Enable the selected controls to decrease their height to fit their content.";
            superToolTip141.Items.Add(toolTipTitleItem141);
            superToolTip141.Items.Add(toolTipItem141);
            superToolTip141.MaxWidth = 210;
            this.commandBarCheckItem5.SuperTip = superToolTip141;
            // 
            // commandBarCheckItem6
            // 
            this.commandBarCheckItem6.Caption = "Can Grow";
            this.commandBarCheckItem6.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.commandBarCheckItem6.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.LabelCanGrow;
            this.commandBarCheckItem6.Enabled = false;
            this.commandBarCheckItem6.Id = 146;
            this.commandBarCheckItem6.Name = "commandBarCheckItem6";
            superToolTip142.FixedTooltipWidth = true;
            toolTipTitleItem142.Text = "Can Grow";
            toolTipItem142.LeftIndent = 6;
            toolTipItem142.Text = "Enable the selected controls to increase their height to fit their content.";
            superToolTip142.Items.Add(toolTipTitleItem142);
            superToolTip142.Items.Add(toolTipItem142);
            superToolTip142.MaxWidth = 210;
            this.commandBarCheckItem6.SuperTip = superToolTip142;
            // 
            // commandBarCheckItem7
            // 
            this.commandBarCheckItem7.Caption = "Auto Width";
            this.commandBarCheckItem7.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.commandBarCheckItem7.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CharacterCombCellAutoWidth;
            this.commandBarCheckItem7.Enabled = false;
            this.commandBarCheckItem7.Id = 147;
            this.commandBarCheckItem7.Name = "commandBarCheckItem7";
            superToolTip143.FixedTooltipWidth = true;
            toolTipTitleItem143.Text = "Cell Auto Width";
            toolTipItem143.LeftIndent = 6;
            toolTipItem143.Text = "Automatically adjust the cell width depending on the current font size.";
            superToolTip143.Items.Add(toolTipTitleItem143);
            superToolTip143.Items.Add(toolTipItem143);
            superToolTip143.MaxWidth = 210;
            this.commandBarCheckItem7.SuperTip = superToolTip143;
            // 
            // commandBarCheckItem8
            // 
            this.commandBarCheckItem8.Caption = "Auto Height";
            this.commandBarCheckItem8.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.commandBarCheckItem8.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CharacterCombCellAutoHeight;
            this.commandBarCheckItem8.Enabled = false;
            this.commandBarCheckItem8.Id = 148;
            this.commandBarCheckItem8.Name = "commandBarCheckItem8";
            superToolTip144.FixedTooltipWidth = true;
            toolTipTitleItem144.Text = "Cell Auto Height";
            toolTipItem144.LeftIndent = 6;
            toolTipItem144.Text = "Automatically adjust the cell height depending on the current font size.";
            superToolTip144.Items.Add(toolTipTitleItem144);
            superToolTip144.Items.Add(toolTipItem144);
            superToolTip144.MaxWidth = 210;
            this.commandBarCheckItem8.SuperTip = superToolTip144;
            // 
            // commandBarItem121
            // 
            this.commandBarItem121.Caption = "Add Data Source";
            this.commandBarItem121.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SparklineAddDataSource;
            this.commandBarItem121.Enabled = false;
            this.commandBarItem121.Id = 149;
            this.commandBarItem121.Name = "commandBarItem121";
            superToolTip145.FixedTooltipWidth = true;
            toolTipTitleItem145.Text = "Add Data Source";
            toolTipItem145.LeftIndent = 6;
            toolTipItem145.Text = "Set up a data source for a sparkline.";
            superToolTip145.Items.Add(toolTipTitleItem145);
            superToolTip145.Items.Add(toolTipItem145);
            superToolTip145.MaxWidth = 210;
            this.commandBarItem121.SuperTip = superToolTip145;
            // 
            // commandBarItem122
            // 
            this.commandBarItem122.Caption = "Flat Light";
            this.commandBarItem122.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.GaugeViewThemeLight;
            this.commandBarItem122.Enabled = false;
            this.commandBarItem122.Id = 150;
            this.commandBarItem122.Name = "commandBarItem122";
            superToolTip146.FixedTooltipWidth = true;
            toolTipTitleItem146.Text = "Flat Light Theme";
            toolTipItem146.LeftIndent = 6;
            toolTipItem146.Text = "Set the Flat Light color theme for a gauge.";
            superToolTip146.Items.Add(toolTipTitleItem146);
            superToolTip146.Items.Add(toolTipItem146);
            superToolTip146.MaxWidth = 210;
            this.commandBarItem122.SuperTip = superToolTip146;
            // 
            // commandBarItem123
            // 
            this.commandBarItem123.Caption = "Flat Dark";
            this.commandBarItem123.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.GaugeViewThemeDark;
            this.commandBarItem123.Enabled = false;
            this.commandBarItem123.Id = 151;
            this.commandBarItem123.Name = "commandBarItem123";
            superToolTip147.FixedTooltipWidth = true;
            toolTipTitleItem147.Text = "Flat Dark Theme";
            toolTipItem147.LeftIndent = 6;
            toolTipItem147.Text = "Set the Flat Dark color theme for a gauge.";
            superToolTip147.Items.Add(toolTipTitleItem147);
            superToolTip147.Items.Add(toolTipItem147);
            superToolTip147.MaxWidth = 210;
            this.commandBarItem123.SuperTip = superToolTip147;
            // 
            // commandBarItem124
            // 
            this.commandBarItem124.Caption = "Stretch";
            this.commandBarItem124.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ShapeStretch;
            this.commandBarItem124.Enabled = false;
            this.commandBarItem124.Id = 152;
            this.commandBarItem124.Name = "commandBarItem124";
            superToolTip148.FixedTooltipWidth = true;
            toolTipTitleItem148.Text = "Stretch";
            toolTipItem148.LeftIndent = 6;
            toolTipItem148.Text = "Stretch a shape to fill its entire area when it is rotated.";
            superToolTip148.Items.Add(toolTipTitleItem148);
            superToolTip148.Items.Add(toolTipItem148);
            superToolTip148.MaxWidth = 210;
            this.commandBarItem124.SuperTip = superToolTip148;
            // 
            // xrDesignBarButtonGroup1
            // 
            this.xrDesignBarButtonGroup1.Id = 155;
            this.xrDesignBarButtonGroup1.ItemLinks.Add(this.barEditItem1);
            this.xrDesignBarButtonGroup1.ItemLinks.Add(this.barEditItem2);
            this.xrDesignBarButtonGroup1.Name = "xrDesignBarButtonGroup1";
            // 
            // xrDesignBarButtonGroup2
            // 
            this.xrDesignBarButtonGroup2.Id = 156;
            this.xrDesignBarButtonGroup2.ItemLinks.Add(this.commandBarItem17);
            this.xrDesignBarButtonGroup2.ItemLinks.Add(this.commandBarItem18);
            this.xrDesignBarButtonGroup2.ItemLinks.Add(this.commandBarItem19);
            this.xrDesignBarButtonGroup2.ItemLinks.Add(this.commandBarItem24);
            this.xrDesignBarButtonGroup2.Name = "xrDesignBarButtonGroup2";
            // 
            // xrDesignBarButtonGroup3
            // 
            this.xrDesignBarButtonGroup3.Id = 157;
            this.xrDesignBarButtonGroup3.ItemLinks.Add(this.commandColorBarItem2);
            this.xrDesignBarButtonGroup3.ItemLinks.Add(this.commandColorBarItem1);
            this.xrDesignBarButtonGroup3.Name = "xrDesignBarButtonGroup3";
            // 
            // xrDesignBarButtonGroup4
            // 
            this.xrDesignBarButtonGroup4.Id = 158;
            this.xrDesignBarButtonGroup4.ItemLinks.Add(this.commandBarItem25);
            this.xrDesignBarButtonGroup4.ItemLinks.Add(this.commandBarItem26);
            this.xrDesignBarButtonGroup4.ItemLinks.Add(this.commandBarItem27);
            this.xrDesignBarButtonGroup4.Name = "xrDesignBarButtonGroup4";
            // 
            // xrDesignBarButtonGroup5
            // 
            this.xrDesignBarButtonGroup5.Id = 159;
            this.xrDesignBarButtonGroup5.ItemLinks.Add(this.commandBarItem20);
            this.xrDesignBarButtonGroup5.ItemLinks.Add(this.commandBarItem21);
            this.xrDesignBarButtonGroup5.ItemLinks.Add(this.commandBarItem22);
            this.xrDesignBarButtonGroup5.ItemLinks.Add(this.commandBarItem23);
            this.xrDesignBarButtonGroup5.Name = "xrDesignBarButtonGroup5";
            // 
            // xrDesignBarButtonGroup6
            // 
            this.xrDesignBarButtonGroup6.Id = 160;
            this.xrDesignBarButtonGroup6.ItemLinks.Add(this.commandBarItem32);
            this.xrDesignBarButtonGroup6.ItemLinks.Add(this.commandBarItem33);
            this.xrDesignBarButtonGroup6.Name = "xrDesignBarButtonGroup6";
            // 
            // xrDesignBarButtonGroup7
            // 
            this.xrDesignBarButtonGroup7.Id = 161;
            this.xrDesignBarButtonGroup7.ItemLinks.Add(this.commandBarItem34);
            this.xrDesignBarButtonGroup7.ItemLinks.Add(this.commandBarItem35);
            this.xrDesignBarButtonGroup7.ItemLinks.Add(this.commandBarItem36);
            this.xrDesignBarButtonGroup7.ItemLinks.Add(this.commandBarItem37);
            this.xrDesignBarButtonGroup7.Name = "xrDesignBarButtonGroup7";
            // 
            // xrDesignBarButtonGroup8
            // 
            this.xrDesignBarButtonGroup8.Id = 162;
            this.xrDesignBarButtonGroup8.ItemLinks.Add(this.commandColorBarItem3);
            this.xrDesignBarButtonGroup8.ItemLinks.Add(this.commandBarItem38);
            this.xrDesignBarButtonGroup8.ItemLinks.Add(this.commandBarEditItem5);
            this.xrDesignBarButtonGroup8.Name = "xrDesignBarButtonGroup8";
            // 
            // xrDesignBarButtonGroup9
            // 
            this.xrDesignBarButtonGroup9.Id = 163;
            this.xrDesignBarButtonGroup9.ItemLinks.Add(this.commandBarItem40);
            this.xrDesignBarButtonGroup9.ItemLinks.Add(this.commandBarItem41);
            this.xrDesignBarButtonGroup9.ItemLinks.Add(this.commandBarItem42);
            this.xrDesignBarButtonGroup9.Name = "xrDesignBarButtonGroup9";
            // 
            // xrDesignBarButtonGroup10
            // 
            this.xrDesignBarButtonGroup10.Id = 164;
            this.xrDesignBarButtonGroup10.ItemLinks.Add(this.commandBarItem43);
            this.xrDesignBarButtonGroup10.ItemLinks.Add(this.commandBarItem44);
            this.xrDesignBarButtonGroup10.ItemLinks.Add(this.commandBarItem45);
            this.xrDesignBarButtonGroup10.Name = "xrDesignBarButtonGroup10";
            // 
            // xrDesignBarButtonGroup11
            // 
            this.xrDesignBarButtonGroup11.Id = 165;
            this.xrDesignBarButtonGroup11.ItemLinks.Add(this.commandBarItem50);
            this.xrDesignBarButtonGroup11.ItemLinks.Add(this.commandBarItem51);
            this.xrDesignBarButtonGroup11.ItemLinks.Add(this.commandBarItem52);
            this.xrDesignBarButtonGroup11.ItemLinks.Add(this.commandBarItem53);
            this.xrDesignBarButtonGroup11.Name = "xrDesignBarButtonGroup11";
            // 
            // xrDesignBarButtonGroup12
            // 
            this.xrDesignBarButtonGroup12.Id = 166;
            this.xrDesignBarButtonGroup12.ItemLinks.Add(this.commandBarItem46);
            this.xrDesignBarButtonGroup12.ItemLinks.Add(this.commandBarItem48);
            this.xrDesignBarButtonGroup12.ItemLinks.Add(this.commandBarItem49);
            this.xrDesignBarButtonGroup12.Name = "xrDesignBarButtonGroup12";
            // 
            // xrDesignBarButtonGroup13
            // 
            this.xrDesignBarButtonGroup13.Id = 167;
            this.xrDesignBarButtonGroup13.ItemLinks.Add(this.commandBarItem54);
            this.xrDesignBarButtonGroup13.ItemLinks.Add(this.commandBarItem55);
            this.xrDesignBarButtonGroup13.ItemLinks.Add(this.commandBarItem56);
            this.xrDesignBarButtonGroup13.ItemLinks.Add(this.commandBarItem57);
            this.xrDesignBarButtonGroup13.Name = "xrDesignBarButtonGroup13";
            // 
            // xrDesignBarButtonGroup14
            // 
            this.xrDesignBarButtonGroup14.Id = 168;
            this.xrDesignBarButtonGroup14.ItemLinks.Add(this.commandBarItem58);
            this.xrDesignBarButtonGroup14.ItemLinks.Add(this.commandBarItem59);
            this.xrDesignBarButtonGroup14.Name = "xrDesignBarButtonGroup14";
            // 
            // printPreviewBarItem1
            // 
            this.printPreviewBarItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem1.Caption = "Editing Fields";
            this.printPreviewBarItem1.Command = DevExpress.XtraPrinting.PrintingSystemCommand.HighlightEditingFields;
            this.printPreviewBarItem1.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem1.Enabled = false;
            this.printPreviewBarItem1.Id = 169;
            this.printPreviewBarItem1.Name = "printPreviewBarItem1";
            superToolTip149.FixedTooltipWidth = true;
            toolTipTitleItem149.Text = "Highlight Editing Fields";
            toolTipItem149.LeftIndent = 6;
            toolTipItem149.Text = "Highlight all editing fields to quickly discover which of the document elements a" +
    "re editable.";
            superToolTip149.Items.Add(toolTipTitleItem149);
            superToolTip149.Items.Add(toolTipItem149);
            superToolTip149.MaxWidth = 210;
            this.printPreviewBarItem1.SuperTip = superToolTip149;
            // 
            // printPreviewBarItem2
            // 
            this.printPreviewBarItem2.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem2.Caption = "Bookmarks";
            this.printPreviewBarItem2.Command = DevExpress.XtraPrinting.PrintingSystemCommand.DocumentMap;
            this.printPreviewBarItem2.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem2.Enabled = false;
            this.printPreviewBarItem2.Id = 170;
            this.printPreviewBarItem2.Name = "printPreviewBarItem2";
            superToolTip150.FixedTooltipWidth = true;
            toolTipTitleItem150.Text = "Document Map";
            toolTipItem150.LeftIndent = 6;
            toolTipItem150.Text = "Open the Document Map, which allows you to navigate through a structural view of " +
    "the document.";
            superToolTip150.Items.Add(toolTipTitleItem150);
            superToolTip150.Items.Add(toolTipItem150);
            superToolTip150.MaxWidth = 210;
            this.printPreviewBarItem2.SuperTip = superToolTip150;
            // 
            // printPreviewBarItem3
            // 
            this.printPreviewBarItem3.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem3.Caption = "Parameters";
            this.printPreviewBarItem3.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Parameters;
            this.printPreviewBarItem3.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem3.Enabled = false;
            this.printPreviewBarItem3.Id = 171;
            this.printPreviewBarItem3.Name = "printPreviewBarItem3";
            superToolTip151.FixedTooltipWidth = true;
            toolTipTitleItem151.Text = "Parameters";
            toolTipItem151.LeftIndent = 6;
            toolTipItem151.Text = "Open the Parameters pane, which allows you to enter values for report parameters." +
    "";
            superToolTip151.Items.Add(toolTipTitleItem151);
            superToolTip151.Items.Add(toolTipItem151);
            superToolTip151.MaxWidth = 210;
            this.printPreviewBarItem3.SuperTip = superToolTip151;
            // 
            // printPreviewBarItem4
            // 
            this.printPreviewBarItem4.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem4.Caption = "Find";
            this.printPreviewBarItem4.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Find;
            this.printPreviewBarItem4.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem4.Enabled = false;
            this.printPreviewBarItem4.Id = 172;
            this.printPreviewBarItem4.Name = "printPreviewBarItem4";
            superToolTip152.FixedTooltipWidth = true;
            toolTipTitleItem152.Text = "Find";
            toolTipItem152.LeftIndent = 6;
            toolTipItem152.Text = "Show the Find dialog to find text in the document.";
            superToolTip152.Items.Add(toolTipTitleItem152);
            superToolTip152.Items.Add(toolTipItem152);
            superToolTip152.MaxWidth = 210;
            this.printPreviewBarItem4.SuperTip = superToolTip152;
            // 
            // printPreviewBarItem5
            // 
            this.printPreviewBarItem5.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem5.Caption = "Thumbnails";
            this.printPreviewBarItem5.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Thumbnails;
            this.printPreviewBarItem5.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem5.Enabled = false;
            this.printPreviewBarItem5.Id = 173;
            this.printPreviewBarItem5.Name = "printPreviewBarItem5";
            superToolTip153.FixedTooltipWidth = true;
            toolTipTitleItem153.Text = "Thumbnails";
            toolTipItem153.LeftIndent = 6;
            toolTipItem153.Text = "Open the Thumbnails, which allows you to navigate through the document.";
            superToolTip153.Items.Add(toolTipTitleItem153);
            superToolTip153.Items.Add(toolTipItem153);
            superToolTip153.MaxWidth = 210;
            this.printPreviewBarItem5.SuperTip = superToolTip153;
            // 
            // printPreviewBarItem7
            // 
            this.printPreviewBarItem7.Caption = "Print";
            this.printPreviewBarItem7.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Print;
            this.printPreviewBarItem7.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem7.Enabled = false;
            this.printPreviewBarItem7.Id = 175;
            this.printPreviewBarItem7.Name = "printPreviewBarItem7";
            superToolTip154.FixedTooltipWidth = true;
            toolTipTitleItem154.Text = "Print (Ctrl+P)";
            toolTipItem154.LeftIndent = 6;
            toolTipItem154.Text = "Select a printer, number of copies and other printing options before printing.";
            superToolTip154.Items.Add(toolTipTitleItem154);
            superToolTip154.Items.Add(toolTipItem154);
            superToolTip154.MaxWidth = 210;
            this.printPreviewBarItem7.SuperTip = superToolTip154;
            // 
            // printPreviewBarItem8
            // 
            this.printPreviewBarItem8.Caption = "Quick Print";
            this.printPreviewBarItem8.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PrintDirect;
            this.printPreviewBarItem8.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem8.Enabled = false;
            this.printPreviewBarItem8.Id = 176;
            this.printPreviewBarItem8.Name = "printPreviewBarItem8";
            superToolTip155.FixedTooltipWidth = true;
            toolTipTitleItem155.Text = "Quick Print";
            toolTipItem155.LeftIndent = 6;
            toolTipItem155.Text = "Send the document directly to the default printer without making changes.";
            superToolTip155.Items.Add(toolTipTitleItem155);
            superToolTip155.Items.Add(toolTipItem155);
            superToolTip155.MaxWidth = 210;
            this.printPreviewBarItem8.SuperTip = superToolTip155;
            // 
            // printPreviewBarItem9
            // 
            this.printPreviewBarItem9.Caption = "Custom Margins...";
            this.printPreviewBarItem9.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageSetup;
            this.printPreviewBarItem9.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem9.Enabled = false;
            this.printPreviewBarItem9.Id = 177;
            this.printPreviewBarItem9.Name = "printPreviewBarItem9";
            superToolTip156.FixedTooltipWidth = true;
            toolTipTitleItem156.Text = "Page Setup";
            toolTipItem156.LeftIndent = 6;
            toolTipItem156.Text = "Show the Page Setup dialog.";
            superToolTip156.Items.Add(toolTipTitleItem156);
            superToolTip156.Items.Add(toolTipItem156);
            superToolTip156.MaxWidth = 210;
            this.printPreviewBarItem9.SuperTip = superToolTip156;
            // 
            // printPreviewBarItem11
            // 
            this.printPreviewBarItem11.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem11.Caption = "Scale";
            this.printPreviewBarItem11.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Scale;
            this.printPreviewBarItem11.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem11.Enabled = false;
            this.printPreviewBarItem11.Id = 179;
            this.printPreviewBarItem11.Name = "printPreviewBarItem11";
            superToolTip157.FixedTooltipWidth = true;
            toolTipTitleItem157.Text = "Scale";
            toolTipItem157.LeftIndent = 6;
            toolTipItem157.Text = "Stretch or shrink the printed output to a percentage of its actual size.";
            superToolTip157.Items.Add(toolTipTitleItem157);
            superToolTip157.Items.Add(toolTipItem157);
            superToolTip157.MaxWidth = 210;
            this.printPreviewBarItem11.SuperTip = superToolTip157;
            // 
            // printPreviewBarItem12
            // 
            this.printPreviewBarItem12.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem12.Caption = "Pointer";
            this.printPreviewBarItem12.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Pointer;
            this.printPreviewBarItem12.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem12.Enabled = false;
            this.printPreviewBarItem12.GroupIndex = 1;
            this.printPreviewBarItem12.Id = 180;
            this.printPreviewBarItem12.Name = "printPreviewBarItem12";
            this.printPreviewBarItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip158.FixedTooltipWidth = true;
            toolTipTitleItem158.Text = "Mouse Pointer";
            toolTipItem158.LeftIndent = 6;
            toolTipItem158.Text = "Show the mouse pointer.";
            superToolTip158.Items.Add(toolTipTitleItem158);
            superToolTip158.Items.Add(toolTipItem158);
            superToolTip158.MaxWidth = 210;
            this.printPreviewBarItem12.SuperTip = superToolTip158;
            // 
            // printPreviewBarItem13
            // 
            this.printPreviewBarItem13.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem13.Caption = "Hand Tool";
            this.printPreviewBarItem13.Command = DevExpress.XtraPrinting.PrintingSystemCommand.HandTool;
            this.printPreviewBarItem13.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem13.Enabled = false;
            this.printPreviewBarItem13.GroupIndex = 1;
            this.printPreviewBarItem13.Id = 181;
            this.printPreviewBarItem13.Name = "printPreviewBarItem13";
            this.printPreviewBarItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip159.FixedTooltipWidth = true;
            toolTipTitleItem159.Text = "Hand Tool";
            toolTipItem159.LeftIndent = 6;
            toolTipItem159.Text = "Invoke the Hand tool to manually scroll through pages.";
            superToolTip159.Items.Add(toolTipTitleItem159);
            superToolTip159.Items.Add(toolTipItem159);
            superToolTip159.MaxWidth = 210;
            this.printPreviewBarItem13.SuperTip = superToolTip159;
            // 
            // printPreviewBarItem14
            // 
            this.printPreviewBarItem14.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem14.Caption = "Magnifier";
            this.printPreviewBarItem14.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Magnifier;
            this.printPreviewBarItem14.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem14.Enabled = false;
            this.printPreviewBarItem14.GroupIndex = 1;
            this.printPreviewBarItem14.Id = 182;
            this.printPreviewBarItem14.Name = "printPreviewBarItem14";
            this.printPreviewBarItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip160.FixedTooltipWidth = true;
            toolTipTitleItem160.Text = "Magnifier";
            toolTipItem160.LeftIndent = 6;
            toolTipItem160.Text = "Invoke the Magnifier tool.\r\n\r\nClicking once on a document zooms it so that a sing" +
    "le page becomes entirely visible, while clicking another time zooms it to 100% o" +
    "f the normal size.";
            superToolTip160.Items.Add(toolTipTitleItem160);
            superToolTip160.Items.Add(toolTipItem160);
            superToolTip160.MaxWidth = 210;
            this.printPreviewBarItem14.SuperTip = superToolTip160;
            // 
            // printPreviewBarItem15
            // 
            this.printPreviewBarItem15.Caption = "Zoom Out";
            this.printPreviewBarItem15.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomOut;
            this.printPreviewBarItem15.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem15.Enabled = false;
            this.printPreviewBarItem15.Id = 183;
            this.printPreviewBarItem15.Name = "printPreviewBarItem15";
            superToolTip161.FixedTooltipWidth = true;
            toolTipTitleItem161.Text = "Zoom Out";
            toolTipItem161.LeftIndent = 6;
            toolTipItem161.Text = "Zoom out to see more of the page at a reduced size.";
            superToolTip161.Items.Add(toolTipTitleItem161);
            superToolTip161.Items.Add(toolTipItem161);
            superToolTip161.MaxWidth = 210;
            this.printPreviewBarItem15.SuperTip = superToolTip161;
            // 
            // printPreviewBarItem16
            // 
            this.printPreviewBarItem16.Caption = "Zoom In";
            this.printPreviewBarItem16.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomIn;
            this.printPreviewBarItem16.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem16.Enabled = false;
            this.printPreviewBarItem16.Id = 184;
            this.printPreviewBarItem16.Name = "printPreviewBarItem16";
            superToolTip162.FixedTooltipWidth = true;
            toolTipTitleItem162.Text = "Zoom In";
            toolTipItem162.LeftIndent = 6;
            toolTipItem162.Text = "Zoom in to get a close-up view of the document.";
            superToolTip162.Items.Add(toolTipTitleItem162);
            superToolTip162.Items.Add(toolTipItem162);
            superToolTip162.MaxWidth = 210;
            this.printPreviewBarItem16.SuperTip = superToolTip162;
            // 
            // printPreviewBarItem17
            // 
            this.printPreviewBarItem17.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem17.Caption = "Zoom";
            this.printPreviewBarItem17.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Zoom;
            this.printPreviewBarItem17.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem17.Enabled = false;
            this.printPreviewBarItem17.Id = 185;
            this.printPreviewBarItem17.Name = "printPreviewBarItem17";
            superToolTip163.FixedTooltipWidth = true;
            toolTipTitleItem163.Text = "Zoom";
            toolTipItem163.LeftIndent = 6;
            toolTipItem163.Text = "Change the zoom level of the document preview.";
            superToolTip163.Items.Add(toolTipTitleItem163);
            superToolTip163.Items.Add(toolTipItem163);
            superToolTip163.MaxWidth = 210;
            this.printPreviewBarItem17.SuperTip = superToolTip163;
            // 
            // printPreviewBarItem18
            // 
            this.printPreviewBarItem18.Caption = "First Page";
            this.printPreviewBarItem18.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowFirstPage;
            this.printPreviewBarItem18.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem18.Enabled = false;
            this.printPreviewBarItem18.Id = 186;
            this.printPreviewBarItem18.Name = "printPreviewBarItem18";
            superToolTip164.FixedTooltipWidth = true;
            toolTipTitleItem164.Text = "First Page (Home)";
            toolTipItem164.LeftIndent = 6;
            toolTipItem164.Text = "Navigate to the first page of the document.";
            superToolTip164.Items.Add(toolTipTitleItem164);
            superToolTip164.Items.Add(toolTipItem164);
            superToolTip164.MaxWidth = 210;
            this.printPreviewBarItem18.SuperTip = superToolTip164;
            // 
            // printPreviewBarItem19
            // 
            this.printPreviewBarItem19.Caption = "Previous Page";
            this.printPreviewBarItem19.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowPrevPage;
            this.printPreviewBarItem19.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem19.Enabled = false;
            this.printPreviewBarItem19.Id = 187;
            this.printPreviewBarItem19.Name = "printPreviewBarItem19";
            superToolTip165.FixedTooltipWidth = true;
            toolTipTitleItem165.Text = "Previous Page (Left Arrow)";
            toolTipItem165.LeftIndent = 6;
            toolTipItem165.Text = "Navigate to the previous page of the document.";
            superToolTip165.Items.Add(toolTipTitleItem165);
            superToolTip165.Items.Add(toolTipItem165);
            superToolTip165.MaxWidth = 210;
            this.printPreviewBarItem19.SuperTip = superToolTip165;
            // 
            // printPreviewBarItem20
            // 
            this.printPreviewBarItem20.Caption = "Next  Page ";
            this.printPreviewBarItem20.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowNextPage;
            this.printPreviewBarItem20.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem20.Enabled = false;
            this.printPreviewBarItem20.Id = 188;
            this.printPreviewBarItem20.Name = "printPreviewBarItem20";
            superToolTip166.FixedTooltipWidth = true;
            toolTipTitleItem166.Text = "Next Page (Right Arrow)";
            toolTipItem166.LeftIndent = 6;
            toolTipItem166.Text = "Navigate to the next page of the document.";
            superToolTip166.Items.Add(toolTipTitleItem166);
            superToolTip166.Items.Add(toolTipItem166);
            superToolTip166.MaxWidth = 210;
            this.printPreviewBarItem20.SuperTip = superToolTip166;
            // 
            // printPreviewBarItem21
            // 
            this.printPreviewBarItem21.Caption = "Last  Page ";
            this.printPreviewBarItem21.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowLastPage;
            this.printPreviewBarItem21.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem21.Enabled = false;
            this.printPreviewBarItem21.Id = 189;
            this.printPreviewBarItem21.Name = "printPreviewBarItem21";
            superToolTip167.FixedTooltipWidth = true;
            toolTipTitleItem167.Text = "Last Page (End)";
            toolTipItem167.LeftIndent = 6;
            toolTipItem167.Text = "Navigate to the last page of the document.";
            superToolTip167.Items.Add(toolTipTitleItem167);
            superToolTip167.Items.Add(toolTipItem167);
            superToolTip167.MaxWidth = 210;
            this.printPreviewBarItem21.SuperTip = superToolTip167;
            // 
            // printPreviewBarItem22
            // 
            this.printPreviewBarItem22.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem22.Caption = "Many Pages";
            this.printPreviewBarItem22.Command = DevExpress.XtraPrinting.PrintingSystemCommand.MultiplePages;
            this.printPreviewBarItem22.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem22.Enabled = false;
            this.printPreviewBarItem22.Id = 190;
            this.printPreviewBarItem22.Name = "printPreviewBarItem22";
            superToolTip168.FixedTooltipWidth = true;
            toolTipTitleItem168.Text = "View Many Pages";
            toolTipItem168.LeftIndent = 6;
            toolTipItem168.Text = "Choose the page layout to arrange the document pages in preview.";
            superToolTip168.Items.Add(toolTipTitleItem168);
            superToolTip168.Items.Add(toolTipItem168);
            superToolTip168.MaxWidth = 210;
            this.printPreviewBarItem22.SuperTip = superToolTip168;
            // 
            // printPreviewBarItem23
            // 
            this.printPreviewBarItem23.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem23.Caption = "Page Color";
            this.printPreviewBarItem23.Command = DevExpress.XtraPrinting.PrintingSystemCommand.FillBackground;
            this.printPreviewBarItem23.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem23.Enabled = false;
            this.printPreviewBarItem23.Id = 191;
            this.printPreviewBarItem23.Name = "printPreviewBarItem23";
            superToolTip169.FixedTooltipWidth = true;
            toolTipTitleItem169.Text = "Background Color";
            toolTipItem169.LeftIndent = 6;
            toolTipItem169.Text = "Choose a color for the background of the document pages.";
            superToolTip169.Items.Add(toolTipTitleItem169);
            superToolTip169.Items.Add(toolTipItem169);
            superToolTip169.MaxWidth = 210;
            this.printPreviewBarItem23.SuperTip = superToolTip169;
            // 
            // printPreviewBarItem24
            // 
            this.printPreviewBarItem24.Caption = "Watermark";
            this.printPreviewBarItem24.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Watermark;
            this.printPreviewBarItem24.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem24.Enabled = false;
            this.printPreviewBarItem24.Id = 192;
            this.printPreviewBarItem24.Name = "printPreviewBarItem24";
            superToolTip170.FixedTooltipWidth = true;
            toolTipTitleItem170.Text = "Watermark";
            toolTipItem170.LeftIndent = 6;
            toolTipItem170.Text = "Insert ghosted text or image behind the content of a page.\r\n\r\nThis is often used " +
    "to indicate that a document is to be treated specially.";
            superToolTip170.Items.Add(toolTipTitleItem170);
            superToolTip170.Items.Add(toolTipItem170);
            superToolTip170.MaxWidth = 210;
            this.printPreviewBarItem24.SuperTip = superToolTip170;
            // 
            // printPreviewBarItem25
            // 
            this.printPreviewBarItem25.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem25.Caption = "Export To";
            this.printPreviewBarItem25.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportFile;
            this.printPreviewBarItem25.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem25.Enabled = false;
            this.printPreviewBarItem25.Id = 193;
            this.printPreviewBarItem25.Name = "printPreviewBarItem25";
            superToolTip171.FixedTooltipWidth = true;
            toolTipTitleItem171.Text = "Export To...";
            toolTipItem171.LeftIndent = 6;
            toolTipItem171.Text = "Export the current document in one of the available formats, and save it to the f" +
    "ile on a disk.";
            superToolTip171.Items.Add(toolTipTitleItem171);
            superToolTip171.Items.Add(toolTipItem171);
            superToolTip171.MaxWidth = 210;
            this.printPreviewBarItem25.SuperTip = superToolTip171;
            // 
            // printPreviewBarItem26
            // 
            this.printPreviewBarItem26.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem26.Caption = "E-Mail As";
            this.printPreviewBarItem26.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendFile;
            this.printPreviewBarItem26.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem26.Enabled = false;
            this.printPreviewBarItem26.Id = 194;
            this.printPreviewBarItem26.Name = "printPreviewBarItem26";
            superToolTip172.FixedTooltipWidth = true;
            toolTipTitleItem172.Text = "E-Mail As...";
            toolTipItem172.LeftIndent = 6;
            toolTipItem172.Text = "Export the current document in one of the available formats, and attach it to the" +
    " e-mail.";
            superToolTip172.Items.Add(toolTipTitleItem172);
            superToolTip172.Items.Add(toolTipItem172);
            superToolTip172.MaxWidth = 210;
            this.printPreviewBarItem26.SuperTip = superToolTip172;
            // 
            // printPreviewBarItem27
            // 
            this.printPreviewBarItem27.Caption = "Close";
            this.printPreviewBarItem27.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ClosePreview;
            this.printPreviewBarItem27.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem27.Enabled = false;
            this.printPreviewBarItem27.Id = 195;
            this.printPreviewBarItem27.Name = "printPreviewBarItem27";
            superToolTip173.FixedTooltipWidth = true;
            toolTipTitleItem173.Text = "Close Print Preview";
            toolTipItem173.LeftIndent = 6;
            toolTipItem173.Text = "Close Print Preview of the document.";
            superToolTip173.Items.Add(toolTipTitleItem173);
            superToolTip173.Items.Add(toolTipItem173);
            superToolTip173.MaxWidth = 210;
            this.printPreviewBarItem27.SuperTip = superToolTip173;
            // 
            // printPreviewBarItem28
            // 
            this.printPreviewBarItem28.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem28.Caption = "Orientation";
            this.printPreviewBarItem28.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageOrientation;
            this.printPreviewBarItem28.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem28.Enabled = false;
            this.printPreviewBarItem28.Id = 196;
            this.printPreviewBarItem28.Name = "printPreviewBarItem28";
            superToolTip174.FixedTooltipWidth = true;
            toolTipTitleItem174.Text = "Page Orientation";
            toolTipItem174.LeftIndent = 6;
            toolTipItem174.Text = "Switch the pages between portrait and landscape layouts.";
            superToolTip174.Items.Add(toolTipTitleItem174);
            superToolTip174.Items.Add(toolTipItem174);
            superToolTip174.MaxWidth = 210;
            this.printPreviewBarItem28.SuperTip = superToolTip174;
            // 
            // printPreviewBarItem29
            // 
            this.printPreviewBarItem29.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem29.Caption = "Size";
            this.printPreviewBarItem29.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PaperSize;
            this.printPreviewBarItem29.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem29.Enabled = false;
            this.printPreviewBarItem29.Id = 197;
            this.printPreviewBarItem29.Name = "printPreviewBarItem29";
            superToolTip175.FixedTooltipWidth = true;
            toolTipTitleItem175.Text = "Page Size";
            toolTipItem175.LeftIndent = 6;
            toolTipItem175.Text = "Choose the paper size of the document.";
            superToolTip175.Items.Add(toolTipTitleItem175);
            superToolTip175.Items.Add(toolTipItem175);
            superToolTip175.MaxWidth = 210;
            this.printPreviewBarItem29.SuperTip = superToolTip175;
            // 
            // printPreviewBarItem30
            // 
            this.printPreviewBarItem30.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem30.Caption = "Margins";
            this.printPreviewBarItem30.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageMargins;
            this.printPreviewBarItem30.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem30.Enabled = false;
            this.printPreviewBarItem30.Id = 198;
            this.printPreviewBarItem30.Name = "printPreviewBarItem30";
            superToolTip176.FixedTooltipWidth = true;
            toolTipTitleItem176.Text = "Page Margins";
            toolTipItem176.LeftIndent = 6;
            toolTipItem176.Text = "Select the margin sizes for the entire document.\r\n\r\nTo apply specific margin size" +
    "s to the document, click Custom Margins.";
            superToolTip176.Items.Add(toolTipTitleItem176);
            superToolTip176.Items.Add(toolTipItem176);
            superToolTip176.MaxWidth = 210;
            this.printPreviewBarItem30.SuperTip = superToolTip176;
            // 
            // printPreviewBarItem31
            // 
            this.printPreviewBarItem31.Caption = "PDF File";
            this.printPreviewBarItem31.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendPdf;
            this.printPreviewBarItem31.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem31.Enabled = false;
            this.printPreviewBarItem31.Id = 199;
            this.printPreviewBarItem31.Name = "printPreviewBarItem31";
            superToolTip177.FixedTooltipWidth = true;
            toolTipTitleItem177.Text = "E-Mail As PDF";
            toolTipItem177.LeftIndent = 6;
            toolTipItem177.Text = "Export the document to PDF and attach it to the e-mail.";
            superToolTip177.Items.Add(toolTipTitleItem177);
            superToolTip177.Items.Add(toolTipItem177);
            superToolTip177.MaxWidth = 210;
            this.printPreviewBarItem31.SuperTip = superToolTip177;
            // 
            // printPreviewBarItem32
            // 
            this.printPreviewBarItem32.Caption = "Text File";
            this.printPreviewBarItem32.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendTxt;
            this.printPreviewBarItem32.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem32.Enabled = false;
            this.printPreviewBarItem32.Id = 200;
            this.printPreviewBarItem32.Name = "printPreviewBarItem32";
            superToolTip178.FixedTooltipWidth = true;
            toolTipTitleItem178.Text = "E-Mail As Text";
            toolTipItem178.LeftIndent = 6;
            toolTipItem178.Text = "Export the document to Text and attach it to the e-mail.";
            superToolTip178.Items.Add(toolTipTitleItem178);
            superToolTip178.Items.Add(toolTipItem178);
            superToolTip178.MaxWidth = 210;
            this.printPreviewBarItem32.SuperTip = superToolTip178;
            // 
            // printPreviewBarItem33
            // 
            this.printPreviewBarItem33.Caption = "CSV File";
            this.printPreviewBarItem33.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendCsv;
            this.printPreviewBarItem33.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem33.Enabled = false;
            this.printPreviewBarItem33.Id = 201;
            this.printPreviewBarItem33.Name = "printPreviewBarItem33";
            superToolTip179.FixedTooltipWidth = true;
            toolTipTitleItem179.Text = "E-Mail As CSV";
            toolTipItem179.LeftIndent = 6;
            toolTipItem179.Text = "Export the document to CSV and attach it to the e-mail.";
            superToolTip179.Items.Add(toolTipTitleItem179);
            superToolTip179.Items.Add(toolTipItem179);
            superToolTip179.MaxWidth = 210;
            this.printPreviewBarItem33.SuperTip = superToolTip179;
            // 
            // printPreviewBarItem34
            // 
            this.printPreviewBarItem34.Caption = "MHT File";
            this.printPreviewBarItem34.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendMht;
            this.printPreviewBarItem34.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem34.Enabled = false;
            this.printPreviewBarItem34.Id = 202;
            this.printPreviewBarItem34.Name = "printPreviewBarItem34";
            superToolTip180.FixedTooltipWidth = true;
            toolTipTitleItem180.Text = "E-Mail As MHT";
            toolTipItem180.LeftIndent = 6;
            toolTipItem180.Text = "Export the document to MHT and attach it to the e-mail.";
            superToolTip180.Items.Add(toolTipTitleItem180);
            superToolTip180.Items.Add(toolTipItem180);
            superToolTip180.MaxWidth = 210;
            this.printPreviewBarItem34.SuperTip = superToolTip180;
            // 
            // printPreviewBarItem35
            // 
            this.printPreviewBarItem35.Caption = "XLS File";
            this.printPreviewBarItem35.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXls;
            this.printPreviewBarItem35.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem35.Enabled = false;
            this.printPreviewBarItem35.Id = 203;
            this.printPreviewBarItem35.Name = "printPreviewBarItem35";
            superToolTip181.FixedTooltipWidth = true;
            toolTipTitleItem181.Text = "E-Mail As XLS";
            toolTipItem181.LeftIndent = 6;
            toolTipItem181.Text = "Export the document to XLS and attach it to the e-mail.";
            superToolTip181.Items.Add(toolTipTitleItem181);
            superToolTip181.Items.Add(toolTipItem181);
            superToolTip181.MaxWidth = 210;
            this.printPreviewBarItem35.SuperTip = superToolTip181;
            // 
            // printPreviewBarItem36
            // 
            this.printPreviewBarItem36.Caption = "XLSX File";
            this.printPreviewBarItem36.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXlsx;
            this.printPreviewBarItem36.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem36.Enabled = false;
            this.printPreviewBarItem36.Id = 204;
            this.printPreviewBarItem36.Name = "printPreviewBarItem36";
            superToolTip182.FixedTooltipWidth = true;
            toolTipTitleItem182.Text = "E-Mail As XLSX";
            toolTipItem182.LeftIndent = 6;
            toolTipItem182.Text = "Export the document to XLSX and attach it to the e-mail.";
            superToolTip182.Items.Add(toolTipTitleItem182);
            superToolTip182.Items.Add(toolTipItem182);
            superToolTip182.MaxWidth = 210;
            this.printPreviewBarItem36.SuperTip = superToolTip182;
            // 
            // printPreviewBarItem37
            // 
            this.printPreviewBarItem37.Caption = "RTF File";
            this.printPreviewBarItem37.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendRtf;
            this.printPreviewBarItem37.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem37.Enabled = false;
            this.printPreviewBarItem37.Id = 205;
            this.printPreviewBarItem37.Name = "printPreviewBarItem37";
            superToolTip183.FixedTooltipWidth = true;
            toolTipTitleItem183.Text = "E-Mail As RTF";
            toolTipItem183.LeftIndent = 6;
            toolTipItem183.Text = "Export the document to RTF and attach it to the e-mail.";
            superToolTip183.Items.Add(toolTipTitleItem183);
            superToolTip183.Items.Add(toolTipItem183);
            superToolTip183.MaxWidth = 210;
            this.printPreviewBarItem37.SuperTip = superToolTip183;
            // 
            // printPreviewBarItem38
            // 
            this.printPreviewBarItem38.Caption = "DOCX File";
            this.printPreviewBarItem38.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendDocx;
            this.printPreviewBarItem38.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem38.Enabled = false;
            this.printPreviewBarItem38.Id = 206;
            this.printPreviewBarItem38.Name = "printPreviewBarItem38";
            superToolTip184.FixedTooltipWidth = true;
            toolTipTitleItem184.Text = "E-Mail As DOCX";
            toolTipItem184.LeftIndent = 6;
            toolTipItem184.Text = "Export the document to DOCX and attach it to the e-mail.";
            superToolTip184.Items.Add(toolTipTitleItem184);
            superToolTip184.Items.Add(toolTipItem184);
            superToolTip184.MaxWidth = 210;
            this.printPreviewBarItem38.SuperTip = superToolTip184;
            // 
            // printPreviewBarItem39
            // 
            this.printPreviewBarItem39.Caption = "Image File";
            this.printPreviewBarItem39.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendGraphic;
            this.printPreviewBarItem39.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem39.Enabled = false;
            this.printPreviewBarItem39.Id = 207;
            this.printPreviewBarItem39.Name = "printPreviewBarItem39";
            superToolTip185.FixedTooltipWidth = true;
            toolTipTitleItem185.Text = "E-Mail As Image";
            toolTipItem185.LeftIndent = 6;
            toolTipItem185.Text = "Export the document to Image and attach it to the e-mail.";
            superToolTip185.Items.Add(toolTipTitleItem185);
            superToolTip185.Items.Add(toolTipItem185);
            superToolTip185.MaxWidth = 210;
            this.printPreviewBarItem39.SuperTip = superToolTip185;
            // 
            // printPreviewBarItem40
            // 
            this.printPreviewBarItem40.Caption = "PDF File";
            this.printPreviewBarItem40.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportPdf;
            this.printPreviewBarItem40.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem40.Enabled = false;
            this.printPreviewBarItem40.Id = 208;
            this.printPreviewBarItem40.Name = "printPreviewBarItem40";
            superToolTip186.FixedTooltipWidth = true;
            toolTipTitleItem186.Text = "Export to PDF";
            toolTipItem186.LeftIndent = 6;
            toolTipItem186.Text = "Export the document to PDF and save it to the file on a disk.";
            superToolTip186.Items.Add(toolTipTitleItem186);
            superToolTip186.Items.Add(toolTipItem186);
            superToolTip186.MaxWidth = 210;
            this.printPreviewBarItem40.SuperTip = superToolTip186;
            // 
            // printPreviewBarItem41
            // 
            this.printPreviewBarItem41.Caption = "HTML File";
            this.printPreviewBarItem41.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportHtm;
            this.printPreviewBarItem41.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem41.Enabled = false;
            this.printPreviewBarItem41.Id = 209;
            this.printPreviewBarItem41.Name = "printPreviewBarItem41";
            superToolTip187.FixedTooltipWidth = true;
            toolTipTitleItem187.Text = "Export to HTML";
            toolTipItem187.LeftIndent = 6;
            toolTipItem187.Text = "Export the document to HTML and save it to the file on a disk.";
            superToolTip187.Items.Add(toolTipTitleItem187);
            superToolTip187.Items.Add(toolTipItem187);
            superToolTip187.MaxWidth = 210;
            this.printPreviewBarItem41.SuperTip = superToolTip187;
            // 
            // printPreviewBarItem42
            // 
            this.printPreviewBarItem42.Caption = "Text File";
            this.printPreviewBarItem42.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportTxt;
            this.printPreviewBarItem42.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem42.Enabled = false;
            this.printPreviewBarItem42.Id = 210;
            this.printPreviewBarItem42.Name = "printPreviewBarItem42";
            superToolTip188.FixedTooltipWidth = true;
            toolTipTitleItem188.Text = "Export to Text";
            toolTipItem188.LeftIndent = 6;
            toolTipItem188.Text = "Export the document to Text and save it to the file on a disk.";
            superToolTip188.Items.Add(toolTipTitleItem188);
            superToolTip188.Items.Add(toolTipItem188);
            superToolTip188.MaxWidth = 210;
            this.printPreviewBarItem42.SuperTip = superToolTip188;
            // 
            // printPreviewBarItem43
            // 
            this.printPreviewBarItem43.Caption = "CSV File";
            this.printPreviewBarItem43.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportCsv;
            this.printPreviewBarItem43.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem43.Enabled = false;
            this.printPreviewBarItem43.Id = 211;
            this.printPreviewBarItem43.Name = "printPreviewBarItem43";
            superToolTip189.FixedTooltipWidth = true;
            toolTipTitleItem189.Text = "Export to CSV";
            toolTipItem189.LeftIndent = 6;
            toolTipItem189.Text = "Export the document to CSV and save it to the file on a disk.";
            superToolTip189.Items.Add(toolTipTitleItem189);
            superToolTip189.Items.Add(toolTipItem189);
            superToolTip189.MaxWidth = 210;
            this.printPreviewBarItem43.SuperTip = superToolTip189;
            // 
            // printPreviewBarItem44
            // 
            this.printPreviewBarItem44.Caption = "MHT File";
            this.printPreviewBarItem44.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportMht;
            this.printPreviewBarItem44.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem44.Enabled = false;
            this.printPreviewBarItem44.Id = 212;
            this.printPreviewBarItem44.Name = "printPreviewBarItem44";
            superToolTip190.FixedTooltipWidth = true;
            toolTipTitleItem190.Text = "Export to MHT";
            toolTipItem190.LeftIndent = 6;
            toolTipItem190.Text = "Export the document to MHT and save it to the file on a disk.";
            superToolTip190.Items.Add(toolTipTitleItem190);
            superToolTip190.Items.Add(toolTipItem190);
            superToolTip190.MaxWidth = 210;
            this.printPreviewBarItem44.SuperTip = superToolTip190;
            // 
            // printPreviewBarItem45
            // 
            this.printPreviewBarItem45.Caption = "XLS File";
            this.printPreviewBarItem45.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXls;
            this.printPreviewBarItem45.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem45.Enabled = false;
            this.printPreviewBarItem45.Id = 213;
            this.printPreviewBarItem45.Name = "printPreviewBarItem45";
            superToolTip191.FixedTooltipWidth = true;
            toolTipTitleItem191.Text = "Export to XLS";
            toolTipItem191.LeftIndent = 6;
            toolTipItem191.Text = "Export the document to XLS and save it to the file on a disk.";
            superToolTip191.Items.Add(toolTipTitleItem191);
            superToolTip191.Items.Add(toolTipItem191);
            superToolTip191.MaxWidth = 210;
            this.printPreviewBarItem45.SuperTip = superToolTip191;
            // 
            // printPreviewBarItem46
            // 
            this.printPreviewBarItem46.Caption = "XLSX File";
            this.printPreviewBarItem46.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXlsx;
            this.printPreviewBarItem46.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem46.Enabled = false;
            this.printPreviewBarItem46.Id = 214;
            this.printPreviewBarItem46.Name = "printPreviewBarItem46";
            superToolTip192.FixedTooltipWidth = true;
            toolTipTitleItem192.Text = "Export to XLSX";
            toolTipItem192.LeftIndent = 6;
            toolTipItem192.Text = "Export the document to XLSX and save it to the file on a disk.";
            superToolTip192.Items.Add(toolTipTitleItem192);
            superToolTip192.Items.Add(toolTipItem192);
            superToolTip192.MaxWidth = 210;
            this.printPreviewBarItem46.SuperTip = superToolTip192;
            // 
            // printPreviewBarItem47
            // 
            this.printPreviewBarItem47.Caption = "RTF File";
            this.printPreviewBarItem47.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportRtf;
            this.printPreviewBarItem47.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem47.Enabled = false;
            this.printPreviewBarItem47.Id = 215;
            this.printPreviewBarItem47.Name = "printPreviewBarItem47";
            superToolTip193.FixedTooltipWidth = true;
            toolTipTitleItem193.Text = "Export to RTF";
            toolTipItem193.LeftIndent = 6;
            toolTipItem193.Text = "Export the document to RTF and save it to the file on a disk.";
            superToolTip193.Items.Add(toolTipTitleItem193);
            superToolTip193.Items.Add(toolTipItem193);
            superToolTip193.MaxWidth = 210;
            this.printPreviewBarItem47.SuperTip = superToolTip193;
            // 
            // printPreviewBarItem48
            // 
            this.printPreviewBarItem48.Caption = "DOCX File";
            this.printPreviewBarItem48.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportDocx;
            this.printPreviewBarItem48.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem48.Enabled = false;
            this.printPreviewBarItem48.Id = 216;
            this.printPreviewBarItem48.Name = "printPreviewBarItem48";
            superToolTip194.FixedTooltipWidth = true;
            toolTipTitleItem194.Text = "Export to DOCX";
            toolTipItem194.LeftIndent = 6;
            toolTipItem194.Text = "Export the document to DOCX and save it to the file on a disk.";
            superToolTip194.Items.Add(toolTipTitleItem194);
            superToolTip194.Items.Add(toolTipItem194);
            superToolTip194.MaxWidth = 210;
            this.printPreviewBarItem48.SuperTip = superToolTip194;
            // 
            // printPreviewBarItem49
            // 
            this.printPreviewBarItem49.Caption = "Image File";
            this.printPreviewBarItem49.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportGraphic;
            this.printPreviewBarItem49.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem49.Enabled = false;
            this.printPreviewBarItem49.Id = 217;
            this.printPreviewBarItem49.Name = "printPreviewBarItem49";
            superToolTip195.FixedTooltipWidth = true;
            toolTipTitleItem195.Text = "Export to Image";
            toolTipItem195.LeftIndent = 6;
            toolTipItem195.Text = "Export the document to Image and save it to the file on a disk.";
            superToolTip195.Items.Add(toolTipTitleItem195);
            superToolTip195.Items.Add(toolTipItem195);
            superToolTip195.MaxWidth = 210;
            this.printPreviewBarItem49.SuperTip = superToolTip195;
            // 
            // printPreviewBarItem50
            // 
            this.printPreviewBarItem50.Caption = "Open";
            this.printPreviewBarItem50.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Open;
            this.printPreviewBarItem50.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem50.Enabled = false;
            this.printPreviewBarItem50.Id = 218;
            this.printPreviewBarItem50.Name = "printPreviewBarItem50";
            superToolTip196.FixedTooltipWidth = true;
            toolTipTitleItem196.Text = "Open (Ctrl + O)";
            toolTipItem196.LeftIndent = 6;
            toolTipItem196.Text = "Open a document.";
            superToolTip196.Items.Add(toolTipTitleItem196);
            superToolTip196.Items.Add(toolTipItem196);
            superToolTip196.MaxWidth = 210;
            this.printPreviewBarItem50.SuperTip = superToolTip196;
            // 
            // printPreviewBarItem51
            // 
            this.printPreviewBarItem51.Caption = "Save";
            this.printPreviewBarItem51.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Save;
            this.printPreviewBarItem51.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem51.Enabled = false;
            this.printPreviewBarItem51.Id = 219;
            this.printPreviewBarItem51.Name = "printPreviewBarItem51";
            superToolTip197.FixedTooltipWidth = true;
            toolTipTitleItem197.Text = "Save (Ctrl + S)";
            toolTipItem197.LeftIndent = 6;
            toolTipItem197.Text = "Save the document.";
            superToolTip197.Items.Add(toolTipTitleItem197);
            superToolTip197.Items.Add(toolTipItem197);
            superToolTip197.MaxWidth = 210;
            this.printPreviewBarItem51.SuperTip = superToolTip197;
            // 
            // printPreviewStaticItem1
            // 
            this.printPreviewStaticItem1.Caption = "Nothing";
            this.printPreviewStaticItem1.Id = 220;
            this.printPreviewStaticItem1.LeftIndent = 1;
            this.printPreviewStaticItem1.Name = "printPreviewStaticItem1";
            this.printPreviewStaticItem1.RightIndent = 1;
            this.printPreviewStaticItem1.Type = "PageOfPages";
            // 
            // progressBarEditItem1
            // 
            this.progressBarEditItem1.ContextSpecifier = this.xrDesignRibbonController1;
            this.progressBarEditItem1.Edit = this.repositoryItemProgressBar1;
            this.progressBarEditItem1.EditHeight = 12;
            this.progressBarEditItem1.EditWidth = 150;
            this.progressBarEditItem1.Id = 221;
            this.progressBarEditItem1.Name = "progressBarEditItem1";
            this.progressBarEditItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // repositoryItemProgressBar1
            // 
            this.repositoryItemProgressBar1.Name = "repositoryItemProgressBar1";
            // 
            // printPreviewBarItem52
            // 
            this.printPreviewBarItem52.Caption = "Stop";
            this.printPreviewBarItem52.Command = DevExpress.XtraPrinting.PrintingSystemCommand.StopPageBuilding;
            this.printPreviewBarItem52.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewBarItem52.Enabled = false;
            this.printPreviewBarItem52.Hint = "Stop";
            this.printPreviewBarItem52.Id = 222;
            this.printPreviewBarItem52.Name = "printPreviewBarItem52";
            this.printPreviewBarItem52.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // printPreviewStaticItem2
            // 
            this.printPreviewStaticItem2.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.printPreviewStaticItem2.AutoSize = DevExpress.XtraBars.BarStaticItemSize.None;
            this.printPreviewStaticItem2.Caption = "100%";
            this.printPreviewStaticItem2.Id = 223;
            this.printPreviewStaticItem2.Name = "printPreviewStaticItem2";
            this.printPreviewStaticItem2.Type = "ZoomFactorText";
            // 
            // zoomTrackBarEditItem1
            // 
            this.zoomTrackBarEditItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.zoomTrackBarEditItem1.ContextSpecifier = this.xrDesignRibbonController1;
            this.zoomTrackBarEditItem1.Edit = this.repositoryItemZoomTrackBar1;
            this.zoomTrackBarEditItem1.EditWidth = 140;
            this.zoomTrackBarEditItem1.Enabled = false;
            this.zoomTrackBarEditItem1.Id = 224;
            this.zoomTrackBarEditItem1.Name = "zoomTrackBarEditItem1";
            this.zoomTrackBarEditItem1.Range = new int[] {
        10,
        500};
            // 
            // repositoryItemZoomTrackBar1
            // 
            this.repositoryItemZoomTrackBar1.Alignment = DevExpress.Utils.VertAlignment.Center;
            this.repositoryItemZoomTrackBar1.AllowFocused = false;
            this.repositoryItemZoomTrackBar1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.repositoryItemZoomTrackBar1.Maximum = 180;
            this.repositoryItemZoomTrackBar1.Name = "repositoryItemZoomTrackBar1";
            // 
            // btnOpenDefaultRprt
            // 
            this.btnOpenDefaultRprt.Caption = "فتح التقرير الإفتراضيٍ";
            this.btnOpenDefaultRprt.Id = 225;
            this.btnOpenDefaultRprt.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnOpenDefaultRprt.ImageOptions.SvgImage")));
            this.btnOpenDefaultRprt.Name = "btnOpenDefaultRprt";
            this.btnOpenDefaultRprt.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.BtnOpenDefaultRprt_ItemClick);
            // 
            // ribbonPageCategory1
            // 
            this.ribbonPageCategory1.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(94)))), ((int)(((byte)(211)))));
            this.ribbonPageCategory1.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory1.AutoStretchPageHeaders = true;
            this.ribbonPageCategory1.Name = "ribbonPageCategory1";
            this.ribbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage6});
            this.ribbonPageCategory1.Text = "Character Comb Tools";
            this.ribbonPageCategory1.Visible = false;
            // 
            // ribbonPage6
            // 
            this.ribbonPage6.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup18});
            this.ribbonPage6.Name = "ribbonPage6";
            this.ribbonPage6.Text = "Design";
            this.ribbonPage6.Visible = false;
            // 
            // xrDesignRibbonPageGroup18
            // 
            this.xrDesignRibbonPageGroup18.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup18.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup18.ItemLinks.Add(this.commandBarCheckItem7);
            this.xrDesignRibbonPageGroup18.ItemLinks.Add(this.commandBarCheckItem8);
            this.xrDesignRibbonPageGroup18.ItemLinks.Add(this.commandBarEditItem1, true);
            this.xrDesignRibbonPageGroup18.ItemLinks.Add(this.commandBarEditItem2);
            this.xrDesignRibbonPageGroup18.ItemLinks.Add(this.commandBarEditItem3, true);
            this.xrDesignRibbonPageGroup18.ItemLinks.Add(this.commandBarEditItem4);
            this.xrDesignRibbonPageGroup18.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.CellSize;
            this.xrDesignRibbonPageGroup18.Name = "xrDesignRibbonPageGroup18";
            this.xrDesignRibbonPageGroup18.Text = "Cell Size";
            // 
            // ribbonPageCategory2
            // 
            this.ribbonPageCategory2.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(203)))), ((int)(((byte)(29)))));
            this.ribbonPageCategory2.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory2.AutoStretchPageHeaders = true;
            this.ribbonPageCategory2.Name = "ribbonPageCategory2";
            this.ribbonPageCategory2.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage7});
            this.ribbonPageCategory2.Text = "Table Tools";
            this.ribbonPageCategory2.Visible = false;
            // 
            // ribbonPage7
            // 
            this.ribbonPage7.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup19,
            this.xrDesignRibbonPageGroup20,
            this.xrDesignRibbonPageGroup21,
            this.xrDesignRibbonPageGroup22,
            this.xrDesignRibbonPageGroup23});
            this.ribbonPage7.Name = "ribbonPage7";
            this.ribbonPage7.Text = "Design";
            this.ribbonPage7.Visible = false;
            // 
            // xrDesignRibbonPageGroup19
            // 
            this.xrDesignRibbonPageGroup19.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup19.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup19.ItemLinks.Add(this.commandBarItem76);
            this.xrDesignRibbonPageGroup19.ItemLinks.Add(this.commandBarItem77);
            this.xrDesignRibbonPageGroup19.ItemLinks.Add(this.commandBarItem75);
            this.xrDesignRibbonPageGroup19.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Select;
            this.xrDesignRibbonPageGroup19.Name = "xrDesignRibbonPageGroup19";
            this.xrDesignRibbonPageGroup19.Text = "Select";
            // 
            // xrDesignRibbonPageGroup20
            // 
            this.xrDesignRibbonPageGroup20.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup20.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup20.ItemLinks.Add(this.commandBarItem82);
            this.xrDesignRibbonPageGroup20.ItemLinks.Add(this.commandBarItem83);
            this.xrDesignRibbonPageGroup20.ItemLinks.Add(this.commandBarItem84);
            this.xrDesignRibbonPageGroup20.ItemLinks.Add(this.commandBarItem85);
            this.xrDesignRibbonPageGroup20.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Insert;
            this.xrDesignRibbonPageGroup20.Name = "xrDesignRibbonPageGroup20";
            this.xrDesignRibbonPageGroup20.Text = "Insert";
            // 
            // xrDesignRibbonPageGroup21
            // 
            this.xrDesignRibbonPageGroup21.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup21.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup21.ItemLinks.Add(this.commandBarItem78);
            this.xrDesignRibbonPageGroup21.ItemLinks.Add(this.commandBarItem79);
            this.xrDesignRibbonPageGroup21.ItemLinks.Add(this.commandBarItem80);
            this.xrDesignRibbonPageGroup21.ItemLinks.Add(this.commandBarItem81);
            this.xrDesignRibbonPageGroup21.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Delete;
            this.xrDesignRibbonPageGroup21.Name = "xrDesignRibbonPageGroup21";
            this.xrDesignRibbonPageGroup21.Text = "Delete";
            // 
            // xrDesignRibbonPageGroup22
            // 
            this.xrDesignRibbonPageGroup22.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup22.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup22.ItemLinks.Add(this.commandBarItem88);
            this.xrDesignRibbonPageGroup22.ItemLinks.Add(this.commandBarItem89);
            this.xrDesignRibbonPageGroup22.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Merge;
            this.xrDesignRibbonPageGroup22.Name = "xrDesignRibbonPageGroup22";
            this.xrDesignRibbonPageGroup22.Text = "Merge";
            // 
            // xrDesignRibbonPageGroup23
            // 
            this.xrDesignRibbonPageGroup23.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup23.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup23.ItemLinks.Add(this.commandBarItem86);
            this.xrDesignRibbonPageGroup23.ItemLinks.Add(this.commandBarItem87);
            this.xrDesignRibbonPageGroup23.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Distribute;
            this.xrDesignRibbonPageGroup23.Name = "xrDesignRibbonPageGroup23";
            this.xrDesignRibbonPageGroup23.Text = "Distribute";
            // 
            // ribbonPageCategory3
            // 
            this.ribbonPageCategory3.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(163)))), ((int)(((byte)(73)))));
            this.ribbonPageCategory3.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory3.AutoStretchPageHeaders = true;
            this.ribbonPageCategory3.Name = "ribbonPageCategory3";
            this.ribbonPageCategory3.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage8});
            this.ribbonPageCategory3.Text = "Chart Tools";
            this.ribbonPageCategory3.Visible = false;
            // 
            // ribbonPage8
            // 
            this.ribbonPage8.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup24,
            this.xrDesignRibbonPageGroup25,
            this.xrDesignRibbonPageGroup26,
            this.xrDesignRibbonPageGroup27,
            this.xrDesignRibbonPageGroup28});
            this.ribbonPage8.Name = "ribbonPage8";
            this.ribbonPage8.Text = "Design";
            this.ribbonPage8.Visible = false;
            // 
            // xrDesignRibbonPageGroup24
            // 
            this.xrDesignRibbonPageGroup24.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup24.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup24.ItemLinks.Add(this.commandBarItem103);
            this.xrDesignRibbonPageGroup24.ItemLinks.Add(this.commandBarItem102);
            this.xrDesignRibbonPageGroup24.ItemLinks.Add(this.commandBarItem101);
            this.xrDesignRibbonPageGroup24.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Layout;
            this.xrDesignRibbonPageGroup24.Name = "xrDesignRibbonPageGroup24";
            this.xrDesignRibbonPageGroup24.Text = "Layout";
            // 
            // xrDesignRibbonPageGroup25
            // 
            this.xrDesignRibbonPageGroup25.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup25.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup25.ItemLinks.Add(this.commandBarItem104);
            this.xrDesignRibbonPageGroup25.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Data;
            this.xrDesignRibbonPageGroup25.Name = "xrDesignRibbonPageGroup25";
            this.xrDesignRibbonPageGroup25.Text = "Data";
            // 
            // xrDesignRibbonPageGroup26
            // 
            this.xrDesignRibbonPageGroup26.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup26.ItemLinks.Add(this.commandBarItem106);
            this.xrDesignRibbonPageGroup26.ItemLinks.Add(this.commandBarItem107);
            this.xrDesignRibbonPageGroup26.ItemLinks.Add(this.commandBarItem108);
            this.xrDesignRibbonPageGroup26.ItemLinks.Add(this.commandBarItem109);
            this.xrDesignRibbonPageGroup26.ItemLinks.Add(this.commandBarItem110);
            this.xrDesignRibbonPageGroup26.ItemLinks.Add(this.commandBarItem111);
            this.xrDesignRibbonPageGroup26.ItemLinks.Add(this.commandBarItem112);
            this.xrDesignRibbonPageGroup26.ItemLinks.Add(this.commandBarItem113);
            this.xrDesignRibbonPageGroup26.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Series;
            this.xrDesignRibbonPageGroup26.Name = "xrDesignRibbonPageGroup26";
            this.xrDesignRibbonPageGroup26.Text = "Series";
            // 
            // xrDesignRibbonPageGroup27
            // 
            this.xrDesignRibbonPageGroup27.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup27.ItemLinks.Add(this.commandBarItem114);
            this.xrDesignRibbonPageGroup27.ItemLinks.Add(this.commandBarItem115);
            this.xrDesignRibbonPageGroup27.ItemLinks.Add(this.commandBarItem116);
            this.xrDesignRibbonPageGroup27.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Annotations;
            this.xrDesignRibbonPageGroup27.Name = "xrDesignRibbonPageGroup27";
            this.xrDesignRibbonPageGroup27.Text = "Annotations";
            // 
            // xrDesignRibbonPageGroup28
            // 
            this.xrDesignRibbonPageGroup28.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup28.ItemLinks.Add(this.commandBarItem105);
            this.xrDesignRibbonPageGroup28.ItemLinks.Add(this.commandGalleryBarItem3);
            this.xrDesignRibbonPageGroup28.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Appearance;
            this.xrDesignRibbonPageGroup28.Name = "xrDesignRibbonPageGroup28";
            this.xrDesignRibbonPageGroup28.Text = "Appearance";
            // 
            // ribbonPageCategory4
            // 
            this.ribbonPageCategory4.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(89)))), ((int)(((byte)(156)))));
            this.ribbonPageCategory4.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory4.AutoStretchPageHeaders = true;
            this.ribbonPageCategory4.Name = "ribbonPageCategory4";
            this.ribbonPageCategory4.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage9});
            this.ribbonPageCategory4.Text = "Pivot Grid Tools";
            this.ribbonPageCategory4.Visible = false;
            // 
            // ribbonPage9
            // 
            this.ribbonPage9.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup29,
            this.xrDesignRibbonPageGroup30,
            this.xrDesignRibbonPageGroup31,
            this.xrDesignRibbonPageGroup32});
            this.ribbonPage9.Name = "ribbonPage9";
            this.ribbonPage9.Text = "Design";
            this.ribbonPage9.Visible = false;
            // 
            // xrDesignRibbonPageGroup29
            // 
            this.xrDesignRibbonPageGroup29.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup29.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup29.ItemLinks.Add(this.commandBarItem90);
            this.xrDesignRibbonPageGroup29.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Layout;
            this.xrDesignRibbonPageGroup29.Name = "xrDesignRibbonPageGroup29";
            this.xrDesignRibbonPageGroup29.Text = "Layout";
            // 
            // xrDesignRibbonPageGroup30
            // 
            this.xrDesignRibbonPageGroup30.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup30.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup30.ItemLinks.Add(this.commandBarItem91);
            this.xrDesignRibbonPageGroup30.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Data;
            this.xrDesignRibbonPageGroup30.Name = "xrDesignRibbonPageGroup30";
            this.xrDesignRibbonPageGroup30.Text = "Data";
            // 
            // xrDesignRibbonPageGroup31
            // 
            this.xrDesignRibbonPageGroup31.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup31.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup31.ItemLinks.Add(this.commandBarItem93);
            this.xrDesignRibbonPageGroup31.ItemLinks.Add(this.commandBarItem92);
            this.xrDesignRibbonPageGroup31.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.PivotFields;
            this.xrDesignRibbonPageGroup31.Name = "xrDesignRibbonPageGroup31";
            this.xrDesignRibbonPageGroup31.Text = "Fields";
            // 
            // xrDesignRibbonPageGroup32
            // 
            this.xrDesignRibbonPageGroup32.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup32.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup32.ItemLinks.Add(this.commandBarItem94);
            this.xrDesignRibbonPageGroup32.ItemLinks.Add(this.commandBarItem95);
            this.xrDesignRibbonPageGroup32.ItemLinks.Add(this.commandBarItem98, true);
            this.xrDesignRibbonPageGroup32.ItemLinks.Add(this.commandBarItem97);
            this.xrDesignRibbonPageGroup32.ItemLinks.Add(this.commandBarItem96);
            this.xrDesignRibbonPageGroup32.ItemLinks.Add(this.commandBarItem99, true);
            this.xrDesignRibbonPageGroup32.ItemLinks.Add(this.commandBarItem100);
            this.xrDesignRibbonPageGroup32.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.PivotPrintOptions;
            this.xrDesignRibbonPageGroup32.Name = "xrDesignRibbonPageGroup32";
            this.xrDesignRibbonPageGroup32.Text = "Print Options";
            // 
            // ribbonPageCategory5
            // 
            this.ribbonPageCategory5.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(94)))), ((int)(((byte)(211)))));
            this.ribbonPageCategory5.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory5.AutoStretchPageHeaders = true;
            this.ribbonPageCategory5.Name = "ribbonPageCategory5";
            this.ribbonPageCategory5.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage10});
            this.ribbonPageCategory5.Text = "Bar Code Tools";
            this.ribbonPageCategory5.Visible = false;
            // 
            // ribbonPage10
            // 
            this.ribbonPage10.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup33,
            this.xrDesignRibbonPageGroup34});
            this.ribbonPage10.Name = "ribbonPage10";
            this.ribbonPage10.Text = "Design";
            this.ribbonPage10.Visible = false;
            // 
            // xrDesignRibbonPageGroup33
            // 
            this.xrDesignRibbonPageGroup33.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup33.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup33.ItemLinks.Add(this.commandBarItem117);
            this.xrDesignRibbonPageGroup33.ItemLinks.Add(this.commandBarItem118);
            this.xrDesignRibbonPageGroup33.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.View;
            this.xrDesignRibbonPageGroup33.Name = "xrDesignRibbonPageGroup33";
            this.xrDesignRibbonPageGroup33.Text = "View";
            // 
            // xrDesignRibbonPageGroup34
            // 
            this.xrDesignRibbonPageGroup34.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup34.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup34.ItemLinks.Add(this.commandGalleryBarItem2);
            this.xrDesignRibbonPageGroup34.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Symbology;
            this.xrDesignRibbonPageGroup34.Name = "xrDesignRibbonPageGroup34";
            this.xrDesignRibbonPageGroup34.Text = "Symbology";
            // 
            // ribbonPageCategory6
            // 
            this.ribbonPageCategory6.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(157)))), ((int)(((byte)(0)))));
            this.ribbonPageCategory6.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory6.AutoStretchPageHeaders = true;
            this.ribbonPageCategory6.Name = "ribbonPageCategory6";
            this.ribbonPageCategory6.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage11});
            this.ribbonPageCategory6.Text = "Gauge Tools";
            this.ribbonPageCategory6.Visible = false;
            // 
            // ribbonPage11
            // 
            this.ribbonPage11.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup35,
            this.xrDesignRibbonPageGroup36});
            this.ribbonPage11.Name = "ribbonPage11";
            this.ribbonPage11.Text = "Design";
            this.ribbonPage11.Visible = false;
            // 
            // xrDesignRibbonPageGroup35
            // 
            this.xrDesignRibbonPageGroup35.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup35.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup35.ItemLinks.Add(this.commandGalleryBarItem5);
            this.xrDesignRibbonPageGroup35.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.View;
            this.xrDesignRibbonPageGroup35.Name = "xrDesignRibbonPageGroup35";
            this.xrDesignRibbonPageGroup35.Text = "View";
            // 
            // xrDesignRibbonPageGroup36
            // 
            this.xrDesignRibbonPageGroup36.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup36.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup36.ItemLinks.Add(this.commandBarItem122);
            this.xrDesignRibbonPageGroup36.ItemLinks.Add(this.commandBarItem123);
            this.xrDesignRibbonPageGroup36.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Theme;
            this.xrDesignRibbonPageGroup36.Name = "xrDesignRibbonPageGroup36";
            this.xrDesignRibbonPageGroup36.Text = "Theme";
            // 
            // ribbonPageCategory7
            // 
            this.ribbonPageCategory7.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(163)))), ((int)(((byte)(73)))));
            this.ribbonPageCategory7.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory7.AutoStretchPageHeaders = true;
            this.ribbonPageCategory7.Name = "ribbonPageCategory7";
            this.ribbonPageCategory7.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage12});
            this.ribbonPageCategory7.Text = "Sparkline Tools";
            this.ribbonPageCategory7.Visible = false;
            // 
            // ribbonPage12
            // 
            this.ribbonPage12.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup37,
            this.xrDesignRibbonPageGroup38});
            this.ribbonPage12.Name = "ribbonPage12";
            this.ribbonPage12.Text = "Design";
            this.ribbonPage12.Visible = false;
            // 
            // xrDesignRibbonPageGroup37
            // 
            this.xrDesignRibbonPageGroup37.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup37.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup37.ItemLinks.Add(this.commandBarItem121);
            this.xrDesignRibbonPageGroup37.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Data;
            this.xrDesignRibbonPageGroup37.Name = "xrDesignRibbonPageGroup37";
            this.xrDesignRibbonPageGroup37.Text = "Data";
            // 
            // xrDesignRibbonPageGroup38
            // 
            this.xrDesignRibbonPageGroup38.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup38.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup38.ItemLinks.Add(this.commandGalleryBarItem4);
            this.xrDesignRibbonPageGroup38.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.View;
            this.xrDesignRibbonPageGroup38.Name = "xrDesignRibbonPageGroup38";
            this.xrDesignRibbonPageGroup38.Text = "View";
            // 
            // ribbonPageCategory8
            // 
            this.ribbonPageCategory8.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(157)))), ((int)(((byte)(0)))));
            this.ribbonPageCategory8.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory8.AutoStretchPageHeaders = true;
            this.ribbonPageCategory8.Name = "ribbonPageCategory8";
            this.ribbonPageCategory8.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage13});
            this.ribbonPageCategory8.Text = "Shape Tools";
            this.ribbonPageCategory8.Visible = false;
            // 
            // ribbonPage13
            // 
            this.ribbonPage13.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup39});
            this.ribbonPage13.Name = "ribbonPage13";
            this.ribbonPage13.Text = "Design";
            this.ribbonPage13.Visible = false;
            // 
            // xrDesignRibbonPageGroup39
            // 
            this.xrDesignRibbonPageGroup39.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup39.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup39.ItemLinks.Add(this.commandBarItem124);
            this.xrDesignRibbonPageGroup39.ItemLinks.Add(this.commandGalleryBarItem6);
            this.xrDesignRibbonPageGroup39.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.View;
            this.xrDesignRibbonPageGroup39.Name = "xrDesignRibbonPageGroup39";
            this.xrDesignRibbonPageGroup39.Text = "View";
            // 
            // ribbonPageCategory9
            // 
            this.ribbonPageCategory9.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(158)))), ((int)(((byte)(197)))), ((int)(((byte)(126)))));
            this.ribbonPageCategory9.Appearance.Options.UseBackColor = true;
            this.ribbonPageCategory9.AutoStretchPageHeaders = true;
            this.ribbonPageCategory9.Name = "ribbonPageCategory9";
            this.ribbonPageCategory9.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage14});
            this.ribbonPageCategory9.Text = "Text Tools";
            this.ribbonPageCategory9.Visible = false;
            // 
            // ribbonPage14
            // 
            this.ribbonPage14.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup40,
            this.xrDesignRibbonPageGroup41});
            this.ribbonPage14.Name = "ribbonPage14";
            this.ribbonPage14.Text = "Text";
            this.ribbonPage14.Visible = false;
            // 
            // xrDesignRibbonPageGroup40
            // 
            this.xrDesignRibbonPageGroup40.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup40.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup40.ItemLinks.Add(this.commandBarItem119);
            this.xrDesignRibbonPageGroup40.ItemLinks.Add(this.commandBarItem120);
            this.xrDesignRibbonPageGroup40.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Design;
            this.xrDesignRibbonPageGroup40.Name = "xrDesignRibbonPageGroup40";
            this.xrDesignRibbonPageGroup40.Text = "Design";
            // 
            // xrDesignRibbonPageGroup41
            // 
            this.xrDesignRibbonPageGroup41.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup41.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup41.ItemLinks.Add(this.commandBarCheckItem3);
            this.xrDesignRibbonPageGroup41.ItemLinks.Add(this.commandBarCheckItem4);
            this.xrDesignRibbonPageGroup41.ItemLinks.Add(this.commandBarCheckItem5, true);
            this.xrDesignRibbonPageGroup41.ItemLinks.Add(this.commandBarCheckItem6);
            this.xrDesignRibbonPageGroup41.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Behavior;
            this.xrDesignRibbonPageGroup41.Name = "xrDesignRibbonPageGroup41";
            this.xrDesignRibbonPageGroup41.Text = "Behavior";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup1,
            this.xrDesignRibbonPageGroup2,
            this.xrDesignRibbonPageGroup3,
            this.xrDesignRibbonPageGroup4,
            this.xrDesignRibbonPageGroup5,
            this.xrDesignRibbonPageGroup6,
            this.xrDesignRibbonPageGroup7});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Home";
            // 
            // xrDesignRibbonPageGroup1
            // 
            this.xrDesignRibbonPageGroup1.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup1.ItemLinks.Add(this.commandBarItem6);
            this.xrDesignRibbonPageGroup1.ItemLinks.Add(this.commandBarItem9);
            this.xrDesignRibbonPageGroup1.ItemLinks.Add(this.btnOpenDefaultRprt);
            this.xrDesignRibbonPageGroup1.ItemLinks.Add(this.commandBarItem7);
            this.xrDesignRibbonPageGroup1.ItemLinks.Add(this.commandBarItem8);
            this.xrDesignRibbonPageGroup1.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Report;
            this.xrDesignRibbonPageGroup1.Name = "xrDesignRibbonPageGroup1";
            this.xrDesignRibbonPageGroup1.Text = "Report";
            // 
            // xrDesignRibbonPageGroup2
            // 
            this.xrDesignRibbonPageGroup2.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup2.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup2.ItemLinks.Add(this.commandBarItem30);
            this.xrDesignRibbonPageGroup2.ItemLinks.Add(this.commandBarItem28);
            this.xrDesignRibbonPageGroup2.ItemLinks.Add(this.commandBarItem29);
            this.xrDesignRibbonPageGroup2.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Data;
            this.xrDesignRibbonPageGroup2.Name = "xrDesignRibbonPageGroup2";
            this.xrDesignRibbonPageGroup2.Text = "Data";
            this.xrDesignRibbonPageGroup2.Visible = false;
            // 
            // xrDesignRibbonPageGroup3
            // 
            this.xrDesignRibbonPageGroup3.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup3.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup3.ItemLinks.Add(this.commandBarItem14);
            this.xrDesignRibbonPageGroup3.ItemLinks.Add(this.commandBarItem15);
            this.xrDesignRibbonPageGroup3.ItemLinks.Add(this.commandBarItem16);
            this.xrDesignRibbonPageGroup3.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Clipboard;
            this.xrDesignRibbonPageGroup3.Name = "xrDesignRibbonPageGroup3";
            this.xrDesignRibbonPageGroup3.Text = "Clipboard";
            // 
            // xrDesignRibbonPageGroup4
            // 
            this.xrDesignRibbonPageGroup4.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup4.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup4.ItemLinks.Add(this.xrDesignBarButtonGroup1);
            this.xrDesignRibbonPageGroup4.ItemLinks.Add(this.xrDesignBarButtonGroup2);
            this.xrDesignRibbonPageGroup4.ItemLinks.Add(this.xrDesignBarButtonGroup3);
            this.xrDesignRibbonPageGroup4.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Font;
            this.xrDesignRibbonPageGroup4.Name = "xrDesignRibbonPageGroup4";
            this.xrDesignRibbonPageGroup4.Text = "Font";
            // 
            // xrDesignRibbonPageGroup5
            // 
            this.xrDesignRibbonPageGroup5.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup5.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup5.ItemLinks.Add(this.xrDesignBarButtonGroup4);
            this.xrDesignRibbonPageGroup5.ItemLinks.Add(this.xrDesignBarButtonGroup5);
            this.xrDesignRibbonPageGroup5.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.TextAlignment;
            this.xrDesignRibbonPageGroup5.Name = "xrDesignRibbonPageGroup5";
            this.xrDesignRibbonPageGroup5.Text = "Alignment";
            // 
            // xrDesignRibbonPageGroup6
            // 
            this.xrDesignRibbonPageGroup6.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup6.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup6.ItemLinks.Add(this.xrDesignBarButtonGroup6);
            this.xrDesignRibbonPageGroup6.ItemLinks.Add(this.xrDesignBarButtonGroup7);
            this.xrDesignRibbonPageGroup6.ItemLinks.Add(this.xrDesignBarButtonGroup8);
            this.xrDesignRibbonPageGroup6.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Borders;
            this.xrDesignRibbonPageGroup6.Name = "xrDesignRibbonPageGroup6";
            this.xrDesignRibbonPageGroup6.Text = "Borders";
            // 
            // xrDesignRibbonPageGroup7
            // 
            this.xrDesignRibbonPageGroup7.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup7.ItemLinks.Add(this.commandBarItem31);
            this.xrDesignRibbonPageGroup7.ItemLinks.Add(this.commandGalleryBarItem1);
            this.xrDesignRibbonPageGroup7.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Styles;
            this.xrDesignRibbonPageGroup7.Name = "xrDesignRibbonPageGroup7";
            this.xrDesignRibbonPageGroup7.Text = "Styles";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup8,
            this.xrDesignRibbonPageGroup9,
            this.xrDesignRibbonPageGroup10,
            this.xrDesignRibbonPageGroup11});
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Layout";
            // 
            // xrDesignRibbonPageGroup8
            // 
            this.xrDesignRibbonPageGroup8.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup8.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup8.ItemLinks.Add(this.xrDesignBarButtonGroup9);
            this.xrDesignRibbonPageGroup8.ItemLinks.Add(this.xrDesignBarButtonGroup10);
            this.xrDesignRibbonPageGroup8.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Alignment;
            this.xrDesignRibbonPageGroup8.Name = "xrDesignRibbonPageGroup8";
            this.xrDesignRibbonPageGroup8.Text = "Alignment";
            // 
            // xrDesignRibbonPageGroup9
            // 
            this.xrDesignRibbonPageGroup9.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup9.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup9.ItemLinks.Add(this.commandBarItem39);
            this.xrDesignRibbonPageGroup9.ItemLinks.Add(this.commandBarItem47);
            this.xrDesignRibbonPageGroup9.ItemLinks.Add(this.commandBarItem62);
            this.xrDesignRibbonPageGroup9.ItemLinks.Add(this.xrDesignBarButtonGroup11);
            this.xrDesignRibbonPageGroup9.ItemLinks.Add(this.xrDesignBarButtonGroup12);
            this.xrDesignRibbonPageGroup9.ItemLinks.Add(this.xrDesignBarButtonGroup13);
            this.xrDesignRibbonPageGroup9.ItemLinks.Add(this.xrDesignBarButtonGroup14);
            this.xrDesignRibbonPageGroup9.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.SizeAndLayout;
            this.xrDesignRibbonPageGroup9.Name = "xrDesignRibbonPageGroup9";
            this.xrDesignRibbonPageGroup9.Text = "Layout";
            // 
            // xrDesignRibbonPageGroup10
            // 
            this.xrDesignRibbonPageGroup10.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup10.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup10.ItemLinks.Add(this.commandBarItem60);
            this.xrDesignRibbonPageGroup10.ItemLinks.Add(this.commandBarItem61);
            this.xrDesignRibbonPageGroup10.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Arranging;
            this.xrDesignRibbonPageGroup10.Name = "xrDesignRibbonPageGroup10";
            this.xrDesignRibbonPageGroup10.Text = "Arranging";
            // 
            // xrDesignRibbonPageGroup11
            // 
            this.xrDesignRibbonPageGroup11.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup11.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup11.ItemLinks.Add(this.commandBarCheckItem1);
            this.xrDesignRibbonPageGroup11.ItemLinks.Add(this.commandBarCheckItem2);
            this.xrDesignRibbonPageGroup11.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Snapping;
            this.xrDesignRibbonPageGroup11.Name = "xrDesignRibbonPageGroup11";
            this.xrDesignRibbonPageGroup11.Text = "Snapping";
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup12,
            this.xrDesignRibbonPageGroup13});
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "Page";
            // 
            // xrDesignRibbonPageGroup12
            // 
            this.xrDesignRibbonPageGroup12.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup12.ItemLinks.Add(this.commandBarItem65);
            this.xrDesignRibbonPageGroup12.ItemLinks.Add(this.commandBarItem64);
            this.xrDesignRibbonPageGroup12.ItemLinks.Add(this.commandBarItem63);
            this.xrDesignRibbonPageGroup12.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.PageSetup;
            this.xrDesignRibbonPageGroup12.Name = "xrDesignRibbonPageGroup12";
            this.xrDesignRibbonPageGroup12.Text = "Page Setup";
            // 
            // xrDesignRibbonPageGroup13
            // 
            this.xrDesignRibbonPageGroup13.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup13.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup13.ItemLinks.Add(this.commandColorBarItem4);
            this.xrDesignRibbonPageGroup13.ItemLinks.Add(this.commandBarItem66);
            this.xrDesignRibbonPageGroup13.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Appearance;
            this.xrDesignRibbonPageGroup13.Name = "xrDesignRibbonPageGroup13";
            this.xrDesignRibbonPageGroup13.Text = "Appearance";
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup14,
            this.xrDesignRibbonPageGroup15,
            this.xrDesignRibbonPageGroup16});
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "View";
            // 
            // xrDesignRibbonPageGroup14
            // 
            this.xrDesignRibbonPageGroup14.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup14.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup14.ItemLinks.Add(this.commandBarItem67);
            this.xrDesignRibbonPageGroup14.ItemLinks.Add(this.commandBarItem68);
            this.xrDesignRibbonPageGroup14.ItemLinks.Add(this.commandBarItem69, true);
            this.xrDesignRibbonPageGroup14.ItemLinks.Add(this.commandBarItem70);
            this.xrDesignRibbonPageGroup14.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Show;
            this.xrDesignRibbonPageGroup14.Name = "xrDesignRibbonPageGroup14";
            this.xrDesignRibbonPageGroup14.Text = "Show";
            // 
            // xrDesignRibbonPageGroup15
            // 
            this.xrDesignRibbonPageGroup15.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup15.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup15.ItemLinks.Add(this.commandBarItem73);
            this.xrDesignRibbonPageGroup15.ItemLinks.Add(this.commandBarItem71);
            this.xrDesignRibbonPageGroup15.ItemLinks.Add(this.commandBarItem72);
            this.xrDesignRibbonPageGroup15.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Zoom;
            this.xrDesignRibbonPageGroup15.Name = "xrDesignRibbonPageGroup15";
            this.xrDesignRibbonPageGroup15.Text = "Zoom";
            // 
            // xrDesignRibbonPageGroup16
            // 
            this.xrDesignRibbonPageGroup16.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup16.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup16.ItemLinks.Add(this.barDockPanelsListItem1);
            this.xrDesignRibbonPageGroup16.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.View;
            this.xrDesignRibbonPageGroup16.Name = "xrDesignRibbonPageGroup16";
            this.xrDesignRibbonPageGroup16.Text = "View";
            // 
            // ribbonPage5
            // 
            this.ribbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup17});
            this.ribbonPage5.Name = "ribbonPage5";
            this.ribbonPage5.Text = "Scripts";
            this.ribbonPage5.Visible = false;
            // 
            // xrDesignRibbonPageGroup17
            // 
            this.xrDesignRibbonPageGroup17.AllowTextClipping = false;
            this.xrDesignRibbonPageGroup17.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.xrDesignRibbonPageGroup17.ItemLinks.Add(this.commandBarEditItem6);
            this.xrDesignRibbonPageGroup17.ItemLinks.Add(this.commandBarEditItem7);
            this.xrDesignRibbonPageGroup17.ItemLinks.Add(this.commandBarItem74);
            this.xrDesignRibbonPageGroup17.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Edit;
            this.xrDesignRibbonPageGroup17.Name = "xrDesignRibbonPageGroup17";
            this.xrDesignRibbonPageGroup17.Text = "Edit";
            // 
            // ribbonPage15
            // 
            this.ribbonPage15.ContextSpecifier = this.xrDesignRibbonController1;
            this.ribbonPage15.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.printPreviewRibbonPageGroup1,
            this.printPreviewRibbonPageGroup2,
            this.printPreviewRibbonPageGroup3,
            this.printPreviewRibbonPageGroup4,
            this.printPreviewRibbonPageGroup5,
            this.printPreviewRibbonPageGroup6,
            this.printPreviewRibbonPageGroup7,
            this.printPreviewRibbonPageGroup8});
            this.ribbonPage15.Name = "ribbonPage15";
            this.ribbonPage15.Text = "Home";
            this.ribbonPage15.Visible = false;
            // 
            // printPreviewRibbonPageGroup1
            // 
            this.printPreviewRibbonPageGroup1.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.printPreviewRibbonPageGroup1.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewRibbonPageGroup1.ItemLinks.Add(this.printPreviewBarItem50);
            this.printPreviewRibbonPageGroup1.ItemLinks.Add(this.printPreviewBarItem51);
            this.printPreviewRibbonPageGroup1.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Document;
            this.printPreviewRibbonPageGroup1.Name = "printPreviewRibbonPageGroup1";
            this.printPreviewRibbonPageGroup1.Text = "Document";
            // 
            // printPreviewRibbonPageGroup2
            // 
            this.printPreviewRibbonPageGroup2.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup2.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.printPreviewRibbonPageGroup2.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem7);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem8);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem3);
            this.printPreviewRibbonPageGroup2.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Print;
            this.printPreviewRibbonPageGroup2.Name = "printPreviewRibbonPageGroup2";
            this.printPreviewRibbonPageGroup2.Text = "Print";
            // 
            // printPreviewRibbonPageGroup3
            // 
            this.printPreviewRibbonPageGroup3.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup3.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem11);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem30);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem28);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem29);
            this.printPreviewRibbonPageGroup3.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.PageSetup;
            this.printPreviewRibbonPageGroup3.Name = "printPreviewRibbonPageGroup3";
            superToolTip198.FixedTooltipWidth = true;
            toolTipTitleItem198.Text = "Page Setup";
            toolTipItem198.LeftIndent = 6;
            toolTipItem198.Text = "Show the Page Setup dialog.";
            superToolTip198.Items.Add(toolTipTitleItem198);
            superToolTip198.Items.Add(toolTipItem198);
            superToolTip198.MaxWidth = 210;
            this.printPreviewRibbonPageGroup3.SuperTip = superToolTip198;
            this.printPreviewRibbonPageGroup3.Text = "Page Setup";
            // 
            // printPreviewRibbonPageGroup4
            // 
            this.printPreviewRibbonPageGroup4.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup4.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.printPreviewRibbonPageGroup4.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem4);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem5);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem2);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem1);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem18, true);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem19);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem20);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem21);
            this.printPreviewRibbonPageGroup4.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Navigation;
            this.printPreviewRibbonPageGroup4.Name = "printPreviewRibbonPageGroup4";
            this.printPreviewRibbonPageGroup4.Text = "Navigation";
            // 
            // printPreviewRibbonPageGroup5
            // 
            this.printPreviewRibbonPageGroup5.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup5.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.printPreviewRibbonPageGroup5.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem12);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem13);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem14);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem22);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem15);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem17);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem16);
            this.printPreviewRibbonPageGroup5.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Zoom;
            this.printPreviewRibbonPageGroup5.Name = "printPreviewRibbonPageGroup5";
            this.printPreviewRibbonPageGroup5.Text = "Zoom";
            // 
            // printPreviewRibbonPageGroup6
            // 
            this.printPreviewRibbonPageGroup6.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup6.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.printPreviewRibbonPageGroup6.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewRibbonPageGroup6.ItemLinks.Add(this.printPreviewBarItem23);
            this.printPreviewRibbonPageGroup6.ItemLinks.Add(this.printPreviewBarItem24);
            this.printPreviewRibbonPageGroup6.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Background;
            this.printPreviewRibbonPageGroup6.Name = "printPreviewRibbonPageGroup6";
            this.printPreviewRibbonPageGroup6.Text = "Page Background";
            // 
            // printPreviewRibbonPageGroup7
            // 
            this.printPreviewRibbonPageGroup7.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup7.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.printPreviewRibbonPageGroup7.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewRibbonPageGroup7.ItemLinks.Add(this.printPreviewBarItem25);
            this.printPreviewRibbonPageGroup7.ItemLinks.Add(this.printPreviewBarItem26);
            this.printPreviewRibbonPageGroup7.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Export;
            this.printPreviewRibbonPageGroup7.Name = "printPreviewRibbonPageGroup7";
            this.printPreviewRibbonPageGroup7.Text = "Export";
            // 
            // printPreviewRibbonPageGroup8
            // 
            this.printPreviewRibbonPageGroup8.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup8.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.printPreviewRibbonPageGroup8.ContextSpecifier = this.xrDesignRibbonController1;
            this.printPreviewRibbonPageGroup8.ItemLinks.Add(this.printPreviewBarItem27);
            this.printPreviewRibbonPageGroup8.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Close;
            this.printPreviewRibbonPageGroup8.Name = "printPreviewRibbonPageGroup8";
            this.printPreviewRibbonPageGroup8.Text = "Close";
            // 
            // ribbonPage16
            // 
            this.ribbonPage16.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage16.Name = "ribbonPage16";
            this.ribbonPage16.Text = "ribbonPage16";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // ribbonPage17
            // 
            this.ribbonPage17.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2});
            this.ribbonPage17.Name = "ribbonPage17";
            this.ribbonPage17.Text = "ribbonPage17";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "ribbonPageGroup2";
            // 
            // ribbonStatusBar1
            // 
            this.ribbonStatusBar1.ItemLinks.Add(this.printPreviewStaticItem1);
            this.ribbonStatusBar1.ItemLinks.Add(this.progressBarEditItem1);
            this.ribbonStatusBar1.ItemLinks.Add(this.printPreviewBarItem52);
            this.ribbonStatusBar1.ItemLinks.Add(this.printPreviewStaticItem2);
            this.ribbonStatusBar1.ItemLinks.Add(this.zoomTrackBarEditItem1);
            this.ribbonStatusBar1.Location = new System.Drawing.Point(0, 738);
            this.ribbonStatusBar1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ribbonStatusBar1.Name = "ribbonStatusBar1";
            this.ribbonStatusBar1.Ribbon = this.ribbonControl1;
            this.ribbonStatusBar1.Size = new System.Drawing.Size(1333, 32);
            // 
            // reportDesigner1
            // 
            this.reportDesigner1.ContainerControl = null;
            xrDesignPanelListener1.DesignControl = this.xrDesignRibbonController1;
            xrDesignPanelListener2.DesignControl = this.xrDesignDockManager1;
            xrDesignPanelListener3.DesignControl = this.fieldListDockPanel1;
            xrDesignPanelListener4.DesignControl = this.propertyGridDockPanel1;
            xrDesignPanelListener5.DesignControl = this.reportExplorerDockPanel1;
            xrDesignPanelListener6.DesignControl = this.reportGalleryDockPanel1;
            xrDesignPanelListener7.DesignControl = this.groupAndSortDockPanel1;
            xrDesignPanelListener8.DesignControl = this.errorListDockPanel1;
            this.reportDesigner1.DesignPanelListeners.AddRange(new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener[] {
            xrDesignPanelListener1,
            xrDesignPanelListener2,
            xrDesignPanelListener3,
            xrDesignPanelListener4,
            xrDesignPanelListener5,
            xrDesignPanelListener6,
            xrDesignPanelListener7,
            xrDesignPanelListener8});
            this.reportDesigner1.Form = this;
            // 
            // ReportEndUserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1333, 770);
            this.Controls.Add(this.panelContainer1);
            this.Controls.Add(this.hideContainerBottom);
            this.Controls.Add(this.ribbonStatusBar1);
            this.Controls.Add(this.ribbonControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ReportEndUserForm";
            this.Ribbon = this.ribbonControl1;
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StatusBar = this.ribbonStatusBar1;
            this.Text = "ReporrtEndUserForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ReportEndUserForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignRibbonController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.recentlyUsedItemsComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignDockManager1)).EndInit();
            this.hideContainerBottom.ResumeLayout(false);
            this.errorListDockPanel1.ResumeLayout(false);
            this.groupAndSortDockPanel1.ResumeLayout(false);
            this.panelContainer1.ResumeLayout(false);
            this.panelContainer2.ResumeLayout(false);
            this.reportExplorerDockPanel1.ResumeLayout(false);
            this.fieldListDockPanel1.ResumeLayout(false);
            this.panelContainer3.ResumeLayout(false);
            this.propertyGridDockPanel1.ResumeLayout(false);
            this.reportGalleryDockPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemImageComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemZoomTrackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportDesigner1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraReports.UserDesigner.XRDesignMdiController reportDesigner1;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonController xrDesignRibbonController1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.ApplicationMenu applicationMenu1;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem6;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem9;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem7;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem8;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem125;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem126;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem1;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem2;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem3;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem4;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem5;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem10;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem11;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem12;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem13;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem14;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem15;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem16;
        private DevExpress.XtraBars.BarEditItem barEditItem1;
        private DevExpress.XtraReports.UserDesigner.RecentlyUsedItemsComboBox recentlyUsedItemsComboBox1;
        private DevExpress.XtraBars.BarEditItem barEditItem2;
        private DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox designRepositoryItemComboBox1;
        private DevExpress.XtraReports.UserDesigner.BarDockPanelsListItem barDockPanelsListItem1;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem17;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem18;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem19;
        private DevExpress.XtraReports.UserDesigner.CommandColorBarItem commandColorBarItem1;
        private DevExpress.XtraReports.UserDesigner.CommandColorBarItem commandColorBarItem2;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem20;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem21;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem22;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem23;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem24;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem25;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem26;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem27;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem28;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem29;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem30;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem31;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem32;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem33;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem34;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem35;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem36;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem37;
        private DevExpress.XtraReports.UserDesigner.CommandColorBarItem commandColorBarItem3;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem38;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem39;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem40;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem41;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem42;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem43;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem44;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem45;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem46;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem47;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem48;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem49;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem50;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem51;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem52;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem53;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem54;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem55;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem56;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem57;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem58;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem59;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem60;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem61;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem commandBarCheckItem1;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem commandBarCheckItem2;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem62;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem63;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem64;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem65;
        private DevExpress.XtraReports.UserDesigner.CommandColorBarItem commandColorBarItem4;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem66;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem67;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem68;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem69;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem70;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem71;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem72;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem73;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem74;
        private DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem commandGalleryBarItem1;
        private DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem commandGalleryBarItem2;
        private DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem commandGalleryBarItem3;
        private DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem commandGalleryBarItem4;
        private DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem commandGalleryBarItem5;
        private DevExpress.XtraReports.UserDesigner.CommandGalleryBarItem commandGalleryBarItem6;
        private DevExpress.XtraReports.UserDesigner.CommandBarEditItem commandBarEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;
        private DevExpress.XtraReports.UserDesigner.CommandBarEditItem commandBarEditItem2;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit2;
        private DevExpress.XtraReports.UserDesigner.CommandBarEditItem commandBarEditItem3;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit3;
        private DevExpress.XtraReports.UserDesigner.CommandBarEditItem commandBarEditItem4;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit4;
        private DevExpress.XtraReports.UserDesigner.CommandBarEditItem commandBarEditItem5;
        private DevExpress.XtraEditors.Repository.RepositoryItemImageComboBox repositoryItemImageComboBox1;
        private DevExpress.XtraReports.UserDesigner.CommandBarEditItem commandBarEditItem6;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private DevExpress.XtraReports.UserDesigner.CommandBarEditItem commandBarEditItem7;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem75;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem76;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem77;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem78;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem79;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem80;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem81;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem82;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem83;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem84;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem85;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem86;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem87;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem88;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem89;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem90;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem91;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem92;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem93;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem94;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem95;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem96;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem97;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem98;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem99;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem100;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem101;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem102;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem103;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem104;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem105;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem106;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem107;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem108;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem109;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem110;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem111;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem112;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem113;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem114;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem115;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem116;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem117;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem118;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem119;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem120;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem commandBarCheckItem3;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem commandBarCheckItem4;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem commandBarCheckItem5;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem commandBarCheckItem6;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem commandBarCheckItem7;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem commandBarCheckItem8;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem121;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem122;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem123;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem124;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup1;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup2;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup3;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup4;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup5;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup6;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup7;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup8;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup9;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup10;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup11;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup12;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup13;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup14;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem2;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem3;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem4;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem5;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem7;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem8;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem9;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem11;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem12;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem13;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem14;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem15;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem16;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem17;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem18;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem19;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem20;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem21;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem22;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem23;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem24;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem25;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem26;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem27;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem28;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem29;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem30;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem31;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem32;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem33;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem34;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem35;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem36;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem37;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem38;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem39;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem40;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem41;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem42;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem43;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem44;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem45;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem46;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem47;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem48;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem49;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem50;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem51;
        private DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem printPreviewStaticItem1;
        private DevExpress.XtraPrinting.Preview.ProgressBarEditItem progressBarEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemProgressBar repositoryItemProgressBar1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem52;
        private DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem printPreviewStaticItem2;
        private DevExpress.XtraPrinting.Preview.ZoomTrackBarEditItem zoomTrackBarEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar repositoryItemZoomTrackBar1;
        private DevExpress.XtraReports.UserDesigner.XRCharacterCombRibbonPageCategory ribbonPageCategory1;
        private DevExpress.XtraReports.UserDesigner.XRCharacterCombDesignContextRibbonPage ribbonPage6;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup18;
        private DevExpress.XtraReports.UserDesigner.XRTableRibbonPageCategory ribbonPageCategory2;
        private DevExpress.XtraReports.UserDesigner.XRTableDesignContextRibbonPage ribbonPage7;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup19;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup20;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup21;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup22;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup23;
        private DevExpress.XtraReports.UserDesigner.XRChartRibbonPageCategory ribbonPageCategory3;
        private DevExpress.XtraReports.UserDesigner.XRChartDesignContextRibbonPage ribbonPage8;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup24;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup25;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup26;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup27;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup28;
        private DevExpress.XtraReports.UserDesigner.XRPivotGridRibbonPageCategory ribbonPageCategory4;
        private DevExpress.XtraReports.UserDesigner.XRPivotGridDesignContextRibbonPage ribbonPage9;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup29;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup30;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup31;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup32;
        private DevExpress.XtraReports.UserDesigner.XRBarCodeRibbonPageCategory ribbonPageCategory5;
        private DevExpress.XtraReports.UserDesigner.XRBarcodeDesignContextRibbonPage ribbonPage10;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup33;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup34;
        private DevExpress.XtraReports.UserDesigner.XRGaugeRibbonPageCategory ribbonPageCategory6;
        private DevExpress.XtraReports.UserDesigner.XRGaugeDesignContextRibbonPage ribbonPage11;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup35;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup36;
        private DevExpress.XtraReports.UserDesigner.XRSparklineRibbonPageCategory ribbonPageCategory7;
        private DevExpress.XtraReports.UserDesigner.XRSparklineDesignContextRibbonPage ribbonPage12;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup37;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup38;
        private DevExpress.XtraReports.UserDesigner.XRShapeRibbonPageCategory ribbonPageCategory8;
        private DevExpress.XtraReports.UserDesigner.XRShapeDesignContextRibbonPage ribbonPage13;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup39;
        private DevExpress.XtraReports.UserDesigner.XRLabelRibbonPageCategory ribbonPageCategory9;
        private DevExpress.XtraReports.UserDesigner.XRLabelTextContextRibbonPage ribbonPage14;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup40;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup41;
        private DevExpress.XtraReports.UserDesigner.XRHomeRibbonPage ribbonPage1;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup1;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup2;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup3;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup4;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup5;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup6;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup7;
        private DevExpress.XtraReports.UserDesigner.XRLayoutRibbonPage ribbonPage2;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup8;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup9;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup10;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup11;
        private DevExpress.XtraReports.UserDesigner.XRPageRibbonPage ribbonPage3;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup12;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup13;
        private DevExpress.XtraReports.UserDesigner.XRViewRibbonPage ribbonPage4;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup14;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup15;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup16;
        private DevExpress.XtraReports.UserDesigner.XRScriptsRibbonPage ribbonPage5;
        private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup17;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage ribbonPage15;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup2;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup3;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup4;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup5;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup6;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup7;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup8;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar1;
        private DevExpress.XtraReports.UserDesigner.XRDesignDockManager xrDesignDockManager1;
        private DevExpress.XtraReports.UserDesigner.GroupAndSortDockPanel groupAndSortDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer groupAndSortDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.ErrorListDockPanel errorListDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer errorListDockPanel1_Container;
        private DevExpress.XtraBars.Docking.DockPanel panelContainer1;
        private DevExpress.XtraBars.Docking.DockPanel panelContainer2;
        private DevExpress.XtraReports.UserDesigner.ReportExplorerDockPanel reportExplorerDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer reportExplorerDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.FieldListDockPanel fieldListDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer fieldListDockPanel1_Container;
        private DevExpress.XtraBars.Docking.DockPanel panelContainer3;
        private DevExpress.XtraReports.UserDesigner.PropertyGridDockPanel propertyGridDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer propertyGridDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.ReportGalleryDockPanel reportGalleryDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer reportGalleryDockPanel1_Container;
        private DevExpress.XtraBars.Docking.AutoHideContainer hideContainerBottom;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage16;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage17;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.BarButtonItem btnOpenDefaultRprt;
    }
}