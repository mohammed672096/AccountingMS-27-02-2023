﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PosFinalCost
{
    class ClsProductBarcodeList
    {
        public string barcodeNo { set; get; }
        public string productName { set; get; }
        public string productMeasurment { set; get; }
        public decimal productSalePrice { set; get; }
    }
}
