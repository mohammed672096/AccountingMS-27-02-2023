﻿
namespace PosFinalCost.Forms
{
    partial class frmBoxPeriod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBoxPeriod));
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.dataLayoutControl1 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.tblSupplyMainBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colsupStatus = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupBankAmount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colnet = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colsupStatusType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.IDTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.BoxPeriodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.OpeningBalanceTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.ClosingBalanceTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.ActualBalanceTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.PeriodUserIDTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.TransferdBalanceTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.RemainingBalanceTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.OpenPeriodButton = new DevExpress.XtraEditors.SimpleButton();
            this.BalanceDifferenceTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.ClosePeriodButton = new DevExpress.XtraEditors.SimpleButton();
            this.BoxIDTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.tblCurrencyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.DifferenceAccountIDTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.ClosingDrwerIDTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.ClosingPeriodUserIDTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.tblUserBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.curNametextEdit = new DevExpress.XtraEditors.TextEdit();
            this.OpenNowtextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.BranchIDTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.tblBranchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.PeriodStartDateEdit = new DevExpress.XtraEditors.DateTimeOffsetEdit();
            this.PeriodEndDateEdit = new DevExpress.XtraEditors.DateTimeOffsetEdit();
            this.totalSubAccBanktextEdit = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.lyc_ClosingGroup = new DevExpress.XtraLayout.LayoutControlGroup();
            this.ItemForClosingPeriodUserID = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForActualBalance = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForBalanceDifference = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForDifferenceAccountID = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForClosingDrwerID = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForTransferdBalance = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForRemainingBalance = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForPeriodEnd = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.lyc_OpeningGroup = new DevExpress.XtraLayout.LayoutControlGroup();
            this.ItemForID = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForBranchID = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForBoxID = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForPeriodStart = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForPeriodUserID = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForOpeningBalance = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.ItemForClosingBalance = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).BeginInit();
            this.dataLayoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplyMainBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxPeriodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpeningBalanceTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosingBalanceTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ActualBalanceTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PeriodUserIDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TransferdBalanceTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RemainingBalanceTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceDifferenceTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxIDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCurrencyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DifferenceAccountIDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosingDrwerIDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosingPeriodUserIDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.curNametextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpenNowtextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BranchIDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblBranchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PeriodStartDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PeriodEndDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalSubAccBanktextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lyc_ClosingGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForClosingPeriodUserID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForActualBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBalanceDifference)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForDifferenceAccountID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForClosingDrwerID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForTransferdBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForRemainingBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPeriodEnd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lyc_OpeningGroup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBranchID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBoxID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPeriodStart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPeriodUserID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForOpeningBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForClosingBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.EmptyAreaImageOptions.ImagePadding = new System.Windows.Forms.Padding(34, 39, 34, 39);
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.ribbonControl1.SearchEditItem,
            this.barButtonItem1,
            this.barButtonItem2,
            this.barButtonItem3});
            resources.ApplyResources(this.ribbonControl1, "ribbonControl1");
            this.ribbonControl1.MaxItemId = 4;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.OptionsMenuMinWidth = 377;
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1});
            this.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.OfficeUniversal;
            // 
            // barButtonItem1
            // 
            resources.ApplyResources(this.barButtonItem1, "barButtonItem1");
            this.barButtonItem1.Id = 1;
            this.barButtonItem1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem1.ImageOptions.SvgImage")));
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // barButtonItem2
            // 
            resources.ApplyResources(this.barButtonItem2, "barButtonItem2");
            this.barButtonItem2.Id = 2;
            this.barButtonItem2.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem2.ImageOptions.SvgImage")));
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // barButtonItem3
            // 
            resources.ApplyResources(this.barButtonItem3, "barButtonItem3");
            this.barButtonItem3.Id = 3;
            this.barButtonItem3.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem3.ImageOptions.SvgImage")));
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem3_ItemClick);
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage1.Name = "ribbonPage1";
            resources.ApplyResources(this.ribbonPage1, "ribbonPage1");
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.barButtonItem1);
            this.ribbonPageGroup1.ItemLinks.Add(this.barButtonItem3);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            resources.ApplyResources(this.ribbonPageGroup1, "ribbonPageGroup1");
            // 
            // dataLayoutControl1
            // 
            this.dataLayoutControl1.Controls.Add(this.gridControl1);
            this.dataLayoutControl1.Controls.Add(this.IDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.OpeningBalanceTextEdit);
            this.dataLayoutControl1.Controls.Add(this.ClosingBalanceTextEdit);
            this.dataLayoutControl1.Controls.Add(this.ActualBalanceTextEdit);
            this.dataLayoutControl1.Controls.Add(this.PeriodUserIDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.TransferdBalanceTextEdit);
            this.dataLayoutControl1.Controls.Add(this.RemainingBalanceTextEdit);
            this.dataLayoutControl1.Controls.Add(this.OpenPeriodButton);
            this.dataLayoutControl1.Controls.Add(this.BalanceDifferenceTextEdit);
            this.dataLayoutControl1.Controls.Add(this.ClosePeriodButton);
            this.dataLayoutControl1.Controls.Add(this.BoxIDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.DifferenceAccountIDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.ClosingDrwerIDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.ClosingPeriodUserIDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.textEdit1);
            this.dataLayoutControl1.Controls.Add(this.curNametextEdit);
            this.dataLayoutControl1.Controls.Add(this.OpenNowtextEdit);
            this.dataLayoutControl1.Controls.Add(this.BranchIDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.PeriodStartDateEdit);
            this.dataLayoutControl1.Controls.Add(this.PeriodEndDateEdit);
            this.dataLayoutControl1.Controls.Add(this.totalSubAccBanktextEdit);
            this.dataLayoutControl1.DataSource = this.BoxPeriodBindingSource;
            resources.ApplyResources(this.dataLayoutControl1, "dataLayoutControl1");
            this.dataLayoutControl1.Name = "dataLayoutControl1";
            this.dataLayoutControl1.OptionsView.RightToLeftMirroringApplied = true;
            this.dataLayoutControl1.Root = this.layoutControlGroup1;
            // 
            // gridControl1
            // 
            this.gridControl1.CausesValidation = false;
            this.gridControl1.DataSource = this.tblSupplyMainBindingSource;
            this.gridControl1.EmbeddedNavigator.Margin = ((System.Windows.Forms.Padding)(resources.GetObject("gridControl1.EmbeddedNavigator.Margin")));
            resources.ApplyResources(this.gridControl1, "gridControl1");
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.MenuManager = this.ribbonControl1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1,
            this.repositoryItemTextEdit2});
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // tblSupplyMainBindingSource
            // 
            this.tblSupplyMainBindingSource.DataSource = typeof(PosFinalCost.tblSupplyMain);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colsupStatus,
            this.colsupNo,
            this.colsupDate,
            this.colsupBankAmount,
            this.colnet,
            this.colsupStatusType});
            this.gridView1.DetailHeight = 450;
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colnet, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // colsupStatus
            // 
            this.colsupStatus.AppearanceCell.Options.UseTextOptions = true;
            this.colsupStatus.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colsupStatus.AppearanceHeader.Options.UseTextOptions = true;
            this.colsupStatus.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.colsupStatus, "colsupStatus");
            this.colsupStatus.FieldName = "supStatus";
            this.colsupStatus.MinWidth = 23;
            this.colsupStatus.Name = "colsupStatus";
            // 
            // colsupNo
            // 
            this.colsupNo.AppearanceCell.Options.UseTextOptions = true;
            this.colsupNo.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colsupNo.AppearanceHeader.Options.UseTextOptions = true;
            this.colsupNo.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.colsupNo, "colsupNo");
            this.colsupNo.FieldName = "supNo";
            this.colsupNo.MinWidth = 23;
            this.colsupNo.Name = "colsupNo";
            // 
            // colsupDate
            // 
            this.colsupDate.AppearanceCell.Options.UseTextOptions = true;
            this.colsupDate.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colsupDate.AppearanceHeader.Options.UseTextOptions = true;
            this.colsupDate.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.colsupDate, "colsupDate");
            this.colsupDate.FieldName = "supDate";
            this.colsupDate.MinWidth = 23;
            this.colsupDate.Name = "colsupDate";
            // 
            // colsupBankAmount
            // 
            resources.ApplyResources(this.colsupBankAmount, "colsupBankAmount");
            this.colsupBankAmount.ColumnEdit = this.repositoryItemTextEdit1;
            this.colsupBankAmount.FieldName = "supBankAmount";
            this.colsupBankAmount.MinWidth = 23;
            this.colsupBankAmount.Name = "colsupBankAmount";
            // 
            // repositoryItemTextEdit1
            // 
            resources.ApplyResources(this.repositoryItemTextEdit1, "repositoryItemTextEdit1");
            this.repositoryItemTextEdit1.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.repositoryItemTextEdit1.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.repositoryItemTextEdit1.MaskSettings.Set("mask", "f");
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // colnet
            // 
            this.colnet.AppearanceCell.Options.UseTextOptions = true;
            this.colnet.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.colnet.AppearanceHeader.Options.UseTextOptions = true;
            this.colnet.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.colnet, "colnet");
            this.colnet.ColumnEdit = this.repositoryItemTextEdit2;
            this.colnet.FieldName = "net";
            this.colnet.MinWidth = 23;
            this.colnet.Name = "colnet";
            // 
            // repositoryItemTextEdit2
            // 
            resources.ApplyResources(this.repositoryItemTextEdit2, "repositoryItemTextEdit2");
            this.repositoryItemTextEdit2.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.repositoryItemTextEdit2.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.repositoryItemTextEdit2.MaskSettings.Set("mask", "f");
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            // 
            // colsupStatusType
            // 
            resources.ApplyResources(this.colsupStatusType, "colsupStatusType");
            this.colsupStatusType.FieldName = "statusType";
            this.colsupStatusType.MinWidth = 23;
            this.colsupStatusType.Name = "colsupStatusType";
            // 
            // IDTextEdit
            // 
            this.IDTextEdit.CausesValidation = false;
            this.IDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "ID", true));
            resources.ApplyResources(this.IDTextEdit, "IDTextEdit");
            this.IDTextEdit.MenuManager = this.ribbonControl1;
            this.IDTextEdit.Name = "IDTextEdit";
            this.IDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.IDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.IDTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("IDTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.IDTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.IDTextEdit.Properties.MaskSettings.Set("mask", "N0");
            this.IDTextEdit.Properties.ReadOnly = true;
            this.IDTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // BoxPeriodBindingSource
            // 
            this.BoxPeriodBindingSource.DataSource = typeof(PosFinalCost.BoxPeriod);
            this.BoxPeriodBindingSource.CurrentChanged += new System.EventHandler(this.BoxPeriodBindingSource_CurrentChanged);
            // 
            // OpeningBalanceTextEdit
            // 
            this.OpeningBalanceTextEdit.CausesValidation = false;
            this.OpeningBalanceTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "OpeningBalance", true));
            resources.ApplyResources(this.OpeningBalanceTextEdit, "OpeningBalanceTextEdit");
            this.OpeningBalanceTextEdit.MenuManager = this.ribbonControl1;
            this.OpeningBalanceTextEdit.Name = "OpeningBalanceTextEdit";
            this.OpeningBalanceTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.OpeningBalanceTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.OpeningBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("OpeningBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.OpeningBalanceTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.OpeningBalanceTextEdit.Properties.MaskSettings.Set("mask", "F");
            this.OpeningBalanceTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // ClosingBalanceTextEdit
            // 
            this.ClosingBalanceTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "ClosingBalance", true));
            resources.ApplyResources(this.ClosingBalanceTextEdit, "ClosingBalanceTextEdit");
            this.ClosingBalanceTextEdit.MenuManager = this.ribbonControl1;
            this.ClosingBalanceTextEdit.Name = "ClosingBalanceTextEdit";
            this.ClosingBalanceTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.ClosingBalanceTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.ClosingBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("ClosingBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.ClosingBalanceTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.ClosingBalanceTextEdit.Properties.MaskSettings.Set("mask", "F");
            this.ClosingBalanceTextEdit.Properties.ReadOnly = true;
            this.ClosingBalanceTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // ActualBalanceTextEdit
            // 
            this.ActualBalanceTextEdit.CausesValidation = false;
            this.ActualBalanceTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "ActualBalance", true));
            resources.ApplyResources(this.ActualBalanceTextEdit, "ActualBalanceTextEdit");
            this.ActualBalanceTextEdit.MenuManager = this.ribbonControl1;
            this.ActualBalanceTextEdit.Name = "ActualBalanceTextEdit";
            this.ActualBalanceTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.ActualBalanceTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.ActualBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("ActualBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.ActualBalanceTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.ActualBalanceTextEdit.Properties.MaskSettings.Set("mask", "F");
            this.ActualBalanceTextEdit.StyleController = this.dataLayoutControl1;
            this.ActualBalanceTextEdit.EditValueChanged += new System.EventHandler(this.ActualBalanceTextEdit_EditValueChanged);
            // 
            // PeriodUserIDTextEdit
            // 
            this.PeriodUserIDTextEdit.CausesValidation = false;
            this.PeriodUserIDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "PeriodUserID", true));
            resources.ApplyResources(this.PeriodUserIDTextEdit, "PeriodUserIDTextEdit");
            this.PeriodUserIDTextEdit.MenuManager = this.ribbonControl1;
            this.PeriodUserIDTextEdit.Name = "PeriodUserIDTextEdit";
            this.PeriodUserIDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.PeriodUserIDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.PeriodUserIDTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("PeriodUserIDTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.PeriodUserIDTextEdit.Properties.ReadOnly = true;
            this.PeriodUserIDTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // TransferdBalanceTextEdit
            // 
            this.TransferdBalanceTextEdit.CausesValidation = false;
            this.TransferdBalanceTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "TransferdBalance", true));
            resources.ApplyResources(this.TransferdBalanceTextEdit, "TransferdBalanceTextEdit");
            this.TransferdBalanceTextEdit.MenuManager = this.ribbonControl1;
            this.TransferdBalanceTextEdit.Name = "TransferdBalanceTextEdit";
            this.TransferdBalanceTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.TransferdBalanceTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.TransferdBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("TransferdBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.TransferdBalanceTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.TransferdBalanceTextEdit.Properties.MaskSettings.Set("mask", "F");
            this.TransferdBalanceTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // RemainingBalanceTextEdit
            // 
            this.RemainingBalanceTextEdit.CausesValidation = false;
            this.RemainingBalanceTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "RemainingBalance", true));
            resources.ApplyResources(this.RemainingBalanceTextEdit, "RemainingBalanceTextEdit");
            this.RemainingBalanceTextEdit.MenuManager = this.ribbonControl1;
            this.RemainingBalanceTextEdit.Name = "RemainingBalanceTextEdit";
            this.RemainingBalanceTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.RemainingBalanceTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.RemainingBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("RemainingBalanceTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.RemainingBalanceTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.RemainingBalanceTextEdit.Properties.MaskSettings.Set("mask", "F");
            this.RemainingBalanceTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // OpenPeriodButton
            // 
            resources.ApplyResources(this.OpenPeriodButton, "OpenPeriodButton");
            this.OpenPeriodButton.Name = "OpenPeriodButton";
            this.OpenPeriodButton.StyleController = this.dataLayoutControl1;
            this.OpenPeriodButton.Click += new System.EventHandler(this.OpenPeriodButton_Click);
            // 
            // BalanceDifferenceTextEdit
            // 
            this.BalanceDifferenceTextEdit.CausesValidation = false;
            resources.ApplyResources(this.BalanceDifferenceTextEdit, "BalanceDifferenceTextEdit");
            this.BalanceDifferenceTextEdit.MenuManager = this.ribbonControl1;
            this.BalanceDifferenceTextEdit.Name = "BalanceDifferenceTextEdit";
            this.BalanceDifferenceTextEdit.Properties.ReadOnly = true;
            this.BalanceDifferenceTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // ClosePeriodButton
            // 
            resources.ApplyResources(this.ClosePeriodButton, "ClosePeriodButton");
            this.ClosePeriodButton.Name = "ClosePeriodButton";
            this.ClosePeriodButton.StyleController = this.dataLayoutControl1;
            this.ClosePeriodButton.Click += new System.EventHandler(this.ClosePeriodButton_Click);
            // 
            // BoxIDTextEdit
            // 
            this.BoxIDTextEdit.CausesValidation = false;
            this.BoxIDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "BoxID", true));
            resources.ApplyResources(this.BoxIDTextEdit, "BoxIDTextEdit");
            this.BoxIDTextEdit.MenuManager = this.ribbonControl1;
            this.BoxIDTextEdit.Name = "BoxIDTextEdit";
            this.BoxIDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.BoxIDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.BoxIDTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("BoxIDTextEdit.Properties.Buttons"))))});
            this.BoxIDTextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("BoxIDTextEdit.Properties.Columns"), resources.GetString("BoxIDTextEdit.Properties.Columns1"), ((int)(resources.GetObject("BoxIDTextEdit.Properties.Columns2"))), ((DevExpress.Utils.FormatType)(resources.GetObject("BoxIDTextEdit.Properties.Columns3"))), resources.GetString("BoxIDTextEdit.Properties.Columns4"), ((bool)(resources.GetObject("BoxIDTextEdit.Properties.Columns5"))), ((DevExpress.Utils.HorzAlignment)(resources.GetObject("BoxIDTextEdit.Properties.Columns6"))), ((DevExpress.Data.ColumnSortOrder)(resources.GetObject("BoxIDTextEdit.Properties.Columns7"))), ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("BoxIDTextEdit.Properties.Columns8"))))});
            this.BoxIDTextEdit.Properties.NullText = resources.GetString("BoxIDTextEdit.Properties.NullText");
            this.BoxIDTextEdit.Properties.ShowFooter = false;
            this.BoxIDTextEdit.Properties.ShowHeader = false;
            this.BoxIDTextEdit.Properties.ShowLines = false;
            this.BoxIDTextEdit.StyleController = this.dataLayoutControl1;
            this.BoxIDTextEdit.EditValueChanged += new System.EventHandler(this.BoxIDTextEdit_EditValueChanged);
            // 
            // tblCurrencyBindingSource
            // 
            this.tblCurrencyBindingSource.DataSource = typeof(PosFinalCost.tblCurrency);
            // 
            // DifferenceAccountIDTextEdit
            // 
            this.DifferenceAccountIDTextEdit.CausesValidation = false;
            this.DifferenceAccountIDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "DifferenceAccountID", true));
            resources.ApplyResources(this.DifferenceAccountIDTextEdit, "DifferenceAccountIDTextEdit");
            this.DifferenceAccountIDTextEdit.MenuManager = this.ribbonControl1;
            this.DifferenceAccountIDTextEdit.Name = "DifferenceAccountIDTextEdit";
            this.DifferenceAccountIDTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.DifferenceAccountIDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.DifferenceAccountIDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.DifferenceAccountIDTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("DifferenceAccountIDTextEdit.Properties.Buttons"))))});
            this.DifferenceAccountIDTextEdit.Properties.NullText = resources.GetString("DifferenceAccountIDTextEdit.Properties.NullText");
            this.DifferenceAccountIDTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // ClosingDrwerIDTextEdit
            // 
            this.ClosingDrwerIDTextEdit.CausesValidation = false;
            this.ClosingDrwerIDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "ClosingDrwerID", true));
            resources.ApplyResources(this.ClosingDrwerIDTextEdit, "ClosingDrwerIDTextEdit");
            this.ClosingDrwerIDTextEdit.MenuManager = this.ribbonControl1;
            this.ClosingDrwerIDTextEdit.Name = "ClosingDrwerIDTextEdit";
            this.ClosingDrwerIDTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.ClosingDrwerIDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.ClosingDrwerIDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.ClosingDrwerIDTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("ClosingDrwerIDTextEdit.Properties.Buttons"))))});
            this.ClosingDrwerIDTextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("ClosingDrwerIDTextEdit.Properties.Columns"), resources.GetString("ClosingDrwerIDTextEdit.Properties.Columns1"), ((int)(resources.GetObject("ClosingDrwerIDTextEdit.Properties.Columns2"))), ((DevExpress.Utils.FormatType)(resources.GetObject("ClosingDrwerIDTextEdit.Properties.Columns3"))), resources.GetString("ClosingDrwerIDTextEdit.Properties.Columns4"), ((bool)(resources.GetObject("ClosingDrwerIDTextEdit.Properties.Columns5"))), ((DevExpress.Utils.HorzAlignment)(resources.GetObject("ClosingDrwerIDTextEdit.Properties.Columns6"))), ((DevExpress.Data.ColumnSortOrder)(resources.GetObject("ClosingDrwerIDTextEdit.Properties.Columns7"))), ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("ClosingDrwerIDTextEdit.Properties.Columns8"))))});
            this.ClosingDrwerIDTextEdit.Properties.DataSource = this.tblCurrencyBindingSource;
            this.ClosingDrwerIDTextEdit.Properties.DisplayMember = "curName";
            this.ClosingDrwerIDTextEdit.Properties.NullText = resources.GetString("ClosingDrwerIDTextEdit.Properties.NullText");
            this.ClosingDrwerIDTextEdit.Properties.ShowFooter = false;
            this.ClosingDrwerIDTextEdit.Properties.ShowHeader = false;
            this.ClosingDrwerIDTextEdit.Properties.ShowLines = false;
            this.ClosingDrwerIDTextEdit.Properties.ValueMember = "id";
            this.ClosingDrwerIDTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // ClosingPeriodUserIDTextEdit
            // 
            this.ClosingPeriodUserIDTextEdit.CausesValidation = false;
            this.ClosingPeriodUserIDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "ClosingPeriodUserID", true));
            resources.ApplyResources(this.ClosingPeriodUserIDTextEdit, "ClosingPeriodUserIDTextEdit");
            this.ClosingPeriodUserIDTextEdit.MenuManager = this.ribbonControl1;
            this.ClosingPeriodUserIDTextEdit.Name = "ClosingPeriodUserIDTextEdit";
            this.ClosingPeriodUserIDTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.ClosingPeriodUserIDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.ClosingPeriodUserIDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.ClosingPeriodUserIDTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("ClosingPeriodUserIDTextEdit.Properties.Buttons"))))});
            this.ClosingPeriodUserIDTextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("ClosingPeriodUserIDTextEdit.Properties.Columns"), resources.GetString("ClosingPeriodUserIDTextEdit.Properties.Columns1"), ((int)(resources.GetObject("ClosingPeriodUserIDTextEdit.Properties.Columns2"))), ((DevExpress.Utils.FormatType)(resources.GetObject("ClosingPeriodUserIDTextEdit.Properties.Columns3"))), resources.GetString("ClosingPeriodUserIDTextEdit.Properties.Columns4"), ((bool)(resources.GetObject("ClosingPeriodUserIDTextEdit.Properties.Columns5"))), ((DevExpress.Utils.HorzAlignment)(resources.GetObject("ClosingPeriodUserIDTextEdit.Properties.Columns6"))), ((DevExpress.Data.ColumnSortOrder)(resources.GetObject("ClosingPeriodUserIDTextEdit.Properties.Columns7"))), ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("ClosingPeriodUserIDTextEdit.Properties.Columns8"))))});
            this.ClosingPeriodUserIDTextEdit.Properties.DataSource = this.tblUserBindingSource;
            this.ClosingPeriodUserIDTextEdit.Properties.DisplayMember = "userName";
            this.ClosingPeriodUserIDTextEdit.Properties.NullText = resources.GetString("ClosingPeriodUserIDTextEdit.Properties.NullText");
            this.ClosingPeriodUserIDTextEdit.Properties.ShowFooter = false;
            this.ClosingPeriodUserIDTextEdit.Properties.ShowHeader = false;
            this.ClosingPeriodUserIDTextEdit.Properties.ShowLines = false;
            this.ClosingPeriodUserIDTextEdit.Properties.ValueMember = "id";
            this.ClosingPeriodUserIDTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // tblUserBindingSource
            // 
            this.tblUserBindingSource.DataSource = typeof(PosFinalCost.tblUser);
            // 
            // textEdit1
            // 
            resources.ApplyResources(this.textEdit1, "textEdit1");
            this.textEdit1.MenuManager = this.ribbonControl1;
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Properties.Appearance.Options.UseTextOptions = true;
            this.textEdit1.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.textEdit1.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.textEdit1.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.textEdit1.Properties.MaskSettings.Set("mask", "f");
            this.textEdit1.Properties.ReadOnly = true;
            this.textEdit1.StyleController = this.dataLayoutControl1;
            // 
            // curNametextEdit
            // 
            resources.ApplyResources(this.curNametextEdit, "curNametextEdit");
            this.curNametextEdit.MenuManager = this.ribbonControl1;
            this.curNametextEdit.Name = "curNametextEdit";
            this.curNametextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.curNametextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.curNametextEdit.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.curNametextEdit.Properties.ReadOnly = true;
            this.curNametextEdit.StyleController = this.dataLayoutControl1;
            // 
            // OpenNowtextEdit
            // 
            this.OpenNowtextEdit.CausesValidation = false;
            resources.ApplyResources(this.OpenNowtextEdit, "OpenNowtextEdit");
            this.OpenNowtextEdit.MenuManager = this.ribbonControl1;
            this.OpenNowtextEdit.Name = "OpenNowtextEdit";
            this.OpenNowtextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("OpenNowtextEdit.Properties.Buttons"))))});
            this.OpenNowtextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("OpenNowtextEdit.Properties.Columns"), resources.GetString("OpenNowtextEdit.Properties.Columns1"), ((int)(resources.GetObject("OpenNowtextEdit.Properties.Columns2"))), ((DevExpress.Utils.FormatType)(resources.GetObject("OpenNowtextEdit.Properties.Columns3"))), resources.GetString("OpenNowtextEdit.Properties.Columns4"), ((bool)(resources.GetObject("OpenNowtextEdit.Properties.Columns5"))), ((DevExpress.Utils.HorzAlignment)(resources.GetObject("OpenNowtextEdit.Properties.Columns6"))), ((DevExpress.Data.ColumnSortOrder)(resources.GetObject("OpenNowtextEdit.Properties.Columns7"))), ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("OpenNowtextEdit.Properties.Columns8"))))});
            this.OpenNowtextEdit.Properties.DataSource = this.BoxPeriodBindingSource;
            this.OpenNowtextEdit.Properties.DisplayMember = "ID";
            this.OpenNowtextEdit.Properties.NullText = resources.GetString("OpenNowtextEdit.Properties.NullText");
            this.OpenNowtextEdit.Properties.ShowFooter = false;
            this.OpenNowtextEdit.Properties.ShowHeader = false;
            this.OpenNowtextEdit.Properties.ShowLines = false;
            this.OpenNowtextEdit.Properties.ValueMember = "ID";
            this.OpenNowtextEdit.StyleController = this.dataLayoutControl1;
            this.OpenNowtextEdit.EditValueChanged += new System.EventHandler(this.OpenNowtextEdit_EditValueChanged);
            // 
            // BranchIDTextEdit
            // 
            this.BranchIDTextEdit.CausesValidation = false;
            this.BranchIDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "BranchID", true));
            resources.ApplyResources(this.BranchIDTextEdit, "BranchIDTextEdit");
            this.BranchIDTextEdit.MenuManager = this.ribbonControl1;
            this.BranchIDTextEdit.Name = "BranchIDTextEdit";
            this.BranchIDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.BranchIDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.BranchIDTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("BranchIDTextEdit.Properties.Buttons"))))});
            this.BranchIDTextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("BranchIDTextEdit.Properties.Columns"), resources.GetString("BranchIDTextEdit.Properties.Columns1"), ((int)(resources.GetObject("BranchIDTextEdit.Properties.Columns2"))), ((DevExpress.Utils.FormatType)(resources.GetObject("BranchIDTextEdit.Properties.Columns3"))), resources.GetString("BranchIDTextEdit.Properties.Columns4"), ((bool)(resources.GetObject("BranchIDTextEdit.Properties.Columns5"))), ((DevExpress.Utils.HorzAlignment)(resources.GetObject("BranchIDTextEdit.Properties.Columns6"))), ((DevExpress.Data.ColumnSortOrder)(resources.GetObject("BranchIDTextEdit.Properties.Columns7"))), ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("BranchIDTextEdit.Properties.Columns8"))))});
            this.BranchIDTextEdit.Properties.NullText = resources.GetString("BranchIDTextEdit.Properties.NullText");
            this.BranchIDTextEdit.Properties.ShowFooter = false;
            this.BranchIDTextEdit.Properties.ShowHeader = false;
            this.BranchIDTextEdit.Properties.ShowLines = false;
            this.BranchIDTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // tblBranchBindingSource
            // 
            this.tblBranchBindingSource.DataSource = typeof(PosFinalCost.tblBranch);
            // 
            // PeriodStartDateEdit
            // 
            this.PeriodStartDateEdit.CausesValidation = false;
            this.PeriodStartDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "PeriodStart", true));
            resources.ApplyResources(this.PeriodStartDateEdit, "PeriodStartDateEdit");
            this.PeriodStartDateEdit.MenuManager = this.ribbonControl1;
            this.PeriodStartDateEdit.Name = "PeriodStartDateEdit";
            this.PeriodStartDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("PeriodStartDateEdit.Properties.Buttons"))))});
            this.PeriodStartDateEdit.Properties.DisplayFormat.FormatString = "d";
            this.PeriodStartDateEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.PeriodStartDateEdit.Properties.EditFormat.FormatString = "d";
            this.PeriodStartDateEdit.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.PeriodStartDateEdit.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Default;
            this.PeriodStartDateEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.DateTimeOffsetMaskManager));
            this.PeriodStartDateEdit.Properties.MaskSettings.Set("mask", "G");
            this.PeriodStartDateEdit.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.PeriodStartDateEdit.StyleController = this.dataLayoutControl1;
            // 
            // PeriodEndDateEdit
            // 
            this.PeriodEndDateEdit.CausesValidation = false;
            this.PeriodEndDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "PeriodEnd", true));
            resources.ApplyResources(this.PeriodEndDateEdit, "PeriodEndDateEdit");
            this.PeriodEndDateEdit.MenuManager = this.ribbonControl1;
            this.PeriodEndDateEdit.Name = "PeriodEndDateEdit";
            this.PeriodEndDateEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.PeriodEndDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("PeriodEndDateEdit.Properties.Buttons"))))});
            this.PeriodEndDateEdit.Properties.DisplayFormat.FormatString = "d";
            this.PeriodEndDateEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.PeriodEndDateEdit.Properties.EditFormat.FormatString = "d";
            this.PeriodEndDateEdit.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.PeriodEndDateEdit.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Default;
            this.PeriodEndDateEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.DateTimeOffsetMaskManager));
            this.PeriodEndDateEdit.Properties.MaskSettings.Set("mask", "G");
            this.PeriodEndDateEdit.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.PeriodEndDateEdit.StyleController = this.dataLayoutControl1;
            // 
            // totalSubAccBanktextEdit
            // 
            resources.ApplyResources(this.totalSubAccBanktextEdit, "totalSubAccBanktextEdit");
            this.totalSubAccBanktextEdit.MenuManager = this.ribbonControl1;
            this.totalSubAccBanktextEdit.Name = "totalSubAccBanktextEdit";
            this.totalSubAccBanktextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.totalSubAccBanktextEdit.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.totalSubAccBanktextEdit.Properties.MaskSettings.Set("mask", "f");
            this.totalSubAccBanktextEdit.Properties.ReadOnly = true;
            this.totalSubAccBanktextEdit.StyleController = this.dataLayoutControl1;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lyc_ClosingGroup,
            this.lyc_OpeningGroup,
            this.layoutControlGroup2});
            this.layoutControlGroup1.Name = "layoutControlGroup1";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1202, 735);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // lyc_ClosingGroup
            // 
            this.lyc_ClosingGroup.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.ItemForClosingPeriodUserID,
            this.ItemForActualBalance,
            this.ItemForBalanceDifference,
            this.ItemForDifferenceAccountID,
            this.ItemForClosingDrwerID,
            this.ItemForTransferdBalance,
            this.ItemForRemainingBalance,
            this.ItemForPeriodEnd,
            this.layoutControlItem17});
            this.lyc_ClosingGroup.Location = new System.Drawing.Point(0, 0);
            this.lyc_ClosingGroup.Name = "lyc_ClosingGroup";
            this.lyc_ClosingGroup.Size = new System.Drawing.Size(304, 709);
            resources.ApplyResources(this.lyc_ClosingGroup, "lyc_ClosingGroup");
            // 
            // ItemForClosingPeriodUserID
            // 
            this.ItemForClosingPeriodUserID.Control = this.ClosingPeriodUserIDTextEdit;
            this.ItemForClosingPeriodUserID.Location = new System.Drawing.Point(0, 30);
            this.ItemForClosingPeriodUserID.Name = "ItemForClosingPeriodUserID";
            this.ItemForClosingPeriodUserID.Size = new System.Drawing.Size(278, 30);
            resources.ApplyResources(this.ItemForClosingPeriodUserID, "ItemForClosingPeriodUserID");
            this.ItemForClosingPeriodUserID.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForActualBalance
            // 
            this.ItemForActualBalance.Control = this.ActualBalanceTextEdit;
            this.ItemForActualBalance.Location = new System.Drawing.Point(0, 60);
            this.ItemForActualBalance.Name = "ItemForActualBalance";
            this.ItemForActualBalance.Size = new System.Drawing.Size(278, 30);
            resources.ApplyResources(this.ItemForActualBalance, "ItemForActualBalance");
            this.ItemForActualBalance.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForBalanceDifference
            // 
            this.ItemForBalanceDifference.Control = this.BalanceDifferenceTextEdit;
            this.ItemForBalanceDifference.Enabled = false;
            this.ItemForBalanceDifference.Location = new System.Drawing.Point(0, 90);
            this.ItemForBalanceDifference.Name = "ItemForBalanceDifference";
            this.ItemForBalanceDifference.Size = new System.Drawing.Size(278, 30);
            resources.ApplyResources(this.ItemForBalanceDifference, "ItemForBalanceDifference");
            this.ItemForBalanceDifference.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForDifferenceAccountID
            // 
            this.ItemForDifferenceAccountID.Control = this.DifferenceAccountIDTextEdit;
            this.ItemForDifferenceAccountID.Location = new System.Drawing.Point(0, 120);
            this.ItemForDifferenceAccountID.Name = "ItemForDifferenceAccountID";
            this.ItemForDifferenceAccountID.Size = new System.Drawing.Size(278, 30);
            resources.ApplyResources(this.ItemForDifferenceAccountID, "ItemForDifferenceAccountID");
            this.ItemForDifferenceAccountID.TextSize = new System.Drawing.Size(142, 18);
            this.ItemForDifferenceAccountID.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // ItemForClosingDrwerID
            // 
            this.ItemForClosingDrwerID.Control = this.ClosingDrwerIDTextEdit;
            this.ItemForClosingDrwerID.Location = new System.Drawing.Point(0, 150);
            this.ItemForClosingDrwerID.Name = "ItemForClosingDrwerID";
            this.ItemForClosingDrwerID.Size = new System.Drawing.Size(278, 30);
            resources.ApplyResources(this.ItemForClosingDrwerID, "ItemForClosingDrwerID");
            this.ItemForClosingDrwerID.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForTransferdBalance
            // 
            this.ItemForTransferdBalance.Control = this.TransferdBalanceTextEdit;
            this.ItemForTransferdBalance.Location = new System.Drawing.Point(0, 180);
            this.ItemForTransferdBalance.Name = "ItemForTransferdBalance";
            this.ItemForTransferdBalance.Size = new System.Drawing.Size(278, 30);
            resources.ApplyResources(this.ItemForTransferdBalance, "ItemForTransferdBalance");
            this.ItemForTransferdBalance.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForRemainingBalance
            // 
            this.ItemForRemainingBalance.Control = this.RemainingBalanceTextEdit;
            this.ItemForRemainingBalance.Location = new System.Drawing.Point(0, 210);
            this.ItemForRemainingBalance.Name = "ItemForRemainingBalance";
            this.ItemForRemainingBalance.Size = new System.Drawing.Size(278, 30);
            resources.ApplyResources(this.ItemForRemainingBalance, "ItemForRemainingBalance");
            this.ItemForRemainingBalance.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForPeriodEnd
            // 
            this.ItemForPeriodEnd.Control = this.PeriodEndDateEdit;
            this.ItemForPeriodEnd.Location = new System.Drawing.Point(0, 0);
            this.ItemForPeriodEnd.Name = "ItemForPeriodEnd";
            this.ItemForPeriodEnd.Size = new System.Drawing.Size(278, 30);
            resources.ApplyResources(this.ItemForPeriodEnd, "ItemForPeriodEnd");
            this.ItemForPeriodEnd.TextSize = new System.Drawing.Size(142, 18);
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.ClosePeriodButton;
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 240);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(278, 412);
            resources.ApplyResources(this.layoutControlItem17, "layoutControlItem17");
            this.layoutControlItem17.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem17.TextVisible = false;
            // 
            // lyc_OpeningGroup
            // 
            this.lyc_OpeningGroup.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.ItemForID,
            this.ItemForBranchID,
            this.ItemForBoxID,
            this.ItemForPeriodStart,
            this.ItemForPeriodUserID,
            this.ItemForOpeningBalance,
            this.layoutControlItem4});
            this.lyc_OpeningGroup.Location = new System.Drawing.Point(811, 0);
            this.lyc_OpeningGroup.Name = "lyc_OpeningGroup";
            this.lyc_OpeningGroup.Size = new System.Drawing.Size(369, 709);
            resources.ApplyResources(this.lyc_OpeningGroup, "lyc_OpeningGroup");
            // 
            // ItemForID
            // 
            this.ItemForID.Control = this.IDTextEdit;
            this.ItemForID.Enabled = false;
            this.ItemForID.Location = new System.Drawing.Point(0, 0);
            this.ItemForID.Name = "ItemForID";
            this.ItemForID.Size = new System.Drawing.Size(343, 30);
            resources.ApplyResources(this.ItemForID, "ItemForID");
            this.ItemForID.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForBranchID
            // 
            this.ItemForBranchID.Control = this.BranchIDTextEdit;
            resources.ApplyResources(this.ItemForBranchID, "ItemForBranchID");
            this.ItemForBranchID.Location = new System.Drawing.Point(0, 30);
            this.ItemForBranchID.Name = "ItemForBranchID";
            this.ItemForBranchID.Size = new System.Drawing.Size(343, 30);
            this.ItemForBranchID.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForBoxID
            // 
            this.ItemForBoxID.Control = this.BoxIDTextEdit;
            this.ItemForBoxID.Location = new System.Drawing.Point(0, 60);
            this.ItemForBoxID.Name = "ItemForBoxID";
            this.ItemForBoxID.Size = new System.Drawing.Size(343, 30);
            resources.ApplyResources(this.ItemForBoxID, "ItemForBoxID");
            this.ItemForBoxID.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForPeriodStart
            // 
            this.ItemForPeriodStart.Control = this.PeriodStartDateEdit;
            this.ItemForPeriodStart.Location = new System.Drawing.Point(0, 90);
            this.ItemForPeriodStart.Name = "ItemForPeriodStart";
            this.ItemForPeriodStart.Size = new System.Drawing.Size(343, 30);
            resources.ApplyResources(this.ItemForPeriodStart, "ItemForPeriodStart");
            this.ItemForPeriodStart.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForPeriodUserID
            // 
            this.ItemForPeriodUserID.Control = this.PeriodUserIDTextEdit;
            this.ItemForPeriodUserID.Enabled = false;
            this.ItemForPeriodUserID.Location = new System.Drawing.Point(0, 120);
            this.ItemForPeriodUserID.Name = "ItemForPeriodUserID";
            this.ItemForPeriodUserID.Size = new System.Drawing.Size(343, 30);
            resources.ApplyResources(this.ItemForPeriodUserID, "ItemForPeriodUserID");
            this.ItemForPeriodUserID.TextSize = new System.Drawing.Size(142, 18);
            // 
            // ItemForOpeningBalance
            // 
            this.ItemForOpeningBalance.Control = this.OpeningBalanceTextEdit;
            this.ItemForOpeningBalance.Location = new System.Drawing.Point(0, 150);
            this.ItemForOpeningBalance.Name = "ItemForOpeningBalance";
            this.ItemForOpeningBalance.Size = new System.Drawing.Size(343, 30);
            resources.ApplyResources(this.ItemForOpeningBalance, "ItemForOpeningBalance");
            this.ItemForOpeningBalance.TextSize = new System.Drawing.Size(142, 18);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.OpenPeriodButton;
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 180);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(343, 472);
            resources.ApplyResources(this.layoutControlItem4, "layoutControlItem4");
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.ItemForClosingBalance,
            this.layoutControlItem6,
            this.layoutControlItem1,
            this.layoutControlItem3,
            this.layoutControlItem2,
            this.layoutControlItem5});
            this.layoutControlGroup2.Location = new System.Drawing.Point(304, 0);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(507, 709);
            resources.ApplyResources(this.layoutControlGroup2, "layoutControlGroup2");
            // 
            // ItemForClosingBalance
            // 
            this.ItemForClosingBalance.Control = this.ClosingBalanceTextEdit;
            this.ItemForClosingBalance.Location = new System.Drawing.Point(0, 622);
            this.ItemForClosingBalance.Name = "ItemForClosingBalance";
            this.ItemForClosingBalance.Size = new System.Drawing.Size(481, 30);
            resources.ApplyResources(this.ItemForClosingBalance, "ItemForClosingBalance");
            this.ItemForClosingBalance.TextSize = new System.Drawing.Size(142, 18);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.gridControl1;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 30);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(481, 532);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.textEdit1;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 562);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(481, 30);
            resources.ApplyResources(this.layoutControlItem1, "layoutControlItem1");
            this.layoutControlItem1.TextSize = new System.Drawing.Size(142, 18);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.OpenNowtextEdit;
            this.layoutControlItem3.Location = new System.Drawing.Point(173, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(308, 30);
            resources.ApplyResources(this.layoutControlItem3, "layoutControlItem3");
            this.layoutControlItem3.TextSize = new System.Drawing.Size(142, 18);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.curNametextEdit;
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(173, 30);
            resources.ApplyResources(this.layoutControlItem2, "layoutControlItem2");
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.totalSubAccBanktextEdit;
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 592);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(481, 30);
            resources.ApplyResources(this.layoutControlItem5, "layoutControlItem5");
            this.layoutControlItem5.TextSize = new System.Drawing.Size(142, 18);
            // 
            // frmBoxPeriod
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataLayoutControl1);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "frmBoxPeriod";
            this.Load += new System.EventHandler(this.frmBoxPeriod_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).EndInit();
            this.dataLayoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplyMainBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxPeriodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpeningBalanceTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosingBalanceTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ActualBalanceTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PeriodUserIDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TransferdBalanceTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RemainingBalanceTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BalanceDifferenceTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxIDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCurrencyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DifferenceAccountIDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosingDrwerIDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClosingPeriodUserIDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.curNametextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpenNowtextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BranchIDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblBranchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PeriodStartDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PeriodEndDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalSubAccBanktextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lyc_ClosingGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForClosingPeriodUserID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForActualBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBalanceDifference)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForDifferenceAccountID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForClosingDrwerID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForTransferdBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForRemainingBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPeriodEnd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lyc_OpeningGroup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBranchID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBoxID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPeriodStart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPeriodUserID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForOpeningBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForClosingBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraEditors.TextEdit IDTextEdit;
        private System.Windows.Forms.BindingSource BoxPeriodBindingSource;
        private DevExpress.XtraEditors.TextEdit OpeningBalanceTextEdit;
        private DevExpress.XtraEditors.TextEdit ClosingBalanceTextEdit;
        private DevExpress.XtraEditors.TextEdit ActualBalanceTextEdit;
        private DevExpress.XtraEditors.TextEdit PeriodUserIDTextEdit;
        private DevExpress.XtraEditors.TextEdit TransferdBalanceTextEdit;
        private DevExpress.XtraEditors.TextEdit RemainingBalanceTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemForID;
        private DevExpress.XtraLayout.LayoutControlItem ItemForPeriodStart;
        private DevExpress.XtraLayout.LayoutControlItem ItemForOpeningBalance;
        private DevExpress.XtraLayout.LayoutControlItem ItemForClosingBalance;
        private DevExpress.XtraLayout.LayoutControlItem ItemForPeriodUserID;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBoxID;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBranchID;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.SimpleButton OpenPeriodButton;
        private DevExpress.XtraEditors.TextEdit BalanceDifferenceTextEdit;
        private DevExpress.XtraEditors.SimpleButton ClosePeriodButton;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem ItemForClosingPeriodUserID;
        private DevExpress.XtraLayout.LayoutControlItem ItemForActualBalance;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBalanceDifference;
        private DevExpress.XtraLayout.LayoutControlItem ItemForDifferenceAccountID;
        private DevExpress.XtraLayout.LayoutControlItem ItemForClosingDrwerID;
        private DevExpress.XtraLayout.LayoutControlItem ItemForTransferdBalance;
        private DevExpress.XtraLayout.LayoutControlItem ItemForRemainingBalance;
        private DevExpress.XtraLayout.LayoutControlItem ItemForPeriodEnd;
        private DevExpress.XtraEditors.LookUpEdit BoxIDTextEdit;
        private System.Windows.Forms.BindingSource tblCurrencyBindingSource;
        private DevExpress.XtraEditors.LookUpEdit DifferenceAccountIDTextEdit;
        private DevExpress.XtraEditors.LookUpEdit ClosingDrwerIDTextEdit;
        private DevExpress.XtraEditors.LookUpEdit ClosingPeriodUserIDTextEdit;
        public DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        public DevExpress.XtraLayout.LayoutControlGroup lyc_ClosingGroup;
        public DevExpress.XtraLayout.LayoutControlGroup lyc_OpeningGroup;
        private System.Windows.Forms.BindingSource tblUserBindingSource;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private DevExpress.XtraEditors.TextEdit curNametextEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraEditors.LookUpEdit OpenNowtextEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private System.Windows.Forms.BindingSource tblSupplyMainBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colsupNo;
        private DevExpress.XtraGrid.Columns.GridColumn colsupStatus;
        private DevExpress.XtraGrid.Columns.GridColumn colsupDate;
        private DevExpress.XtraGrid.Columns.GridColumn colsupStatusType;
        private DevExpress.XtraEditors.LookUpEdit BranchIDTextEdit;
        private System.Windows.Forms.BindingSource tblBranchBindingSource;
        private DevExpress.XtraEditors.DateTimeOffsetEdit PeriodStartDateEdit;
        private DevExpress.XtraEditors.DateTimeOffsetEdit PeriodEndDateEdit;
        private DevExpress.XtraGrid.Columns.GridColumn colnet;
        private DevExpress.XtraGrid.Columns.GridColumn colsupBankAmount;
        private DevExpress.XtraEditors.TextEdit totalSubAccBanktextEdit;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
    }
}