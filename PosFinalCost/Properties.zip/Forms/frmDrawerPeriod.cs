﻿using DevExpress.XtraEditors;
using DevExpress.XtraLayout;
using PosFinalCost.Classe;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Migrations;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PosFinalCost.Forms
{
    public partial class frmBoxPeriod : DevExpress.XtraEditors.XtraForm
    {
        bool isnew;
        public frmBoxPeriod(bool IsNew)
        {
            InitializeComponent();
            BoxPeriodBindingSource.AddNew();
            CurrBoxPeriod.PeriodUserID= Session.CurrentUser.ID;
            CurrBoxPeriod.BranchID= Session.CurrentBranch.ID;
            //CurrBoxPeriod.PeriodStart = Convert.ToDateTime(PeriodStartDateEdit.EditValue);
            //CurrBoxPeriod.OpeningBalance = Convert.ToDouble(OpeningBalanceTextEdit.EditValue);
            isnew = IsNew;
        }
        void Newdata()
        {
            BoxIDTextEdit.IntializeData(Session.Boxes);
            PeriodUserIDTextEdit.EditValue = Session.CurrentUser.Name;
            BranchIDTextEdit.IntializeData(Session.Branches);
            BranchIDTextEdit.EditValue = Session.CurrentBranch.ID;
        }
        BoxPeriod CurrBoxPeriod => BoxPeriodBindingSource.Current as BoxPeriod;
        private void OpenPeriodButton_Click(object sender, EventArgs e)
        {
            if (BoxIDTextEdit.Text == "")
            {
                BoxIDTextEdit.ErrorText = "ادخل اسم الصندوق";
                return;
            }
            var testid = Session.BoxPeriods.ToList().FirstOrDefault(m => m.PeriodUserID == Session.CurrentUser.ID && m.BranchID == Session.CurrentBranch.ID && m.PeriodEnd == null && m.BoxID == CurrBoxPeriod.BoxID);
            if (testid != null)
            {
                XtraMessageBox.Show(text: "يوجد  فتره مفتوحه لهذا الصندوق او المستخدم مسبقا ولم يتم اغلاقها \n يرجي اغلاق الفتره السابقه اولا", caption: "", icon: MessageBoxIcon.Error, buttons: MessageBoxButtons.OK);
                return;
            }
            using (var db=new PosDBDataContext(Program.ConnectionString))
            {
                CurrBoxPeriod.Status = false;
                db.BoxPeriods.InsertOnSubmit(CurrBoxPeriod);
                db.SubmitChanges();
            }
            XtraMessageBox.Show(text: " تم فتح الفتره  بنجاح", caption: "", icon: MessageBoxIcon.Information, buttons: MessageBoxButtons.OK);
            Newdata();
            OpenPeriodButton.Enabled = false;
        }

        internal void GetPeriodSummery()
        {
            //var drp = Session.BoxPeriods.Find(Convert.ToInt32(OpenNowtextEdit.Text));
            //if (drp == null) return;
            //var filgrid = Session.tblSupplyMains.ToList().Where(M => M.supDate >= drp.PeriodStart && M.supCurrency == drp.BoxID && M.supUserId == drp.PeriodUserID);
            //gridControl1.DataSource = filgrid;
            //totalSubAccBanktextEdit.EditValue = Math.Round(Convert.ToDouble(filgrid.Sum(x => x.supBankAmount)),2);
            //textEdit1.EditValue = Math.Round(Convert.ToDouble(filgrid.Sum(x => x.net)),2);
            ClosingBalanceTextEdit.EditValue = Convert.ToDouble(OpeningBalanceTextEdit.EditValue) + Convert.ToDouble(textEdit1.EditValue);
            ActualBalanceTextEdit.EditValue = ClosingBalanceTextEdit.EditValue;



            //period.Summery?.Clear();
            //var Box = db.Box.SingleOrDefault(x => x.ID == period.BoxID);
            //if (Box == null)
            //    return;

            ////  period.PeriodStart = period.PeriodStart.Date;

            //var accountJornalTrans =
            //    (from jd in db.JournalDetails.Include(x => x.Journal)
            //     where jd.Journal.Date >= period.PeriodStart
            //     && jd.AccountID == Box.AccountID
            //     group jd by jd.Journal.ProcessType into g
            //     select g).ToList();


            //period.Summery.AddRange((from g in accountJornalTrans
            //                         select new BoxPeriodTransSummeryItem
            //                         {
            //                             BoxPeriod = period,
            //                             ProcessCount = g.Count(),
            //                             ProcessSum = (g.Sum(x => (double?)x.Debit * x.CurrencyRate) ?? 0) - (g.Sum(x => (double?)x.Credit * x.CurrencyRate) ?? 0),
            //                             ProcessType = g.Key
            //                         }).ToList());

            //var accountJournals = from jd in db.JournalDetails.Include(x => x.Journal)
            //                      where jd.Journal.Date < period.PeriodStart
            //                      && jd.AccountID == Box.AccountID
            //                      select jd;
            //double totalDebit = accountJournals.Sum(x => (double?)(x.Debit * x.CurrencyRate)) ?? 0;
            //double totalCredit = accountJournals.Sum(x => (double?)(x.Credit * x.CurrencyRate)) ?? 0;
            //double balance = totalDebit - totalCredit;
            //period.OpeningBalance = balance;
            //period.ClosingBalance = period.OpeningBalance + (period.Summery.Sum(x => (double?)x.ProcessSum) ?? 0);
            //period.ActualBalance = period.ClosingBalance;
            //gridControl1.DataSource = period.Summery;

        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //ERPDataContext db = new ERPDataContext();
            //List<int> PassList = new List<int>();
            //List<string> log = new List<string>();
            //foreach (int item in ids)
            //{
            //    string Msg = string.Empty;
            //    if (CheckIfInvoiceCanBeDeleted(item, out Msg))
            //        PassList.Add(item);
            //    log.Add(Msg);
            //}
            //ids = PassList;

            //var entries = db.BoxPeriods.Where(d => ids.Contains(d.ID));
            //var summaries = entries.Include(x => x.Summery).SelectMany(x => x.Summery);

            //var journals = db.Journals.Where(j => entries.Select(x => x.ID).Contains(j.ProcessID) && (j.ProcessType == SystemProcess.BoxPeriodClosing || j.ProcessType == SystemProcess.Boxuttlement));
            //db.JournalDetails.RemoveRange(db.JournalDetails.Where(jd => journals.Select(x => x.ID).Contains(jd.JournalID)));
            //db.Journals.RemoveRange(journals);
            //db.BoxPeriods.RemoveRange(entries);
            //db.BoxPeriodTransSummeryItems.RemoveRange(summaries);
            //db.SaveChanges();
            //frm_LogViewer.ViewLog("سجل حذف يوميات الصناديق", log);
        }

        private void ClosePeriodButton_Click(object sender, EventArgs e)
        {
            if (OpenNowtextEdit.Text == "")
            {
                XtraMessageBox.Show(text: " حدد الفترة المفتوحة الان", caption: "", icon: MessageBoxIcon.Error, buttons: MessageBoxButtons.OK);
                return;
            }
            if (ClosingPeriodUserIDTextEdit.Text == "")
            {
                XtraMessageBox.Show(text: " حدد مستخدم الاغلاق", caption: "", icon: MessageBoxIcon.Error, buttons: MessageBoxButtons.OK);
                return;
            }
            if (ClosingDrwerIDTextEdit.Text == "")
            {
                XtraMessageBox.Show(text: " حدد صندوق الاغلاق", caption: "", icon: MessageBoxIcon.Error, buttons: MessageBoxButtons.OK);
                return;
            }
                  if (PeriodEndDateEdit.Text == "")
            {
                XtraMessageBox.Show(text: " حدد تاريخ الاغلاق ", caption: "", icon: MessageBoxIcon.Error, buttons: MessageBoxButtons.OK);
                return;
            }


           // var drp = db.BoxPeriods.Find(Convert.ToInt32(OpenNowtextEdit.Text));

           //// drp.BranchID = Session.CurBranch.brnId;
           //// drp.BoxID = Convert.ToInt32(BoxIDTextEdit.EditValue);
           // drp.PeriodEnd = Convert.ToDateTime(PeriodEndDateEdit.EditValue);
           // drp.ClosingPeriodUserID = Convert.ToInt32(ClosingPeriodUserIDTextEdit.EditValue);
           // drp.ClosingDrwerID = Convert.ToInt32(ClosingDrwerIDTextEdit.EditValue);
           // drp.TransferdBalance = Convert.ToDouble(TransferdBalanceTextEdit.EditValue);
           // drp.RemainingBalance = Convert.ToDouble(RemainingBalanceTextEdit.EditValue);
           // drp.ClosingBalance = Convert.ToDouble(ClosingBalanceTextEdit.EditValue);
           // drp.totalSupSccBank = Convert.ToDouble(totalSubAccBanktextEdit.EditValue);
           // drp.Status  = true;

           // //db.BoxPeriods.Add(drp);
           // db.SaveChanges();
            //OpenNowtextEdit.Properties.DataSource = db.BoxPeriods.ToList().Where(x => x.PeriodEnd == null);
            XtraMessageBox.Show(text: " تم غلق الفتره  بنجاح", caption: "", icon: MessageBoxIcon.Information, buttons: MessageBoxButtons.OK);


            //using (accountingEntities db = new accountingEntities())
            //{


            //    if (CheckAction(WindowActions.Add) == false)
            //        return;

            //    if (period == null)
            //        return;
            //    if (period.PeriodEnd.HasValue == false)
            //    {
            //        period.PeriodEnd = DateTime.Now;
            //    }

            //    if ((period.ClosingPeriodUserID ?? 0) == 0)
            //    {
            //        period.ClosingPeriodUserID = CurrentSession.CurrentUser.ID;
            //    }
            //    EnableValidation(dataLayoutControl1);
            //    if (this.ValidateChildren() == false)
            //        return;
            //    DisableValidation(dataLayoutControl1);


            //    if (((period.DifferenceAccountID ?? 0) == 0) && period.BalanceDifference != 0)
            //    {
            //        DifferenceAccountIDLookUpEdit.ErrorText = "يجب اختيار الحساب في حاله وجود عجز او ذياده";
            //        return;
            //    }
            //    db.BoxPeriodTransSummeryItems.RemoveRange(db.BoxPeriodTransSummeryItems.Where(x => x.BoxPeriodID == period.ID));
            //    var Box = db.Box.Find(period.BoxID);
            //    var joirnals = db.Journals.Include(x => x.Details).Where(x =>
            //      (x.ProcessType == SystemProcess.Boxuttlement || x.ProcessType == SystemProcess.BoxPeriodClosing) && x.ProcessID == period.ID);
            //    db.JournalDetails.RemoveRange(joirnals.SelectMany(x => x.Details));
            //    db.Journals.RemoveRange(joirnals);
            //    if (period.BalanceDifference != 0)
            //    {

            //        Journal journal = new Journal();
            //        journal.BranchID = CurrentSession.DefaultBranch?.ID ?? db.Stores.FirstOrDefault()?.ID ?? 0;
            //        if (journal.BranchID == 0)
            //        {
            //            XtraMessageBox.Show(text: "يجب اضافه فرع واحد علي الاقل الي النظام  ", caption: "", icon: MessageBoxIcon.Error, buttons: MessageBoxButtons.OK);
            //            return;
            //        }
            //        journal.Date = period.PeriodEnd.Value;
            //        journal.ProcessType = SystemProcess.Boxuttlement;
            //        db.SaveChanges();
            //        string statment = "تسويه عجز / ذياده ليوميه صندوق" + " رقم " + period.ID;

            //        journal.Note = statment;
            //        journal.ProcessID = period.ID;
            //        journal.Details = new BindingList<JournalDetail>();


            //        journal.Details.Add(new JournalDetail()
            //        {
            //            Account = db.Accounts.Single(x => x.ID == Box.AccountID),
            //            Debit = (period.BalanceDifference > 0) ? Math.Abs(period.BalanceDifference) : 0,
            //            Credit = (period.BalanceDifference < 0) ? Math.Abs(period.BalanceDifference) : 0,
            //            Currency = db.Currencies.Single(x => x.ID == 1),
            //            Statement = statment/* + " - "+ "سداد" */,
            //            CurrencyRate = 1,
            //            Journal = journal,
            //        });
            //        journal.Details.Add(new JournalDetail()
            //        {
            //            Account = db.Accounts.Single(x => x.ID == period.DifferenceAccountID),
            //            Debit = (period.BalanceDifference < 0) ? Math.Abs(period.BalanceDifference) : 0,
            //            Credit = (period.BalanceDifference > 0) ? Math.Abs(period.BalanceDifference) : 0,
            //            Currency = db.Currencies.Single(x => x.ID == 1),
            //            Statement = statment/* + " - "+ "سداد" */,
            //            CurrencyRate = 1,
            //            Journal = journal,
            //        });
            //        db.Journals.Add(journal);
            //    }


            //    if (period.TransferdBalance != 0)
            //    {

            //        Journal journal = new Journal();
            //        var transferBox = db.Box.Find(period.ClosingDrwerID);
            //        journal.BranchID = CurrentSession.DefaultBranch?.ID ?? db.Stores.FirstOrDefault()?.ID ?? 0;
            //        journal.Date = period.PeriodEnd.Value;
            //        journal.ProcessType = SystemProcess.BoxPeriodClosing;
            //        db.SaveChanges();
            //        string statment = "اغلاق يوميه صندوق" + " رقم " + period.ID;

            //        journal.Note = statment;
            //        journal.ProcessID = period.ID;
            //        journal.Details = new BindingList<JournalDetail>();


            //        journal.Details.Add(new JournalDetail()
            //        {
            //            Account = db.Accounts.Single(x => x.ID == Box.AccountID),
            //            Debit = (period.TransferdBalance < 0) ? Math.Abs(period.TransferdBalance) : 0,
            //            Credit = (period.TransferdBalance > 0) ? Math.Abs(period.TransferdBalance) : 0,
            //            Currency = db.Currencies.Single(x => x.ID == 1),
            //            Statement = statment,
            //            CurrencyRate = 1,
            //            Journal = journal,
            //        });
            //        journal.Details.Add(new JournalDetail()
            //        {
            //            Account = db.Accounts.Single(x => x.ID == transferBox.AccountID),
            //            Debit = (period.TransferdBalance > 0) ? Math.Abs(period.TransferdBalance) : 0,
            //            Credit = (period.TransferdBalance < 0) ? Math.Abs(period.TransferdBalance) : 0,
            //            Currency = db.Currencies.Single(x => x.ID == 1),
            //            Statement = statment,
            //            CurrencyRate = 1,
            //            Journal = journal,
            //        });
            //        db.Journals.Add(journal);
            //    }


            //    db.BoxPeriods.AddOrUpdate(period);
            //    db.SaveChanges();
            //    XtraMessageBox.Show(text: $" تم اغلاق الفتره رقم {period.ID } بنجاح", caption: "", icon: MessageBoxIcon.Information, buttons: MessageBoxButtons.OK);

            //    base.Save();
            //    ClosePeriodButton.Enabled = false;
            //}
        }


        public bool CheckAction()
        {
            //  return CurrentSession.CurrentUser.Type == UserType.Administrator || Classes.UserAuthentication.CheckAction(this.Profile, actions);
            return true;
        }

        public void Save()
        {

            //if (CurrentSession.CurrentUser.SettingsProfile.PrintAfterSave && IsNew)
            //    btn_Print.PerformClick();
            //base.Save();
        }
        public void Delete()
        {
            //LogAction(WindowActions.Delete);
            //base.Delete();
        }
        public void Saved()
        {
            // LogAction((IsNew ? WindowActions.Add : WindowActions.Edit));
        }

        public void BeforeSave()
        {
            //  ERPDataContext.ClearTrackedItems();
        }

        public void AfterPrint()
        {
            //  LogAction(WindowActions.Print);
        }

        private void frmBoxPeriod_Load(object sender, EventArgs e)
        {
            PeriodStartDateEdit.EditValue = DateTime.Now.ToString("G");
            PeriodEndDateEdit.EditValue = DateTime.Now.ToString("G");
            if (isnew == true)
            {
                lyc_OpeningGroup.Enabled = true;
                lyc_ClosingGroup.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
                //  layoutControlItem3.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
                Newdata();
            }
            else
            {
                lyc_OpeningGroup.Enabled = false;
                lyc_ClosingGroup.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Always;
                //  layoutControlItem3.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Always;
                //Newdata();
                //OpenNowtextEdit.Properties.DataSource = db.BoxPeriods.ToList().Where(x => x.PeriodEnd == null);
                //ClosingDrwerIDTextEdit.Properties.DataSource = db.tblCurrencies.ToList();
                //ClosingPeriodUserIDTextEdit.Properties.DataSource = db.tblUsers.ToList();
            }



            //if ((period?.ID ?? 0) == 0)
            //{
            //    int id = PrompetForID();
            //    if (id > 0)
            //    {

            //        this.GoTo(id);
            //    }
            //    else
            //    {
            //        this.BeginInvoke(new MethodInvoker(this.Close));
            //        return;
            //    }

            //}
        }

        public void GoTo(int id)
        {
            //if (IsSafeToClearData())
            //{
            //    db = new ERPDataContext();
            //    var loadedPeriod = db.BoxPeriods.Include(x => x.Summery).SingleOrDefault(x => x.ID == id);
            //    if (loadedPeriod == null)
            //    {
            //        XtraMessageBox.Show(text: $"الفتره غير موجوده !", caption: "", icon: MessageBoxIcon.Exclamation, buttons: MessageBoxButtons.OK);
            //        this.BeginInvoke(new MethodInvoker(this.Close));
            //        return;
            //    }
            //    period = loadedPeriod;
            //    if (period.PeriodEnd.HasValue == false)
            //    {
            //        GetPeriodSummery();
            //    }
            //    gridControl1.DataSource = period.Summery;
            //}
        }
        // internal void

        int PrompetForID()
        {

            XtraInputBoxArgs args = new XtraInputBoxArgs();
            // set required Input Box options
            args.Caption = "عرض يوميه صندوق";
            args.Prompt = "كود اليوميه";

            args.DefaultButtonIndex = 0;
            // initialize a DateEdit editor with custom settings
            TextEdit editor = new TextEdit();
            editor.Properties.MaskSettings.DataType = typeof(int);
            editor.Properties.MaskSettings.MaskExpression = "d";

            //editor.EditValue = args.DefaultResponse = db.BoxPeriods.Where(x => x.PeriodUserID == CurrentSession.CurrentUser.ID && x.PeriodEnd.HasValue == false).FirstOrDefault()?.ID ?? 0;
            //args.Editor = editor;
            //var result = XtraInputBox.Show(args);
            //if (result is int id)
            //    return id;

            return 0;

        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            BoxPeriodBindingSource.DataSource = new BoxPeriod();
            Newdata();
            OpenPeriodButton.Enabled = true;
        }

        private void OpenNowtextEdit_EditValueChanged(object sender, EventArgs e)
        {
            //if (lyc_ClosingGroup.Visibility == DevExpress.XtraLayout.Utils.LayoutVisibility.Always)
            //{
            BoxPeriodBindingSource.DataSource = new BoxPeriod();

            Newdata();

            curNametextEdit.Text = "";
            curNametextEdit.Visible = true;
            //var drp = db.BoxPeriods.Find(Convert.ToInt32(OpenNowtextEdit.EditValue));
            //if (drp == null) return;
           
            //IDTextEdit.EditValue = OpenNowtextEdit.EditValue;
            //var BranchN = db.tblBranches.Find(drp.BranchID);
            //BranchIDTextEdit.EditValue = BranchN.brnName;
            //var cue = db.tblCurrencies.Find(drp.BoxID);
            //curNametextEdit.Text = cue.curName;
            //BoxIDTextEdit.EditValue = drp.BoxID;
            ////PeriodEndDateEdit.EditValue = drp.PeriodEnd;
            ////ClosingPeriodUserIDTextEdit.EditValue = drp.ClosingPeriodUserID;
            //PeriodStartDateEdit.EditValue = drp.PeriodStart;
            //var UserN = db.tblUsers.Find(drp.PeriodUserID);
            //PeriodUserIDTextEdit.EditValue = Session.CurrentUser.userName;
            //OpeningBalanceTextEdit.EditValue = drp.OpeningBalance;
            PeriodEndDateEdit.EditValue = DateTime.Now;
            // }
            GetPeriodSummery();
        }

        private void BoxIDTextEdit_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void ActualBalanceTextEdit_EditValueChanged(object sender, EventArgs e)
        {
            BalanceDifferenceTextEdit.EditValue = Convert.ToDouble(ActualBalanceTextEdit.EditValue) - Convert.ToDouble(ClosingBalanceTextEdit.EditValue);
        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            //OpenNowtextEdit.Properties.DataSource = db.BoxPeriods.ToList().Where(x => x.Status == false);

            if (OpenNowtextEdit.Text == "")
            {
                XtraMessageBox.Show(text: "ادخل كود الفترة أولا", caption: "", icon: MessageBoxIcon.Error, buttons: MessageBoxButtons.OK);
                return;
            }

            GetPeriodSummery();
        }

        private void BoxPeriodBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        //void LogAction(WindowActions action)
        //{
        //    LayoutControl layoutControl;
        //    layoutControl = this.Controls.OfType<LayoutControl>().FirstOrDefault();
        //    if (layoutControl != null)
        //    {
        //        IEnumerable<BaseEdit> controls = layoutControl.Controls.OfType<BaseEdit>();
        //        EntityCode = controls.Where(x => x.Name.StartsWith("Code")).FirstOrDefault()?.EditValue?.ToString();
        //        var id = controls.Where(x => x.Name.StartsWith("ID")).FirstOrDefault()?.EditValue;
        //        if (id != null)
        //        {
        //            if (id is int IdValue)
        //                EntityID = IdValue;
        //            else
        //                int.TryParse(id.ToString(), out EntityID);
        //        }
        //    }
        //    ERPDataContext.SaveTrackedItems(EntityID, EntityCode, ScreenName, this.GetType().Name, action, CurrentSession.CurrentUser.ID);
        //}


    }
}