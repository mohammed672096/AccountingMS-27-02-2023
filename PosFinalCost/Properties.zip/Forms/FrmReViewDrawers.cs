﻿using DevExpress.XtraEditors;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PosFinalCost.Forms
{
    public partial class FrmReViewBox : DevExpress.XtraEditors.XtraForm
    {
        PosDBDataContext db = new PosDBDataContext();
        public FrmReViewBox()
        {
            InitializeComponent();
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            datafill();
        }

        private void FrmReViewBox_Load(object sender, EventArgs e)
        {
            //  var userid = db.BoxPeriods.ToList(); 
            PeriodUserIDTextEdit.Properties.DataSource = Session.UserTbls.ToList();
            StartdateEdit.EditValue = DateTime.Now.ToString("yyyy/MM/dd");
            EnddateEdit.EditValue = DateTime.Now.ToString("yyyy/MM/dd");
            datafill();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            datafill();
        }

        public void datafill()
        {
            using (PosDBDataContext db = new PosDBDataContext())
            {
                try
                {
                    if (PeriodUserIDTextEdit.Text=="")
                    {
                        XtraMessageBox.Show(text: "حدد المستخدم أولاً", caption: "", icon: MessageBoxIcon.Error, buttons: MessageBoxButtons.OK);
                        return;
                    }
                    viewBoxRevBindingSource.Clear();

                    DateTime datestar = Convert.ToDateTime(StartdateEdit.EditValue);
                    DateTime dateend = Convert.ToDateTime(EnddateEdit.EditValue);

                    //var tall = db.View_BoxRev.ToList().Where(a => a.PeriodStart.Date >= datestar.Date && a.PeriodStart.Date <= dateend.Date
                                                               //&& a.PeriodUserID==Convert.ToInt32( PeriodUserIDTextEdit.EditValue) );
                    //viewBoxRevBindingSource.DataSource = tall;
                }
                catch (Exception)
                {

                }
            }

        }

        private void PeriodUserIDTextEdit_EditValueChanged(object sender, EventArgs e)
        {
            datafill();
        }

        private void gridControl1_Click(object sender, EventArgs e)
        {

        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            using (ReportForm frmr = new ReportForm(null))
            {
                //Reports.reportBoxPeriod rep = new Reports.reportBoxPeriod();
                ////rep.xrTitelName.Text = " تقرير عن اجمالى عمولة مندوب من تاريخ"
                ////    + datefirt.Value.ToString("yyyy/MM/dd")
                ////    + " الى تاريخ "
                ////    + datelast.Value.ToString("yyyy/MM/dd");

                //rep.DataSource = gridView1.DataSource;
                //rep.RequestParameters = false;
                //frmr.documentViewer1.DocumentSource = rep;
                //frmr.ShowDialog();
            }
        }
    }
}