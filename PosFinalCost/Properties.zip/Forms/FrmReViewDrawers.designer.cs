﻿
namespace PosFinalCost.Forms
{
    partial class FrmReViewBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmReViewBox));
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.dataLayoutControl1 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.viewBoxRevBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colbrnName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPeriodStart = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPeriodUserID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.coluserName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcurName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colActualBalance = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colClosingBalance = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colClosingDrwerID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colClosingPeriodUserID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDifferenceAccountID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colOpeningBalance = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPeriodEnd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colRemainingBalance = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTransferdBalance = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTransferdBalance1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.IDTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.BoxPeriodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.PeriodUserIDTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.tblUserBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.StartdateEdit = new DevExpress.XtraEditors.DateEdit();
            this.EnddateEdit = new DevExpress.XtraEditors.DateEdit();
            this.ItemForID = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForPeriodUserID = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).BeginInit();
            this.dataLayoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBoxRevBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxPeriodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PeriodUserIDTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StartdateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StartdateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnddateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnddateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPeriodUserID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.ribbonControl1.SearchEditItem,
            this.barButtonItem1,
            this.barButtonItem2});
            resources.ApplyResources(this.ribbonControl1, "ribbonControl1");
            this.ribbonControl1.MaxItemId = 3;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1});
            this.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.OfficeUniversal;
            // 
            // barButtonItem1
            // 
            resources.ApplyResources(this.barButtonItem1, "barButtonItem1");
            this.barButtonItem1.Id = 1;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonItem2
            // 
            resources.ApplyResources(this.barButtonItem2, "barButtonItem2");
            this.barButtonItem2.Id = 2;
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1,
            this.ribbonPageGroup2});
            this.ribbonPage1.Name = "ribbonPage1";
            resources.ApplyResources(this.ribbonPage1, "ribbonPage1");
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.barButtonItem1);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            resources.ApplyResources(this.ribbonPageGroup1, "ribbonPageGroup1");
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("ribbonPageGroup2.ImageOptions.SvgImage")));
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem2);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            resources.ApplyResources(this.ribbonPageGroup2, "ribbonPageGroup2");
            // 
            // dataLayoutControl1
            // 
            this.dataLayoutControl1.Controls.Add(this.gridControl1);
            this.dataLayoutControl1.Controls.Add(this.IDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.simpleButton1);
            this.dataLayoutControl1.Controls.Add(this.PeriodUserIDTextEdit);
            this.dataLayoutControl1.Controls.Add(this.simpleButton2);
            this.dataLayoutControl1.Controls.Add(this.StartdateEdit);
            this.dataLayoutControl1.Controls.Add(this.EnddateEdit);
            this.dataLayoutControl1.DataSource = this.BoxPeriodBindingSource;
            resources.ApplyResources(this.dataLayoutControl1, "dataLayoutControl1");
            this.dataLayoutControl1.HiddenItems.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.ItemForID});
            this.dataLayoutControl1.Name = "dataLayoutControl1";
            this.dataLayoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(1270, 337, 650, 400);
            this.dataLayoutControl1.OptionsView.RightToLeftMirroringApplied = true;
            this.dataLayoutControl1.Root = this.layoutControlGroup1;
            // 
            // gridControl1
            // 
            this.gridControl1.DataSource = this.viewBoxRevBindingSource;
            resources.ApplyResources(this.gridControl1, "gridControl1");
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.MenuManager = this.ribbonControl1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            this.gridControl1.Click += new System.EventHandler(this.gridControl1_Click);
            // 
            // viewBoxRevBindingSource
            // 
            //this.viewBoxRevBindingSource.DataSource = typeof(PosFinalCost.View_BoxRev);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colbrnName,
            this.colPeriodStart,
            this.colPeriodUserID,
            this.coluserName,
            this.colcurName,
            this.colActualBalance,
            this.colClosingBalance,
            this.colClosingDrwerID,
            this.colClosingPeriodUserID,
            this.colDifferenceAccountID,
            this.colOpeningBalance,
            this.colPeriodEnd,
            this.colRemainingBalance,
            this.colTransferdBalance,
            this.colTransferdBalance1});
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.Editable = false;
            // 
            // colbrnName
            // 
            resources.ApplyResources(this.colbrnName, "colbrnName");
            this.colbrnName.FieldName = "brnName";
            this.colbrnName.Name = "colbrnName";
            // 
            // colPeriodStart
            // 
            resources.ApplyResources(this.colPeriodStart, "colPeriodStart");
            this.colPeriodStart.FieldName = "PeriodStart";
            this.colPeriodStart.Name = "colPeriodStart";
            // 
            // colPeriodUserID
            // 
            resources.ApplyResources(this.colPeriodUserID, "colPeriodUserID");
            this.colPeriodUserID.FieldName = "PeriodUserID";
            this.colPeriodUserID.Name = "colPeriodUserID";
            // 
            // coluserName
            // 
            resources.ApplyResources(this.coluserName, "coluserName");
            this.coluserName.FieldName = "userName";
            this.coluserName.Name = "coluserName";
            // 
            // colcurName
            // 
            resources.ApplyResources(this.colcurName, "colcurName");
            this.colcurName.FieldName = "curName";
            this.colcurName.Name = "colcurName";
            // 
            // colActualBalance
            // 
            resources.ApplyResources(this.colActualBalance, "colActualBalance");
            this.colActualBalance.FieldName = "ActualBalance";
            this.colActualBalance.Name = "colActualBalance";
            // 
            // colClosingBalance
            // 
            resources.ApplyResources(this.colClosingBalance, "colClosingBalance");
            this.colClosingBalance.FieldName = "ClosingBalance";
            this.colClosingBalance.Name = "colClosingBalance";
            // 
            // colClosingDrwerID
            // 
            resources.ApplyResources(this.colClosingDrwerID, "colClosingDrwerID");
            this.colClosingDrwerID.FieldName = "ClosingDrwerID";
            this.colClosingDrwerID.Name = "colClosingDrwerID";
            // 
            // colClosingPeriodUserID
            // 
            resources.ApplyResources(this.colClosingPeriodUserID, "colClosingPeriodUserID");
            this.colClosingPeriodUserID.FieldName = "ClosingPeriodUserID";
            this.colClosingPeriodUserID.Name = "colClosingPeriodUserID";
            // 
            // colDifferenceAccountID
            // 
            resources.ApplyResources(this.colDifferenceAccountID, "colDifferenceAccountID");
            this.colDifferenceAccountID.FieldName = "DifferenceAccountID";
            this.colDifferenceAccountID.Name = "colDifferenceAccountID";
            // 
            // colOpeningBalance
            // 
            resources.ApplyResources(this.colOpeningBalance, "colOpeningBalance");
            this.colOpeningBalance.FieldName = "OpeningBalance";
            this.colOpeningBalance.Name = "colOpeningBalance";
            // 
            // colPeriodEnd
            // 
            resources.ApplyResources(this.colPeriodEnd, "colPeriodEnd");
            this.colPeriodEnd.FieldName = "PeriodEnd";
            this.colPeriodEnd.Name = "colPeriodEnd";
            // 
            // colRemainingBalance
            // 
            resources.ApplyResources(this.colRemainingBalance, "colRemainingBalance");
            this.colRemainingBalance.FieldName = "RemainingBalance";
            this.colRemainingBalance.Name = "colRemainingBalance";
            // 
            // colTransferdBalance
            // 
            resources.ApplyResources(this.colTransferdBalance, "colTransferdBalance");
            this.colTransferdBalance.FieldName = "TransferdBalance";
            this.colTransferdBalance.Name = "colTransferdBalance";
            // 
            // colTransferdBalance1
            // 
            resources.ApplyResources(this.colTransferdBalance1, "colTransferdBalance1");
            this.colTransferdBalance1.FieldName = "totalSupSccBank";
            this.colTransferdBalance1.Name = "colTransferdBalance1";
            // 
            // IDTextEdit
            // 
            this.IDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "ID", true));
            resources.ApplyResources(this.IDTextEdit, "IDTextEdit");
            this.IDTextEdit.MenuManager = this.ribbonControl1;
            this.IDTextEdit.Name = "IDTextEdit";
            this.IDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.IDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.IDTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("IDTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.IDTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.IDTextEdit.Properties.MaskSettings.Set("mask", "N0");
            this.IDTextEdit.StyleController = this.dataLayoutControl1;
            // 
            // BoxPeriodBindingSource
            // 
            this.BoxPeriodBindingSource.DataSource = typeof(PosFinalCost.BoxPeriod);
            // 
            // simpleButton1
            // 
            this.simpleButton1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("simpleButton1.ImageOptions.SvgImage")));
            resources.ApplyResources(this.simpleButton1, "simpleButton1");
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.StyleController = this.dataLayoutControl1;
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // PeriodUserIDTextEdit
            // 
            this.PeriodUserIDTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.BoxPeriodBindingSource, "PeriodUserID", true));
            resources.ApplyResources(this.PeriodUserIDTextEdit, "PeriodUserIDTextEdit");
            this.PeriodUserIDTextEdit.MenuManager = this.ribbonControl1;
            this.PeriodUserIDTextEdit.Name = "PeriodUserIDTextEdit";
            this.PeriodUserIDTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.PeriodUserIDTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.PeriodUserIDTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("PeriodUserIDTextEdit.Properties.Buttons"))))});
            this.PeriodUserIDTextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("PeriodUserIDTextEdit.Properties.Columns"), resources.GetString("PeriodUserIDTextEdit.Properties.Columns1"), ((int)(resources.GetObject("PeriodUserIDTextEdit.Properties.Columns2"))), ((DevExpress.Utils.FormatType)(resources.GetObject("PeriodUserIDTextEdit.Properties.Columns3"))), resources.GetString("PeriodUserIDTextEdit.Properties.Columns4"), ((bool)(resources.GetObject("PeriodUserIDTextEdit.Properties.Columns5"))), ((DevExpress.Utils.HorzAlignment)(resources.GetObject("PeriodUserIDTextEdit.Properties.Columns6"))), ((DevExpress.Data.ColumnSortOrder)(resources.GetObject("PeriodUserIDTextEdit.Properties.Columns7"))), ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("PeriodUserIDTextEdit.Properties.Columns8"))))});
            this.PeriodUserIDTextEdit.Properties.DataSource = this.tblUserBindingSource;
            this.PeriodUserIDTextEdit.Properties.DisplayMember = "userName";
            this.PeriodUserIDTextEdit.Properties.NullText = resources.GetString("PeriodUserIDTextEdit.Properties.NullText");
            this.PeriodUserIDTextEdit.Properties.ShowFooter = false;
            this.PeriodUserIDTextEdit.Properties.ShowHeader = false;
            this.PeriodUserIDTextEdit.Properties.ShowLines = false;
            this.PeriodUserIDTextEdit.Properties.ValueMember = "id";
            this.PeriodUserIDTextEdit.StyleController = this.dataLayoutControl1;
            this.PeriodUserIDTextEdit.EditValueChanged += new System.EventHandler(this.PeriodUserIDTextEdit_EditValueChanged);
            // 
            // tblUserBindingSource
            // 
            this.tblUserBindingSource.DataSource = typeof(PosFinalCost.tblUser);
            // 
            // simpleButton2
            // 
            this.simpleButton2.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("simpleButton2.ImageOptions.SvgImage")));
            resources.ApplyResources(this.simpleButton2, "simpleButton2");
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.StyleController = this.dataLayoutControl1;
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // StartdateEdit
            // 
            resources.ApplyResources(this.StartdateEdit, "StartdateEdit");
            this.StartdateEdit.MenuManager = this.ribbonControl1;
            this.StartdateEdit.Name = "StartdateEdit";
            this.StartdateEdit.Properties.BeepOnError = ((bool)(resources.GetObject("StartdateEdit.Properties.BeepOnError")));
            this.StartdateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("StartdateEdit.Properties.Buttons"))))});
            this.StartdateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("StartdateEdit.Properties.CalendarTimeProperties.Buttons"))))});
            this.StartdateEdit.Properties.DisplayFormat.FormatString = "";
            this.StartdateEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.StartdateEdit.Properties.Mask.EditMask = resources.GetString("StartdateEdit.Properties.Mask.EditMask");
            this.StartdateEdit.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("StartdateEdit.Properties.Mask.MaskType")));
            this.StartdateEdit.Properties.MaskSettings.Set("mask", "");
            this.StartdateEdit.StyleController = this.dataLayoutControl1;
            // 
            // EnddateEdit
            // 
            resources.ApplyResources(this.EnddateEdit, "EnddateEdit");
            this.EnddateEdit.MenuManager = this.ribbonControl1;
            this.EnddateEdit.Name = "EnddateEdit";
            this.EnddateEdit.Properties.BeepOnError = ((bool)(resources.GetObject("EnddateEdit.Properties.BeepOnError")));
            this.EnddateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("EnddateEdit.Properties.Buttons"))))});
            this.EnddateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("EnddateEdit.Properties.CalendarTimeProperties.Buttons"))))});
            this.EnddateEdit.Properties.Mask.EditMask = resources.GetString("EnddateEdit.Properties.Mask.EditMask");
            this.EnddateEdit.Properties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("EnddateEdit.Properties.Mask.MaskType")));
            this.EnddateEdit.Properties.MaskSettings.Set("mask", "");
            this.EnddateEdit.StyleController = this.dataLayoutControl1;
            // 
            // ItemForID
            // 
            this.ItemForID.Control = this.IDTextEdit;
            this.ItemForID.Location = new System.Drawing.Point(0, 0);
            this.ItemForID.Name = "ItemForID";
            this.ItemForID.Size = new System.Drawing.Size(918, 485);
            resources.ApplyResources(this.ItemForID, "ItemForID");
            this.ItemForID.TextSize = new System.Drawing.Size(12, 14);
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup2});
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(950, 509);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AllowDrawBackground = false;
            this.layoutControlGroup2.GroupBordersVisible = false;
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem3,
            this.ItemForPeriodUserID,
            this.emptySpaceItem1,
            this.emptySpaceItem2,
            this.emptySpaceItem3,
            this.layoutControlItem5,
            this.layoutControlItem4,
            this.emptySpaceItem4});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup2.Name = "autoGeneratedGroup0";
            this.layoutControlGroup2.Size = new System.Drawing.Size(930, 489);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.gridControl1;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 112);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(930, 377);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.StartdateEdit;
            this.layoutControlItem2.Location = new System.Drawing.Point(465, 64);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(465, 24);
            resources.ApplyResources(this.layoutControlItem2, "layoutControlItem2");
            this.layoutControlItem2.TextSize = new System.Drawing.Size(52, 14);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.EnddateEdit;
            this.layoutControlItem3.Location = new System.Drawing.Point(465, 88);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(465, 24);
            resources.ApplyResources(this.layoutControlItem3, "layoutControlItem3");
            this.layoutControlItem3.TextSize = new System.Drawing.Size(52, 14);
            // 
            // ItemForPeriodUserID
            // 
            this.ItemForPeriodUserID.Control = this.PeriodUserIDTextEdit;
            this.ItemForPeriodUserID.Location = new System.Drawing.Point(465, 40);
            this.ItemForPeriodUserID.Name = "ItemForPeriodUserID";
            this.ItemForPeriodUserID.Size = new System.Drawing.Size(465, 24);
            resources.ApplyResources(this.ItemForPeriodUserID, "ItemForPeriodUserID");
            this.ItemForPeriodUserID.TextSize = new System.Drawing.Size(52, 14);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 88);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(465, 24);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 64);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(465, 24);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 40);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(465, 24);
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.simpleButton1;
            this.layoutControlItem5.Location = new System.Drawing.Point(249, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(184, 40);
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.simpleButton2;
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(249, 40);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.Location = new System.Drawing.Point(433, 0);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(497, 40);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // FrmReViewBox
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataLayoutControl1);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "FrmReViewBox";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmReViewBox_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).EndInit();
            this.dataLayoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBoxRevBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxPeriodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PeriodUserIDTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StartdateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StartdateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnddateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnddateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPeriodUserID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraEditors.TextEdit IDTextEdit;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem ItemForID;
        private System.Windows.Forms.BindingSource BoxPeriodBindingSource;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.LookUpEdit PeriodUserIDTextEdit;
        private System.Windows.Forms.BindingSource tblUserBindingSource;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem ItemForPeriodUserID;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private System.Windows.Forms.BindingSource viewBoxRevBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colbrnName;
        private DevExpress.XtraGrid.Columns.GridColumn colPeriodStart;
        private DevExpress.XtraGrid.Columns.GridColumn colPeriodUserID;
        private DevExpress.XtraGrid.Columns.GridColumn coluserName;
        private DevExpress.XtraGrid.Columns.GridColumn colcurName;
        private DevExpress.XtraGrid.Columns.GridColumn colActualBalance;
        private DevExpress.XtraGrid.Columns.GridColumn colClosingBalance;
        private DevExpress.XtraGrid.Columns.GridColumn colClosingDrwerID;
        private DevExpress.XtraGrid.Columns.GridColumn colClosingPeriodUserID;
        private DevExpress.XtraGrid.Columns.GridColumn colDifferenceAccountID;
        private DevExpress.XtraGrid.Columns.GridColumn colOpeningBalance;
        private DevExpress.XtraGrid.Columns.GridColumn colPeriodEnd;
        private DevExpress.XtraGrid.Columns.GridColumn colRemainingBalance;
        private DevExpress.XtraGrid.Columns.GridColumn colTransferdBalance;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraEditors.DateEdit StartdateEdit;
        private DevExpress.XtraEditors.DateEdit EnddateEdit;
        private DevExpress.XtraGrid.Columns.GridColumn colTransferdBalance1;
    }
}