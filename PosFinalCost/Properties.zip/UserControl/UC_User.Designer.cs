﻿namespace PosFinalCost
{
    partial class UC_User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions3 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject9 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject10 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject11 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject12 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions4 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject13 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject14 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject15 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject16 = new DevExpress.Utils.SerializableAppearanceObject();
            this.repositoryItemRibbonSearchEdit1 = new DevExpress.XtraBars.Ribbon.Internal.RepositoryItemRibbonSearchEdit();
            this.tblRoleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.tblUserBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colfkUserId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colRoleID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEditRoleID = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.colUsSettProfID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEditUsSettProf = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.userSettingsProfileBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataLayoutControl2 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.gridControlBranch = new DevExpress.XtraGrid.GridControl();
            this.branchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colbrnId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colbrnName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.mainRibbonControl = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.bbiSave = new DevExpress.XtraBars.BarButtonItem();
            this.bbiReset = new DevExpress.XtraBars.BarButtonItem();
            this.bbiClose = new DevExpress.XtraBars.BarButtonItem();
            this.mainRibbonPage = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.mainRibbonPageGroup = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlForGridBranch = new DevExpress.XtraLayout.LayoutControlItem();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRibbonSearchEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblRoleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditRoleID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditUsSettProf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userSettingsProfileBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl2)).BeginInit();
            this.dataLayoutControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlBranch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainRibbonControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlForGridBranch)).BeginInit();
            this.SuspendLayout();
            // 
            // repositoryItemRibbonSearchEdit1
            // 
            this.repositoryItemRibbonSearchEdit1.AllowFocused = false;
            this.repositoryItemRibbonSearchEdit1.AutoHeight = false;
            this.repositoryItemRibbonSearchEdit1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            editorButtonImageOptions3.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.True;
            this.repositoryItemRibbonSearchEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, true, editorButtonImageOptions3, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject9, serializableAppearanceObject10, serializableAppearanceObject11, serializableAppearanceObject12, "", null, null, DevExpress.Utils.ToolTipAnchor.Default),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Clear, "", -1, true, false, false, editorButtonImageOptions4, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject13, serializableAppearanceObject14, serializableAppearanceObject15, serializableAppearanceObject16, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.repositoryItemRibbonSearchEdit1.Name = "repositoryItemRibbonSearchEdit1";
            this.repositoryItemRibbonSearchEdit1.NullText = "Search";
            // 
            // tblRoleBindingSource
            // 
            this.tblRoleBindingSource.DataSource = typeof(PosFinalCost.RoleTbl);
            // 
            // gridControl2
            // 
            this.gridControl2.DataSource = this.tblUserBindingSource;
            this.gridControl2.Location = new System.Drawing.Point(425, 40);
            this.gridControl2.MainView = this.gridView;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEditUsSettProf,
            this.repositoryItemLookUpEditRoleID});
            this.gridControl2.Size = new System.Drawing.Size(785, 614);
            this.gridControl2.TabIndex = 0;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView});
            // 
            // tblUserBindingSource
            // 
            this.tblUserBindingSource.DataSource = typeof(PosFinalCost.UserTbl);
            // 
            // gridView
            // 
            this.gridView.Appearance.EvenRow.BackColor = System.Drawing.Color.MintCream;
            this.gridView.Appearance.EvenRow.BackColor2 = System.Drawing.Color.WhiteSmoke;
            this.gridView.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridView.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.gridView.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.gridView.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.gridView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colfkUserId,
            this.colRoleID,
            this.colUsSettProfID});
            this.gridView.DetailHeight = 431;
            this.gridView.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
            this.gridView.GridControl = this.gridControl2;
            this.gridView.Name = "gridView";
            this.gridView.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView.OptionsView.ShowGroupPanel = false;
            // 
            // colfkUserId
            // 
            this.colfkUserId.AppearanceCell.Options.UseTextOptions = true;
            this.colfkUserId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colfkUserId.Caption = "المستخدم";
            this.colfkUserId.FieldName = "Name";
            this.colfkUserId.MinWidth = 23;
            this.colfkUserId.Name = "colfkUserId";
            this.colfkUserId.OptionsColumn.AllowEdit = false;
            this.colfkUserId.OptionsColumn.ReadOnly = true;
            this.colfkUserId.Visible = true;
            this.colfkUserId.VisibleIndex = 0;
            this.colfkUserId.Width = 87;
            // 
            // colRoleID
            // 
            this.colRoleID.Caption = "اسم صلاحية المستخدم";
            this.colRoleID.ColumnEdit = this.repositoryItemLookUpEditRoleID;
            this.colRoleID.FieldName = "RoleID";
            this.colRoleID.MinWidth = 25;
            this.colRoleID.Name = "colRoleID";
            this.colRoleID.Visible = true;
            this.colRoleID.VisibleIndex = 1;
            this.colRoleID.Width = 94;
            // 
            // repositoryItemLookUpEditRoleID
            // 
            this.repositoryItemLookUpEditRoleID.AutoHeight = false;
            this.repositoryItemLookUpEditRoleID.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEditRoleID.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Name", "Name4")});
            this.repositoryItemLookUpEditRoleID.DataSource = this.tblRoleBindingSource;
            this.repositoryItemLookUpEditRoleID.DisplayMember = "Name";
            this.repositoryItemLookUpEditRoleID.Name = "repositoryItemLookUpEditRoleID";
            this.repositoryItemLookUpEditRoleID.NullText = "";
            this.repositoryItemLookUpEditRoleID.ShowFooter = false;
            this.repositoryItemLookUpEditRoleID.ShowHeader = false;
            this.repositoryItemLookUpEditRoleID.ShowLines = false;
            this.repositoryItemLookUpEditRoleID.ValueMember = "ID";
            this.repositoryItemLookUpEditRoleID.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.repositoryItemLookUpEditRoleID_EditValueChanging);
            // 
            // colUsSettProfID
            // 
            this.colUsSettProfID.Caption = "اسم اعدادات المستخدم";
            this.colUsSettProfID.ColumnEdit = this.repositoryItemLookUpEditUsSettProf;
            this.colUsSettProfID.FieldName = "UsSettProfID";
            this.colUsSettProfID.MinWidth = 25;
            this.colUsSettProfID.Name = "colUsSettProfID";
            this.colUsSettProfID.Visible = true;
            this.colUsSettProfID.VisibleIndex = 2;
            this.colUsSettProfID.Width = 94;
            // 
            // repositoryItemLookUpEditUsSettProf
            // 
            this.repositoryItemLookUpEditUsSettProf.AutoHeight = false;
            this.repositoryItemLookUpEditUsSettProf.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEditUsSettProf.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Name", "Name5")});
            this.repositoryItemLookUpEditUsSettProf.DataSource = this.userSettingsProfileBindingSource;
            this.repositoryItemLookUpEditUsSettProf.DisplayMember = "Name";
            this.repositoryItemLookUpEditUsSettProf.Name = "repositoryItemLookUpEditUsSettProf";
            this.repositoryItemLookUpEditUsSettProf.NullText = "";
            this.repositoryItemLookUpEditUsSettProf.ShowFooter = false;
            this.repositoryItemLookUpEditUsSettProf.ShowHeader = false;
            this.repositoryItemLookUpEditUsSettProf.ShowLines = false;
            this.repositoryItemLookUpEditUsSettProf.ValueMember = "ID";
            this.repositoryItemLookUpEditUsSettProf.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.repositoryItemLookUpEditUsSettProf_EditValueChanging);
            // 
            // userSettingsProfileBindingSource
            // 
            this.userSettingsProfileBindingSource.DataSource = typeof(PosFinalCost.UserSettingsProfile);
            // 
            // dataLayoutControl2
            // 
            this.dataLayoutControl2.Controls.Add(this.gridControl2);
            this.dataLayoutControl2.Controls.Add(this.gridControlBranch);
            this.dataLayoutControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataLayoutControl2.Location = new System.Drawing.Point(5, 65);
            this.dataLayoutControl2.Name = "dataLayoutControl2";
            this.dataLayoutControl2.OptionsView.RightToLeftMirroringApplied = true;
            this.dataLayoutControl2.Root = this.layoutControlGroup1;
            this.dataLayoutControl2.Size = new System.Drawing.Size(1224, 668);
            this.dataLayoutControl2.TabIndex = 1;
            this.dataLayoutControl2.Text = "dataLayoutControl2";
            // 
            // gridControlBranch
            // 
            this.gridControlBranch.AllowRestoreSelectionAndFocusedRow = DevExpress.Utils.DefaultBoolean.True;
            this.gridControlBranch.DataSource = this.branchBindingSource;
            this.gridControlBranch.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControlBranch.Location = new System.Drawing.Point(26, 78);
            this.gridControlBranch.MainView = this.gridView1;
            this.gridControlBranch.MenuManager = this.mainRibbonControl;
            this.gridControlBranch.Name = "gridControlBranch";
            this.gridControlBranch.Size = new System.Drawing.Size(383, 564);
            this.gridControlBranch.TabIndex = 4;
            this.gridControlBranch.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // branchBindingSource
            // 
            this.branchBindingSource.DataSource = typeof(PosFinalCost.Branch);
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colbrnId,
            this.colbrnName});
            this.gridView1.DetailHeight = 450;
            this.gridView1.GridControl = this.gridControlBranch;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.ReadOnly = true;
            this.gridView1.OptionsFind.SearchInPreview = true;
            this.gridView1.OptionsSelection.CheckBoxSelectorColumnWidth = 34;
            this.gridView1.OptionsSelection.MultiSelect = true;
            this.gridView1.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            this.gridView1.OptionsView.ShowColumnHeaders = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // colbrnId
            // 
            this.colbrnId.FieldName = "ID";
            this.colbrnId.MinWidth = 23;
            this.colbrnId.Name = "colbrnId";
            this.colbrnId.Width = 86;
            // 
            // colbrnName
            // 
            this.colbrnName.FieldName = "Name";
            this.colbrnName.MinWidth = 23;
            this.colbrnName.Name = "colbrnName";
            this.colbrnName.Visible = true;
            this.colbrnName.VisibleIndex = 1;
            this.colbrnName.Width = 86;
            // 
            // mainRibbonControl
            // 
            this.mainRibbonControl.EmptyAreaImageOptions.ImagePadding = new System.Windows.Forms.Padding(34, 39, 34, 39);
            this.mainRibbonControl.ExpandCollapseItem.Id = 0;
            this.mainRibbonControl.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.mainRibbonControl.ExpandCollapseItem,
            this.mainRibbonControl.SearchEditItem,
            this.bbiSave,
            this.bbiReset,
            this.bbiClose});
            this.mainRibbonControl.Location = new System.Drawing.Point(0, 0);
            this.mainRibbonControl.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.mainRibbonControl.MaxItemId = 10;
            this.mainRibbonControl.Name = "mainRibbonControl";
            this.mainRibbonControl.OptionsMenuMinWidth = 377;
            this.mainRibbonControl.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.mainRibbonPage});
            this.mainRibbonControl.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemRibbonSearchEdit1});
            this.mainRibbonControl.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2013;
            this.mainRibbonControl.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
            this.mainRibbonControl.ShowPageHeadersMode = DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
            this.mainRibbonControl.Size = new System.Drawing.Size(1066, 0);
            this.mainRibbonControl.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // bbiSave
            // 
            this.bbiSave.Caption = "حفظ";
            this.bbiSave.Id = 2;
            this.bbiSave.ImageOptions.ImageUri.Uri = "Save";
            this.bbiSave.Name = "bbiSave";
            // 
            // bbiReset
            // 
            this.bbiReset.Caption = "Reset Changes";
            this.bbiReset.Id = 5;
            this.bbiReset.ImageOptions.ImageUri.Uri = "Reset";
            this.bbiReset.Name = "bbiReset";
            // 
            // bbiClose
            // 
            this.bbiClose.Caption = "إغلاق";
            this.bbiClose.Id = 7;
            this.bbiClose.ImageOptions.ImageUri.Uri = "Close";
            this.bbiClose.Name = "bbiClose";
            // 
            // mainRibbonPage
            // 
            this.mainRibbonPage.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.mainRibbonPageGroup});
            this.mainRibbonPage.MergeOrder = 0;
            this.mainRibbonPage.Name = "mainRibbonPage";
            this.mainRibbonPage.Text = "Home";
            // 
            // mainRibbonPageGroup
            // 
            this.mainRibbonPageGroup.AllowTextClipping = false;
            this.mainRibbonPageGroup.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.mainRibbonPageGroup.ItemLinks.Add(this.bbiSave);
            this.mainRibbonPageGroup.ItemLinks.Add(this.bbiClose);
            this.mainRibbonPageGroup.Name = "mainRibbonPageGroup";
            this.mainRibbonPageGroup.Text = "Tasks";
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup2});
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup1.Size = new System.Drawing.Size(1224, 668);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem6,
            this.layoutControlGroup4});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(1224, 668);
            this.layoutControlGroup2.Text = "ربط المستخدمين بالصلاحيات والاعدادات والفروع";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.gridControl2;
            this.layoutControlItem6.Location = new System.Drawing.Point(411, 0);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(789, 618);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.CustomizationFormText = "صلاحيات الفروع";
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlForGridBranch});
            this.layoutControlGroup4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.OptionsItemText.TextToControlDistance = 3;
            this.layoutControlGroup4.OptionsPrint.AppearanceGroupCaption.Font = new System.Drawing.Font("Tahoma", 9F);
            this.layoutControlGroup4.OptionsPrint.AppearanceGroupCaption.Options.UseFont = true;
            this.layoutControlGroup4.OptionsPrint.AppearanceItem.Font = new System.Drawing.Font("Tahoma", 9F);
            this.layoutControlGroup4.OptionsPrint.AppearanceItem.Options.UseFont = true;
            this.layoutControlGroup4.OptionsPrint.AppearanceItemControl.Font = new System.Drawing.Font("Tahoma", 9F);
            this.layoutControlGroup4.OptionsPrint.AppearanceItemControl.Options.UseFont = true;
            this.layoutControlGroup4.OptionsPrint.AppearanceItemText.Font = new System.Drawing.Font("Tahoma", 9F);
            this.layoutControlGroup4.OptionsPrint.AppearanceItemText.Options.UseFont = true;
            this.layoutControlGroup4.Size = new System.Drawing.Size(411, 618);
            this.layoutControlGroup4.Text = "صلاحيات الفروع";
            // 
            // layoutControlForGridBranch
            // 
            this.layoutControlForGridBranch.AppearanceItemCaptionDisabled.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.layoutControlForGridBranch.AppearanceItemCaptionDisabled.Options.UseBackColor = true;
            this.layoutControlForGridBranch.Control = this.gridControlBranch;
            this.layoutControlForGridBranch.ControlAlignment = System.Drawing.ContentAlignment.TopRight;
            this.layoutControlForGridBranch.CustomizationFormText = "layoutControlItem1";
            this.layoutControlForGridBranch.Location = new System.Drawing.Point(0, 0);
            this.layoutControlForGridBranch.Name = "layoutControlForGridBranch";
            this.layoutControlForGridBranch.OptionsPrint.AppearanceItem.Font = new System.Drawing.Font("Tahoma", 9F);
            this.layoutControlForGridBranch.OptionsPrint.AppearanceItem.Options.UseFont = true;
            this.layoutControlForGridBranch.OptionsPrint.AppearanceItemControl.Font = new System.Drawing.Font("Tahoma", 9F);
            this.layoutControlForGridBranch.OptionsPrint.AppearanceItemControl.Options.UseFont = true;
            this.layoutControlForGridBranch.OptionsPrint.AppearanceItemText.Font = new System.Drawing.Font("Tahoma", 9F);
            this.layoutControlForGridBranch.OptionsPrint.AppearanceItemText.Options.UseFont = true;
            this.layoutControlForGridBranch.Size = new System.Drawing.Size(387, 568);
            this.layoutControlForGridBranch.Text = "layoutControlItem1";
            this.layoutControlForGridBranch.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlForGridBranch.TextVisible = false;
            // 
            // UC_User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataLayoutControl2);
            this.Name = "UC_User";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Size = new System.Drawing.Size(1234, 738);
            this.Controls.SetChildIndex(this.dataLayoutControl2, 0);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRibbonSearchEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblRoleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditRoleID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditUsSettProf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userSettingsProfileBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl2)).EndInit();
            this.dataLayoutControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlBranch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainRibbonControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlForGridBranch)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource tblRoleBindingSource;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView;
        private System.Windows.Forms.BindingSource tblUserBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colfkUserId;
        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraGrid.GridControl gridControlBranch;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn colbrnId;
        private DevExpress.XtraGrid.Columns.GridColumn colbrnName;
        private DevExpress.XtraBars.Ribbon.RibbonControl mainRibbonControl;
        private DevExpress.XtraBars.BarButtonItem bbiSave;
        private DevExpress.XtraBars.BarButtonItem bbiReset;
        private DevExpress.XtraBars.BarButtonItem bbiClose;
        private DevExpress.XtraBars.Ribbon.RibbonPage mainRibbonPage;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup mainRibbonPageGroup;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlForGridBranch;
        private System.Windows.Forms.BindingSource userSettingsProfileBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colRoleID;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditRoleID;
        private DevExpress.XtraGrid.Columns.GridColumn colUsSettProfID;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditUsSettProf;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private System.Windows.Forms.BindingSource branchBindingSource;
        private DevExpress.XtraBars.Ribbon.Internal.RepositoryItemRibbonSearchEdit repositoryItemRibbonSearchEdit1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
    }
    //partial class UCuserRight
    //{
    //    /// <summary>
    //    /// Required designer variable.
    //    /// </summary>
    //    private System.ComponentModel.IContainer components = null;

    //    /// <summary>
    //    /// Clean up any resources being used.
    //    /// </summary>
    //    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    //    protected override void Dispose(bool disposing)
    //    {
    //        if (disposing && (components != null))
    //        {
    //            components.Dispose();
    //        }
    //        base.Dispose(disposing);
    //    }

    //    #region Windows Form Designer generated code

    //    /// <summary>
    //    /// Required method for Designer support - do not modify
    //    /// the contents of this method with the code editor.
    //    /// </summary>
    //    private void InitializeComponent()
    //    {
    //        this.components = new System.ComponentModel.Container();
    //        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCuserRight));
    //        this.ribbonControl = new DevExpress.XtraBars.Ribbon.RibbonControl();
    //        this.bsiRecordsCount = new DevExpress.XtraBars.BarStaticItem();
    //        this.bbiAddRole = new DevExpress.XtraBars.BarButtonItem();
    //        this.bbiAddPermission = new DevExpress.XtraBars.BarButtonItem();
    //        this.bbiRoleUser = new DevExpress.XtraBars.BarButtonItem();
    //        this.bbiRefresh = new DevExpress.XtraBars.BarButtonItem();
    //        this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
    //        this.bbiUserBranch = new DevExpress.XtraBars.BarButtonItem();
    //        this.bbiDscntPrmsion = new DevExpress.XtraBars.BarButtonItem();
    //        this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
    //        this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
    //        this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
    //        this.ribbonStatusBar = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
    //        this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
    //        this.gridControl = new DevExpress.XtraGrid.GridControl();
    //        this.tblRoleBindingSource = new System.Windows.Forms.BindingSource(this.components);
    //        this.gridView = new DevExpress.XtraGrid.Views.Grid.GridView();
    //        this.colrolId = new DevExpress.XtraGrid.Columns.GridColumn();
    //        this.colrolName = new DevExpress.XtraGrid.Columns.GridColumn();
    //        this.splitterControl1 = new DevExpress.XtraEditors.SplitterControl();
    //        this.gridControl2 = new DevExpress.XtraGrid.GridControl();
    //        this.tblUserRoleBindingSource = new System.Windows.Forms.BindingSource(this.components);
    //        this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
    //        this.colfkUserId = new DevExpress.XtraGrid.Columns.GridColumn();
    //        this.gridControl1 = new DevExpress.XtraGrid.GridControl();
    //        this.RoleControlTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
    //        this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
    //        this.colrcId = new DevExpress.XtraGrid.Columns.GridColumn();
    //        this.colfkRoleId = new DevExpress.XtraGrid.Columns.GridColumn();
    //        this.colfkucNo = new DevExpress.XtraGrid.Columns.GridColumn();
    //        this.colfkControlId = new DevExpress.XtraGrid.Columns.GridColumn();
    //        this.treeList1 = new DevExpress.XtraTreeList.TreeList();
    //        this.colName1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colCaption1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colCaptionEn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.treeListColumn1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.controlTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
    //        this.colNo1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colName = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colCaption = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colCaptionEn = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colRoleId1 = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colNo = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colUserId = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        this.colRoleId = new DevExpress.XtraTreeList.Columns.TreeListColumn();
    //        ((System.ComponentModel.ISupportInitialize)(this.ribbonControl)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).BeginInit();
    //        this.splitContainerControl1.Panel1.SuspendLayout();
    //        ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).BeginInit();
    //        this.splitContainerControl1.Panel2.SuspendLayout();
    //        this.splitContainerControl1.SuspendLayout();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridControl)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.tblRoleBindingSource)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridView)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.tblUserRoleBindingSource)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.RoleControlTblBindingSource)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.treeList1)).BeginInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.controlTblBindingSource)).BeginInit();
    //        this.SuspendLayout();
    //        // 
    //        // ribbonControl
    //        // 
    //        this.ribbonControl.EmptyAreaImageOptions.ImagePadding = new System.Windows.Forms.Padding(30, 34, 30, 34);
    //        this.ribbonControl.ExpandCollapseItem.Id = 0;
    //        this.ribbonControl.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
    //        this.ribbonControl.ExpandCollapseItem,
    //        this.ribbonControl.SearchEditItem,
    //        this.bsiRecordsCount,
    //        this.bbiAddRole,
    //        this.bbiAddPermission,
    //        this.bbiRoleUser,
    //        this.bbiRefresh,
    //        this.barButtonItem1,
    //        this.bbiUserBranch,
    //        this.bbiDscntPrmsion});
    //        this.ribbonControl.Location = new System.Drawing.Point(0, 0);
    //        this.ribbonControl.MaxItemId = 24;
    //        this.ribbonControl.Name = "ribbonControl";
    //        this.ribbonControl.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
    //        this.ribbonPage1});
    //        this.ribbonControl.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.Office2013;
    //        this.ribbonControl.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
    //        this.ribbonControl.Size = new System.Drawing.Size(1401, 162);
    //        this.ribbonControl.StatusBar = this.ribbonStatusBar;
    //        this.ribbonControl.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
    //        // 
    //        // bsiRecordsCount
    //        // 
    //        this.bsiRecordsCount.Caption = "RECORDS : 0";
    //        this.bsiRecordsCount.Id = 15;
    //        this.bsiRecordsCount.Name = "bsiRecordsCount";
    //        // 
    //        // bbiAddRole
    //        // 
    //        this.bbiAddRole.Caption = "إضافة صلاحية";
    //        this.bbiAddRole.Id = 16;
    //        this.bbiAddRole.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiAddRole.ImageOptions.Image")));
    //        this.bbiAddRole.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiAddRole.ImageOptions.LargeImage")));
    //        this.bbiAddRole.Name = "bbiAddRole";
    //        this.bbiAddRole.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiAddRole_ItemClick);
    //        // 
    //        // bbiAddPermission
    //        // 
    //        this.bbiAddPermission.Caption = "إذن الصلاحيات";
    //        this.bbiAddPermission.Id = 17;
    //        this.bbiAddPermission.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiAddPermission.ImageOptions.Image")));
    //        this.bbiAddPermission.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiAddPermission.ImageOptions.LargeImage")));
    //        this.bbiAddPermission.Name = "bbiAddPermission";
    //        this.bbiAddPermission.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiAddPermission_ItemClick);
    //        // 
    //        // bbiRoleUser
    //        // 
    //        this.bbiRoleUser.Caption = "تعين صلاحية المستخدمين";
    //        this.bbiRoleUser.Id = 18;
    //        this.bbiRoleUser.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiRoleUser.ImageOptions.Image")));
    //        this.bbiRoleUser.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiRoleUser.ImageOptions.LargeImage")));
    //        this.bbiRoleUser.Name = "bbiRoleUser";
    //        this.bbiRoleUser.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiRoleUser_ItemClick);
    //        // 
    //        // bbiRefresh
    //        // 
    //        this.bbiRefresh.Caption = "تحديث";
    //        this.bbiRefresh.Id = 19;
    //        this.bbiRefresh.Name = "bbiRefresh";
    //        this.bbiRefresh.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiRefresh_ItemClick);
    //        // 
    //        // barButtonItem1
    //        // 
    //        this.barButtonItem1.Caption = "إضافة مستخدم";
    //        this.barButtonItem1.Id = 20;
    //        this.barButtonItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem1.ImageOptions.Image")));
    //        this.barButtonItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("barButtonItem1.ImageOptions.LargeImage")));
    //        this.barButtonItem1.Name = "barButtonItem1";
    //        this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
    //        // 
    //        // bbiUserBranch
    //        // 
    //        this.bbiUserBranch.Caption = "barButtonItem2";
    //        this.bbiUserBranch.Id = 22;
    //        this.bbiUserBranch.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bbiUserBranch.ImageOptions.SvgImage")));
    //        this.bbiUserBranch.Name = "bbiUserBranch";
    //        this.bbiUserBranch.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiUserBranch_ItemClick);
    //        // 
    //        // bbiDscntPrmsion
    //        // 
    //        this.bbiDscntPrmsion.Caption = "تعين صلاحيات الخصم";
    //        this.bbiDscntPrmsion.Id = 23;
    //        this.bbiDscntPrmsion.Name = "bbiDscntPrmsion";
    //        this.bbiDscntPrmsion.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiDscntPrmsion_ItemClick);
    //        // 
    //        // ribbonPage1
    //        // 
    //        this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
    //        this.ribbonPageGroup1,
    //        this.ribbonPageGroup2});
    //        this.ribbonPage1.MergeOrder = 0;
    //        this.ribbonPage1.Name = "ribbonPage1";
    //        this.ribbonPage1.Text = "الرئيسية";
    //        // 
    //        // ribbonPageGroup1
    //        // 
    //        this.ribbonPageGroup1.AllowTextClipping = false;
    //        this.ribbonPageGroup1.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
    //        this.ribbonPageGroup1.ItemLinks.Add(this.barButtonItem1);
    //        this.ribbonPageGroup1.ItemLinks.Add(this.bbiAddRole);
    //        this.ribbonPageGroup1.ItemLinks.Add(this.bbiAddPermission);
    //        this.ribbonPageGroup1.ItemLinks.Add(this.bbiRoleUser);
    //        this.ribbonPageGroup1.ItemLinks.Add(this.bbiUserBranch);
    //        this.ribbonPageGroup1.ItemLinks.Add(this.bbiRefresh);
    //        this.ribbonPageGroup1.Name = "ribbonPageGroup1";
    //        this.ribbonPageGroup1.Text = "العمليات";
    //        // 
    //        // ribbonPageGroup2
    //        // 
    //        this.ribbonPageGroup2.AllowTextClipping = false;
    //        this.ribbonPageGroup2.ItemLinks.Add(this.bbiDscntPrmsion);
    //        this.ribbonPageGroup2.Name = "ribbonPageGroup2";
    //        this.ribbonPageGroup2.Text = "صلاحيات الخصم";
    //        // 
    //        // ribbonStatusBar
    //        // 
    //        this.ribbonStatusBar.ItemLinks.Add(this.bsiRecordsCount);
    //        this.ribbonStatusBar.Location = new System.Drawing.Point(0, 706);
    //        this.ribbonStatusBar.Name = "ribbonStatusBar";
    //        this.ribbonStatusBar.Ribbon = this.ribbonControl;
    //        this.ribbonStatusBar.Size = new System.Drawing.Size(1401, 32);
    //        // 
    //        // splitContainerControl1
    //        // 
    //        this.splitContainerControl1.Dock = System.Windows.Forms.DockStyle.Fill;
    //        this.splitContainerControl1.Location = new System.Drawing.Point(0, 162);
    //        this.splitContainerControl1.Name = "splitContainerControl1";
    //        // 
    //        // splitContainerControl1.Panel1
    //        // 
    //        this.splitContainerControl1.Panel1.Controls.Add(this.gridControl);
    //        this.splitContainerControl1.Panel1.Controls.Add(this.splitterControl1);
    //        this.splitContainerControl1.Panel1.Controls.Add(this.gridControl2);
    //        this.splitContainerControl1.Panel1.Text = "Panel1";
    //        // 
    //        // splitContainerControl1.Panel2
    //        // 
    //        this.splitContainerControl1.Panel2.Controls.Add(this.gridControl1);
    //        this.splitContainerControl1.Panel2.Controls.Add(this.treeList1);
    //        this.splitContainerControl1.Panel2.Text = "Panel2";
    //        this.splitContainerControl1.ShowSplitGlyph = DevExpress.Utils.DefaultBoolean.True;
    //        this.splitContainerControl1.Size = new System.Drawing.Size(1401, 544);
    //        this.splitContainerControl1.SplitterPosition = 276;
    //        this.splitContainerControl1.TabIndex = 4;
    //        this.splitContainerControl1.Text = "splitContainerControl1";
    //        // 
    //        // gridControl
    //        // 
    //        this.gridControl.DataSource = this.tblRoleBindingSource;
    //        this.gridControl.Dock = System.Windows.Forms.DockStyle.Fill;
    //        this.gridControl.Location = new System.Drawing.Point(0, 0);
    //        this.gridControl.MainView = this.gridView;
    //        this.gridControl.MenuManager = this.ribbonControl;
    //        this.gridControl.Name = "gridControl";
    //        this.gridControl.Size = new System.Drawing.Size(276, 286);
    //        this.gridControl.TabIndex = 6;
    //        this.gridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
    //        this.gridView});
    //        // 
    //        // tblRoleBindingSource
    //        // 
    //        this.tblRoleBindingSource.DataSource = typeof(PosFinalCost.RoleTbl);
    //        // 
    //        // gridView
    //        // 
    //        this.gridView.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F);
    //        this.gridView.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
    //        this.gridView.Appearance.HeaderPanel.Options.UseFont = true;
    //        this.gridView.Appearance.HeaderPanel.Options.UseForeColor = true;
    //        this.gridView.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
    //        this.gridView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
    //        this.colrolId,
    //        this.colrolName});
    //        this.gridView.DetailHeight = 431;
    //        this.gridView.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
    //        this.gridView.GridControl = this.gridControl;
    //        this.gridView.Name = "gridView";
    //        this.gridView.OptionsBehavior.Editable = false;
    //        this.gridView.OptionsBehavior.ReadOnly = true;
    //        this.gridView.OptionsSelection.EnableAppearanceFocusedCell = false;
    //        this.gridView.OptionsView.ShowGroupPanel = false;
    //        this.gridView.OptionsView.ShowIndicator = false;
    //        // 
    //        // colrolId
    //        // 
    //        this.colrolId.FieldName = "ID";
    //        this.colrolId.MinWidth = 23;
    //        this.colrolId.Name = "colrolId";
    //        this.colrolId.Width = 87;
    //        // 
    //        // colrolName
    //        // 
    //        this.colrolName.Caption = "الصلاحيات";
    //        this.colrolName.FieldName = "Name";
    //        this.colrolName.MinWidth = 23;
    //        this.colrolName.Name = "colrolName";
    //        this.colrolName.Visible = true;
    //        this.colrolName.VisibleIndex = 0;
    //        this.colrolName.Width = 87;
    //        // 
    //        // splitterControl1
    //        // 
    //        this.splitterControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
    //        this.splitterControl1.Location = new System.Drawing.Point(0, 286);
    //        this.splitterControl1.Name = "splitterControl1";
    //        this.splitterControl1.ShowSplitGlyph = DevExpress.Utils.DefaultBoolean.True;
    //        this.splitterControl1.Size = new System.Drawing.Size(276, 12);
    //        this.splitterControl1.TabIndex = 1;
    //        this.splitterControl1.TabStop = false;
    //        // 
    //        // gridControl2
    //        // 
    //        this.gridControl2.DataSource = this.tblUserRoleBindingSource;
    //        this.gridControl2.Dock = System.Windows.Forms.DockStyle.Bottom;
    //        this.gridControl2.Location = new System.Drawing.Point(0, 298);
    //        this.gridControl2.MainView = this.gridView2;
    //        this.gridControl2.MenuManager = this.ribbonControl;
    //        this.gridControl2.Name = "gridControl2";
    //        this.gridControl2.Size = new System.Drawing.Size(276, 246);
    //        this.gridControl2.TabIndex = 0;
    //        this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
    //        this.gridView2});
    //        // 
    //        // tblUserRoleBindingSource
    //        // 
    //        this.tblUserRoleBindingSource.DataSource = typeof(PosFinalCost.UserRoleTbl);
    //        // 
    //        // gridView2
    //        // 
    //        this.gridView2.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F);
    //        this.gridView2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
    //        this.gridView2.Appearance.HeaderPanel.Options.UseFont = true;
    //        this.gridView2.Appearance.HeaderPanel.Options.UseForeColor = true;
    //        this.gridView2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
    //        this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
    //        this.colfkUserId});
    //        this.gridView2.DetailHeight = 431;
    //        this.gridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
    //        this.gridView2.GridControl = this.gridControl2;
    //        this.gridView2.Name = "gridView2";
    //        this.gridView2.OptionsBehavior.Editable = false;
    //        this.gridView2.OptionsBehavior.ReadOnly = true;
    //        this.gridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
    //        this.gridView2.OptionsView.ShowGroupPanel = false;
    //        this.gridView2.OptionsView.ShowIndicator = false;
    //        // 
    //        // colfkUserId
    //        // 
    //        this.colfkUserId.AppearanceCell.Options.UseTextOptions = true;
    //        this.colfkUserId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
    //        this.colfkUserId.Caption = "المستخدمين";
    //        this.colfkUserId.FieldName = "UserId";
    //        this.colfkUserId.MinWidth = 23;
    //        this.colfkUserId.Name = "colfkUserId";
    //        this.colfkUserId.Visible = true;
    //        this.colfkUserId.VisibleIndex = 0;
    //        this.colfkUserId.Width = 87;
    //        // 
    //        // gridControl1
    //        // 
    //        this.gridControl1.DataSource = this.RoleControlTblBindingSource;
    //        this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
    //        this.gridControl1.Location = new System.Drawing.Point(0, 0);
    //        this.gridControl1.MainView = this.gridView1;
    //        this.gridControl1.MenuManager = this.ribbonControl;
    //        this.gridControl1.Name = "gridControl1";
    //        this.gridControl1.Size = new System.Drawing.Size(1113, 544);
    //        this.gridControl1.TabIndex = 0;
    //        this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
    //        this.gridView1});
    //        // 
    //        // RoleControlTblBindingSource
    //        // 
    //        this.RoleControlTblBindingSource.DataSource = typeof(PosFinalCost.RoleControlTbl);
    //        // 
    //        // gridView1
    //        // 
    //        this.gridView1.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F);
    //        this.gridView1.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
    //        this.gridView1.Appearance.HeaderPanel.Options.UseFont = true;
    //        this.gridView1.Appearance.HeaderPanel.Options.UseForeColor = true;
    //        this.gridView1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
    //        this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
    //        this.colrcId,
    //        this.colfkRoleId,
    //        this.colfkucNo,
    //        this.colfkControlId});
    //        this.gridView1.DetailHeight = 431;
    //        this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
    //        this.gridView1.GridControl = this.gridControl1;
    //        this.gridView1.GroupCount = 1;
    //        this.gridView1.Name = "gridView1";
    //        this.gridView1.OptionsBehavior.AutoExpandAllGroups = true;
    //        this.gridView1.OptionsBehavior.Editable = false;
    //        this.gridView1.OptionsBehavior.ReadOnly = true;
    //        this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
    //        this.gridView1.OptionsView.ShowGroupPanel = false;
    //        this.gridView1.OptionsView.ShowIndicator = false;
    //        this.gridView1.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
    //        new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colfkucNo, DevExpress.Data.ColumnSortOrder.Ascending),
    //        new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colfkControlId, DevExpress.Data.ColumnSortOrder.Ascending)});
    //        // 
    //        // colrcId
    //        // 
    //        this.colrcId.FieldName = "ID";
    //        this.colrcId.MinWidth = 23;
    //        this.colrcId.Name = "colrcId";
    //        this.colrcId.OptionsColumn.ShowInCustomizationForm = false;
    //        this.colrcId.Width = 87;
    //        // 
    //        // colfkRoleId
    //        // 
    //        this.colfkRoleId.AppearanceCell.Options.UseTextOptions = true;
    //        this.colfkRoleId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
    //        this.colfkRoleId.FieldName = "RoleId";
    //        this.colfkRoleId.MinWidth = 23;
    //        this.colfkRoleId.Name = "colfkRoleId";
    //        this.colfkRoleId.OptionsColumn.ShowInCustomizationForm = false;
    //        this.colfkRoleId.Width = 87;
    //        // 
    //        // colfkucNo
    //        // 
    //        this.colfkucNo.AppearanceCell.Options.UseTextOptions = true;
    //        this.colfkucNo.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
    //        this.colfkucNo.Caption = "شاشة";
    //        this.colfkucNo.FieldName = "No";
    //        this.colfkucNo.MinWidth = 23;
    //        this.colfkucNo.Name = "colfkucNo";
    //        this.colfkucNo.Visible = true;
    //        this.colfkucNo.VisibleIndex = 1;
    //        this.colfkucNo.Width = 87;
    //        // 
    //        // colfkControlId
    //        // 
    //        this.colfkControlId.AppearanceCell.Options.UseTextOptions = true;
    //        this.colfkControlId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
    //        this.colfkControlId.Caption = "إذن الصلاحية";
    //        this.colfkControlId.FieldName = "ControlId";
    //        this.colfkControlId.MinWidth = 23;
    //        this.colfkControlId.Name = "colfkControlId";
    //        this.colfkControlId.Visible = true;
    //        this.colfkControlId.VisibleIndex = 0;
    //        this.colfkControlId.Width = 87;
    //        // 
    //        // treeList1
    //        // 
    //        this.treeList1.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
    //        this.colName1,
    //        this.colCaption1,
    //        this.colCaptionEn1,
    //        this.treeListColumn1});
    //        this.treeList1.DataSource = this.controlTblBindingSource;
    //        this.treeList1.Location = new System.Drawing.Point(1011, 0);
    //        this.treeList1.MenuManager = this.ribbonControl;
    //        this.treeList1.Name = "treeList1";
    //        this.treeList1.OptionsBehavior.ReadOnly = true;
    //        this.treeList1.Size = new System.Drawing.Size(102, 544);
    //        this.treeList1.TabIndex = 1;
    //        // 
    //        // colName1
    //        // 
    //        this.colName1.FieldName = "Name";
    //        this.colName1.Name = "colName1";
    //        // 
    //        // colCaption1
    //        // 
    //        this.colCaption1.Caption = "اذن الصلاحيات";
    //        this.colCaption1.FieldName = "Caption";
    //        this.colCaption1.Name = "colCaption1";
    //        this.colCaption1.Visible = true;
    //        this.colCaption1.VisibleIndex = 0;
    //        this.colCaption1.Width = 520;
    //        // 
    //        // colCaptionEn1
    //        // 
    //        this.colCaptionEn1.FieldName = "CaptionEn";
    //        this.colCaptionEn1.Name = "colCaptionEn1";
    //        // 
    //        // treeListColumn1
    //        // 
    //        this.treeListColumn1.Caption = "الشاشة";
    //        this.treeListColumn1.FieldName = "ParentID";
    //        this.treeListColumn1.Name = "treeListColumn1";
    //        this.treeListColumn1.Width = 97;
    //        // 
    //        // controlTblBindingSource
    //        // 
    //        this.controlTblBindingSource.DataSource = typeof(PosFinalCost.ControlTbl);
    //        // 
    //        // colNo1
    //        // 
    //        this.colNo1.FieldName = "No";
    //        this.colNo1.Name = "colNo1";
    //        // 
    //        // colName
    //        // 
    //        this.colName.FieldName = "Name";
    //        this.colName.Name = "colName";
    //        // 
    //        // colCaption
    //        // 
    //        this.colCaption.FieldName = "Caption";
    //        this.colCaption.Name = "colCaption";
    //        this.colCaption.Visible = true;
    //        this.colCaption.VisibleIndex = 0;
    //        // 
    //        // colCaptionEn
    //        // 
    //        this.colCaptionEn.FieldName = "CaptionEn";
    //        this.colCaptionEn.Name = "colCaptionEn";
    //        this.colCaptionEn.Visible = true;
    //        this.colCaptionEn.VisibleIndex = 1;
    //        // 
    //        // colRoleId1
    //        // 
    //        this.colRoleId1.FieldName = "RoleId";
    //        this.colRoleId1.Name = "colRoleId1";
    //        this.colRoleId1.Visible = true;
    //        this.colRoleId1.VisibleIndex = 0;
    //        // 
    //        // colNo
    //        // 
    //        this.colNo.FieldName = "No";
    //        this.colNo.Name = "colNo";
    //        this.colNo.Visible = true;
    //        this.colNo.VisibleIndex = 1;
    //        // 
    //        // colUserId
    //        // 
    //        this.colUserId.FieldName = "UserId";
    //        this.colUserId.Name = "colUserId";
    //        this.colUserId.Visible = true;
    //        this.colUserId.VisibleIndex = 0;
    //        // 
    //        // colRoleId
    //        // 
    //        this.colRoleId.FieldName = "RoleId";
    //        this.colRoleId.Name = "colRoleId";
    //        this.colRoleId.Visible = true;
    //        this.colRoleId.VisibleIndex = 1;
    //        // 
    //        // UCuserRight
    //        // 
    //        this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
    //        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
    //        this.Controls.Add(this.splitContainerControl1);
    //        this.Controls.Add(this.ribbonStatusBar);
    //        this.Controls.Add(this.ribbonControl);
    //        this.Name = "UCuserRight";
    //        this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
    //        this.Size = new System.Drawing.Size(1401, 738);
    //        ((System.ComponentModel.ISupportInitialize)(this.ribbonControl)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).EndInit();
    //        this.splitContainerControl1.Panel1.ResumeLayout(false);
    //        ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).EndInit();
    //        this.splitContainerControl1.Panel2.ResumeLayout(false);
    //        ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
    //        this.splitContainerControl1.ResumeLayout(false);
    //        ((System.ComponentModel.ISupportInitialize)(this.gridControl)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.tblRoleBindingSource)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridView)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.tblUserRoleBindingSource)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.RoleControlTblBindingSource)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.treeList1)).EndInit();
    //        ((System.ComponentModel.ISupportInitialize)(this.controlTblBindingSource)).EndInit();
    //        this.ResumeLayout(false);
    //        this.PerformLayout();

    //    }

    //    #endregion
    //    private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
    //    private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
    //    private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;
    //    private DevExpress.XtraBars.BarStaticItem bsiRecordsCount;
    //    private DevExpress.XtraBars.BarButtonItem bbiAddRole;
    //    private DevExpress.XtraBars.BarButtonItem bbiAddPermission;
    //    private DevExpress.XtraBars.BarButtonItem bbiRoleUser;
    //    private DevExpress.XtraBars.BarButtonItem bbiRefresh;
    //    private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
    //    private System.Windows.Forms.BindingSource tblRoleBindingSource;
    //    private DevExpress.XtraGrid.GridControl gridControl1;
    //    private System.Windows.Forms.BindingSource RoleControlTblBindingSource;
    //    private DevExpress.XtraGrid.GridControl gridControl;
    //    private DevExpress.XtraGrid.Views.Grid.GridView gridView;
    //    private DevExpress.XtraGrid.Columns.GridColumn colrolId;
    //    private DevExpress.XtraGrid.Columns.GridColumn colrolName;
    //    private DevExpress.XtraEditors.SplitterControl splitterControl1;
    //    private DevExpress.XtraGrid.GridControl gridControl2;
    //    private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
    //    private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
    //    private DevExpress.XtraGrid.Columns.GridColumn colrcId;
    //    private DevExpress.XtraGrid.Columns.GridColumn colfkRoleId;
    //    private DevExpress.XtraGrid.Columns.GridColumn colfkControlId;
    //    private DevExpress.XtraBars.BarButtonItem barButtonItem1;
    //    internal DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl;
    //    private System.Windows.Forms.BindingSource tblUserRoleBindingSource;
    //    private DevExpress.XtraGrid.Columns.GridColumn colfkUserId;
    //    private DevExpress.XtraGrid.Columns.GridColumn colfkucNo;
    //    private DevExpress.XtraBars.BarButtonItem bbiUserBranch;
    //    private DevExpress.XtraBars.BarButtonItem bbiDscntPrmsion;
    //    private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colRoleId1;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colNo;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colUserId;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colRoleId;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colNo1;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colName;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colCaption;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colCaptionEn;
    //    private System.Windows.Forms.BindingSource controlTblBindingSource;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colName1;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colCaption1;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn colCaptionEn1;
    //    private DevExpress.XtraTreeList.Columns.TreeListColumn treeListColumn1;
    //    public DevExpress.XtraTreeList.TreeList treeList1;
    //}
}
