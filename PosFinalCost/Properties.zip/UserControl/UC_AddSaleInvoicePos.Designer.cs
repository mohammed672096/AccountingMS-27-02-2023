﻿namespace PosFinalCost.Forms
{
    partial class UC_AddSaleInvoicePos
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_AddSaleInvoicePos));
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions1 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition2 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition3 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition4 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition2 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition3 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableSpan tableSpan1 = new DevExpress.XtraEditors.TableLayout.TableSpan();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement2 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.ItemTemplate itemTemplate1 = new DevExpress.XtraGrid.Views.Tile.ItemTemplate();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition5 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition6 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement3 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement4 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement5 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement6 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition4 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition5 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition6 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableSpan tableSpan2 = new DevExpress.XtraEditors.TableLayout.TableSpan();
            DevExpress.XtraEditors.TableLayout.TableSpan tableSpan3 = new DevExpress.XtraEditors.TableLayout.TableSpan();
            DevExpress.XtraGrid.Views.Tile.ItemTemplate itemTemplate2 = new DevExpress.XtraGrid.Views.Tile.ItemTemplate();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition7 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition8 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement7 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement8 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement9 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition7 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition8 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition9 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableSpan tableSpan4 = new DevExpress.XtraEditors.TableLayout.TableSpan();
            DevExpress.XtraEditors.TableLayout.TableSpan tableSpan5 = new DevExpress.XtraEditors.TableLayout.TableSpan();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition9 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition10 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition10 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition11 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition12 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraEditors.TableLayout.TableSpan tableSpan6 = new DevExpress.XtraEditors.TableLayout.TableSpan();
            DevExpress.XtraEditors.TableLayout.TableSpan tableSpan7 = new DevExpress.XtraEditors.TableLayout.TableSpan();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement10 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement11 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement12 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement13 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            DevExpress.XtraEditors.TableLayout.TableColumnDefinition tableColumnDefinition1 = new DevExpress.XtraEditors.TableLayout.TableColumnDefinition();
            DevExpress.XtraEditors.TableLayout.TableRowDefinition tableRowDefinition1 = new DevExpress.XtraEditors.TableLayout.TableRowDefinition();
            DevExpress.XtraGrid.Views.Tile.TileViewItemElement tileViewItemElement1 = new DevExpress.XtraGrid.Views.Tile.TileViewItemElement();
            this.dataLayoutControl1 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.btn_DecreaseQte = new DevExpress.XtraEditors.SimpleButton();
            this.btn_IncreaseQte = new DevExpress.XtraEditors.SimpleButton();
            this.txt_Brcode = new DevExpress.XtraEditors.TextEdit();
            this.btn_AddAddition = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Nine = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Eight = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Six = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Seven = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Five = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Three = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Two = new DevExpress.XtraEditors.SimpleButton();
            this.btn_Four = new DevExpress.XtraEditors.SimpleButton();
            this.btn_One = new DevExpress.XtraEditors.SimpleButton();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup9 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.gridControlItems = new DevExpress.XtraGrid.GridControl();
            this.grd_Addition_View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btn_DeleteAddition = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridViewItems = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colcurrency_from = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.colval1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.grd_Quantity = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.colexchange_price = new DevExpress.XtraGrid.Columns.GridColumn();
            this.coldiscount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.grdSpin_Total = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.gridColumnDelete = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemButtonEditDeleteRow = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.spinEditltemCount = new DevExpress.XtraEditors.SpinEdit();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup6 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup7 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.spinEditTotal = new DevExpress.XtraEditors.SpinEdit();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.spinEditDiscount = new DevExpress.XtraEditors.SpinEdit();
            this.layoutControlGroup8 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.spinEditNet = new DevExpress.XtraEditors.SpinEdit();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.spinEditTax = new DevExpress.XtraEditors.SpinEdit();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem18 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem20 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem21 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem19 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlInvoiceType = new DevExpress.XtraLayout.LayoutControlItem();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.tileViewInvType = new DevExpress.XtraGrid.Views.Tile.TileView();
            this.coltype = new DevExpress.XtraGrid.Columns.TileViewColumn();
            this.colname = new DevExpress.XtraGrid.Columns.TileViewColumn();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup5 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.gridControlProudct = new DevExpress.XtraGrid.GridControl();
            this.tileViewProducts = new DevExpress.XtraGrid.Views.Tile.TileView();
            this.colIcon = new DevExpress.XtraGrid.Columns.TileViewColumn();
            this.repositoryItemPictureEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.tileViewColumn2 = new DevExpress.XtraGrid.Columns.TileViewColumn();
            this.tileViewColumn3 = new DevExpress.XtraGrid.Columns.TileViewColumn();
            this.tileViewColumn4 = new DevExpress.XtraGrid.Columns.TileViewColumn();
            this.repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.colName1 = new DevExpress.XtraGrid.Columns.TileViewColumn();
            this.tileViewCategoris = new DevExpress.XtraGrid.Views.Tile.TileView();
            this.colColor = new DevExpress.XtraGrid.Columns.TileViewColumn();
            this.groupStrBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).BeginInit();
            this.dataLayoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txt_Brcode.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_Addition_View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_DeleteAddition)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_Quantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSpin_Total)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditDeleteRow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditltemCount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditTotal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditDiscount.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditNet.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditTax.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlInvoiceType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tileViewInvType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlProudct)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tileViewProducts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tileViewCategoris)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupStrBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataLayoutControl1
            // 
            this.dataLayoutControl1.Controls.Add(this.btn_DecreaseQte);
            this.dataLayoutControl1.Controls.Add(this.btn_IncreaseQte);
            this.dataLayoutControl1.Controls.Add(this.txt_Brcode);
            this.dataLayoutControl1.Controls.Add(this.btn_AddAddition);
            this.dataLayoutControl1.Controls.Add(this.btn_Nine);
            this.dataLayoutControl1.Controls.Add(this.btn_Eight);
            this.dataLayoutControl1.Controls.Add(this.btn_Six);
            this.dataLayoutControl1.Controls.Add(this.btn_Seven);
            this.dataLayoutControl1.Controls.Add(this.btn_Five);
            this.dataLayoutControl1.Controls.Add(this.btn_Three);
            this.dataLayoutControl1.Controls.Add(this.btn_Two);
            this.dataLayoutControl1.Controls.Add(this.btn_Four);
            this.dataLayoutControl1.Controls.Add(this.btn_One);
            this.dataLayoutControl1.Controls.Add(this.gridControl2);
            this.dataLayoutControl1.Controls.Add(this.gridControl1);
            this.dataLayoutControl1.Controls.Add(this.spinEditltemCount);
            this.dataLayoutControl1.Controls.Add(this.spinEditNet);
            this.dataLayoutControl1.Controls.Add(this.spinEditTax);
            this.dataLayoutControl1.Controls.Add(this.spinEditDiscount);
            this.dataLayoutControl1.Controls.Add(this.spinEditTotal);
            this.dataLayoutControl1.Controls.Add(this.gridControlItems);
            this.dataLayoutControl1.Controls.Add(this.gridControlProudct);
            resources.ApplyResources(this.dataLayoutControl1, "dataLayoutControl1");
            this.dataLayoutControl1.Name = "dataLayoutControl1";
            this.dataLayoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(426, 161, 650, 400);
            this.dataLayoutControl1.OptionsFocus.MoveFocusRightToLeft = true;
            this.dataLayoutControl1.OptionsView.RightToLeftMirroringApplied = true;
            this.dataLayoutControl1.Root = this.Root;
            // 
            // btn_DecreaseQte
            // 
            this.btn_DecreaseQte.ImageOptions.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            resources.ApplyResources(this.btn_DecreaseQte, "btn_DecreaseQte");
            this.btn_DecreaseQte.Name = "btn_DecreaseQte";
            this.btn_DecreaseQte.StyleController = this.dataLayoutControl1;
            // 
            // btn_IncreaseQte
            // 
            this.btn_IncreaseQte.ImageOptions.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            resources.ApplyResources(this.btn_IncreaseQte, "btn_IncreaseQte");
            this.btn_IncreaseQte.Name = "btn_IncreaseQte";
            this.btn_IncreaseQte.StyleController = this.dataLayoutControl1;
            // 
            // txt_Brcode
            // 
            resources.ApplyResources(this.txt_Brcode, "txt_Brcode");
            this.txt_Brcode.Name = "txt_Brcode";
            this.txt_Brcode.StyleController = this.dataLayoutControl1;
            // 
            // btn_AddAddition
            // 
            this.btn_AddAddition.ImageOptions.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            this.btn_AddAddition.ImageOptions.ImageToTextIndent = 0;
            resources.ApplyResources(this.btn_AddAddition, "btn_AddAddition");
            this.btn_AddAddition.Name = "btn_AddAddition";
            this.btn_AddAddition.StyleController = this.dataLayoutControl1;
            // 
            // btn_Nine
            // 
            this.btn_Nine.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_Nine, "btn_Nine");
            this.btn_Nine.Name = "btn_Nine";
            this.btn_Nine.StyleController = this.dataLayoutControl1;
            // 
            // btn_Eight
            // 
            this.btn_Eight.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_Eight, "btn_Eight");
            this.btn_Eight.Name = "btn_Eight";
            this.btn_Eight.StyleController = this.dataLayoutControl1;
            // 
            // btn_Six
            // 
            this.btn_Six.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_Six, "btn_Six");
            this.btn_Six.Name = "btn_Six";
            this.btn_Six.StyleController = this.dataLayoutControl1;
            // 
            // btn_Seven
            // 
            this.btn_Seven.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_Seven, "btn_Seven");
            this.btn_Seven.Name = "btn_Seven";
            this.btn_Seven.StyleController = this.dataLayoutControl1;
            // 
            // btn_Five
            // 
            this.btn_Five.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_Five, "btn_Five");
            this.btn_Five.Name = "btn_Five";
            this.btn_Five.StyleController = this.dataLayoutControl1;
            // 
            // btn_Three
            // 
            this.btn_Three.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_Three, "btn_Three");
            this.btn_Three.Name = "btn_Three";
            this.btn_Three.StyleController = this.dataLayoutControl1;
            // 
            // btn_Two
            // 
            this.btn_Two.ImageOptions.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.RightCenter;
            this.btn_Two.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_Two, "btn_Two");
            this.btn_Two.Name = "btn_Two";
            this.btn_Two.StyleController = this.dataLayoutControl1;
            // 
            // btn_Four
            // 
            this.btn_Four.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_Four, "btn_Four");
            this.btn_Four.Name = "btn_Four";
            this.btn_Four.StyleController = this.dataLayoutControl1;
            // 
            // btn_One
            // 
            this.btn_One.AllowHtmlDraw = DevExpress.Utils.DefaultBoolean.False;
            this.btn_One.ImageOptions.AllowGlyphSkinning = DevExpress.Utils.DefaultBoolean.True;
            this.btn_One.ImageOptions.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            this.btn_One.ImageOptions.ImageToTextIndent = 0;
            this.btn_One.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            resources.ApplyResources(this.btn_One, "btn_One");
            this.btn_One.Name = "btn_One";
            this.btn_One.StyleController = this.dataLayoutControl1;
            // 
            // gridControl2
            // 
            this.gridControl2.DataSource = this.groupStrBindingSource;
            this.gridControl2.EmbeddedNavigator.Margin = ((System.Windows.Forms.Padding)(resources.GetObject("gridControl2.EmbeddedNavigator.Margin")));
            resources.ApplyResources(this.gridControl2, "gridControl2");
            this.gridControl2.MainView = this.tileViewCategoris;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.tileViewCategoris});
            // 
            // Root
            // 
            resources.ApplyResources(this.Root, "Root");
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup9,
            this.layoutControlInvoiceType,
            this.layoutControlGroup3});
            this.Root.MoveFocusRightToLeft = DevExpress.Utils.DefaultBoolean.False;
            this.Root.Name = "Root";
            this.Root.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.Root.Size = new System.Drawing.Size(1419, 805);
            this.Root.TextVisible = false;
            // 
            // layoutControlGroup9
            // 
            resources.ApplyResources(this.layoutControlGroup9, "layoutControlGroup9");
            this.layoutControlGroup9.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup2,
            this.layoutControlItem19});
            this.layoutControlGroup9.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup9.Name = "layoutControlGroup9";
            this.layoutControlGroup9.OptionsTableLayoutItem.RowSpan = 2;
            this.layoutControlGroup9.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup9.Size = new System.Drawing.Size(416, 805);
            this.layoutControlGroup9.TextVisible = false;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.BorderColor = DevExpress.LookAndFeel.DXSkinColors.FillColors.Success;
            this.layoutControlGroup2.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGroup2.AppearanceGroup.Options.UseTextOptions = true;
            this.layoutControlGroup2.AppearanceGroup.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.layoutControlGroup2, "layoutControlGroup2");
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem3,
            this.layoutControlItem6,
            this.layoutControlItem11,
            this.layoutControlItem14,
            this.emptySpaceItem1,
            this.layoutControlItem5,
            this.layoutControlGroup6,
            this.layoutControlItem12,
            this.layoutControlItem13,
            this.layoutControlItem16,
            this.layoutControlItem17,
            this.layoutControlItem15,
            this.layoutControlItem18,
            this.layoutControlItem2,
            this.layoutControlItem20,
            this.layoutControlItem21});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 26);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup2.Size = new System.Drawing.Size(410, 773);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.gridControlItems;
            resources.ApplyResources(this.layoutControlItem3, "layoutControlItem3");
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(345, 585);
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // gridControlItems
            // 
            this.gridControlItems.EmbeddedNavigator.Margin = ((System.Windows.Forms.Padding)(resources.GetObject("gridControlItems.EmbeddedNavigator.Margin")));
            gridLevelNode1.LevelTemplate = this.grd_Addition_View;
            gridLevelNode1.RelationName = "Additions";
            this.gridControlItems.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1});
            resources.ApplyResources(this.gridControlItems, "gridControlItems");
            this.gridControlItems.MainView = this.gridViewItems;
            this.gridControlItems.Name = "gridControlItems";
            this.gridControlItems.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEditDeleteRow,
            this.repositoryItemMemoEdit2,
            this.grdSpin_Total,
            this.grd_Quantity,
            this.btn_DeleteAddition,
            this.repositoryItemSpinEdit2});
            this.gridControlItems.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.grd_Addition_View,
            this.gridViewItems});
            // 
            // grd_Addition_View
            // 
            this.grd_Addition_View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn7});
            this.grd_Addition_View.DetailHeight = 485;
            this.grd_Addition_View.GridControl = this.gridControlItems;
            this.grd_Addition_View.Name = "grd_Addition_View";
            // 
            // gridColumn2
            // 
            resources.ApplyResources(this.gridColumn2, "gridColumn2");
            this.gridColumn2.FieldName = "Addition.AdditionName";
            this.gridColumn2.MinWidth = 27;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn3
            // 
            resources.ApplyResources(this.gridColumn3, "gridColumn3");
            this.gridColumn3.FieldName = "Quantity";
            this.gridColumn3.MinWidth = 27;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn4
            // 
            resources.ApplyResources(this.gridColumn4, "gridColumn4");
            this.gridColumn4.FieldName = "Price";
            this.gridColumn4.MinWidth = 27;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn5
            // 
            resources.ApplyResources(this.gridColumn5, "gridColumn5");
            this.gridColumn5.FieldName = "Total";
            this.gridColumn5.MinWidth = 27;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn7
            // 
            this.gridColumn7.ColumnEdit = this.btn_DeleteAddition;
            this.gridColumn7.MinWidth = 27;
            this.gridColumn7.Name = "gridColumn7";
            resources.ApplyResources(this.gridColumn7, "gridColumn7");
            // 
            // btn_DeleteAddition
            // 
            resources.ApplyResources(this.btn_DeleteAddition, "btn_DeleteAddition");
            this.btn_DeleteAddition.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("btn_DeleteAddition.Buttons"))))});
            this.btn_DeleteAddition.Name = "btn_DeleteAddition";
            this.btn_DeleteAddition.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // gridViewItems
            // 
            this.gridViewItems.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.gridViewItems.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridViewItems.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridViewItems.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridViewItems.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.gridViewItems.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridViewItems.Appearance.OddRow.Options.UseBackColor = true;
            this.gridViewItems.Appearance.OddRow.Options.UseForeColor = true;
            this.gridViewItems.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colcurrency_from,
            this.colval1,
            this.colexchange_price,
            this.coldiscount,
            this.gridColumn1,
            this.gridColumnDelete,
            this.gridColumn6,
            this.gridColumn8});
            this.gridViewItems.CustomizationFormBounds = new System.Drawing.Rectangle(472, 361, 336, 368);
            this.gridViewItems.DetailHeight = 485;
            this.gridViewItems.GridControl = this.gridControlItems;
            this.gridViewItems.Name = "gridViewItems";
            this.gridViewItems.OptionsDetail.ShowDetailTabs = false;
            this.gridViewItems.OptionsDetail.ShowEmbeddedDetailIndent = DevExpress.Utils.DefaultBoolean.False;
            this.gridViewItems.OptionsView.EnableAppearanceEvenRow = true;
            this.gridViewItems.OptionsView.EnableAppearanceOddRow = true;
            this.gridViewItems.OptionsView.RowAutoHeight = true;
            this.gridViewItems.OptionsView.ShowGroupPanel = false;
            this.gridViewItems.OptionsView.ShowIndicator = false;
            this.gridViewItems.RowHeight = 42;
            // 
            // colcurrency_from
            // 
            this.colcurrency_from.AppearanceCell.Options.UseTextOptions = true;
            this.colcurrency_from.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colcurrency_from.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            resources.ApplyResources(this.colcurrency_from, "colcurrency_from");
            this.colcurrency_from.ColumnEdit = this.repositoryItemMemoEdit2;
            this.colcurrency_from.DisplayFormat.FormatString = "n2";
            this.colcurrency_from.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colcurrency_from.FieldName = "Product.Name";
            this.colcurrency_from.MinWidth = 27;
            this.colcurrency_from.Name = "colcurrency_from";
            this.colcurrency_from.OptionsColumn.AllowEdit = false;
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("repositoryItemMemoEdit2.Appearance.Font")));
            this.repositoryItemMemoEdit2.Appearance.Options.UseFont = true;
            this.repositoryItemMemoEdit2.Appearance.Options.UseTextOptions = true;
            this.repositoryItemMemoEdit2.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.repositoryItemMemoEdit2.AppearanceReadOnly.Options.UseTextOptions = true;
            this.repositoryItemMemoEdit2.AppearanceReadOnly.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.repositoryItemMemoEdit2.ExportMode = DevExpress.XtraEditors.Repository.ExportMode.DisplayText;
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // colval1
            // 
            resources.ApplyResources(this.colval1, "colval1");
            this.colval1.ColumnEdit = this.grd_Quantity;
            this.colval1.DisplayFormat.FormatString = "n2";
            this.colval1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colval1.FieldName = "Quantity";
            this.colval1.MinWidth = 27;
            this.colval1.Name = "colval1";
            // 
            // grd_Quantity
            // 
            this.grd_Quantity.AppearanceDropDown.Font = ((System.Drawing.Font)(resources.GetObject("grd_Quantity.AppearanceDropDown.Font")));
            this.grd_Quantity.AppearanceDropDown.Options.UseFont = true;
            resources.ApplyResources(this.grd_Quantity, "grd_Quantity");
            this.grd_Quantity.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("grd_Quantity.Buttons"))))});
            this.grd_Quantity.Name = "grd_Quantity";
            // 
            // colexchange_price
            // 
            resources.ApplyResources(this.colexchange_price, "colexchange_price");
            this.colexchange_price.DisplayFormat.FormatString = "n2";
            this.colexchange_price.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colexchange_price.FieldName = "Price";
            this.colexchange_price.MinWidth = 27;
            this.colexchange_price.Name = "colexchange_price";
            this.colexchange_price.OptionsColumn.AllowEdit = false;
            // 
            // coldiscount
            // 
            resources.ApplyResources(this.coldiscount, "coldiscount");
            this.coldiscount.FieldName = "Discount";
            this.coldiscount.MinWidth = 27;
            this.coldiscount.Name = "coldiscount";
            // 
            // gridColumn1
            // 
            resources.ApplyResources(this.gridColumn1, "gridColumn1");
            this.gridColumn1.ColumnEdit = this.grdSpin_Total;
            this.gridColumn1.DisplayFormat.FormatString = "n2";
            this.gridColumn1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn1.FieldName = "Net";
            this.gridColumn1.MinWidth = 27;
            this.gridColumn1.Name = "gridColumn1";
            // 
            // grdSpin_Total
            // 
            resources.ApplyResources(this.grdSpin_Total, "grdSpin_Total");
            this.grdSpin_Total.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("grdSpin_Total.Buttons"))))});
            this.grdSpin_Total.Name = "grdSpin_Total";
            // 
            // gridColumnDelete
            // 
            this.gridColumnDelete.ColumnEdit = this.repositoryItemButtonEditDeleteRow;
            this.gridColumnDelete.ImageOptions.SvgImageSize = new System.Drawing.Size(25, 25);
            this.gridColumnDelete.MinWidth = 27;
            this.gridColumnDelete.Name = "gridColumnDelete";
            resources.ApplyResources(this.gridColumnDelete, "gridColumnDelete");
            // 
            // repositoryItemButtonEditDeleteRow
            // 
            resources.ApplyResources(this.repositoryItemButtonEditDeleteRow, "repositoryItemButtonEditDeleteRow");
            editorButtonImageOptions1.SvgImageSize = new System.Drawing.Size(25, 25);
            this.repositoryItemButtonEditDeleteRow.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemButtonEditDeleteRow.Buttons"))), resources.GetString("repositoryItemButtonEditDeleteRow.Buttons1"), ((int)(resources.GetObject("repositoryItemButtonEditDeleteRow.Buttons2"))), ((bool)(resources.GetObject("repositoryItemButtonEditDeleteRow.Buttons3"))), ((bool)(resources.GetObject("repositoryItemButtonEditDeleteRow.Buttons4"))), ((bool)(resources.GetObject("repositoryItemButtonEditDeleteRow.Buttons5"))), editorButtonImageOptions1, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, resources.GetString("repositoryItemButtonEditDeleteRow.Buttons6"), ((object)(resources.GetObject("repositoryItemButtonEditDeleteRow.Buttons7"))), ((DevExpress.Utils.SuperToolTip)(resources.GetObject("repositoryItemButtonEditDeleteRow.Buttons8"))), ((DevExpress.Utils.ToolTipAnchor)(resources.GetObject("repositoryItemButtonEditDeleteRow.Buttons9"))))});
            this.repositoryItemButtonEditDeleteRow.ContextImageOptions.SvgImageSize = new System.Drawing.Size(25, 25);
            this.repositoryItemButtonEditDeleteRow.Name = "repositoryItemButtonEditDeleteRow";
            this.repositoryItemButtonEditDeleteRow.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // gridColumn6
            // 
            resources.ApplyResources(this.gridColumn6, "gridColumn6");
            this.gridColumn6.DisplayFormat.FormatString = "n2";
            this.gridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn6.FieldName = "Tax";
            this.gridColumn6.MinWidth = 27;
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            // 
            // gridColumn8
            // 
            resources.ApplyResources(this.gridColumn8, "gridColumn8");
            this.gridColumn8.ColumnEdit = this.repositoryItemSpinEdit2;
            this.gridColumn8.DisplayFormat.FormatString = "{0:n2}%";
            this.gridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn8.FieldName = "TaxPercentage";
            this.gridColumn8.MinWidth = 27;
            this.gridColumn8.Name = "gridColumn8";
            // 
            // repositoryItemSpinEdit2
            // 
            resources.ApplyResources(this.repositoryItemSpinEdit2, "repositoryItemSpinEdit2");
            this.repositoryItemSpinEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemSpinEdit2.Buttons"))))});
            this.repositoryItemSpinEdit2.MaskSettings.Set("mask", "p");
            this.repositoryItemSpinEdit2.Name = "repositoryItemSpinEdit2";
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.btn_Two;
            resources.ApplyResources(this.layoutControlItem6, "layoutControlItem6");
            this.layoutControlItem6.Location = new System.Drawing.Point(345, 116);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextVisible = false;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.btn_Three;
            resources.ApplyResources(this.layoutControlItem11, "layoutControlItem11");
            this.layoutControlItem11.Location = new System.Drawing.Point(345, 145);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.spinEditltemCount;
            resources.ApplyResources(this.layoutControlItem14, "layoutControlItem14");
            this.layoutControlItem14.Enabled = false;
            this.layoutControlItem14.Location = new System.Drawing.Point(0, 585);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(404, 28);
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // spinEditltemCount
            // 
            resources.ApplyResources(this.spinEditltemCount, "spinEditltemCount");
            this.spinEditltemCount.Name = "spinEditltemCount";
            this.spinEditltemCount.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEditltemCount.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.spinEditltemCount.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEditltemCount.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("spinEditltemCount.Properties.Buttons"))))});
            this.spinEditltemCount.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("spinEditltemCount.Properties.Mask.UseMaskAsDisplayFormat")));
            this.spinEditltemCount.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.SimpleMaskManager));
            this.spinEditltemCount.Properties.MaskSettings.Set("mask", "عدد عناصر الطلب هو 000");
            this.spinEditltemCount.Properties.MaskSettings.Set("placeholder", ' ');
            this.spinEditltemCount.StyleController = this.dataLayoutControl1;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(345, 348);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(59, 237);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.btn_Four;
            resources.ApplyResources(this.layoutControlItem5, "layoutControlItem5");
            this.layoutControlItem5.Location = new System.Drawing.Point(345, 174);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextVisible = false;
            // 
            // layoutControlGroup6
            // 
            this.layoutControlGroup6.AppearanceGroup.BorderColor = DevExpress.LookAndFeel.DXSkinColors.FillColors.Danger;
            this.layoutControlGroup6.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGroup6.AppearanceGroup.Options.UseTextOptions = true;
            this.layoutControlGroup6.AppearanceGroup.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.layoutControlGroup6, "layoutControlGroup6");
            this.layoutControlGroup6.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup7,
            this.layoutControlGroup8});
            this.layoutControlGroup6.Location = new System.Drawing.Point(0, 613);
            this.layoutControlGroup6.Name = "layoutControlGroup6";
            this.layoutControlGroup6.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup6.Size = new System.Drawing.Size(404, 123);
            // 
            // layoutControlGroup7
            // 
            resources.ApplyResources(this.layoutControlGroup7, "layoutControlGroup7");
            this.layoutControlGroup7.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem7,
            this.layoutControlItem8});
            this.layoutControlGroup7.Location = new System.Drawing.Point(191, 0);
            this.layoutControlGroup7.Name = "layoutControlGroup7";
            this.layoutControlGroup7.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup7.Size = new System.Drawing.Size(207, 86);
            this.layoutControlGroup7.TextVisible = false;
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.spinEditTotal;
            resources.ApplyResources(this.layoutControlItem7, "layoutControlItem7");
            this.layoutControlItem7.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(201, 40);
            this.layoutControlItem7.TextSize = new System.Drawing.Size(52, 17);
            // 
            // spinEditTotal
            // 
            resources.ApplyResources(this.spinEditTotal, "spinEditTotal");
            this.spinEditTotal.Name = "spinEditTotal";
            this.spinEditTotal.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("spinEditTotal.Properties.Appearance.Font")));
            this.spinEditTotal.Properties.Appearance.Options.UseFont = true;
            this.spinEditTotal.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEditTotal.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.spinEditTotal.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEditTotal.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("spinEditTotal.Properties.Buttons"))))});
            this.spinEditTotal.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("spinEditTotal.Properties.Mask.UseMaskAsDisplayFormat")));
            this.spinEditTotal.Properties.MaskSettings.Set("mask", "n2");
            this.spinEditTotal.Properties.ReadOnly = true;
            this.spinEditTotal.StyleController = this.dataLayoutControl1;
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.spinEditDiscount;
            resources.ApplyResources(this.layoutControlItem8, "layoutControlItem8");
            this.layoutControlItem8.Location = new System.Drawing.Point(0, 40);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(201, 40);
            this.layoutControlItem8.TextSize = new System.Drawing.Size(52, 17);
            // 
            // spinEditDiscount
            // 
            resources.ApplyResources(this.spinEditDiscount, "spinEditDiscount");
            this.spinEditDiscount.Name = "spinEditDiscount";
            this.spinEditDiscount.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("spinEditDiscount.Properties.Appearance.Font")));
            this.spinEditDiscount.Properties.Appearance.Options.UseFont = true;
            this.spinEditDiscount.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEditDiscount.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.spinEditDiscount.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEditDiscount.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("spinEditDiscount.Properties.Buttons"))))});
            this.spinEditDiscount.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("spinEditDiscount.Properties.Mask.UseMaskAsDisplayFormat")));
            this.spinEditDiscount.Properties.MaskSettings.Set("mask", "n2");
            this.spinEditDiscount.StyleController = this.dataLayoutControl1;
            // 
            // layoutControlGroup8
            // 
            resources.ApplyResources(this.layoutControlGroup8, "layoutControlGroup8");
            this.layoutControlGroup8.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem10,
            this.layoutControlItem9});
            this.layoutControlGroup8.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup8.Name = "layoutControlGroup8";
            this.layoutControlGroup8.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup8.Size = new System.Drawing.Size(191, 86);
            this.layoutControlGroup8.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.spinEditNet;
            resources.ApplyResources(this.layoutControlItem10, "layoutControlItem10");
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 40);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(185, 40);
            this.layoutControlItem10.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem10.TextSize = new System.Drawing.Size(42, 17);
            this.layoutControlItem10.TextToControlDistance = 5;
            // 
            // spinEditNet
            // 
            resources.ApplyResources(this.spinEditNet, "spinEditNet");
            this.spinEditNet.Name = "spinEditNet";
            this.spinEditNet.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("spinEditNet.Properties.Appearance.Font")));
            this.spinEditNet.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(56)))), ((int)(((byte)(152)))), ((int)(((byte)(83)))));
            this.spinEditNet.Properties.Appearance.Options.UseFont = true;
            this.spinEditNet.Properties.Appearance.Options.UseForeColor = true;
            this.spinEditNet.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEditNet.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.spinEditNet.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEditNet.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("spinEditNet.Properties.Buttons"))))});
            this.spinEditNet.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("spinEditNet.Properties.Mask.UseMaskAsDisplayFormat")));
            this.spinEditNet.Properties.MaskSettings.Set("mask", "n2");
            this.spinEditNet.Properties.ReadOnly = true;
            this.spinEditNet.StyleController = this.dataLayoutControl1;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.spinEditTax;
            resources.ApplyResources(this.layoutControlItem9, "layoutControlItem9");
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(185, 40);
            this.layoutControlItem9.Tag = "";
            this.layoutControlItem9.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem9.TextSize = new System.Drawing.Size(41, 17);
            this.layoutControlItem9.TextToControlDistance = 5;
            // 
            // spinEditTax
            // 
            resources.ApplyResources(this.spinEditTax, "spinEditTax");
            this.spinEditTax.Name = "spinEditTax";
            this.spinEditTax.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("spinEditTax.Properties.Appearance.Font")));
            this.spinEditTax.Properties.Appearance.Options.UseFont = true;
            this.spinEditTax.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEditTax.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.spinEditTax.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEditTax.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("spinEditTax.Properties.Buttons"))))});
            this.spinEditTax.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("spinEditTax.Properties.Mask.UseMaskAsDisplayFormat")));
            this.spinEditTax.Properties.MaskSettings.Set("mask", "n2");
            this.spinEditTax.Properties.ReadOnly = true;
            this.spinEditTax.StyleController = this.dataLayoutControl1;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btn_Five;
            resources.ApplyResources(this.layoutControlItem12, "layoutControlItem12");
            this.layoutControlItem12.Location = new System.Drawing.Point(345, 203);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.btn_Seven;
            resources.ApplyResources(this.layoutControlItem13, "layoutControlItem13");
            this.layoutControlItem13.Location = new System.Drawing.Point(345, 261);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.btn_Eight;
            resources.ApplyResources(this.layoutControlItem16, "layoutControlItem16");
            this.layoutControlItem16.Location = new System.Drawing.Point(345, 290);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem16.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem16.TextVisible = false;
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.btn_Nine;
            resources.ApplyResources(this.layoutControlItem17, "layoutControlItem17");
            this.layoutControlItem17.Location = new System.Drawing.Point(345, 319);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem17.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem17.TextVisible = false;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.btn_Six;
            resources.ApplyResources(this.layoutControlItem15, "layoutControlItem15");
            this.layoutControlItem15.Location = new System.Drawing.Point(345, 232);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextVisible = false;
            // 
            // layoutControlItem18
            // 
            this.layoutControlItem18.Control = this.btn_AddAddition;
            resources.ApplyResources(this.layoutControlItem18, "layoutControlItem18");
            this.layoutControlItem18.Location = new System.Drawing.Point(345, 0);
            this.layoutControlItem18.Name = "layoutControlItem18";
            this.layoutControlItem18.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem18.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem18.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.btn_One;
            resources.ApplyResources(this.layoutControlItem2, "layoutControlItem2");
            this.layoutControlItem2.Location = new System.Drawing.Point(345, 87);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem20
            // 
            this.layoutControlItem20.Control = this.btn_IncreaseQte;
            resources.ApplyResources(this.layoutControlItem20, "layoutControlItem20");
            this.layoutControlItem20.Location = new System.Drawing.Point(345, 29);
            this.layoutControlItem20.Name = "layoutControlItem20";
            this.layoutControlItem20.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem20.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem20.TextVisible = false;
            // 
            // layoutControlItem21
            // 
            this.layoutControlItem21.Control = this.btn_DecreaseQte;
            resources.ApplyResources(this.layoutControlItem21, "layoutControlItem21");
            this.layoutControlItem21.Location = new System.Drawing.Point(345, 58);
            this.layoutControlItem21.Name = "layoutControlItem21";
            this.layoutControlItem21.Size = new System.Drawing.Size(59, 29);
            this.layoutControlItem21.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem21.TextVisible = false;
            // 
            // layoutControlItem19
            // 
            this.layoutControlItem19.Control = this.txt_Brcode;
            resources.ApplyResources(this.layoutControlItem19, "layoutControlItem19");
            this.layoutControlItem19.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem19.Name = "layoutControlItem19";
            this.layoutControlItem19.Size = new System.Drawing.Size(410, 26);
            this.layoutControlItem19.TextSize = new System.Drawing.Size(52, 17);
            // 
            // layoutControlInvoiceType
            // 
            this.layoutControlInvoiceType.Control = this.gridControl1;
            resources.ApplyResources(this.layoutControlInvoiceType, "layoutControlInvoiceType");
            this.layoutControlInvoiceType.Location = new System.Drawing.Point(416, 746);
            this.layoutControlInvoiceType.MaxSize = new System.Drawing.Size(0, 69);
            this.layoutControlInvoiceType.MinSize = new System.Drawing.Size(32, 33);
            this.layoutControlInvoiceType.Name = "layoutControlInvoiceType";
            this.layoutControlInvoiceType.OptionsTableLayoutItem.ColumnIndex = 1;
            this.layoutControlInvoiceType.OptionsTableLayoutItem.ColumnSpan = 2;
            this.layoutControlInvoiceType.OptionsTableLayoutItem.RowIndex = 1;
            this.layoutControlInvoiceType.Size = new System.Drawing.Size(1003, 59);
            this.layoutControlInvoiceType.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlInvoiceType.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlInvoiceType.TextVisible = false;
            // 
            // gridControl1
            // 
            this.gridControl1.EmbeddedNavigator.Margin = ((System.Windows.Forms.Padding)(resources.GetObject("gridControl1.EmbeddedNavigator.Margin")));
            resources.ApplyResources(this.gridControl1, "gridControl1");
            this.gridControl1.MainView = this.tileViewInvType;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.tileViewInvType});
            // 
            // tileViewInvType
            // 
            this.tileViewInvType.Appearance.ItemNormal.BackColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Question;
            this.tileViewInvType.Appearance.ItemNormal.BackColor2 = ((System.Drawing.Color)(resources.GetObject("tileViewInvType.Appearance.ItemNormal.BackColor2")));
            this.tileViewInvType.Appearance.ItemNormal.BorderColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.ControlText;
            this.tileViewInvType.Appearance.ItemNormal.Font = ((System.Drawing.Font)(resources.GetObject("tileViewInvType.Appearance.ItemNormal.Font")));
            this.tileViewInvType.Appearance.ItemNormal.ForeColor = System.Drawing.Color.White;
            this.tileViewInvType.Appearance.ItemNormal.Options.UseBackColor = true;
            this.tileViewInvType.Appearance.ItemNormal.Options.UseBorderColor = true;
            this.tileViewInvType.Appearance.ItemNormal.Options.UseFont = true;
            this.tileViewInvType.Appearance.ItemNormal.Options.UseForeColor = true;
            this.tileViewInvType.Appearance.ItemNormal.Options.UseTextOptions = true;
            this.tileViewInvType.Appearance.ItemNormal.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tileViewInvType.Appearance.ItemNormal.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tileViewInvType.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.coltype,
            this.colname});
            this.tileViewInvType.ContextButtonOptions.BottomPanelPadding = new System.Windows.Forms.Padding(0);
            this.tileViewInvType.ContextButtonOptions.CenterPanelPadding = new System.Windows.Forms.Padding(0);
            this.tileViewInvType.ContextButtonOptions.FarPanelPadding = new System.Windows.Forms.Padding(0);
            this.tileViewInvType.ContextButtonOptions.NearPanelPadding = new System.Windows.Forms.Padding(0);
            this.tileViewInvType.ContextButtonOptions.TopPanelPadding = new System.Windows.Forms.Padding(0);
            this.tileViewInvType.DetailHeight = 485;
            this.tileViewInvType.GridControl = this.gridControl1;
            this.tileViewInvType.Name = "tileViewInvType";
            this.tileViewInvType.OptionsTiles.GroupTextPadding = new System.Windows.Forms.Padding(0);
            this.tileViewInvType.OptionsTiles.ItemPadding = new System.Windows.Forms.Padding(0);
            this.tileViewInvType.OptionsTiles.ItemSize = new System.Drawing.Size(130, 30);
            this.tileViewInvType.OptionsTiles.Padding = new System.Windows.Forms.Padding(0);
            this.tileViewInvType.OptionsTiles.ScrollMode = DevExpress.XtraEditors.TileControlScrollMode.ScrollButtons;
            this.tileViewInvType.TileColumns.Add(tableColumnDefinition2);
            this.tileViewInvType.TileColumns.Add(tableColumnDefinition3);
            this.tileViewInvType.TileColumns.Add(tableColumnDefinition4);
            this.tileViewInvType.TileRows.Add(tableRowDefinition2);
            this.tileViewInvType.TileRows.Add(tableRowDefinition3);
            tableSpan1.ColumnSpan = 3;
            tableSpan1.RowSpan = 2;
            this.tileViewInvType.TileSpans.Add(tableSpan1);
            tileViewItemElement2.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font")));
            tileViewItemElement2.Appearance.Normal.FontStyleDelta = ((System.Drawing.FontStyle)(resources.GetObject("resource.FontStyleDelta")));
            tileViewItemElement2.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement2.Column = this.colname;
            tileViewItemElement2.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement2.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            resources.ApplyResources(tileViewItemElement2, "tileViewItemElement2");
            tileViewItemElement2.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            this.tileViewInvType.TileTemplate.Add(tileViewItemElement2);
            // 
            // coltype
            // 
            this.coltype.FieldName = "type";
            this.coltype.MinWidth = 27;
            this.coltype.Name = "coltype";
            resources.ApplyResources(this.coltype, "coltype");
            // 
            // colname
            // 
            this.colname.FieldName = "name";
            this.colname.MinWidth = 27;
            this.colname.Name = "colname";
            resources.ApplyResources(this.colname, "colname");
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AppearanceGroup.BorderColor = DevExpress.LookAndFeel.DXSkinColors.FillColors.Question;
            this.layoutControlGroup3.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGroup3.AppearanceGroup.Options.UseTextOptions = true;
            this.layoutControlGroup3.AppearanceGroup.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.layoutControlGroup3, "layoutControlGroup3");
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlGroup5});
            this.layoutControlGroup3.Location = new System.Drawing.Point(416, 0);
            this.layoutControlGroup3.Name = "layoutControlGroup3";
            this.layoutControlGroup3.OptionsTableLayoutItem.ColumnIndex = 2;
            this.layoutControlGroup3.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup3.Size = new System.Drawing.Size(1003, 746);
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.gridControl2;
            resources.ApplyResources(this.layoutControlItem1, "layoutControlItem1");
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(997, 158);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlGroup5
            // 
            this.layoutControlGroup5.AppearanceGroup.BorderColor = DevExpress.LookAndFeel.DXSkinColors.FillColors.Primary;
            this.layoutControlGroup5.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGroup5.AppearanceGroup.Options.UseTextOptions = true;
            this.layoutControlGroup5.AppearanceGroup.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.layoutControlGroup5, "layoutControlGroup5");
            this.layoutControlGroup5.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem4});
            this.layoutControlGroup5.Location = new System.Drawing.Point(0, 158);
            this.layoutControlGroup5.Name = "layoutControlGroup5";
            this.layoutControlGroup5.OptionsTableLayoutItem.ColumnIndex = 1;
            this.layoutControlGroup5.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup5.Size = new System.Drawing.Size(997, 551);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.gridControlProudct;
            resources.ApplyResources(this.layoutControlItem4, "layoutControlItem4");
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(991, 514);
            this.layoutControlItem4.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem4.TextVisible = false;
            // 
            // gridControlProudct
            // 
            this.gridControlProudct.EmbeddedNavigator.Appearance.BackColor = System.Drawing.Color.SkyBlue;
            this.gridControlProudct.EmbeddedNavigator.Appearance.Options.UseBackColor = true;
            this.gridControlProudct.EmbeddedNavigator.Margin = ((System.Windows.Forms.Padding)(resources.GetObject("gridControlProudct.EmbeddedNavigator.Margin")));
            resources.ApplyResources(this.gridControlProudct, "gridControlProudct");
            this.gridControlProudct.MainView = this.tileViewProducts;
            this.gridControlProudct.Name = "gridControlProudct";
            this.gridControlProudct.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemSpinEdit1,
            this.repositoryItemPictureEdit1});
            this.gridControlProudct.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.tileViewProducts});
            // 
            // tileViewProducts
            // 
            this.tileViewProducts.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colIcon,
            this.tileViewColumn2,
            this.tileViewColumn3,
            this.tileViewColumn4});
            this.tileViewProducts.DetailHeight = 485;
            this.tileViewProducts.GridControl = this.gridControlProudct;
            this.tileViewProducts.Name = "tileViewProducts";
            this.tileViewProducts.OptionsDragDrop.AllowDrag = true;
            this.tileViewProducts.OptionsTiles.GroupTextPadding = new System.Windows.Forms.Padding(0, -1, -1, -1);
            this.tileViewProducts.OptionsTiles.IndentBetweenGroups = 0;
            this.tileViewProducts.OptionsTiles.IndentBetweenItems = 0;
            this.tileViewProducts.OptionsTiles.ItemPadding = new System.Windows.Forms.Padding(0);
            this.tileViewProducts.OptionsTiles.ItemSize = new System.Drawing.Size(95, 54);
            this.tileViewProducts.OptionsTiles.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.tileViewProducts.OptionsTiles.Padding = new System.Windows.Forms.Padding(0);
            this.tileViewProducts.OptionsTiles.RowCount = 0;
            tableColumnDefinition5.Length.Value = 46D;
            tableColumnDefinition6.Length.Value = 75D;
            itemTemplate1.Columns.Add(tableColumnDefinition5);
            itemTemplate1.Columns.Add(tableColumnDefinition6);
            tileViewItemElement3.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font1")));
            tileViewItemElement3.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement3.Appearance.Normal.Options.UseTextOptions = true;
            tileViewItemElement3.Appearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            tileViewItemElement3.Column = this.tileViewColumn2;
            tileViewItemElement3.ColumnIndex = 1;
            tileViewItemElement3.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement3.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement3.RowIndex = 1;
            resources.ApplyResources(tileViewItemElement3, "tileViewItemElement3");
            tileViewItemElement3.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement4.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font2")));
            tileViewItemElement4.Appearance.Normal.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Critical;
            tileViewItemElement4.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement4.Appearance.Normal.Options.UseForeColor = true;
            tileViewItemElement4.Column = this.tileViewColumn3;
            tileViewItemElement4.ColumnIndex = 1;
            tileViewItemElement4.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement4.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement4.RowIndex = 2;
            resources.ApplyResources(tileViewItemElement4, "tileViewItemElement4");
            tileViewItemElement4.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement5.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font3")));
            tileViewItemElement5.Appearance.Normal.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Information;
            tileViewItemElement5.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement5.Appearance.Normal.Options.UseForeColor = true;
            tileViewItemElement5.Column = this.tileViewColumn4;
            tileViewItemElement5.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement5.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement5.RowIndex = 2;
            resources.ApplyResources(tileViewItemElement5, "tileViewItemElement5");
            tileViewItemElement5.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement6.Column = this.colIcon;
            tileViewItemElement6.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement6.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.Stretch;
            resources.ApplyResources(tileViewItemElement6, "tileViewItemElement6");
            tileViewItemElement6.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            itemTemplate1.Elements.Add(tileViewItemElement3);
            itemTemplate1.Elements.Add(tileViewItemElement4);
            itemTemplate1.Elements.Add(tileViewItemElement5);
            itemTemplate1.Elements.Add(tileViewItemElement6);
            itemTemplate1.Name = "ImageTemplate";
            tableRowDefinition4.Length.Value = 19D;
            tableRowDefinition5.Length.Value = 16D;
            tableRowDefinition6.Length.Value = 9D;
            itemTemplate1.Rows.Add(tableRowDefinition4);
            itemTemplate1.Rows.Add(tableRowDefinition5);
            itemTemplate1.Rows.Add(tableRowDefinition6);
            tableSpan2.ColumnSpan = 2;
            tableSpan2.RowIndex = 1;
            tableSpan3.ColumnSpan = 2;
            itemTemplate1.Spans.Add(tableSpan2);
            itemTemplate1.Spans.Add(tableSpan3);
            tableColumnDefinition7.Length.Value = 46D;
            tableColumnDefinition8.Length.Value = 75D;
            itemTemplate2.Columns.Add(tableColumnDefinition7);
            itemTemplate2.Columns.Add(tableColumnDefinition8);
            tileViewItemElement7.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font4")));
            tileViewItemElement7.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement7.Appearance.Normal.Options.UseTextOptions = true;
            tileViewItemElement7.Appearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            tileViewItemElement7.Column = this.tileViewColumn2;
            tileViewItemElement7.ColumnIndex = 1;
            tileViewItemElement7.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement7.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement7.RowIndex = 1;
            resources.ApplyResources(tileViewItemElement7, "tileViewItemElement7");
            tileViewItemElement7.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement8.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font5")));
            tileViewItemElement8.Appearance.Normal.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Critical;
            tileViewItemElement8.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement8.Appearance.Normal.Options.UseForeColor = true;
            tileViewItemElement8.Column = this.tileViewColumn3;
            tileViewItemElement8.ColumnIndex = 1;
            tileViewItemElement8.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement8.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement8.RowIndex = 2;
            resources.ApplyResources(tileViewItemElement8, "tileViewItemElement8");
            tileViewItemElement8.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement9.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font6")));
            tileViewItemElement9.Appearance.Normal.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Information;
            tileViewItemElement9.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement9.Appearance.Normal.Options.UseForeColor = true;
            tileViewItemElement9.Column = this.tileViewColumn4;
            tileViewItemElement9.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement9.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement9.RowIndex = 2;
            resources.ApplyResources(tileViewItemElement9, "tileViewItemElement9");
            tileViewItemElement9.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            itemTemplate2.Elements.Add(tileViewItemElement7);
            itemTemplate2.Elements.Add(tileViewItemElement8);
            itemTemplate2.Elements.Add(tileViewItemElement9);
            itemTemplate2.Name = "NonImageTemplate";
            tableRowDefinition7.Length.Value = 2D;
            tableRowDefinition8.Length.Value = 41D;
            tableRowDefinition9.Length.Value = 11D;
            itemTemplate2.Rows.Add(tableRowDefinition7);
            itemTemplate2.Rows.Add(tableRowDefinition8);
            itemTemplate2.Rows.Add(tableRowDefinition9);
            tableSpan4.ColumnSpan = 2;
            tableSpan4.RowIndex = 1;
            tableSpan5.ColumnSpan = 2;
            itemTemplate2.Spans.Add(tableSpan4);
            itemTemplate2.Spans.Add(tableSpan5);
            this.tileViewProducts.Templates.Add(itemTemplate1);
            this.tileViewProducts.Templates.Add(itemTemplate2);
            tableColumnDefinition9.Length.Value = 46D;
            tableColumnDefinition10.Length.Value = 75D;
            this.tileViewProducts.TileColumns.Add(tableColumnDefinition9);
            this.tileViewProducts.TileColumns.Add(tableColumnDefinition10);
            tableRowDefinition10.Length.Value = 19D;
            tableRowDefinition11.Length.Value = 16D;
            tableRowDefinition12.Length.Value = 9D;
            this.tileViewProducts.TileRows.Add(tableRowDefinition10);
            this.tileViewProducts.TileRows.Add(tableRowDefinition11);
            this.tileViewProducts.TileRows.Add(tableRowDefinition12);
            tableSpan6.ColumnSpan = 2;
            tableSpan6.RowIndex = 1;
            tableSpan7.ColumnSpan = 2;
            this.tileViewProducts.TileSpans.Add(tableSpan6);
            this.tileViewProducts.TileSpans.Add(tableSpan7);
            tileViewItemElement10.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font7")));
            tileViewItemElement10.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement10.Appearance.Normal.Options.UseTextOptions = true;
            tileViewItemElement10.Appearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            tileViewItemElement10.Column = this.tileViewColumn2;
            tileViewItemElement10.ColumnIndex = 1;
            tileViewItemElement10.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement10.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement10.RowIndex = 1;
            resources.ApplyResources(tileViewItemElement10, "tileViewItemElement10");
            tileViewItemElement10.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement11.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font8")));
            tileViewItemElement11.Appearance.Normal.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Critical;
            tileViewItemElement11.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement11.Appearance.Normal.Options.UseForeColor = true;
            tileViewItemElement11.Column = this.tileViewColumn3;
            tileViewItemElement11.ColumnIndex = 1;
            tileViewItemElement11.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement11.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement11.RowIndex = 2;
            resources.ApplyResources(tileViewItemElement11, "tileViewItemElement11");
            tileViewItemElement11.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement12.Appearance.Normal.Font = ((System.Drawing.Font)(resources.GetObject("resource.Font9")));
            tileViewItemElement12.Appearance.Normal.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Information;
            tileViewItemElement12.Appearance.Normal.Options.UseFont = true;
            tileViewItemElement12.Appearance.Normal.Options.UseForeColor = true;
            tileViewItemElement12.Column = this.tileViewColumn4;
            tileViewItemElement12.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement12.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.ZoomInside;
            tileViewItemElement12.RowIndex = 2;
            resources.ApplyResources(tileViewItemElement12, "tileViewItemElement12");
            tileViewItemElement12.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement13.Column = this.colIcon;
            tileViewItemElement13.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement13.ImageOptions.ImageScaleMode = DevExpress.XtraEditors.TileItemImageScaleMode.Stretch;
            resources.ApplyResources(tileViewItemElement13, "tileViewItemElement13");
            tileViewItemElement13.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            this.tileViewProducts.TileTemplate.Add(tileViewItemElement10);
            this.tileViewProducts.TileTemplate.Add(tileViewItemElement11);
            this.tileViewProducts.TileTemplate.Add(tileViewItemElement12);
            this.tileViewProducts.TileTemplate.Add(tileViewItemElement13);
            // 
            // colIcon
            // 
            resources.ApplyResources(this.colIcon, "colIcon");
            this.colIcon.ColumnEdit = this.repositoryItemPictureEdit1;
            this.colIcon.FieldName = "Image";
            this.colIcon.MinWidth = 27;
            this.colIcon.Name = "colIcon";
            // 
            // repositoryItemPictureEdit1
            // 
            this.repositoryItemPictureEdit1.Name = "repositoryItemPictureEdit1";
            // 
            // tileViewColumn2
            // 
            resources.ApplyResources(this.tileViewColumn2, "tileViewColumn2");
            this.tileViewColumn2.FieldName = "Name";
            this.tileViewColumn2.MinWidth = 27;
            this.tileViewColumn2.Name = "tileViewColumn2";
            this.tileViewColumn2.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.True;
            // 
            // tileViewColumn3
            // 
            resources.ApplyResources(this.tileViewColumn3, "tileViewColumn3");
            this.tileViewColumn3.DisplayFormat.FormatString = "{0:#.00}";
            this.tileViewColumn3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.tileViewColumn3.FieldName = "Price";
            this.tileViewColumn3.MinWidth = 27;
            this.tileViewColumn3.Name = "tileViewColumn3";
            // 
            // tileViewColumn4
            // 
            resources.ApplyResources(this.tileViewColumn4, "tileViewColumn4");
            this.tileViewColumn4.ColumnEdit = this.repositoryItemSpinEdit1;
            this.tileViewColumn4.FieldName = "SellDiscount";
            this.tileViewColumn4.MinWidth = 27;
            this.tileViewColumn4.Name = "tileViewColumn4";
            // 
            // repositoryItemSpinEdit1
            // 
            resources.ApplyResources(this.repositoryItemSpinEdit1, "repositoryItemSpinEdit1");
            this.repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemSpinEdit1.Buttons"))))});
            this.repositoryItemSpinEdit1.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemSpinEdit1.Mask.UseMaskAsDisplayFormat")));
            this.repositoryItemSpinEdit1.MaskSettings.Set("mask", "P0");
            this.repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // colName1
            // 
            this.colName1.FieldName = "Name";
            this.colName1.MinWidth = 27;
            this.colName1.Name = "colName1";
            resources.ApplyResources(this.colName1, "colName1");
            // 
            // tileViewCategoris
            // 
            this.tileViewCategoris.Appearance.EmptySpace.Options.UseBackColor = true;
            this.tileViewCategoris.Appearance.EmptySpace.Options.UseBorderColor = true;
            this.tileViewCategoris.Appearance.ItemNormal.Options.UseImage = true;
            this.tileViewCategoris.Appearance.ItemNormal.Options.UseTextOptions = true;
            this.tileViewCategoris.Appearance.ItemNormal.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.tileViewCategoris.Appearance.ItemNormal.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.tileViewCategoris.Appearance.ItemNormal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.tileViewCategoris.Appearance.ItemSelected.BackColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Information;
            this.tileViewCategoris.Appearance.ItemSelected.BackColor2 = ((System.Drawing.Color)(resources.GetObject("tileViewCategoris.Appearance.ItemSelected.BackColor2")));
            this.tileViewCategoris.Appearance.ItemSelected.BorderColor = System.Drawing.Color.Indigo;
            this.tileViewCategoris.Appearance.ItemSelected.Options.UseBackColor = true;
            this.tileViewCategoris.Appearance.ItemSelected.Options.UseBorderColor = true;
            this.tileViewCategoris.Appearance.ItemSelected.Options.UseImage = true;
            this.tileViewCategoris.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colColor,
            this.colName1});
            this.tileViewCategoris.ColumnSet.BackgroundImageColumn = this.colColor;
            this.tileViewCategoris.DetailHeight = 485;
            this.tileViewCategoris.GridControl = this.gridControl2;
            this.tileViewCategoris.Name = "tileViewCategoris";
            this.tileViewCategoris.OptionsBehavior.AllowSmoothScrolling = true;
            this.tileViewCategoris.OptionsTiles.IndentBetweenGroups = 11;
            this.tileViewCategoris.OptionsTiles.IndentBetweenItems = 1;
            this.tileViewCategoris.OptionsTiles.ItemPadding = new System.Windows.Forms.Padding(0);
            this.tileViewCategoris.OptionsTiles.ItemSize = new System.Drawing.Size(45, 35);
            this.tileViewCategoris.OptionsTiles.Padding = new System.Windows.Forms.Padding(2);
            this.tileViewCategoris.OptionsTiles.RowCount = 0;
            this.tileViewCategoris.OptionsTiles.ScrollMode = DevExpress.XtraEditors.TileControlScrollMode.ScrollButtons;
            this.tileViewCategoris.OptionsTiles.VerticalContentAlignment = DevExpress.Utils.VertAlignment.Top;
            this.tileViewCategoris.OptionsView.BackgroundColorMode = DevExpress.XtraGrid.Views.Tile.BackgroundColorMode.ItemBackground;
            this.tileViewCategoris.TileColumns.Add(tableColumnDefinition1);
            tableRowDefinition1.Length.Value = 15D;
            this.tileViewCategoris.TileRows.Add(tableRowDefinition1);
            tileViewItemElement1.Appearance.Normal.Options.UseTextOptions = true;
            tileViewItemElement1.Appearance.Normal.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            tileViewItemElement1.Column = this.colName1;
            tileViewItemElement1.ImageOptions.ImageAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            tileViewItemElement1.ImageOptions.ImageSize = new System.Drawing.Size(50, 35);
            resources.ApplyResources(tileViewItemElement1, "tileViewItemElement1");
            tileViewItemElement1.TextAlignment = DevExpress.XtraEditors.TileItemContentAlignment.MiddleCenter;
            this.tileViewCategoris.TileTemplate.Add(tileViewItemElement1);
            // 
            // colColor
            // 
            this.colColor.AppearanceCell.Options.UseBackColor = true;
            resources.ApplyResources(this.colColor, "colColor");
            this.colColor.FieldName = "RgbColor";
            this.colColor.MinWidth = 27;
            this.colColor.Name = "colColor";
            // 
            // groupStrBindingSource
            // 
            this.groupStrBindingSource.DataSource = typeof(PosFinalCost.GroupStr);
            // 
            // UC_AddSaleInvoicePos
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataLayoutControl1);
            this.Name = "UC_AddSaleInvoicePos";
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).EndInit();
            this.dataLayoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txt_Brcode.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_Addition_View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_DeleteAddition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd_Quantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSpin_Total)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEditDeleteRow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditltemCount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditTotal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditDiscount.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditNet.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditTax.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlInvoiceType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tileViewInvType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlProudct)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tileViewProducts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tileViewCategoris)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupStrBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl1;
        private DevExpress.XtraEditors.SimpleButton btn_DecreaseQte;
        private DevExpress.XtraEditors.SimpleButton btn_IncreaseQte;
        private DevExpress.XtraEditors.TextEdit txt_Brcode;
        private DevExpress.XtraEditors.SimpleButton btn_AddAddition;
        private DevExpress.XtraEditors.SimpleButton btn_Nine;
        private DevExpress.XtraEditors.SimpleButton btn_Eight;
        private DevExpress.XtraEditors.SimpleButton btn_Six;
        private DevExpress.XtraEditors.SimpleButton btn_Seven;
        private DevExpress.XtraEditors.SimpleButton btn_Five;
        private DevExpress.XtraEditors.SimpleButton btn_Three;
        private DevExpress.XtraEditors.SimpleButton btn_Two;
        private DevExpress.XtraEditors.SimpleButton btn_Four;
        private DevExpress.XtraEditors.SimpleButton btn_One;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private System.Windows.Forms.BindingSource groupStrBindingSource;
        private DevExpress.XtraGrid.Views.Tile.TileView tileViewCategoris;
        private DevExpress.XtraGrid.Columns.TileViewColumn colColor;
        private DevExpress.XtraGrid.Columns.TileViewColumn colName1;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Tile.TileView tileViewInvType;
        private DevExpress.XtraGrid.Columns.TileViewColumn coltype;
        private DevExpress.XtraGrid.Columns.TileViewColumn colname;
        private DevExpress.XtraEditors.SpinEdit spinEditltemCount;
        private DevExpress.XtraEditors.SpinEdit spinEditNet;
        private DevExpress.XtraEditors.SpinEdit spinEditTax;
        private DevExpress.XtraEditors.SpinEdit spinEditDiscount;
        private DevExpress.XtraEditors.SpinEdit spinEditTotal;
        private DevExpress.XtraGrid.GridControl gridControlItems;
        private DevExpress.XtraGrid.Views.Grid.GridView grd_Addition_View;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btn_DeleteAddition;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewItems;
        private DevExpress.XtraGrid.Columns.GridColumn colcurrency_from;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn colval1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit grd_Quantity;
        private DevExpress.XtraGrid.Columns.GridColumn colexchange_price;
        private DevExpress.XtraGrid.Columns.GridColumn coldiscount;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit grdSpin_Total;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumnDelete;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEditDeleteRow;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit2;
        private DevExpress.XtraGrid.GridControl gridControlProudct;
        private DevExpress.XtraGrid.Views.Tile.TileView tileViewProducts;
        private DevExpress.XtraGrid.Columns.TileViewColumn colIcon;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit1;
        private DevExpress.XtraGrid.Columns.TileViewColumn tileViewColumn2;
        private DevExpress.XtraGrid.Columns.TileViewColumn tileViewColumn3;
        private DevExpress.XtraGrid.Columns.TileViewColumn tileViewColumn4;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup9;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup6;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem18;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem20;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem21;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem19;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlInvoiceType;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
    }
}
