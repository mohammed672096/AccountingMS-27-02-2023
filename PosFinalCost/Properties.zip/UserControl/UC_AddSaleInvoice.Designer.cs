﻿namespace PosFinalCost.Forms
{
    partial class UC_AddSaleInvoice
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_AddSaleInvoice));
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule1 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule2 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule3 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions2 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject5 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject6 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject7 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject8 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions3 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject9 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject10 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject11 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject12 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions1 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new DevExpress.Utils.SerializableAppearanceObject();
            this.dataLayConMain = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.labelECR = new System.Windows.Forms.Label();
            this.gridControl = new DevExpress.XtraGrid.GridControl();
            this.SupplySubBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colsupPrdNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSearchLookUpEditPrdNo = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.ProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.repositoryItemSearchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colprdId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdSalePrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupMusrName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdGrpNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupPrdName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEditProName = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.colMsur = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEditMeasurment = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.PrdMeasurmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.colCurrency = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupPrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colQuanMain = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEditQuan = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.colsupSalePrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCalcEdit1SalePrice = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.colsupTaxPercent = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTaxPrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupDesc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEditDesc = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colTotalPrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPrdManufacture = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupDscntPercent = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDscntAmount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupPrdBarcode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdQuanAvlb = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colFinalAmount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWidth = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colHeight = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMeter = new DevExpress.XtraGrid.Columns.GridColumn();
            this.col_SubNoPacks = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupOvertime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupWorkingtime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bindingNavigator11 = new System.Windows.Forms.BindingNavigator(this.components);
            this.btnSave = new System.Windows.Forms.ToolStripButton();
            this.btnSaveAndNew = new System.Windows.Forms.ToolStripButton();
            this.btnClose = new System.Windows.Forms.ToolStripButton();
            this.btnReset = new System.Windows.Forms.ToolStripButton();
            this.btnPrintPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnPdfPrevious = new System.Windows.Forms.ToolStripButton();
            this.btnXslPrevious = new System.Windows.Forms.ToolStripButton();
            this.bbiSelect = new System.Windows.Forms.ToolStripButton();
            this.btnPrdPrice = new System.Windows.Forms.ToolStripButton();
            this.btnEditPrice = new System.Windows.Forms.ToolStripButton();
            this.btnEditQuantity = new System.Windows.Forms.ToolStripButton();
            this.btnSaveAndNewNoPrint = new System.Windows.Forms.ToolStripButton();
            this.btnPaidCreditShortcut = new System.Windows.Forms.ToolStripButton();
            this.supNoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.SupplyMainBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.radioGroupIsCash = new DevExpress.XtraEditors.RadioGroup();
            this.checkEdit1 = new DevExpress.XtraEditors.CheckEdit();
            this.textEditCounterNumber = new DevExpress.XtraEditors.TextEdit();
            this.textEditPlateNumber = new DevExpress.XtraEditors.TextEdit();
            this.textEditCarType = new DevExpress.XtraEditors.TextEdit();
            this.supDescTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.DateDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.BoxNoLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.CurrencyChngTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.checkEditTax = new DevExpress.XtraEditors.CheckEdit();
            this.supCurrTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.CustNoSearchLookUpEdit = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.searchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colcustNo1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustName1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustPhnNo1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustCurrency1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.notDateTextEdit = new DevExpress.XtraEditors.DateEdit();
            this.PoNumberTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.StrIdLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.textEditBarcodeNo = new DevExpress.XtraEditors.TextEdit();
            this.btnDeleteRow = new DevExpress.XtraEditors.SimpleButton();
            this.supDscntPercentTextEdit = new DevExpress.XtraEditors.SpinEdit();
            this.BtnDscnFraction = new DevExpress.XtraEditors.SimpleButton();
            this.BtnAddFraction = new DevExpress.XtraEditors.SimpleButton();
            this.spinEditTotalFinalDecimal = new DevExpress.XtraEditors.SpinEdit();
            this.BankLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.saleNoTextEdit = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.SupplyMainBindingSourceEditor = new System.Windows.Forms.BindingSource(this.components);
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colStatus = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDesc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTotal = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNet = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colTotalAfterDiscount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIsCash = new DevExpress.XtraGrid.Columns.GridColumn();
            this.labelTotalPriceDecimal = new DevExpress.XtraEditors.SpinEdit();
            this.labelTotalDecimal = new DevExpress.XtraEditors.SpinEdit();
            this.labelTotalTaxDecimal = new DevExpress.XtraEditors.SpinEdit();
            this.labelTotalTaxDecimal1 = new DevExpress.XtraEditors.SpinEdit();
            this.labelTotalTaxDecimal2 = new DevExpress.XtraEditors.SpinEdit();
            this.NotesTextEdit = new DevExpress.XtraEditors.MemoEdit();
            this.spinEditMonyFinal = new DevExpress.XtraEditors.CalcEdit();
            this.DscntAmountTextEdit = new DevExpress.XtraEditors.CalcEdit();
            this.textEditPaidCreditCard = new DevExpress.XtraEditors.ButtonEdit();
            this.textEditPaidCash = new DevExpress.XtraEditors.CalcEdit();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGrooupMain = new DevExpress.XtraLayout.LayoutControlGroup();
            this.ItemForSalesNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlCarData = new DevExpress.XtraLayout.LayoutControlGroup();
            this.ItemForCounter = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForCarType = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForPlateNumber = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForStore = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForDate = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForIsCash = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForNotes = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForTax = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForRoundTotal = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForBoxNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupCur = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForCurrencyChng = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupDesc = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForPoNumber = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupCustNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemFornotDate = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup10 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.simpleLabelItem1 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.ItemForBarcodeText = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForBtnDeleteRow = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelItemsCount = new DevExpress.XtraLayout.SimpleLabelItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup8 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup4 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.labelTotalPriceString = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelTotalString = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelDiscountString = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelTotalTaxString = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelTotalFinalString = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelTotalTaxString2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelTotalTaxString1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.itemForPaidCreditCard = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForBankId = new DevExpress.XtraLayout.LayoutControlItem();
            this.itemForPaidCash = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup5 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.itemForsupDscntPercent = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.dxValidationProvider1 = new DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider(this.components);
            this.colBtnBarcode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemBtnBarcode = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayConMain)).BeginInit();
            this.dataLayConMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SupplySubBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEditPrdNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditProName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditMeasurment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrdMeasurmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEditQuan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1SalePrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEditDesc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator11)).BeginInit();
            this.bindingNavigator11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.supNoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SupplyMainBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroupIsCash.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditCounterNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPlateNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditCarType.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDescTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxNoLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CurrencyChngTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEditTax.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCurrTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustNoSearchLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notDateTextEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notDateTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PoNumberTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StrIdLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditBarcodeNo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDscntPercentTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditTotalFinalDecimal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BankLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleNoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SupplyMainBindingSourceEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalPriceDecimal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalDecimal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxDecimal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxDecimal1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxDecimal2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotesTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditMonyFinal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DscntAmountTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPaidCreditCard.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPaidCash.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGrooupMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForSalesNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlCarData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForCounter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForCarType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPlateNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForStore)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForIsCash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForNotes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForTax)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForRoundTotal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBoxNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCur)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForCurrencyChng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupDesc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPoNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCustNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemFornotDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBarcodeText)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBtnDeleteRow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelItemsCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalPriceString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelDiscountString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalFinalString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxString2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxString1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForPaidCreditCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBankId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForPaidCash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForsupDscntPercent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemBtnBarcode)).BeginInit();
            this.SuspendLayout();
            // 
            // dataLayConMain
            // 
            this.dataLayConMain.AllowCustomization = false;
            this.dataLayConMain.Appearance.ControlDisabled.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.DisabledText;
            this.dataLayConMain.Appearance.ControlDisabled.Options.UseForeColor = true;
            this.dataLayConMain.Appearance.DisabledLayoutItem.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.DisabledText;
            this.dataLayConMain.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.dataLayConMain.Controls.Add(this.labelECR);
            this.dataLayConMain.Controls.Add(this.gridControl);
            this.dataLayConMain.Controls.Add(this.bindingNavigator11);
            this.dataLayConMain.Controls.Add(this.supNoTextEdit);
            this.dataLayConMain.Controls.Add(this.radioGroupIsCash);
            this.dataLayConMain.Controls.Add(this.checkEdit1);
            this.dataLayConMain.Controls.Add(this.textEditCounterNumber);
            this.dataLayConMain.Controls.Add(this.textEditPlateNumber);
            this.dataLayConMain.Controls.Add(this.textEditCarType);
            this.dataLayConMain.Controls.Add(this.supDescTextEdit);
            this.dataLayConMain.Controls.Add(this.DateDateEdit);
            this.dataLayConMain.Controls.Add(this.BoxNoLookUpEdit);
            this.dataLayConMain.Controls.Add(this.CurrencyChngTextEdit);
            this.dataLayConMain.Controls.Add(this.checkEditTax);
            this.dataLayConMain.Controls.Add(this.supCurrTextEdit);
            this.dataLayConMain.Controls.Add(this.CustNoSearchLookUpEdit);
            this.dataLayConMain.Controls.Add(this.notDateTextEdit);
            this.dataLayConMain.Controls.Add(this.PoNumberTextEdit);
            this.dataLayConMain.Controls.Add(this.StrIdLookUpEdit);
            this.dataLayConMain.Controls.Add(this.textEditBarcodeNo);
            this.dataLayConMain.Controls.Add(this.btnDeleteRow);
            this.dataLayConMain.Controls.Add(this.supDscntPercentTextEdit);
            this.dataLayConMain.Controls.Add(this.BtnDscnFraction);
            this.dataLayConMain.Controls.Add(this.BtnAddFraction);
            this.dataLayConMain.Controls.Add(this.spinEditTotalFinalDecimal);
            this.dataLayConMain.Controls.Add(this.BankLookUpEdit);
            this.dataLayConMain.Controls.Add(this.saleNoTextEdit);
            this.dataLayConMain.Controls.Add(this.labelTotalPriceDecimal);
            this.dataLayConMain.Controls.Add(this.labelTotalDecimal);
            this.dataLayConMain.Controls.Add(this.labelTotalTaxDecimal);
            this.dataLayConMain.Controls.Add(this.labelTotalTaxDecimal1);
            this.dataLayConMain.Controls.Add(this.labelTotalTaxDecimal2);
            this.dataLayConMain.Controls.Add(this.NotesTextEdit);
            this.dataLayConMain.Controls.Add(this.spinEditMonyFinal);
            this.dataLayConMain.Controls.Add(this.DscntAmountTextEdit);
            this.dataLayConMain.Controls.Add(this.textEditPaidCreditCard);
            this.dataLayConMain.Controls.Add(this.textEditPaidCash);
            this.dataLayConMain.DataSource = this.SupplyMainBindingSource;
            resources.ApplyResources(this.dataLayConMain, "dataLayConMain");
            this.dataLayConMain.HiddenItems.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1});
            this.dataLayConMain.Name = "dataLayConMain";
            this.dataLayConMain.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(716, 87, 650, 400);
            this.dataLayConMain.OptionsFocus.EnableAutoTabOrder = false;
            this.dataLayConMain.OptionsView.RightToLeftMirroringApplied = true;
            this.dataLayConMain.Root = this.layoutControlGroup1;
            // 
            // labelECR
            // 
            resources.ApplyResources(this.labelECR, "labelECR");
            this.labelECR.ForeColor = System.Drawing.Color.Red;
            this.labelECR.Name = "labelECR";
            // 
            // gridControl
            // 
            this.gridControl.DataSource = this.SupplySubBindingSource;
            this.gridControl.EmbeddedNavigator.Margin = ((System.Windows.Forms.Padding)(resources.GetObject("gridControl.EmbeddedNavigator.Margin")));
            resources.ApplyResources(this.gridControl, "gridControl");
            this.gridControl.MainView = this.gridView;
            this.gridControl.Name = "gridControl";
            this.gridControl.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemSpinEditQuan,
            this.repositoryItemCalcEdit1SalePrice,
            this.repositoryItemLookUpEditMeasurment,
            this.repositoryItemSearchLookUpEditPrdNo,
            this.repositoryItemTextEditDesc,
            this.repositoryItemLookUpEditProName,
            this.repositoryItemBtnBarcode});
            this.gridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView});
            // 
            // SupplySubBindingSource
            // 
            this.SupplySubBindingSource.DataSource = typeof(PosFinalCost.SupplySub);
            // 
            // gridView
            // 
            this.gridView.Appearance.FocusedCell.Font = ((System.Drawing.Font)(resources.GetObject("gridView.Appearance.FocusedCell.Font")));
            this.gridView.Appearance.FocusedCell.Options.UseFont = true;
            this.gridView.Appearance.FocusedRow.Font = ((System.Drawing.Font)(resources.GetObject("gridView.Appearance.FocusedRow.Font")));
            this.gridView.Appearance.FocusedRow.Options.UseFont = true;
            this.gridView.Appearance.FooterPanel.Options.UseTextOptions = true;
            this.gridView.Appearance.FooterPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridView.Appearance.HeaderPanel.Font = ((System.Drawing.Font)(resources.GetObject("gridView.Appearance.HeaderPanel.Font")));
            this.gridView.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.gridView.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView.Appearance.Row.Font = ((System.Drawing.Font)(resources.GetObject("gridView.Appearance.Row.Font")));
            this.gridView.Appearance.Row.Options.UseFont = true;
            this.gridView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colsupPrdNo,
            this.colsupPrdName,
            this.colMsur,
            this.colCurrency,
            this.colsupPrice,
            this.colQuanMain,
            this.colsupSalePrice,
            this.colsupTaxPercent,
            this.colTaxPrice,
            this.colsupDesc,
            this.colTotalPrice,
            this.colPrdManufacture,
            this.colsupDscntPercent,
            this.colDscntAmount,
            this.colid,
            this.colsupNo,
            this.colsupPrdBarcode,
            this.colprdQuanAvlb,
            this.colCount,
            this.colFinalAmount,
            this.colWidth,
            this.colHeight,
            this.colMeter,
            this.col_SubNoPacks,
            this.colsupOvertime,
            this.colsupWorkingtime,
            this.colBtnBarcode});
            this.gridView.GridControl = this.gridControl;
            this.gridView.Name = "gridView";
            this.gridView.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView.OptionsCustomization.AllowGroup = false;
            this.gridView.OptionsCustomization.AllowSort = false;
            this.gridView.OptionsCustomization.CustomizationFormSnapMode = ((DevExpress.Utils.Controls.SnapMode)((((DevExpress.Utils.Controls.SnapMode.OwnerControl | DevExpress.Utils.Controls.SnapMode.OwnerForm) 
            | DevExpress.Utils.Controls.SnapMode.Screens) 
            | DevExpress.Utils.Controls.SnapMode.SnapForms)));
            this.gridView.OptionsCustomization.UseAdvancedCustomizationForm = DevExpress.Utils.DefaultBoolean.True;
            this.gridView.OptionsFind.AllowFindPanel = false;
            this.gridView.OptionsMenu.ShowConditionalFormattingItem = true;
            this.gridView.OptionsSelection.CheckBoxSelectorColumnWidth = 34;
            this.gridView.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            this.gridView.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridView.OptionsView.ShowGroupPanel = false;
            // 
            // colsupPrdNo
            // 
            resources.ApplyResources(this.colsupPrdNo, "colsupPrdNo");
            this.colsupPrdNo.ColumnEdit = this.repositoryItemSearchLookUpEditPrdNo;
            this.colsupPrdNo.FieldName = "PrdId";
            this.colsupPrdNo.Name = "colsupPrdNo";
            // 
            // repositoryItemSearchLookUpEditPrdNo
            // 
            resources.ApplyResources(this.repositoryItemSearchLookUpEditPrdNo, "repositoryItemSearchLookUpEditPrdNo");
            this.repositoryItemSearchLookUpEditPrdNo.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.repositoryItemSearchLookUpEditPrdNo.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemSearchLookUpEditPrdNo.Buttons"))))});
            this.repositoryItemSearchLookUpEditPrdNo.DataSource = this.ProductBindingSource;
            this.repositoryItemSearchLookUpEditPrdNo.DisplayMember = "No";
            this.repositoryItemSearchLookUpEditPrdNo.Name = "repositoryItemSearchLookUpEditPrdNo";
            this.repositoryItemSearchLookUpEditPrdNo.PopupView = this.repositoryItemSearchLookUpEdit1View;
            this.repositoryItemSearchLookUpEditPrdNo.ValueMember = "ID";
            // 
            // ProductBindingSource
            // 
            this.ProductBindingSource.DataSource = typeof(PosFinalCost.Product);
            // 
            // repositoryItemSearchLookUpEdit1View
            // 
            this.repositoryItemSearchLookUpEdit1View.Appearance.EvenRow.BackColor = System.Drawing.Color.LightCyan;
            this.repositoryItemSearchLookUpEdit1View.Appearance.EvenRow.Options.UseBackColor = true;
            this.repositoryItemSearchLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colprdId,
            this.colprdNo,
            this.colprdName,
            this.colprdSalePrice,
            this.colsupMusrName,
            this.colprdGrpNo});
            this.repositoryItemSearchLookUpEdit1View.DetailHeight = 400;
            this.repositoryItemSearchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemSearchLookUpEdit1View.Name = "repositoryItemSearchLookUpEdit1View";
            this.repositoryItemSearchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemSearchLookUpEdit1View.OptionsView.EnableAppearanceEvenRow = true;
            this.repositoryItemSearchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            this.repositoryItemSearchLookUpEdit1View.OptionsView.ShowIndicator = false;
            // 
            // colprdId
            // 
            this.colprdId.FieldName = "ID";
            this.colprdId.Name = "colprdId";
            // 
            // colprdNo
            // 
            resources.ApplyResources(this.colprdNo, "colprdNo");
            this.colprdNo.FieldName = "No";
            this.colprdNo.MaxWidth = 150;
            this.colprdNo.Name = "colprdNo";
            // 
            // colprdName
            // 
            resources.ApplyResources(this.colprdName, "colprdName");
            this.colprdName.FieldName = "Name";
            this.colprdName.Name = "colprdName";
            // 
            // colprdSalePrice
            // 
            this.colprdSalePrice.AppearanceCell.Options.UseTextOptions = true;
            this.colprdSalePrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colprdSalePrice, "colprdSalePrice");
            this.colprdSalePrice.DisplayFormat.FormatString = "n2";
            this.colprdSalePrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colprdSalePrice.FieldName = "colPrdSalePrice";
            this.colprdSalePrice.MaxWidth = 100;
            this.colprdSalePrice.Name = "colprdSalePrice";
            this.colprdSalePrice.OptionsColumn.AllowIncrementalSearch = false;
            this.colprdSalePrice.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            // 
            // colsupMusrName
            // 
            resources.ApplyResources(this.colsupMusrName, "colsupMusrName");
            this.colsupMusrName.FieldName = "colsupMusrName";
            this.colsupMusrName.Name = "colsupMusrName";
            this.colsupMusrName.UnboundDataType = typeof(string);
            // 
            // colprdGrpNo
            // 
            this.colprdGrpNo.FieldName = "GrpNo";
            this.colprdGrpNo.Name = "colprdGrpNo";
            // 
            // colsupPrdName
            // 
            resources.ApplyResources(this.colsupPrdName, "colsupPrdName");
            this.colsupPrdName.ColumnEdit = this.repositoryItemLookUpEditProName;
            this.colsupPrdName.FieldName = "PrdId";
            this.colsupPrdName.Name = "colsupPrdName";
            this.colsupPrdName.OptionsColumn.AllowEdit = false;
            this.colsupPrdName.OptionsColumn.AllowFocus = false;
            this.colsupPrdName.OptionsColumn.ReadOnly = true;
            this.colsupPrdName.OptionsColumn.TabStop = false;
            // 
            // repositoryItemLookUpEditProName
            // 
            resources.ApplyResources(this.repositoryItemLookUpEditProName, "repositoryItemLookUpEditProName");
            this.repositoryItemLookUpEditProName.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemLookUpEditProName.Buttons"))))});
            this.repositoryItemLookUpEditProName.DataSource = this.ProductBindingSource;
            this.repositoryItemLookUpEditProName.DisplayMember = "Name";
            this.repositoryItemLookUpEditProName.Name = "repositoryItemLookUpEditProName";
            this.repositoryItemLookUpEditProName.ValueMember = "ID";
            // 
            // colMsur
            // 
            this.colMsur.AppearanceCell.Options.UseTextOptions = true;
            this.colMsur.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colMsur, "colMsur");
            this.colMsur.ColumnEdit = this.repositoryItemLookUpEditMeasurment;
            this.colMsur.FieldName = "Msur";
            this.colMsur.Name = "colMsur";
            // 
            // repositoryItemLookUpEditMeasurment
            // 
            resources.ApplyResources(this.repositoryItemLookUpEditMeasurment, "repositoryItemLookUpEditMeasurment");
            this.repositoryItemLookUpEditMeasurment.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemLookUpEditMeasurment.Buttons"))))});
            this.repositoryItemLookUpEditMeasurment.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("repositoryItemLookUpEditMeasurment.Columns"), resources.GetString("repositoryItemLookUpEditMeasurment.Columns1"))});
            this.repositoryItemLookUpEditMeasurment.DataSource = this.PrdMeasurmentBindingSource;
            this.repositoryItemLookUpEditMeasurment.DisplayMember = "Name";
            this.repositoryItemLookUpEditMeasurment.Name = "repositoryItemLookUpEditMeasurment";
            this.repositoryItemLookUpEditMeasurment.ValueMember = "ID";
            // 
            // PrdMeasurmentBindingSource
            // 
            this.PrdMeasurmentBindingSource.DataSource = typeof(PosFinalCost.PrdMeasurment);
            // 
            // colCurrency
            // 
            this.colCurrency.AppearanceCell.Options.UseTextOptions = true;
            this.colCurrency.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colCurrency, "colCurrency");
            this.colCurrency.FieldName = "Currency";
            this.colCurrency.Name = "colCurrency";
            this.colCurrency.OptionsColumn.AllowEdit = false;
            this.colCurrency.OptionsColumn.AllowFocus = false;
            this.colCurrency.OptionsColumn.ShowInExpressionEditor = false;
            this.colCurrency.OptionsColumn.TabStop = false;
            // 
            // colsupPrice
            // 
            this.colsupPrice.AppearanceCell.Options.UseTextOptions = true;
            this.colsupPrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colsupPrice, "colsupPrice");
            this.colsupPrice.DisplayFormat.FormatString = "f2";
            this.colsupPrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colsupPrice.FieldName = "BuyPrice";
            this.colsupPrice.Name = "colsupPrice";
            this.colsupPrice.OptionsColumn.ReadOnly = true;
            // 
            // colQuanMain
            // 
            this.colQuanMain.AppearanceCell.Options.UseTextOptions = true;
            this.colQuanMain.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colQuanMain, "colQuanMain");
            this.colQuanMain.ColumnEdit = this.repositoryItemSpinEditQuan;
            this.colQuanMain.FieldName = "QuanMain";
            this.colQuanMain.Name = "colQuanMain";
            // 
            // repositoryItemSpinEditQuan
            // 
            resources.ApplyResources(this.repositoryItemSpinEditQuan, "repositoryItemSpinEditQuan");
            this.repositoryItemSpinEditQuan.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemSpinEditQuan.Buttons"))))});
            this.repositoryItemSpinEditQuan.Mask.EditMask = resources.GetString("repositoryItemSpinEditQuan.Mask.EditMask");
            this.repositoryItemSpinEditQuan.MaxValue = new decimal(new int[] {
            999999999,
            0,
            0,
            131072});
            this.repositoryItemSpinEditQuan.Name = "repositoryItemSpinEditQuan";
            // 
            // colsupSalePrice
            // 
            this.colsupSalePrice.AppearanceCell.Options.UseTextOptions = true;
            this.colsupSalePrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colsupSalePrice, "colsupSalePrice");
            this.colsupSalePrice.ColumnEdit = this.repositoryItemCalcEdit1SalePrice;
            this.colsupSalePrice.DisplayFormat.FormatString = "N2";
            this.colsupSalePrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colsupSalePrice.FieldName = "SalePrice";
            this.colsupSalePrice.Name = "colsupSalePrice";
            // 
            // repositoryItemCalcEdit1SalePrice
            // 
            resources.ApplyResources(this.repositoryItemCalcEdit1SalePrice, "repositoryItemCalcEdit1SalePrice");
            this.repositoryItemCalcEdit1SalePrice.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemCalcEdit1SalePrice.Buttons"))))});
            this.repositoryItemCalcEdit1SalePrice.Mask.EditMask = resources.GetString("repositoryItemCalcEdit1SalePrice.Mask.EditMask");
            this.repositoryItemCalcEdit1SalePrice.Name = "repositoryItemCalcEdit1SalePrice";
            this.repositoryItemCalcEdit1SalePrice.Precision = 2;
            this.repositoryItemCalcEdit1SalePrice.ShowCloseButton = true;
            // 
            // colsupTaxPercent
            // 
            this.colsupTaxPercent.AppearanceCell.Options.UseTextOptions = true;
            this.colsupTaxPercent.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colsupTaxPercent, "colsupTaxPercent");
            this.colsupTaxPercent.FieldName = "TaxPercent";
            this.colsupTaxPercent.Name = "colsupTaxPercent";
            this.colsupTaxPercent.OptionsColumn.AllowEdit = false;
            this.colsupTaxPercent.OptionsColumn.AllowFocus = false;
            this.colsupTaxPercent.OptionsColumn.TabStop = false;
            // 
            // colTaxPrice
            // 
            this.colTaxPrice.AppearanceCell.Options.UseTextOptions = true;
            this.colTaxPrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colTaxPrice, "colTaxPrice");
            this.colTaxPrice.DisplayFormat.FormatString = "n2";
            this.colTaxPrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTaxPrice.FieldName = "TaxPrice";
            this.colTaxPrice.Name = "colTaxPrice";
            this.colTaxPrice.OptionsColumn.AllowEdit = false;
            this.colTaxPrice.OptionsColumn.AllowFocus = false;
            this.colTaxPrice.OptionsColumn.TabStop = false;
            // 
            // colsupDesc
            // 
            resources.ApplyResources(this.colsupDesc, "colsupDesc");
            this.colsupDesc.ColumnEdit = this.repositoryItemTextEditDesc;
            this.colsupDesc.FieldName = "Desc";
            this.colsupDesc.Name = "colsupDesc";
            // 
            // repositoryItemTextEditDesc
            // 
            resources.ApplyResources(this.repositoryItemTextEditDesc, "repositoryItemTextEditDesc");
            this.repositoryItemTextEditDesc.MaxLength = 150;
            this.repositoryItemTextEditDesc.Name = "repositoryItemTextEditDesc";
            // 
            // colTotalPrice
            // 
            this.colTotalPrice.AppearanceCell.Options.UseTextOptions = true;
            this.colTotalPrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colTotalPrice, "colTotalPrice");
            this.colTotalPrice.DisplayFormat.FormatString = "n2";
            this.colTotalPrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotalPrice.FieldName = "Total";
            this.colTotalPrice.Name = "colTotalPrice";
            this.colTotalPrice.OptionsColumn.TabStop = false;
            this.colTotalPrice.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(((DevExpress.Data.SummaryItemType)(resources.GetObject("colTotalPrice.Summary"))), resources.GetString("colTotalPrice.Summary1"), resources.GetString("colTotalPrice.Summary2"))});
            // 
            // colPrdManufacture
            // 
            resources.ApplyResources(this.colPrdManufacture, "colPrdManufacture");
            this.colPrdManufacture.FieldName = "PrdManufacture";
            this.colPrdManufacture.Name = "colPrdManufacture";
            this.colPrdManufacture.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colsupDscntPercent
            // 
            this.colsupDscntPercent.AppearanceCell.Options.UseTextOptions = true;
            this.colsupDscntPercent.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colsupDscntPercent, "colsupDscntPercent");
            this.colsupDscntPercent.DisplayFormat.FormatString = "n2";
            this.colsupDscntPercent.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colsupDscntPercent.FieldName = "DscntPercent";
            this.colsupDscntPercent.Name = "colsupDscntPercent";
            // 
            // colDscntAmount
            // 
            this.colDscntAmount.AppearanceCell.Options.UseTextOptions = true;
            this.colDscntAmount.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colDscntAmount, "colDscntAmount");
            this.colDscntAmount.FieldName = "DscntAmount";
            this.colDscntAmount.Name = "colDscntAmount";
            // 
            // colid
            // 
            this.colid.FieldName = "ID";
            this.colid.Name = "colid";
            this.colid.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colsupNo
            // 
            resources.ApplyResources(this.colsupNo, "colsupNo");
            this.colsupNo.FieldName = "ParentID";
            this.colsupNo.Name = "colsupNo";
            this.colsupNo.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colsupPrdBarcode
            // 
            resources.ApplyResources(this.colsupPrdBarcode, "colsupPrdBarcode");
            this.colsupPrdBarcode.FieldName = "PrdBarcode";
            this.colsupPrdBarcode.Name = "colsupPrdBarcode";
            this.colsupPrdBarcode.OptionsColumn.AllowEdit = false;
            this.colsupPrdBarcode.OptionsColumn.AllowFocus = false;
            this.colsupPrdBarcode.OptionsColumn.ReadOnly = true;
            this.colsupPrdBarcode.OptionsColumn.TabStop = false;
            // 
            // colprdQuanAvlb
            // 
            this.colprdQuanAvlb.AppearanceCell.Options.UseTextOptions = true;
            this.colprdQuanAvlb.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colprdQuanAvlb, "colprdQuanAvlb");
            this.colprdQuanAvlb.FieldName = "colprdQuanAvlb";
            this.colprdQuanAvlb.Name = "colprdQuanAvlb";
            this.colprdQuanAvlb.OptionsColumn.AllowEdit = false;
            this.colprdQuanAvlb.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            // 
            // colCount
            // 
            this.colCount.AppearanceCell.Options.UseTextOptions = true;
            this.colCount.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colCount, "colCount");
            this.colCount.FieldName = "colCount";
            this.colCount.Name = "colCount";
            this.colCount.OptionsColumn.AllowEdit = false;
            this.colCount.OptionsColumn.ReadOnly = true;
            this.colCount.OptionsColumn.TabStop = false;
            this.colCount.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            // 
            // colFinalAmount
            // 
            resources.ApplyResources(this.colFinalAmount, "colFinalAmount");
            this.colFinalAmount.FieldName = "FinalAmount";
            this.colFinalAmount.Name = "colFinalAmount";
            this.colFinalAmount.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            // 
            // colWidth
            // 
            resources.ApplyResources(this.colWidth, "colWidth");
            this.colWidth.FieldName = "Width";
            this.colWidth.Name = "colWidth";
            // 
            // colHeight
            // 
            resources.ApplyResources(this.colHeight, "colHeight");
            this.colHeight.FieldName = "Height";
            this.colHeight.Name = "colHeight";
            // 
            // colMeter
            // 
            resources.ApplyResources(this.colMeter, "colMeter");
            this.colMeter.FieldName = "QteMeter";
            this.colMeter.Name = "colMeter";
            // 
            // col_SubNoPacks
            // 
            resources.ApplyResources(this.col_SubNoPacks, "col_SubNoPacks");
            this.col_SubNoPacks.FieldName = "NoPacks";
            this.col_SubNoPacks.Name = "col_SubNoPacks";
            this.col_SubNoPacks.OptionsColumn.AllowEdit = false;
            // 
            // colsupOvertime
            // 
            resources.ApplyResources(this.colsupOvertime, "colsupOvertime");
            this.colsupOvertime.FieldName = "Overtime";
            this.colsupOvertime.MinWidth = 25;
            this.colsupOvertime.Name = "colsupOvertime";
            // 
            // colsupWorkingtime
            // 
            resources.ApplyResources(this.colsupWorkingtime, "colsupWorkingtime");
            this.colsupWorkingtime.FieldName = "Workingtime";
            this.colsupWorkingtime.MinWidth = 25;
            this.colsupWorkingtime.Name = "colsupWorkingtime";
            // 
            // bindingNavigator11
            // 
            this.bindingNavigator11.AddNewItem = null;
            resources.ApplyResources(this.bindingNavigator11, "bindingNavigator11");
            this.bindingNavigator11.CountItem = null;
            this.bindingNavigator11.DeleteItem = null;
            this.bindingNavigator11.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bindingNavigator11.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnSave,
            this.btnSaveAndNew,
            this.btnClose,
            this.btnReset,
            this.btnPrintPrevious,
            this.btnPdfPrevious,
            this.btnXslPrevious,
            this.bbiSelect,
            this.btnPrdPrice,
            this.btnEditPrice,
            this.btnEditQuantity,
            this.btnSaveAndNewNoPrint,
            this.btnPaidCreditShortcut});
            this.bindingNavigator11.MoveFirstItem = null;
            this.bindingNavigator11.MoveLastItem = null;
            this.bindingNavigator11.MoveNextItem = null;
            this.bindingNavigator11.MovePreviousItem = null;
            this.bindingNavigator11.Name = "bindingNavigator11";
            this.bindingNavigator11.PositionItem = null;
            // 
            // btnSave
            // 
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            resources.ApplyResources(this.btnSave, "btnSave");
            this.btnSave.Name = "btnSave";
            // 
            // btnSaveAndNew
            // 
            this.btnSaveAndNew.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnSaveAndNew.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnSaveAndNew, "btnSaveAndNew");
            this.btnSaveAndNew.Name = "btnSaveAndNew";
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnClose.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnClose, "btnClose");
            this.btnClose.Name = "btnClose";
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnReset.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnReset, "btnReset");
            this.btnReset.Name = "btnReset";
            // 
            // btnPrintPrevious
            // 
            this.btnPrintPrevious.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnPrintPrevious.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnPrintPrevious, "btnPrintPrevious");
            this.btnPrintPrevious.Name = "btnPrintPrevious";
            // 
            // btnPdfPrevious
            // 
            this.btnPdfPrevious.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnPdfPrevious.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnPdfPrevious, "btnPdfPrevious");
            this.btnPdfPrevious.Name = "btnPdfPrevious";
            // 
            // btnXslPrevious
            // 
            this.btnXslPrevious.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnXslPrevious.ForeColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnXslPrevious, "btnXslPrevious");
            this.btnXslPrevious.Name = "btnXslPrevious";
            // 
            // bbiSelect
            // 
            this.bbiSelect.CheckOnClick = true;
            this.bbiSelect.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            resources.ApplyResources(this.bbiSelect, "bbiSelect");
            this.bbiSelect.Name = "bbiSelect";
            this.bbiSelect.CheckedChanged += new System.EventHandler(this.bbiSelect_CheckedChanged);
            // 
            // btnPrdPrice
            // 
            this.btnPrdPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnPrdPrice.Name = "btnPrdPrice";
            resources.ApplyResources(this.btnPrdPrice, "btnPrdPrice");
            // 
            // btnEditPrice
            // 
            this.btnEditPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            resources.ApplyResources(this.btnEditPrice, "btnEditPrice");
            this.btnEditPrice.Name = "btnEditPrice";
            // 
            // btnEditQuantity
            // 
            this.btnEditQuantity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            resources.ApplyResources(this.btnEditQuantity, "btnEditQuantity");
            this.btnEditQuantity.Name = "btnEditQuantity";
            // 
            // btnSaveAndNewNoPrint
            // 
            this.btnSaveAndNewNoPrint.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            resources.ApplyResources(this.btnSaveAndNewNoPrint, "btnSaveAndNewNoPrint");
            this.btnSaveAndNewNoPrint.Name = "btnSaveAndNewNoPrint";
            // 
            // btnPaidCreditShortcut
            // 
            this.btnPaidCreditShortcut.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            resources.ApplyResources(this.btnPaidCreditShortcut, "btnPaidCreditShortcut");
            this.btnPaidCreditShortcut.Name = "btnPaidCreditShortcut";
            // 
            // supNoTextEdit
            // 
            this.supNoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "No", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.supNoTextEdit, "supNoTextEdit");
            this.supNoTextEdit.Name = "supNoTextEdit";
            this.supNoTextEdit.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("supNoTextEdit.Properties.Mask.BeepOnError")));
            this.supNoTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("supNoTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.supNoTextEdit.Properties.ReadOnly = true;
            this.supNoTextEdit.Properties.UseReadOnlyAppearance = false;
            this.supNoTextEdit.StyleController = this.dataLayConMain;
            conditionValidationRule1.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.NotEquals;
            conditionValidationRule1.ErrorText = "This value is not valid";
            conditionValidationRule1.Value1 = 0;
            this.dxValidationProvider1.SetValidationRule(this.supNoTextEdit, conditionValidationRule1);
            // 
            // SupplyMainBindingSource
            // 
            this.SupplyMainBindingSource.DataSource = typeof(PosFinalCost.SupplyMain);
            // 
            // radioGroupIsCash
            // 
            this.radioGroupIsCash.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "IsCash", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.radioGroupIsCash, "radioGroupIsCash");
            this.radioGroupIsCash.Name = "radioGroupIsCash";
            this.radioGroupIsCash.Properties.Columns = 3;
            this.radioGroupIsCash.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((object)(resources.GetObject("radioGroupIsCash.Properties.Items"))), resources.GetString("radioGroupIsCash.Properties.Items1")),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((object)(resources.GetObject("radioGroupIsCash.Properties.Items2"))), resources.GetString("radioGroupIsCash.Properties.Items3"))});
            this.radioGroupIsCash.Properties.Padding = new System.Windows.Forms.Padding(0);
            this.radioGroupIsCash.StyleController = this.dataLayConMain;
            // 
            // checkEdit1
            // 
            resources.ApplyResources(this.checkEdit1, "checkEdit1");
            this.checkEdit1.Name = "checkEdit1";
            this.checkEdit1.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("checkEdit1.Properties.Appearance.Font")));
            this.checkEdit1.Properties.Appearance.Options.UseFont = true;
            this.checkEdit1.Properties.Caption = resources.GetString("checkEdit1.Properties.Caption");
            this.checkEdit1.Properties.GlyphAlignment = ((DevExpress.Utils.HorzAlignment)(resources.GetObject("checkEdit1.Properties.GlyphAlignment")));
            this.checkEdit1.StyleController = this.dataLayConMain;
            // 
            // textEditCounterNumber
            // 
            this.textEditCounterNumber.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "CounterNumber", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.textEditCounterNumber, "textEditCounterNumber");
            this.textEditCounterNumber.Name = "textEditCounterNumber";
            this.textEditCounterNumber.StyleController = this.dataLayConMain;
            // 
            // textEditPlateNumber
            // 
            this.textEditPlateNumber.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "PlateNumber", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.textEditPlateNumber, "textEditPlateNumber");
            this.textEditPlateNumber.Name = "textEditPlateNumber";
            this.textEditPlateNumber.StyleController = this.dataLayConMain;
            // 
            // textEditCarType
            // 
            this.textEditCarType.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "CarType", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.textEditCarType, "textEditCarType");
            this.textEditCarType.Name = "textEditCarType";
            this.textEditCarType.StyleController = this.dataLayConMain;
            // 
            // supDescTextEdit
            // 
            this.supDescTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "Desc", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.supDescTextEdit, "supDescTextEdit");
            this.supDescTextEdit.Name = "supDescTextEdit";
            this.supDescTextEdit.Properties.MaxLength = 100;
            this.supDescTextEdit.StyleController = this.dataLayConMain;
            // 
            // DateDateEdit
            // 
            this.DateDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "Date", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.DateDateEdit, "DateDateEdit");
            this.DateDateEdit.Name = "DateDateEdit";
            this.DateDateEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.DateDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("DateDateEdit.Properties.Buttons"))))});
            this.DateDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("DateDateEdit.Properties.CalendarTimeProperties.Buttons"))))});
            this.DateDateEdit.StyleController = this.dataLayConMain;
            // 
            // BoxNoLookUpEdit
            // 
            this.BoxNoLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "BoxId", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.BoxNoLookUpEdit, "BoxNoLookUpEdit");
            this.BoxNoLookUpEdit.Name = "BoxNoLookUpEdit";
            this.BoxNoLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.BoxNoLookUpEdit.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.BoxNoLookUpEdit.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.BoxNoLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("BoxNoLookUpEdit.Properties.Buttons"))))});
            this.BoxNoLookUpEdit.Properties.NullText = resources.GetString("BoxNoLookUpEdit.Properties.NullText");
            this.BoxNoLookUpEdit.Properties.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoSearch;
            this.BoxNoLookUpEdit.StyleController = this.dataLayConMain;
            // 
            // CurrencyChngTextEdit
            // 
            this.CurrencyChngTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "CurrencyChng", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.CurrencyChngTextEdit, "CurrencyChngTextEdit");
            this.CurrencyChngTextEdit.Name = "CurrencyChngTextEdit";
            this.CurrencyChngTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.CurrencyChngTextEdit.StyleController = this.dataLayConMain;
            // 
            // checkEditTax
            // 
            resources.ApplyResources(this.checkEditTax, "checkEditTax");
            this.checkEditTax.Name = "checkEditTax";
            this.checkEditTax.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("checkEditTax.Properties.Appearance.Font")));
            this.checkEditTax.Properties.Appearance.Options.UseFont = true;
            this.checkEditTax.Properties.Caption = resources.GetString("checkEditTax.Properties.Caption");
            this.checkEditTax.Properties.GlyphAlignment = ((DevExpress.Utils.HorzAlignment)(resources.GetObject("checkEditTax.Properties.GlyphAlignment")));
            this.checkEditTax.StyleController = this.dataLayConMain;
            // 
            // supCurrTextEdit
            // 
            this.supCurrTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "Currency", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.supCurrTextEdit, "supCurrTextEdit");
            this.supCurrTextEdit.Name = "supCurrTextEdit";
            this.supCurrTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.supCurrTextEdit.Properties.DisplayMember = "curName";
            this.supCurrTextEdit.Properties.NullText = resources.GetString("supCurrTextEdit.Properties.NullText");
            this.supCurrTextEdit.Properties.ReadOnly = true;
            this.supCurrTextEdit.Properties.UseReadOnlyAppearance = false;
            this.supCurrTextEdit.Properties.ValueMember = "ID";
            this.supCurrTextEdit.StyleController = this.dataLayConMain;
            this.supCurrTextEdit.TabStop = false;
            conditionValidationRule2.ErrorText = "This value is not valid";
            this.dxValidationProvider1.SetValidationRule(this.supCurrTextEdit, conditionValidationRule2);
            // 
            // CustNoSearchLookUpEdit
            // 
            this.CustNoSearchLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "CustId", true));
            resources.ApplyResources(this.CustNoSearchLookUpEdit, "CustNoSearchLookUpEdit");
            this.CustNoSearchLookUpEdit.Name = "CustNoSearchLookUpEdit";
            this.CustNoSearchLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.CustNoSearchLookUpEdit.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.CustNoSearchLookUpEdit.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.CustNoSearchLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("CustNoSearchLookUpEdit.Properties.Buttons")))),
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("CustNoSearchLookUpEdit.Properties.Buttons1"))))});
            this.CustNoSearchLookUpEdit.Properties.DataSource = this.customerBindingSource;
            this.CustNoSearchLookUpEdit.Properties.DisplayMember = "Name";
            this.CustNoSearchLookUpEdit.Properties.NullText = resources.GetString("CustNoSearchLookUpEdit.Properties.NullText");
            this.CustNoSearchLookUpEdit.Properties.PopupView = this.searchLookUpEdit1View;
            this.CustNoSearchLookUpEdit.Properties.PopupWidthMode = DevExpress.XtraEditors.PopupWidthMode.UseEditorWidth;
            this.CustNoSearchLookUpEdit.Properties.ValueMember = "ID";
            this.CustNoSearchLookUpEdit.Properties.ButtonPressed += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.RepositoryItemSearchLookUpEditCustomerBbi_ButtonClick);
            this.CustNoSearchLookUpEdit.StyleController = this.dataLayConMain;
            this.CustNoSearchLookUpEdit.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.RepositoryItemSearchLookUpEditCustomerBbi_ButtonClick);
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataSource = typeof(PosFinalCost.Customer);
            // 
            // searchLookUpEdit1View
            // 
            this.searchLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colcustNo1,
            this.colcustName1,
            this.colcustPhnNo1,
            this.colcustCurrency1});
            this.searchLookUpEdit1View.DetailHeight = 400;
            this.searchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.searchLookUpEdit1View.Name = "searchLookUpEdit1View";
            this.searchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.searchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            this.searchLookUpEdit1View.OptionsView.ShowIndicator = false;
            // 
            // colcustNo1
            // 
            this.colcustNo1.AppearanceCell.Options.UseTextOptions = true;
            this.colcustNo1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            resources.ApplyResources(this.colcustNo1, "colcustNo1");
            this.colcustNo1.FieldName = "ID";
            this.colcustNo1.MaxWidth = 75;
            this.colcustNo1.Name = "colcustNo1";
            // 
            // colcustName1
            // 
            resources.ApplyResources(this.colcustName1, "colcustName1");
            this.colcustName1.FieldName = "Name";
            this.colcustName1.Name = "colcustName1";
            // 
            // colcustPhnNo1
            // 
            resources.ApplyResources(this.colcustPhnNo1, "colcustPhnNo1");
            this.colcustPhnNo1.FieldName = "PhnNo";
            this.colcustPhnNo1.Name = "colcustPhnNo1";
            // 
            // colcustCurrency1
            // 
            resources.ApplyResources(this.colcustCurrency1, "colcustCurrency1");
            this.colcustCurrency1.FieldName = "Currency";
            this.colcustCurrency1.Name = "colcustCurrency1";
            // 
            // notDateTextEdit
            // 
            this.notDateTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "DueDate", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.notDateTextEdit, "notDateTextEdit");
            this.notDateTextEdit.Name = "notDateTextEdit";
            this.notDateTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.notDateTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("notDateTextEdit.Properties.Buttons"))))});
            this.notDateTextEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("notDateTextEdit.Properties.CalendarTimeProperties.Buttons"))))});
            this.notDateTextEdit.Properties.DisplayFormat.FormatString = "";
            this.notDateTextEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.notDateTextEdit.Properties.EditFormat.FormatString = "";
            this.notDateTextEdit.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.notDateTextEdit.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("notDateTextEdit.Properties.Mask.BeepOnError")));
            this.notDateTextEdit.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("notDateTextEdit.Properties.Mask.UseMaskAsDisplayFormat")));
            this.notDateTextEdit.StyleController = this.dataLayConMain;
            // 
            // PoNumberTextEdit
            // 
            this.PoNumberTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "PoNumber", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.PoNumberTextEdit, "PoNumberTextEdit");
            this.PoNumberTextEdit.Name = "PoNumberTextEdit";
            this.PoNumberTextEdit.StyleController = this.dataLayConMain;
            // 
            // StrIdLookUpEdit
            // 
            this.StrIdLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "StrId", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.StrIdLookUpEdit, "StrIdLookUpEdit");
            this.StrIdLookUpEdit.Name = "StrIdLookUpEdit";
            this.StrIdLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.StrIdLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("StrIdLookUpEdit.Properties.Buttons"))))});
            this.StrIdLookUpEdit.Properties.NullText = resources.GetString("StrIdLookUpEdit.Properties.NullText");
            this.StrIdLookUpEdit.Properties.ShowHeader = false;
            this.StrIdLookUpEdit.StyleController = this.dataLayConMain;
            conditionValidationRule3.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule3.ErrorText = "This value is not valid";
            this.dxValidationProvider1.SetValidationRule(this.StrIdLookUpEdit, conditionValidationRule3);
            // 
            // textEditBarcodeNo
            // 
            resources.ApplyResources(this.textEditBarcodeNo, "textEditBarcodeNo");
            this.textEditBarcodeNo.Name = "textEditBarcodeNo";
            this.textEditBarcodeNo.Properties.Appearance.BackColor = System.Drawing.Color.Yellow;
            this.textEditBarcodeNo.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("textEditBarcodeNo.Properties.Appearance.Font")));
            this.textEditBarcodeNo.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.textEditBarcodeNo.Properties.Appearance.Options.UseBackColor = true;
            this.textEditBarcodeNo.Properties.Appearance.Options.UseFont = true;
            this.textEditBarcodeNo.Properties.Appearance.Options.UseForeColor = true;
            this.textEditBarcodeNo.StyleController = this.dataLayConMain;
            // 
            // btnDeleteRow
            // 
            this.btnDeleteRow.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("btnDeleteRow.Appearance.Font")));
            this.btnDeleteRow.Appearance.Options.UseFont = true;
            this.btnDeleteRow.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnDeleteRow.ImageOptions.Image")));
            resources.ApplyResources(this.btnDeleteRow, "btnDeleteRow");
            this.btnDeleteRow.Name = "btnDeleteRow";
            this.btnDeleteRow.StyleController = this.dataLayConMain;
            this.btnDeleteRow.Click += new System.EventHandler(this.btnDeleteRow_Click);
            // 
            // supDscntPercentTextEdit
            // 
            this.supDscntPercentTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "DscntPercent", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.supDscntPercentTextEdit, "supDscntPercentTextEdit");
            this.supDscntPercentTextEdit.Name = "supDscntPercentTextEdit";
            this.supDscntPercentTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.supDscntPercentTextEdit.Properties.Appearance.Options.UseFont = true;
            this.supDscntPercentTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.supDscntPercentTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.supDscntPercentTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("supDscntPercentTextEdit.Properties.Buttons"))))});
            this.supDscntPercentTextEdit.Properties.DisplayFormat.FormatString = "n2";
            this.supDscntPercentTextEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.supDscntPercentTextEdit.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Default;
            this.supDscntPercentTextEdit.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("supDscntPercentTextEdit.Properties.Mask.BeepOnError")));
            this.supDscntPercentTextEdit.Properties.MaskSettings.Set("mask", "n");
            this.supDscntPercentTextEdit.Properties.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.supDscntPercentTextEdit.StyleController = this.dataLayConMain;
            // 
            // BtnDscnFraction
            // 
            this.BtnDscnFraction.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnDscnFraction.ImageOptions.Image")));
            resources.ApplyResources(this.BtnDscnFraction, "BtnDscnFraction");
            this.BtnDscnFraction.Name = "BtnDscnFraction";
            this.BtnDscnFraction.StyleController = this.dataLayConMain;
            this.BtnDscnFraction.Click += new System.EventHandler(this.BtnDscnFraction_Click);
            // 
            // BtnAddFraction
            // 
            this.BtnAddFraction.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("BtnAddFraction.ImageOptions.Image")));
            resources.ApplyResources(this.BtnAddFraction, "BtnAddFraction");
            this.BtnAddFraction.Name = "BtnAddFraction";
            this.BtnAddFraction.StyleController = this.dataLayConMain;
            this.BtnAddFraction.Click += new System.EventHandler(this.BtnAddFraction_Click);
            // 
            // spinEditTotalFinalDecimal
            // 
            this.spinEditTotalFinalDecimal.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "Net", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.spinEditTotalFinalDecimal, "spinEditTotalFinalDecimal");
            this.spinEditTotalFinalDecimal.Name = "spinEditTotalFinalDecimal";
            this.spinEditTotalFinalDecimal.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.spinEditTotalFinalDecimal.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("spinEditTotalFinalDecimal.Properties.Appearance.Font")));
            this.spinEditTotalFinalDecimal.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.spinEditTotalFinalDecimal.Properties.Appearance.Options.UseFont = true;
            this.spinEditTotalFinalDecimal.Properties.Appearance.Options.UseForeColor = true;
            this.spinEditTotalFinalDecimal.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEditTotalFinalDecimal.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.spinEditTotalFinalDecimal.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEditTotalFinalDecimal.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("spinEditTotalFinalDecimal.Properties.Buttons"))))});
            this.spinEditTotalFinalDecimal.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("spinEditTotalFinalDecimal.Properties.Mask.UseMaskAsDisplayFormat")));
            this.spinEditTotalFinalDecimal.Properties.MaskSettings.Set("mask", "n");
            this.spinEditTotalFinalDecimal.Properties.ReadOnly = true;
            this.spinEditTotalFinalDecimal.StyleController = this.dataLayConMain;
            // 
            // BankLookUpEdit
            // 
            this.BankLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "BankId", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.BankLookUpEdit, "BankLookUpEdit");
            this.BankLookUpEdit.Name = "BankLookUpEdit";
            this.BankLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.BankLookUpEdit.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.BankLookUpEdit.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.BankLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("BankLookUpEdit.Properties.Buttons"))))});
            this.BankLookUpEdit.Properties.NullText = resources.GetString("BankLookUpEdit.Properties.NullText");
            this.BankLookUpEdit.Properties.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoSearch;
            this.BankLookUpEdit.StyleController = this.dataLayConMain;
            // 
            // saleNoTextEdit
            // 
            resources.ApplyResources(this.saleNoTextEdit, "saleNoTextEdit");
            this.saleNoTextEdit.Name = "saleNoTextEdit";
            this.saleNoTextEdit.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.saleNoTextEdit.Properties.Appearance.Options.UseBackColor = true;
            this.saleNoTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("saleNoTextEdit.Properties.Buttons"))))});
            this.saleNoTextEdit.Properties.DataSource = this.SupplyMainBindingSourceEditor;
            this.saleNoTextEdit.Properties.DisplayMember = "No";
            this.saleNoTextEdit.Properties.NullText = resources.GetString("saleNoTextEdit.Properties.NullText");
            this.saleNoTextEdit.Properties.PopupView = this.gridView1;
            this.saleNoTextEdit.Properties.ValueMember = "No";
            this.saleNoTextEdit.StyleController = this.dataLayConMain;
            // 
            // SupplyMainBindingSourceEditor
            // 
            this.SupplyMainBindingSourceEditor.DataSource = typeof(PosFinalCost.SupplyMain);
            // 
            // gridView1
            // 
            this.gridView1.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gridView1.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridView1.Appearance.HeaderPanel.Font = ((System.Drawing.Font)(resources.GetObject("gridView1.Appearance.HeaderPanel.Font")));
            this.gridView1.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.gridView1.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Appearance.Row.Options.UseTextOptions = true;
            this.gridView1.Appearance.Row.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colStatus,
            this.gridColumn1,
            this.colNo,
            this.colDesc,
            this.colTotal,
            this.colDate,
            this.gridColumn2,
            this.gridColumn4,
            this.colNet,
            this.colTotalAfterDiscount,
            this.colIsCash});
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AllowGroupExpandAnimation = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.AllowSortAnimation = DevExpress.Utils.DefaultBoolean.True;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.ReadOnly = true;
            this.gridView1.OptionsFind.AlwaysVisible = true;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // colStatus
            // 
            resources.ApplyResources(this.colStatus, "colStatus");
            this.colStatus.FieldName = "Status";
            this.colStatus.MinWidth = 26;
            this.colStatus.Name = "colStatus";
            // 
            // gridColumn1
            // 
            resources.ApplyResources(this.gridColumn1, "gridColumn1");
            this.gridColumn1.FieldName = "ID";
            this.gridColumn1.MinWidth = 26;
            this.gridColumn1.Name = "gridColumn1";
            // 
            // colNo
            // 
            resources.ApplyResources(this.colNo, "colNo");
            this.colNo.FieldName = "No";
            this.colNo.MinWidth = 26;
            this.colNo.Name = "colNo";
            // 
            // colDesc
            // 
            resources.ApplyResources(this.colDesc, "colDesc");
            this.colDesc.FieldName = "Desc";
            this.colDesc.MinWidth = 26;
            this.colDesc.Name = "colDesc";
            // 
            // colTotal
            // 
            resources.ApplyResources(this.colTotal, "colTotal");
            this.colTotal.DisplayFormat.FormatString = "n2";
            this.colTotal.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotal.FieldName = "Total";
            this.colTotal.MinWidth = 26;
            this.colTotal.Name = "colTotal";
            // 
            // colDate
            // 
            resources.ApplyResources(this.colDate, "colDate");
            this.colDate.DisplayFormat.FormatString = "yyyy/MM/dd hh:mm tt";
            this.colDate.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colDate.FieldName = "Date";
            this.colDate.Name = "colDate";
            // 
            // gridColumn2
            // 
            resources.ApplyResources(this.gridColumn2, "gridColumn2");
            this.gridColumn2.DisplayFormat.FormatString = "n2";
            this.gridColumn2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn2.FieldName = "TaxPrice";
            this.gridColumn2.MinWidth = 26;
            this.gridColumn2.Name = "gridColumn2";
            // 
            // gridColumn4
            // 
            resources.ApplyResources(this.gridColumn4, "gridColumn4");
            this.gridColumn4.DisplayFormat.FormatString = "n2";
            this.gridColumn4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn4.FieldName = "DscntAmount";
            this.gridColumn4.MinWidth = 23;
            this.gridColumn4.Name = "gridColumn4";
            // 
            // colNet
            // 
            resources.ApplyResources(this.colNet, "colNet");
            this.colNet.DisplayFormat.FormatString = "n2";
            this.colNet.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colNet.FieldName = "Net";
            this.colNet.MinWidth = 23;
            this.colNet.Name = "colNet";
            this.colNet.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            // 
            // colTotalAfterDiscount
            // 
            resources.ApplyResources(this.colTotalAfterDiscount, "colTotalAfterDiscount");
            this.colTotalAfterDiscount.DisplayFormat.FormatString = "n2";
            this.colTotalAfterDiscount.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colTotalAfterDiscount.FieldName = "TotalAfterDiscount";
            this.colTotalAfterDiscount.MinWidth = 25;
            this.colTotalAfterDiscount.Name = "colTotalAfterDiscount";
            // 
            // colIsCash
            // 
            resources.ApplyResources(this.colIsCash, "colIsCash");
            this.colIsCash.FieldName = "IsCash";
            this.colIsCash.Name = "colIsCash";
            // 
            // labelTotalPriceDecimal
            // 
            this.labelTotalPriceDecimal.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "Total", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.labelTotalPriceDecimal, "labelTotalPriceDecimal");
            this.labelTotalPriceDecimal.Name = "labelTotalPriceDecimal";
            this.labelTotalPriceDecimal.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("labelTotalPriceDecimal.Properties.Appearance.Font")));
            this.labelTotalPriceDecimal.Properties.Appearance.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelTotalPriceDecimal.Properties.Appearance.Options.UseFont = true;
            this.labelTotalPriceDecimal.Properties.Appearance.Options.UseForeColor = true;
            this.labelTotalPriceDecimal.Properties.Appearance.Options.UseTextOptions = true;
            this.labelTotalPriceDecimal.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalPriceDecimal.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.labelTotalPriceDecimal.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("labelTotalPriceDecimal.Properties.Buttons"))))});
            this.labelTotalPriceDecimal.Properties.DisplayFormat.FormatString = "n2";
            this.labelTotalPriceDecimal.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.labelTotalPriceDecimal.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.labelTotalPriceDecimal.Properties.MaskSettings.Set("MaskManagerSignature", "allowNull=False");
            this.labelTotalPriceDecimal.Properties.MaskSettings.Set("mask", "n");
            this.labelTotalPriceDecimal.Properties.ReadOnly = true;
            this.labelTotalPriceDecimal.StyleController = this.dataLayConMain;
            // 
            // labelTotalDecimal
            // 
            this.labelTotalDecimal.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "TotalAfterDiscount", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.labelTotalDecimal, "labelTotalDecimal");
            this.labelTotalDecimal.Name = "labelTotalDecimal";
            this.labelTotalDecimal.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.labelTotalDecimal.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("labelTotalDecimal.Properties.Appearance.Font")));
            this.labelTotalDecimal.Properties.Appearance.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelTotalDecimal.Properties.Appearance.Options.UseFont = true;
            this.labelTotalDecimal.Properties.Appearance.Options.UseForeColor = true;
            this.labelTotalDecimal.Properties.Appearance.Options.UseTextOptions = true;
            this.labelTotalDecimal.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalDecimal.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.labelTotalDecimal.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("labelTotalDecimal.Properties.Buttons"))))});
            this.labelTotalDecimal.Properties.DisplayFormat.FormatString = "n2";
            this.labelTotalDecimal.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.labelTotalDecimal.Properties.MaskSettings.Set("mask", "n");
            this.labelTotalDecimal.Properties.ReadOnly = true;
            this.labelTotalDecimal.StyleController = this.dataLayConMain;
            // 
            // labelTotalTaxDecimal
            // 
            this.labelTotalTaxDecimal.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "TaxPrice", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.labelTotalTaxDecimal, "labelTotalTaxDecimal");
            this.labelTotalTaxDecimal.Name = "labelTotalTaxDecimal";
            this.labelTotalTaxDecimal.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.labelTotalTaxDecimal.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("labelTotalTaxDecimal.Properties.Appearance.Font")));
            this.labelTotalTaxDecimal.Properties.Appearance.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelTotalTaxDecimal.Properties.Appearance.Options.UseFont = true;
            this.labelTotalTaxDecimal.Properties.Appearance.Options.UseForeColor = true;
            this.labelTotalTaxDecimal.Properties.Appearance.Options.UseTextOptions = true;
            this.labelTotalTaxDecimal.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalTaxDecimal.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.labelTotalTaxDecimal.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("labelTotalTaxDecimal.Properties.Buttons"))))});
            this.labelTotalTaxDecimal.Properties.DisplayFormat.FormatString = "n2";
            this.labelTotalTaxDecimal.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.labelTotalTaxDecimal.Properties.MaskSettings.Set("mask", "n");
            this.labelTotalTaxDecimal.Properties.ReadOnly = true;
            this.labelTotalTaxDecimal.StyleController = this.dataLayConMain;
            // 
            // labelTotalTaxDecimal1
            // 
            this.labelTotalTaxDecimal1.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "TotalPaid", true));
            resources.ApplyResources(this.labelTotalTaxDecimal1, "labelTotalTaxDecimal1");
            this.labelTotalTaxDecimal1.Name = "labelTotalTaxDecimal1";
            this.labelTotalTaxDecimal1.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.labelTotalTaxDecimal1.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("labelTotalTaxDecimal1.Properties.Appearance.Font")));
            this.labelTotalTaxDecimal1.Properties.Appearance.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelTotalTaxDecimal1.Properties.Appearance.Options.UseFont = true;
            this.labelTotalTaxDecimal1.Properties.Appearance.Options.UseForeColor = true;
            this.labelTotalTaxDecimal1.Properties.Appearance.Options.UseTextOptions = true;
            this.labelTotalTaxDecimal1.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalTaxDecimal1.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.labelTotalTaxDecimal1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("labelTotalTaxDecimal1.Properties.Buttons"))))});
            this.labelTotalTaxDecimal1.Properties.DisplayFormat.FormatString = "n2";
            this.labelTotalTaxDecimal1.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.labelTotalTaxDecimal1.Properties.MaskSettings.Set("mask", "n");
            this.labelTotalTaxDecimal1.Properties.ReadOnly = true;
            this.labelTotalTaxDecimal1.StyleController = this.dataLayConMain;
            // 
            // labelTotalTaxDecimal2
            // 
            this.labelTotalTaxDecimal2.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "Remin", true));
            resources.ApplyResources(this.labelTotalTaxDecimal2, "labelTotalTaxDecimal2");
            this.labelTotalTaxDecimal2.Name = "labelTotalTaxDecimal2";
            this.labelTotalTaxDecimal2.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.labelTotalTaxDecimal2.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("labelTotalTaxDecimal2.Properties.Appearance.Font")));
            this.labelTotalTaxDecimal2.Properties.Appearance.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelTotalTaxDecimal2.Properties.Appearance.Options.UseFont = true;
            this.labelTotalTaxDecimal2.Properties.Appearance.Options.UseForeColor = true;
            this.labelTotalTaxDecimal2.Properties.Appearance.Options.UseTextOptions = true;
            this.labelTotalTaxDecimal2.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalTaxDecimal2.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.labelTotalTaxDecimal2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("labelTotalTaxDecimal2.Properties.Buttons"))))});
            this.labelTotalTaxDecimal2.Properties.DisplayFormat.FormatString = "n2";
            this.labelTotalTaxDecimal2.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.labelTotalTaxDecimal2.Properties.MaskSettings.Set("mask", "n");
            this.labelTotalTaxDecimal2.Properties.ReadOnly = true;
            this.labelTotalTaxDecimal2.StyleController = this.dataLayConMain;
            // 
            // NotesTextEdit
            // 
            this.NotesTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "Notes", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.NotesTextEdit, "NotesTextEdit");
            this.NotesTextEdit.Name = "NotesTextEdit";
            this.NotesTextEdit.StyleController = this.dataLayConMain;
            // 
            // spinEditMonyFinal
            // 
            resources.ApplyResources(this.spinEditMonyFinal, "spinEditMonyFinal");
            this.spinEditMonyFinal.Name = "spinEditMonyFinal";
            this.spinEditMonyFinal.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.spinEditMonyFinal.Properties.Appearance.Options.UseFont = true;
            this.spinEditMonyFinal.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEditMonyFinal.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.spinEditMonyFinal.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEditMonyFinal.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("spinEditMonyFinal.Properties.Buttons"))))});
            this.spinEditMonyFinal.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.spinEditMonyFinal.Properties.MaskSettings.Set("mask", "n");
            this.spinEditMonyFinal.Properties.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("spinEditMonyFinal.Properties.UseMaskAsDisplayFormat")));
            this.spinEditMonyFinal.StyleController = this.dataLayConMain;
            this.spinEditMonyFinal.KeyDown += new System.Windows.Forms.KeyEventHandler(this.spinEditMonyFinal_KeyDown);
            // 
            // DscntAmountTextEdit
            // 
            this.DscntAmountTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "DscntAmount", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.DscntAmountTextEdit, "DscntAmountTextEdit");
            this.DscntAmountTextEdit.Name = "DscntAmountTextEdit";
            this.DscntAmountTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.DscntAmountTextEdit.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("DscntAmountTextEdit.Properties.Appearance.Font")));
            this.DscntAmountTextEdit.Properties.Appearance.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.DscntAmountTextEdit.Properties.Appearance.Options.UseFont = true;
            this.DscntAmountTextEdit.Properties.Appearance.Options.UseForeColor = true;
            this.DscntAmountTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.DscntAmountTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.DscntAmountTextEdit.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.DscntAmountTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("DscntAmountTextEdit.Properties.Buttons"))))});
            this.DscntAmountTextEdit.Properties.DisplayFormat.FormatString = "n2";
            this.DscntAmountTextEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.DscntAmountTextEdit.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.DscntAmountTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.DscntAmountTextEdit.Properties.MaskSettings.Set("mask", "n");
            this.DscntAmountTextEdit.StyleController = this.dataLayConMain;
            // 
            // textEditPaidCreditCard
            // 
            this.textEditPaidCreditCard.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "BankAmount", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            resources.ApplyResources(this.textEditPaidCreditCard, "textEditPaidCreditCard");
            this.textEditPaidCreditCard.Name = "textEditPaidCreditCard";
            this.textEditPaidCreditCard.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.textEditPaidCreditCard.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditPaidCreditCard.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            editorButtonImageOptions2.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            editorButtonImageOptions3.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.LeftCenter;
            this.textEditPaidCreditCard.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons"))), resources.GetString("textEditPaidCreditCard.Properties.Buttons1"), ((int)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons2"))), ((bool)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons3"))), ((bool)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons4"))), ((bool)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons5"))), editorButtonImageOptions2, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject5, serializableAppearanceObject6, serializableAppearanceObject7, serializableAppearanceObject8, resources.GetString("textEditPaidCreditCard.Properties.Buttons6"), ((object)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons7"))), ((DevExpress.Utils.SuperToolTip)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons8"))), ((DevExpress.Utils.ToolTipAnchor)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons9")))),
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons10"))), resources.GetString("textEditPaidCreditCard.Properties.Buttons11"), ((int)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons12"))), ((bool)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons13"))), ((bool)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons14"))), ((bool)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons15"))), editorButtonImageOptions3, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject9, serializableAppearanceObject10, serializableAppearanceObject11, serializableAppearanceObject12, resources.GetString("textEditPaidCreditCard.Properties.Buttons16"), ((object)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons17"))), ((DevExpress.Utils.SuperToolTip)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons18"))), ((DevExpress.Utils.ToolTipAnchor)(resources.GetObject("textEditPaidCreditCard.Properties.Buttons19"))))});
            this.textEditPaidCreditCard.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("textEditPaidCreditCard.Properties.Mask.BeepOnError")));
            this.textEditPaidCreditCard.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("textEditPaidCreditCard.Properties.Mask.UseMaskAsDisplayFormat")));
            this.textEditPaidCreditCard.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.textEditPaidCreditCard.Properties.MaskSettings.Set("mask", "n");
            this.textEditPaidCreditCard.StyleController = this.dataLayConMain;
            this.textEditPaidCreditCard.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.textEditPaidCreditCard_ButtonClick);
            // 
            // textEditPaidCash
            // 
            this.textEditPaidCash.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.SupplyMainBindingSource, "paidCash", true));
            resources.ApplyResources(this.textEditPaidCash, "textEditPaidCash");
            this.textEditPaidCash.Name = "textEditPaidCash";
            this.textEditPaidCash.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.textEditPaidCash.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditPaidCash.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.textEditPaidCash.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("textEditPaidCash.Properties.Buttons"))))});
            this.textEditPaidCash.Properties.Mask.BeepOnError = ((bool)(resources.GetObject("textEditPaidCash.Properties.Mask.BeepOnError")));
            this.textEditPaidCash.Properties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("textEditPaidCash.Properties.Mask.UseMaskAsDisplayFormat")));
            this.textEditPaidCash.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.textEditPaidCash.Properties.MaskSettings.Set("mask", "n");
            this.textEditPaidCash.StyleController = this.dataLayConMain;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.labelECR;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 31);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(843, 31);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup3});
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.OptionsCustomization.AllowDrag = DevExpress.XtraLayout.ItemDragDropMode.UseParentOptions;
            this.layoutControlGroup1.OptionsCustomization.AllowDrop = DevExpress.XtraLayout.ItemDragDropMode.UseParentOptions;
            this.layoutControlGroup1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 3, 0);
            this.layoutControlGroup1.Size = new System.Drawing.Size(1419, 805);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AllowDrawBackground = false;
            this.layoutControlGroup3.GroupBordersVisible = false;
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGrooupMain,
            this.layoutControlGroup10,
            this.layoutControlItem3,
            this.layoutControlGroup8,
            this.layoutControlGroup2,
            this.layoutControlGroup5});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup3.Name = "autoGeneratedGroup0";
            this.layoutControlGroup3.Size = new System.Drawing.Size(1419, 805);
            // 
            // layoutControlGrooupMain
            // 
            this.layoutControlGrooupMain.AppearanceGroup.BorderColor = System.Drawing.Color.PowderBlue;
            this.layoutControlGrooupMain.AppearanceGroup.Font = ((System.Drawing.Font)(resources.GetObject("layoutControlGrooupMain.AppearanceGroup.Font")));
            this.layoutControlGrooupMain.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGrooupMain.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGrooupMain.AppearanceItemCaption.Font = ((System.Drawing.Font)(resources.GetObject("layoutControlGrooupMain.AppearanceItemCaption.Font")));
            this.layoutControlGrooupMain.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.layoutControlGrooupMain.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlGrooupMain.AppearanceItemCaption.Options.UseForeColor = true;
            this.layoutControlGrooupMain.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlGrooupMain.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlGrooupMain.ExpandButtonVisible = true;
            this.layoutControlGrooupMain.ExpandOnDoubleClick = true;
            this.layoutControlGrooupMain.GroupStyle = DevExpress.Utils.GroupStyle.Title;
            this.layoutControlGrooupMain.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.ItemForSalesNo,
            this.layoutControlCarData,
            this.ItemForStore,
            this.ItemForDate,
            this.ItemForIsCash,
            this.ItemForsupNo,
            this.ItemForNotes,
            this.ItemForTax,
            this.ItemForRoundTotal,
            this.ItemForBoxNo,
            this.ItemForsupCur,
            this.ItemForCurrencyChng,
            this.ItemForsupDesc,
            this.ItemForPoNumber,
            this.ItemForsupCustNo,
            this.ItemFornotDate});
            this.layoutControlGrooupMain.Location = new System.Drawing.Point(0, 64);
            this.layoutControlGrooupMain.Name = "layoutControlGrooupMain";
            this.layoutControlGrooupMain.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 5, 5);
            this.layoutControlGrooupMain.Size = new System.Drawing.Size(1419, 280);
            resources.ApplyResources(this.layoutControlGrooupMain, "layoutControlGrooupMain");
            // 
            // ItemForSalesNo
            // 
            this.ItemForSalesNo.Control = this.saleNoTextEdit;
            resources.ApplyResources(this.ItemForSalesNo, "ItemForSalesNo");
            this.ItemForSalesNo.Location = new System.Drawing.Point(0, 0);
            this.ItemForSalesNo.Name = "ItemForSalesNo";
            this.ItemForSalesNo.Size = new System.Drawing.Size(1405, 28);
            this.ItemForSalesNo.TextSize = new System.Drawing.Size(121, 23);
            this.ItemForSalesNo.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // layoutControlCarData
            // 
            this.layoutControlCarData.AppearanceGroup.BorderColor = System.Drawing.Color.PowderBlue;
            this.layoutControlCarData.AppearanceGroup.Options.UseBorderColor = true;
            resources.ApplyResources(this.layoutControlCarData, "layoutControlCarData");
            this.layoutControlCarData.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.ItemForCounter,
            this.ItemForCarType,
            this.ItemForPlateNumber});
            this.layoutControlCarData.Location = new System.Drawing.Point(0, 143);
            this.layoutControlCarData.Name = "layoutControlCarData";
            this.layoutControlCarData.Size = new System.Drawing.Size(1405, 87);
            this.layoutControlCarData.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // ItemForCounter
            // 
            this.ItemForCounter.Control = this.textEditCounterNumber;
            this.ItemForCounter.Location = new System.Drawing.Point(0, 0);
            this.ItemForCounter.Name = "ItemForCounter";
            this.ItemForCounter.Size = new System.Drawing.Size(460, 28);
            resources.ApplyResources(this.ItemForCounter, "ItemForCounter");
            this.ItemForCounter.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForCarType
            // 
            this.ItemForCarType.Control = this.textEditCarType;
            this.ItemForCarType.Location = new System.Drawing.Point(920, 0);
            this.ItemForCarType.Name = "ItemForCarType";
            this.ItemForCarType.Size = new System.Drawing.Size(461, 28);
            resources.ApplyResources(this.ItemForCarType, "ItemForCarType");
            this.ItemForCarType.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForPlateNumber
            // 
            this.ItemForPlateNumber.Control = this.textEditPlateNumber;
            this.ItemForPlateNumber.Location = new System.Drawing.Point(460, 0);
            this.ItemForPlateNumber.Name = "ItemForPlateNumber";
            this.ItemForPlateNumber.Size = new System.Drawing.Size(460, 28);
            resources.ApplyResources(this.ItemForPlateNumber, "ItemForPlateNumber");
            this.ItemForPlateNumber.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForStore
            // 
            this.ItemForStore.Control = this.StrIdLookUpEdit;
            resources.ApplyResources(this.ItemForStore, "ItemForStore");
            this.ItemForStore.Location = new System.Drawing.Point(351, 28);
            this.ItemForStore.Name = "ItemForStore";
            this.ItemForStore.Size = new System.Drawing.Size(351, 28);
            this.ItemForStore.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForDate
            // 
            this.ItemForDate.Control = this.DateDateEdit;
            this.ItemForDate.Location = new System.Drawing.Point(0, 28);
            this.ItemForDate.Name = "ItemForDate";
            this.ItemForDate.Size = new System.Drawing.Size(351, 28);
            resources.ApplyResources(this.ItemForDate, "ItemForDate");
            this.ItemForDate.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForIsCash
            // 
            this.ItemForIsCash.Control = this.radioGroupIsCash;
            this.ItemForIsCash.Location = new System.Drawing.Point(702, 28);
            this.ItemForIsCash.MinSize = new System.Drawing.Size(214, 27);
            this.ItemForIsCash.Name = "ItemForIsCash";
            this.ItemForIsCash.Size = new System.Drawing.Size(351, 28);
            this.ItemForIsCash.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            resources.ApplyResources(this.ItemForIsCash, "ItemForIsCash");
            this.ItemForIsCash.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForsupNo
            // 
            this.ItemForsupNo.Control = this.supNoTextEdit;
            this.ItemForsupNo.Location = new System.Drawing.Point(1053, 28);
            this.ItemForsupNo.Name = "ItemForsupNo";
            this.ItemForsupNo.Size = new System.Drawing.Size(352, 28);
            resources.ApplyResources(this.ItemForsupNo, "ItemForsupNo");
            this.ItemForsupNo.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForNotes
            // 
            this.ItemForNotes.Control = this.NotesTextEdit;
            resources.ApplyResources(this.ItemForNotes, "ItemForNotes");
            this.ItemForNotes.Location = new System.Drawing.Point(0, 112);
            this.ItemForNotes.Name = "ItemForNotes";
            this.ItemForNotes.Size = new System.Drawing.Size(702, 31);
            this.ItemForNotes.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForTax
            // 
            this.ItemForTax.Control = this.checkEditTax;
            resources.ApplyResources(this.ItemForTax, "ItemForTax");
            this.ItemForTax.Location = new System.Drawing.Point(1053, 112);
            this.ItemForTax.Name = "ItemForTax";
            this.ItemForTax.Size = new System.Drawing.Size(352, 31);
            this.ItemForTax.TextSize = new System.Drawing.Size(0, 0);
            this.ItemForTax.TextVisible = false;
            // 
            // ItemForRoundTotal
            // 
            this.ItemForRoundTotal.Control = this.checkEdit1;
            resources.ApplyResources(this.ItemForRoundTotal, "ItemForRoundTotal");
            this.ItemForRoundTotal.Location = new System.Drawing.Point(702, 112);
            this.ItemForRoundTotal.Name = "ItemForRoundTotal";
            this.ItemForRoundTotal.Size = new System.Drawing.Size(351, 31);
            this.ItemForRoundTotal.TextSize = new System.Drawing.Size(0, 0);
            this.ItemForRoundTotal.TextVisible = false;
            // 
            // ItemForBoxNo
            // 
            this.ItemForBoxNo.Control = this.BoxNoLookUpEdit;
            this.ItemForBoxNo.Location = new System.Drawing.Point(702, 56);
            this.ItemForBoxNo.Name = "ItemForBoxNo";
            this.ItemForBoxNo.Size = new System.Drawing.Size(703, 28);
            resources.ApplyResources(this.ItemForBoxNo, "ItemForBoxNo");
            this.ItemForBoxNo.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForsupCur
            // 
            this.ItemForsupCur.Control = this.supCurrTextEdit;
            this.ItemForsupCur.Location = new System.Drawing.Point(351, 56);
            this.ItemForsupCur.Name = "ItemForsupCur";
            this.ItemForsupCur.Size = new System.Drawing.Size(351, 28);
            resources.ApplyResources(this.ItemForsupCur, "ItemForsupCur");
            this.ItemForsupCur.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForCurrencyChng
            // 
            this.ItemForCurrencyChng.Control = this.CurrencyChngTextEdit;
            resources.ApplyResources(this.ItemForCurrencyChng, "ItemForCurrencyChng");
            this.ItemForCurrencyChng.Location = new System.Drawing.Point(0, 56);
            this.ItemForCurrencyChng.Name = "ItemForCurrencyChng";
            this.ItemForCurrencyChng.Size = new System.Drawing.Size(351, 28);
            this.ItemForCurrencyChng.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForsupDesc
            // 
            this.ItemForsupDesc.Control = this.supDescTextEdit;
            this.ItemForsupDesc.Location = new System.Drawing.Point(351, 84);
            this.ItemForsupDesc.Name = "ItemForsupDesc";
            this.ItemForsupDesc.Size = new System.Drawing.Size(351, 28);
            resources.ApplyResources(this.ItemForsupDesc, "ItemForsupDesc");
            this.ItemForsupDesc.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForPoNumber
            // 
            this.ItemForPoNumber.Control = this.PoNumberTextEdit;
            this.ItemForPoNumber.Location = new System.Drawing.Point(0, 84);
            this.ItemForPoNumber.Name = "ItemForPoNumber";
            this.ItemForPoNumber.Size = new System.Drawing.Size(351, 28);
            resources.ApplyResources(this.ItemForPoNumber, "ItemForPoNumber");
            this.ItemForPoNumber.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemForsupCustNo
            // 
            this.ItemForsupCustNo.AppearanceItemCaption.BorderColor = System.Drawing.Color.PowderBlue;
            this.ItemForsupCustNo.AppearanceItemCaption.Options.UseBorderColor = true;
            this.ItemForsupCustNo.Control = this.CustNoSearchLookUpEdit;
            this.ItemForsupCustNo.Location = new System.Drawing.Point(1053, 84);
            this.ItemForsupCustNo.Name = "ItemForsupCustNo";
            this.ItemForsupCustNo.Size = new System.Drawing.Size(352, 28);
            resources.ApplyResources(this.ItemForsupCustNo, "ItemForsupCustNo");
            this.ItemForsupCustNo.TextSize = new System.Drawing.Size(121, 23);
            // 
            // ItemFornotDate
            // 
            this.ItemFornotDate.Control = this.notDateTextEdit;
            this.ItemFornotDate.Location = new System.Drawing.Point(702, 84);
            this.ItemFornotDate.Name = "ItemFornotDate";
            this.ItemFornotDate.Size = new System.Drawing.Size(351, 28);
            resources.ApplyResources(this.ItemFornotDate, "ItemFornotDate");
            this.ItemFornotDate.TextSize = new System.Drawing.Size(121, 23);
            // 
            // layoutControlGroup10
            // 
            this.layoutControlGroup10.AppearanceGroup.BorderColor = System.Drawing.Color.PowderBlue;
            this.layoutControlGroup10.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGroup10.ExpandButtonVisible = true;
            this.layoutControlGroup10.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.simpleLabelItem1,
            this.ItemForBarcodeText,
            this.ItemForBtnDeleteRow,
            this.labelItemsCount,
            this.layoutControlItem2});
            this.layoutControlGroup10.Location = new System.Drawing.Point(0, 344);
            this.layoutControlGroup10.Name = "layoutControlGroup10";
            this.layoutControlGroup10.Size = new System.Drawing.Size(1419, 240);
            resources.ApplyResources(this.layoutControlGroup10, "layoutControlGroup10");
            // 
            // simpleLabelItem1
            // 
            this.simpleLabelItem1.AllowHotTrack = false;
            this.simpleLabelItem1.AppearanceItemCaption.Font = ((System.Drawing.Font)(resources.GetObject("simpleLabelItem1.AppearanceItemCaption.Font")));
            this.simpleLabelItem1.AppearanceItemCaption.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Information;
            this.simpleLabelItem1.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem1.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem1.Location = new System.Drawing.Point(0, 0);
            this.simpleLabelItem1.Name = "simpleLabelItem1";
            this.simpleLabelItem1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 23, 3, 3);
            this.simpleLabelItem1.Size = new System.Drawing.Size(465, 32);
            resources.ApplyResources(this.simpleLabelItem1, "simpleLabelItem1");
            this.simpleLabelItem1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.simpleLabelItem1.TextSize = new System.Drawing.Size(162, 23);
            // 
            // ItemForBarcodeText
            // 
            this.ItemForBarcodeText.Control = this.textEditBarcodeNo;
            resources.ApplyResources(this.ItemForBarcodeText, "ItemForBarcodeText");
            this.ItemForBarcodeText.Location = new System.Drawing.Point(930, 0);
            this.ItemForBarcodeText.Name = "ItemForBarcodeText";
            this.ItemForBarcodeText.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 30, 2, 2);
            this.ItemForBarcodeText.Size = new System.Drawing.Size(465, 32);
            this.ItemForBarcodeText.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.ItemForBarcodeText.TextSize = new System.Drawing.Size(79, 18);
            this.ItemForBarcodeText.TextToControlDistance = 5;
            // 
            // ItemForBtnDeleteRow
            // 
            this.ItemForBtnDeleteRow.Control = this.btnDeleteRow;
            resources.ApplyResources(this.ItemForBtnDeleteRow, "ItemForBtnDeleteRow");
            this.ItemForBtnDeleteRow.Location = new System.Drawing.Point(465, 0);
            this.ItemForBtnDeleteRow.Name = "ItemForBtnDeleteRow";
            this.ItemForBtnDeleteRow.Size = new System.Drawing.Size(465, 32);
            this.ItemForBtnDeleteRow.TextSize = new System.Drawing.Size(0, 0);
            this.ItemForBtnDeleteRow.TextVisible = false;
            // 
            // labelItemsCount
            // 
            this.labelItemsCount.AllowHotTrack = false;
            this.labelItemsCount.AppearanceItemCaption.ForeColor = System.Drawing.Color.Green;
            this.labelItemsCount.AppearanceItemCaption.Options.UseFont = true;
            this.labelItemsCount.AppearanceItemCaption.Options.UseForeColor = true;
            resources.ApplyResources(this.labelItemsCount, "labelItemsCount");
            this.labelItemsCount.Location = new System.Drawing.Point(0, 170);
            this.labelItemsCount.Name = "labelItemsCount";
            this.labelItemsCount.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 3, 0);
            this.labelItemsCount.Size = new System.Drawing.Size(1395, 21);
            this.labelItemsCount.TextSize = new System.Drawing.Size(121, 18);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.gridControl;
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 32);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(1395, 138);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.bindingNavigator11;
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(1419, 64);
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // layoutControlGroup8
            // 
            this.layoutControlGroup8.AppearanceGroup.BorderColor = System.Drawing.Color.PowderBlue;
            this.layoutControlGroup8.AppearanceGroup.Font = ((System.Drawing.Font)(resources.GetObject("layoutControlGroup8.AppearanceGroup.Font")));
            this.layoutControlGroup8.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGroup8.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup8.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlGroup8.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlGroup8.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup4});
            this.layoutControlGroup8.Location = new System.Drawing.Point(0, 584);
            this.layoutControlGroup8.Name = "layoutControlGroup8";
            this.layoutControlGroup8.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup8.Size = new System.Drawing.Size(946, 221);
            resources.ApplyResources(this.layoutControlGroup8, "layoutControlGroup8");
            // 
            // layoutControlGroup4
            // 
            this.layoutControlGroup4.AppearanceItemCaption.Font = ((System.Drawing.Font)(resources.GetObject("layoutControlGroup4.AppearanceItemCaption.Font")));
            this.layoutControlGroup4.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlGroup4.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.labelTotalPriceString,
            this.labelTotalString,
            this.labelDiscountString,
            this.labelTotalTaxString,
            this.labelTotalFinalString,
            this.labelTotalTaxString2,
            this.labelTotalTaxString1});
            this.layoutControlGroup4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup4.Name = "layoutControlGroup4";
            this.layoutControlGroup4.Padding = new DevExpress.XtraLayout.Utils.Padding(3, 3, 3, 3);
            this.layoutControlGroup4.Size = new System.Drawing.Size(940, 180);
            this.layoutControlGroup4.TextVisible = false;
            // 
            // labelTotalPriceString
            // 
            this.labelTotalPriceString.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelTotalPriceString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalPriceString.AppearanceItemCaption.Options.UseTextOptions = true;
            this.labelTotalPriceString.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalPriceString.Control = this.labelTotalPriceDecimal;
            resources.ApplyResources(this.labelTotalPriceString, "labelTotalPriceString");
            this.labelTotalPriceString.Location = new System.Drawing.Point(696, 0);
            this.labelTotalPriceString.Name = "labelTotalPriceString";
            this.labelTotalPriceString.Size = new System.Drawing.Size(232, 73);
            this.labelTotalPriceString.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.labelTotalPriceString.TextLocation = DevExpress.Utils.Locations.Top;
            this.labelTotalPriceString.TextSize = new System.Drawing.Size(159, 30);
            this.labelTotalPriceString.TextToControlDistance = 5;
            // 
            // labelTotalString
            // 
            this.labelTotalString.AppearanceItemCaption.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelTotalString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalString.AppearanceItemCaption.Options.UseTextOptions = true;
            this.labelTotalString.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalString.Control = this.labelTotalDecimal;
            resources.ApplyResources(this.labelTotalString, "labelTotalString");
            this.labelTotalString.Location = new System.Drawing.Point(696, 73);
            this.labelTotalString.Name = "labelTotalString";
            this.labelTotalString.Size = new System.Drawing.Size(232, 95);
            this.labelTotalString.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.labelTotalString.TextLocation = DevExpress.Utils.Locations.Top;
            this.labelTotalString.TextSize = new System.Drawing.Size(159, 30);
            this.labelTotalString.TextToControlDistance = 5;
            // 
            // labelDiscountString
            // 
            this.labelDiscountString.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelDiscountString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelDiscountString.AppearanceItemCaption.Options.UseTextOptions = true;
            this.labelDiscountString.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelDiscountString.Control = this.DscntAmountTextEdit;
            resources.ApplyResources(this.labelDiscountString, "labelDiscountString");
            this.labelDiscountString.Location = new System.Drawing.Point(464, 0);
            this.labelDiscountString.Name = "labelDiscountString";
            this.labelDiscountString.Size = new System.Drawing.Size(232, 73);
            this.labelDiscountString.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.labelDiscountString.TextLocation = DevExpress.Utils.Locations.Top;
            this.labelDiscountString.TextSize = new System.Drawing.Size(159, 30);
            this.labelDiscountString.TextToControlDistance = 5;
            // 
            // labelTotalTaxString
            // 
            this.labelTotalTaxString.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelTotalTaxString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalTaxString.AppearanceItemCaption.Options.UseTextOptions = true;
            this.labelTotalTaxString.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalTaxString.Control = this.labelTotalTaxDecimal;
            resources.ApplyResources(this.labelTotalTaxString, "labelTotalTaxString");
            this.labelTotalTaxString.Location = new System.Drawing.Point(464, 73);
            this.labelTotalTaxString.Name = "labelTotalTaxString";
            this.labelTotalTaxString.Size = new System.Drawing.Size(232, 95);
            this.labelTotalTaxString.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.labelTotalTaxString.TextLocation = DevExpress.Utils.Locations.Top;
            this.labelTotalTaxString.TextSize = new System.Drawing.Size(159, 30);
            this.labelTotalTaxString.TextToControlDistance = 5;
            // 
            // labelTotalFinalString
            // 
            this.labelTotalFinalString.AppearanceItemCaption.Font = ((System.Drawing.Font)(resources.GetObject("labelTotalFinalString.AppearanceItemCaption.Font")));
            this.labelTotalFinalString.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelTotalFinalString.AppearanceItemCaption.Options.UseFont = true;
            this.labelTotalFinalString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalFinalString.AppearanceItemCaption.Options.UseTextOptions = true;
            this.labelTotalFinalString.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalFinalString.Control = this.spinEditTotalFinalDecimal;
            this.labelTotalFinalString.Location = new System.Drawing.Point(232, 0);
            this.labelTotalFinalString.Name = "labelTotalFinalString";
            this.labelTotalFinalString.Size = new System.Drawing.Size(232, 168);
            resources.ApplyResources(this.labelTotalFinalString, "labelTotalFinalString");
            this.labelTotalFinalString.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.labelTotalFinalString.TextLocation = DevExpress.Utils.Locations.Top;
            this.labelTotalFinalString.TextSize = new System.Drawing.Size(211, 46);
            this.labelTotalFinalString.TextToControlDistance = 5;
            // 
            // labelTotalTaxString2
            // 
            this.labelTotalTaxString2.AppearanceItemCaption.Options.UseTextOptions = true;
            this.labelTotalTaxString2.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalTaxString2.Control = this.labelTotalTaxDecimal2;
            resources.ApplyResources(this.labelTotalTaxString2, "labelTotalTaxString2");
            this.labelTotalTaxString2.Location = new System.Drawing.Point(0, 71);
            this.labelTotalTaxString2.Name = "labelTotalTaxString2";
            this.labelTotalTaxString2.Size = new System.Drawing.Size(232, 97);
            this.labelTotalTaxString2.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.labelTotalTaxString2.TextLocation = DevExpress.Utils.Locations.Top;
            this.labelTotalTaxString2.TextSize = new System.Drawing.Size(118, 28);
            this.labelTotalTaxString2.TextToControlDistance = 5;
            // 
            // labelTotalTaxString1
            // 
            this.labelTotalTaxString1.AppearanceItemCaption.Options.UseTextOptions = true;
            this.labelTotalTaxString1.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.labelTotalTaxString1.Control = this.labelTotalTaxDecimal1;
            resources.ApplyResources(this.labelTotalTaxString1, "labelTotalTaxString1");
            this.labelTotalTaxString1.Location = new System.Drawing.Point(0, 0);
            this.labelTotalTaxString1.Name = "labelTotalTaxString1";
            this.labelTotalTaxString1.Size = new System.Drawing.Size(232, 71);
            this.labelTotalTaxString1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.labelTotalTaxString1.TextLocation = DevExpress.Utils.Locations.Top;
            this.labelTotalTaxString1.TextSize = new System.Drawing.Size(117, 28);
            this.labelTotalTaxString1.TextToControlDistance = 5;
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.AppearanceGroup.BorderColor = System.Drawing.Color.PowderBlue;
            this.layoutControlGroup2.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGroup2.AppearanceItemCaption.Font = ((System.Drawing.Font)(resources.GetObject("layoutControlGroup2.AppearanceItemCaption.Font")));
            this.layoutControlGroup2.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlGroup2.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlGroup2.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.itemForPaidCreditCard,
            this.ItemForBankId,
            this.itemForPaidCash});
            this.layoutControlGroup2.Location = new System.Drawing.Point(946, 683);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Padding = new DevExpress.XtraLayout.Utils.Padding(3, 3, 3, 3);
            this.layoutControlGroup2.Size = new System.Drawing.Size(473, 122);
            resources.ApplyResources(this.layoutControlGroup2, "layoutControlGroup2");
            // 
            // itemForPaidCreditCard
            // 
            this.itemForPaidCreditCard.Control = this.textEditPaidCreditCard;
            this.itemForPaidCreditCard.Location = new System.Drawing.Point(0, 56);
            this.itemForPaidCreditCard.Name = "itemForPaidCreditCard";
            this.itemForPaidCreditCard.Size = new System.Drawing.Size(461, 29);
            resources.ApplyResources(this.itemForPaidCreditCard, "itemForPaidCreditCard");
            this.itemForPaidCreditCard.TextSize = new System.Drawing.Size(121, 20);
            // 
            // ItemForBankId
            // 
            this.ItemForBankId.Control = this.BankLookUpEdit;
            resources.ApplyResources(this.ItemForBankId, "ItemForBankId");
            this.ItemForBankId.Location = new System.Drawing.Point(0, 28);
            this.ItemForBankId.Name = "ItemForBankId";
            this.ItemForBankId.Size = new System.Drawing.Size(461, 28);
            this.ItemForBankId.TextSize = new System.Drawing.Size(121, 20);
            // 
            // itemForPaidCash
            // 
            this.itemForPaidCash.Control = this.textEditPaidCash;
            resources.ApplyResources(this.itemForPaidCash, "itemForPaidCash");
            this.itemForPaidCash.Location = new System.Drawing.Point(0, 0);
            this.itemForPaidCash.Name = "itemForPaidCash";
            this.itemForPaidCash.Size = new System.Drawing.Size(461, 28);
            this.itemForPaidCash.TextSize = new System.Drawing.Size(121, 20);
            // 
            // layoutControlGroup5
            // 
            this.layoutControlGroup5.AppearanceGroup.BorderColor = System.Drawing.Color.PowderBlue;
            this.layoutControlGroup5.AppearanceGroup.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.layoutControlGroup5.AppearanceGroup.Options.UseBorderColor = true;
            this.layoutControlGroup5.AppearanceGroup.Options.UseForeColor = true;
            this.layoutControlGroup5.AppearanceItemCaption.Font = ((System.Drawing.Font)(resources.GetObject("layoutControlGroup5.AppearanceItemCaption.Font")));
            this.layoutControlGroup5.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlGroup5.AppearanceItemCaption.Options.UseTextOptions = true;
            this.layoutControlGroup5.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.layoutControlGroup5.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.itemForsupDscntPercent,
            this.layoutControlItem5,
            this.layoutControlItem14,
            this.layoutControlItem13});
            this.layoutControlGroup5.Location = new System.Drawing.Point(946, 584);
            this.layoutControlGroup5.Name = "layoutControlGroup5";
            this.layoutControlGroup5.Padding = new DevExpress.XtraLayout.Utils.Padding(3, 3, 3, 3);
            this.layoutControlGroup5.Size = new System.Drawing.Size(473, 99);
            resources.ApplyResources(this.layoutControlGroup5, "layoutControlGroup5");
            // 
            // itemForsupDscntPercent
            // 
            this.itemForsupDscntPercent.Control = this.supDscntPercentTextEdit;
            this.itemForsupDscntPercent.Location = new System.Drawing.Point(139, 0);
            this.itemForsupDscntPercent.Name = "itemForsupDscntPercent";
            this.itemForsupDscntPercent.Size = new System.Drawing.Size(322, 31);
            resources.ApplyResources(this.itemForsupDscntPercent, "itemForsupDscntPercent");
            this.itemForsupDscntPercent.TextSize = new System.Drawing.Size(121, 20);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.spinEditMonyFinal;
            this.layoutControlItem5.Location = new System.Drawing.Point(139, 31);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(322, 31);
            resources.ApplyResources(this.layoutControlItem5, "layoutControlItem5");
            this.layoutControlItem5.TextSize = new System.Drawing.Size(121, 20);
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.BtnAddFraction;
            resources.ApplyResources(this.layoutControlItem14, "layoutControlItem14");
            this.layoutControlItem14.Location = new System.Drawing.Point(0, 31);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(139, 31);
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.BtnDscnFraction;
            resources.ApplyResources(this.layoutControlItem13, "layoutControlItem13");
            this.layoutControlItem13.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(139, 31);
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // dxValidationProvider1
            // 
            this.dxValidationProvider1.ValidateHiddenControls = false;
            // 
            // colBtnBarcode
            // 
            resources.ApplyResources(this.colBtnBarcode, "colBtnBarcode");
            this.colBtnBarcode.ColumnEdit = this.repositoryItemBtnBarcode;
            this.colBtnBarcode.FieldName = "colBtnBarcode";
            this.colBtnBarcode.MinWidth = 25;
            this.colBtnBarcode.Name = "colBtnBarcode";
            // 
            // repositoryItemBtnBarcode
            // 
            resources.ApplyResources(this.repositoryItemBtnBarcode, "repositoryItemBtnBarcode");
            resources.ApplyResources(editorButtonImageOptions1, "editorButtonImageOptions1");
            this.repositoryItemBtnBarcode.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemBtnBarcode.Buttons"))), resources.GetString("repositoryItemBtnBarcode.Buttons1"), ((int)(resources.GetObject("repositoryItemBtnBarcode.Buttons2"))), ((bool)(resources.GetObject("repositoryItemBtnBarcode.Buttons3"))), ((bool)(resources.GetObject("repositoryItemBtnBarcode.Buttons4"))), ((bool)(resources.GetObject("repositoryItemBtnBarcode.Buttons5"))), editorButtonImageOptions1, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, resources.GetString("repositoryItemBtnBarcode.Buttons6"), ((object)(resources.GetObject("repositoryItemBtnBarcode.Buttons7"))), ((DevExpress.Utils.SuperToolTip)(resources.GetObject("repositoryItemBtnBarcode.Buttons8"))), ((DevExpress.Utils.ToolTipAnchor)(resources.GetObject("repositoryItemBtnBarcode.Buttons9"))))});
            this.repositoryItemBtnBarcode.Name = "repositoryItemBtnBarcode";
            this.repositoryItemBtnBarcode.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // UC_AddSaleInvoice
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataLayConMain);
            this.Name = "UC_AddSaleInvoice";
            ((System.ComponentModel.ISupportInitialize)(this.dataLayConMain)).EndInit();
            this.dataLayConMain.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SupplySubBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEditPrdNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditProName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditMeasurment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PrdMeasurmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEditQuan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1SalePrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEditDesc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator11)).EndInit();
            this.bindingNavigator11.ResumeLayout(false);
            this.bindingNavigator11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.supNoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SupplyMainBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.radioGroupIsCash.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditCounterNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPlateNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditCarType.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDescTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DateDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BoxNoLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CurrencyChngTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEditTax.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCurrTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CustNoSearchLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notDateTextEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notDateTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PoNumberTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StrIdLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditBarcodeNo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDscntPercentTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditTotalFinalDecimal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BankLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleNoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SupplyMainBindingSourceEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalPriceDecimal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalDecimal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxDecimal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxDecimal1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxDecimal2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotesTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditMonyFinal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DscntAmountTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPaidCreditCard.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPaidCash.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGrooupMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForSalesNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlCarData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForCounter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForCarType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPlateNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForStore)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForIsCash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForNotes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForTax)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForRoundTotal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBoxNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCur)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForCurrencyChng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupDesc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPoNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCustNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemFornotDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBarcodeText)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBtnDeleteRow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelItemsCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalPriceString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelDiscountString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalFinalString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxString2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxString1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForPaidCreditCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBankId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForPaidCash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForsupDscntPercent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemBtnBarcode)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public DevExpress.XtraDataLayout.DataLayoutControl dataLayConMain;
        public System.Windows.Forms.BindingNavigator bindingNavigator11;
        public System.Windows.Forms.ToolStripButton btnSave;
        public System.Windows.Forms.ToolStripButton btnSaveAndNew;
        public System.Windows.Forms.ToolStripButton btnClose;
        public System.Windows.Forms.ToolStripButton btnReset;
        public System.Windows.Forms.ToolStripButton btnPrintPrevious;
        public System.Windows.Forms.ToolStripButton bbiSelect;
        public System.Windows.Forms.ToolStripButton btnPrdPrice;
        public System.Windows.Forms.ToolStripButton btnEditPrice;
        public System.Windows.Forms.ToolStripButton btnEditQuantity;
        public System.Windows.Forms.ToolStripButton btnSaveAndNewNoPrint;
        public System.Windows.Forms.ToolStripButton btnPaidCreditShortcut;
        private DevExpress.XtraEditors.TextEdit supNoTextEdit;
        private DevExpress.XtraEditors.RadioGroup radioGroupIsCash;
        private DevExpress.XtraEditors.CheckEdit checkEdit1;
        private DevExpress.XtraEditors.TextEdit textEditCounterNumber;
        private DevExpress.XtraEditors.TextEdit textEditPlateNumber;
        private DevExpress.XtraEditors.TextEdit textEditCarType;
        private DevExpress.XtraEditors.TextEdit supDescTextEdit;
        private DevExpress.XtraEditors.DateEdit DateDateEdit;
        private DevExpress.XtraEditors.LookUpEdit BoxNoLookUpEdit;
        private DevExpress.XtraEditors.TextEdit CurrencyChngTextEdit;
        private DevExpress.XtraEditors.CheckEdit checkEditTax;
        private DevExpress.XtraEditors.LookUpEdit supCurrTextEdit;
        private DevExpress.XtraEditors.SearchLookUpEdit CustNoSearchLookUpEdit;
        private DevExpress.XtraGrid.Views.Grid.GridView searchLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn colcustNo1;
        private DevExpress.XtraGrid.Columns.GridColumn colcustName1;
        private DevExpress.XtraGrid.Columns.GridColumn colcustPhnNo1;
        private DevExpress.XtraGrid.Columns.GridColumn colcustCurrency1;
        private DevExpress.XtraEditors.DateEdit notDateTextEdit;
        private DevExpress.XtraEditors.TextEdit PoNumberTextEdit;
        private DevExpress.XtraEditors.LookUpEdit StrIdLookUpEdit;
        private DevExpress.XtraEditors.SimpleButton btnDeleteRow;
        private DevExpress.XtraEditors.SpinEdit supDscntPercentTextEdit;
        private DevExpress.XtraEditors.SimpleButton BtnDscnFraction;
        private DevExpress.XtraEditors.SimpleButton BtnAddFraction;
        private DevExpress.XtraEditors.SpinEdit spinEditTotalFinalDecimal;
        private DevExpress.XtraEditors.LookUpEdit BankLookUpEdit;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlItem ItemForSalesNo;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlCarData;
        private DevExpress.XtraLayout.LayoutControlItem ItemForCounter;
        private DevExpress.XtraLayout.LayoutControlItem ItemForCarType;
        private DevExpress.XtraLayout.LayoutControlItem ItemForPlateNumber;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup10;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem1;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBarcodeText;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBtnDeleteRow;
        private DevExpress.XtraLayout.SimpleLabelItem labelItemsCount;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private System.Windows.Forms.BindingSource SupplyMainBindingSourceEditor;
        private System.Windows.Forms.BindingSource SupplyMainBindingSource;
        private System.Windows.Forms.BindingSource SupplySubBindingSource;
        private System.Windows.Forms.BindingSource ProductBindingSource;
        private System.Windows.Forms.BindingSource PrdMeasurmentBindingSource;
        private DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider dxValidationProvider1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrdNo;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit repositoryItemSearchLookUpEditPrdNo;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemSearchLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn colprdId;
        private DevExpress.XtraGrid.Columns.GridColumn colprdNo;
        private DevExpress.XtraGrid.Columns.GridColumn colprdName;
        private DevExpress.XtraGrid.Columns.GridColumn colprdSalePrice;
        private DevExpress.XtraGrid.Columns.GridColumn colsupMusrName;
        private DevExpress.XtraGrid.Columns.GridColumn colprdGrpNo;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrdName;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditProName;
        private DevExpress.XtraGrid.Columns.GridColumn colMsur;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditMeasurment;
        private DevExpress.XtraGrid.Columns.GridColumn colCurrency;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrice;
        private DevExpress.XtraGrid.Columns.GridColumn colQuanMain;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEditQuan;
        private DevExpress.XtraGrid.Columns.GridColumn colsupSalePrice;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit repositoryItemCalcEdit1SalePrice;
        private DevExpress.XtraGrid.Columns.GridColumn colsupTaxPercent;
        private DevExpress.XtraGrid.Columns.GridColumn colTaxPrice;
        private DevExpress.XtraGrid.Columns.GridColumn colsupDesc;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEditDesc;
        private DevExpress.XtraGrid.Columns.GridColumn colTotalPrice;
        private DevExpress.XtraGrid.Columns.GridColumn colPrdManufacture;
        private DevExpress.XtraGrid.Columns.GridColumn colsupDscntPercent;
        private DevExpress.XtraGrid.Columns.GridColumn colDscntAmount;
        private DevExpress.XtraGrid.Columns.GridColumn colid;
        private DevExpress.XtraGrid.Columns.GridColumn colsupNo;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrdBarcode;
        private DevExpress.XtraGrid.Columns.GridColumn colprdQuanAvlb;
        private DevExpress.XtraGrid.Columns.GridColumn colCount;
        private DevExpress.XtraGrid.Columns.GridColumn colFinalAmount;
        private DevExpress.XtraGrid.Columns.GridColumn colWidth;
        private DevExpress.XtraGrid.Columns.GridColumn colHeight;
        private DevExpress.XtraGrid.Columns.GridColumn colMeter;
        private DevExpress.XtraGrid.Columns.GridColumn col_SubNoPacks;
        private DevExpress.XtraGrid.Columns.GridColumn colsupOvertime;
        private DevExpress.XtraGrid.Columns.GridColumn colsupWorkingtime;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        public DevExpress.XtraGrid.GridControl gridControl;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private DevExpress.XtraEditors.SearchLookUpEdit saleNoTextEdit;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn colStatus;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn colNo;
        private DevExpress.XtraGrid.Columns.GridColumn colDesc;
        private DevExpress.XtraGrid.Columns.GridColumn colTotal;
        private DevExpress.XtraGrid.Columns.GridColumn colDate;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn colNet;
        private DevExpress.XtraGrid.Columns.GridColumn colTotalAfterDiscount;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup8;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup5;
        private DevExpress.XtraLayout.LayoutControlItem itemForsupDscntPercent;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraLayout.LayoutControlItem labelDiscountString;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem labelTotalPriceString;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup4;
        private DevExpress.XtraLayout.LayoutControlItem labelTotalString;
        private DevExpress.XtraLayout.LayoutControlItem labelTotalTaxString;
        private DevExpress.XtraLayout.LayoutControlItem labelTotalFinalString;
        private System.Windows.Forms.Label labelECR;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraEditors.SpinEdit labelTotalPriceDecimal;
        private DevExpress.XtraEditors.SpinEdit labelTotalDecimal;
        private DevExpress.XtraEditors.SpinEdit labelTotalTaxDecimal;
        private DevExpress.XtraEditors.SpinEdit labelTotalTaxDecimal1;
        private DevExpress.XtraEditors.SpinEdit labelTotalTaxDecimal2;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBankId;
        private DevExpress.XtraLayout.LayoutControlItem ItemForTax;
        private DevExpress.XtraLayout.LayoutControlItem ItemForRoundTotal;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupCustNo;
        private DevExpress.XtraLayout.LayoutControlItem ItemForNotes;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupDesc;
        private DevExpress.XtraLayout.LayoutControlItem ItemForPoNumber;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupCur;
        private DevExpress.XtraLayout.LayoutControlItem ItemForCurrencyChng;
        private DevExpress.XtraLayout.LayoutControlItem ItemForStore;
        private DevExpress.XtraLayout.LayoutControlItem ItemForDate;
        private DevExpress.XtraEditors.MemoEdit NotesTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem labelTotalTaxString2;
        private DevExpress.XtraLayout.LayoutControlItem labelTotalTaxString1;
        public DevExpress.XtraEditors.TextEdit textEditBarcodeNo;
        private DevExpress.XtraEditors.CalcEdit spinEditMonyFinal;
        private DevExpress.XtraEditors.CalcEdit DscntAmountTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemForIsCash;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupNo;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBoxNo;
        private DevExpress.XtraLayout.LayoutControlItem itemForPaidCash;
        private DevExpress.XtraEditors.ButtonEdit textEditPaidCreditCard;
        private DevExpress.XtraEditors.CalcEdit textEditPaidCash;
        private DevExpress.XtraLayout.LayoutControlItem itemForPaidCreditCard;
        private DevExpress.XtraLayout.LayoutControlItem ItemFornotDate;
        public DevExpress.XtraLayout.LayoutControlGroup layoutControlGrooupMain;
        public System.Windows.Forms.ToolStripButton btnPdfPrevious;
        public System.Windows.Forms.ToolStripButton btnXslPrevious;
        private DevExpress.XtraGrid.Columns.GridColumn colIsCash;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraGrid.Columns.GridColumn colBtnBarcode;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemBtnBarcode;
    }
}
