﻿namespace PosFinalCost
{
    partial class UCuserRight
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode2 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule2 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            this.gridViewD = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colName1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCaption1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.controlDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.colCaptionEn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colNo1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridControl4 = new DevExpress.XtraGrid.GridControl();
            this.userControlTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewM = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCaption = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCaptionEn = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemLookUpEdit11 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemLookUpEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.tblRoleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.splitContainerControl1 = new DevExpress.XtraEditors.SplitContainerControl();
            this.splitterControl1 = new DevExpress.XtraEditors.SplitterControl();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.tblUserBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colfkUserId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridControl = new DevExpress.XtraGrid.GridControl();
            this.gridView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colrolId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colrolName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dataLayoutControl2 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.RoleControlTblBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colrcId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colfkRoleId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colfkucNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colfkControlId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGridUpdate = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGridView = new DevExpress.XtraLayout.LayoutControlItem();
            this.dxValidationProvider1 = new DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider(this.components);
            this.dxValidationProvider11 = new DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider(this.components);
            this.dataLayoutControl1 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.RolNameTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroupRole = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.dxValidationProvider12 = new DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.controlDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userControlTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblRoleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).BeginInit();
            this.splitContainerControl1.Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).BeginInit();
            this.splitContainerControl1.Panel2.SuspendLayout();
            this.splitContainerControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl2)).BeginInit();
            this.dataLayoutControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RoleControlTblBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGridUpdate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).BeginInit();
            this.dataLayoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RolNameTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroupRole)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider12)).BeginInit();
            this.SuspendLayout();
            // 
            // gridViewD
            // 
            this.gridViewD.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Navy;
            this.gridViewD.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridViewD.Appearance.Row.BackColor = System.Drawing.Color.FloralWhite;
            this.gridViewD.Appearance.Row.BackColor2 = System.Drawing.Color.WhiteSmoke;
            this.gridViewD.Appearance.Row.Options.UseBackColor = true;
            this.gridViewD.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colName1,
            this.colCaption1,
            this.colCaptionEn1,
            this.colID,
            this.colNo1});
            this.gridViewD.DetailHeight = 485;
            this.gridViewD.GridControl = this.gridControl4;
            this.gridViewD.Name = "gridViewD";
            this.gridViewD.OptionsBehavior.ReadOnly = true;
            this.gridViewD.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.gridViewD.OptionsSelection.MultiSelect = true;
            this.gridViewD.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            this.gridViewD.OptionsView.ShowColumnHeaders = false;
            this.gridViewD.OptionsView.ShowGroupPanel = false;
            // 
            // colName1
            // 
            this.colName1.FieldName = "Name";
            this.colName1.MinWidth = 25;
            this.colName1.Name = "colName1";
            this.colName1.Width = 94;
            // 
            // colCaption1
            // 
            this.colCaption1.AppearanceHeader.BackColor = DevExpress.LookAndFeel.DXSkinColors.FillColors.Primary;
            this.colCaption1.AppearanceHeader.Options.UseBackColor = true;
            this.colCaption1.Caption = "إذن الصلاحية";
            this.colCaption1.ColumnEdit = this.repositoryItemLookUpEdit1;
            this.colCaption1.FieldName = "ControlDataID";
            this.colCaption1.MinWidth = 25;
            this.colCaption1.Name = "colCaption1";
            this.colCaption1.Visible = true;
            this.colCaption1.VisibleIndex = 1;
            this.colCaption1.Width = 94;
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.DataSource = this.controlDataBindingSource;
            this.repositoryItemLookUpEdit1.DisplayMember = "Caption";
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            this.repositoryItemLookUpEdit1.NullText = "";
            this.repositoryItemLookUpEdit1.ValueMember = "ID";
            // 
            // controlDataBindingSource
            // 
            this.controlDataBindingSource.DataSource = typeof(PosFinalCost.ControlData);
            // 
            // colCaptionEn1
            // 
            this.colCaptionEn1.Caption = "Role Authorization";
            this.colCaptionEn1.FieldName = "CaptionEn";
            this.colCaptionEn1.MinWidth = 25;
            this.colCaptionEn1.Name = "colCaptionEn1";
            this.colCaptionEn1.Width = 94;
            // 
            // colID
            // 
            this.colID.FieldName = "ID";
            this.colID.MinWidth = 25;
            this.colID.Name = "colID";
            this.colID.Width = 94;
            // 
            // colNo1
            // 
            this.colNo1.FieldName = "No";
            this.colNo1.MinWidth = 25;
            this.colNo1.Name = "colNo1";
            this.colNo1.Width = 94;
            // 
            // gridControl4
            // 
            this.gridControl4.DataSource = this.userControlTblBindingSource;
            this.gridControl4.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            gridLevelNode2.LevelTemplate = this.gridViewD;
            gridLevelNode2.RelationName = "ControlTbls";
            this.gridControl4.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode2});
            this.gridControl4.Location = new System.Drawing.Point(2, 2);
            this.gridControl4.MainView = this.gridViewM;
            this.gridControl4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControl4.Name = "gridControl4";
            this.gridControl4.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemLookUpEdit11,
            this.repositoryItemLookUpEdit2,
            this.repositoryItemLookUpEdit1});
            this.gridControl4.Size = new System.Drawing.Size(867, 259);
            this.gridControl4.TabIndex = 0;
            this.gridControl4.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewM,
            this.gridViewD});
            // 
            // userControlTblBindingSource
            // 
            this.userControlTblBindingSource.DataSource = typeof(PosFinalCost.UserControlTbl);
            // 
            // gridViewM
            // 
            this.gridViewM.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.gridViewM.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.gridViewM.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridViewM.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridViewM.Appearance.Row.Options.UseTextOptions = true;
            this.gridViewM.Appearance.Row.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridViewM.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colNo,
            this.colName,
            this.colCaption,
            this.colCaptionEn});
            this.gridViewM.DetailHeight = 485;
            this.gridViewM.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
            this.gridViewM.GridControl = this.gridControl4;
            this.gridViewM.Name = "gridViewM";
            this.gridViewM.OptionsBehavior.AllowGroupExpandAnimation = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewM.OptionsBehavior.AllowSortAnimation = DevExpress.Utils.DefaultBoolean.True;
            this.gridViewM.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridViewM.OptionsBehavior.Editable = false;
            this.gridViewM.OptionsBehavior.ReadOnly = true;
            this.gridViewM.OptionsDetail.ShowDetailTabs = false;
            this.gridViewM.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridViewM.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            this.gridViewM.OptionsView.AnimationType = DevExpress.XtraGrid.Views.Base.GridAnimationType.AnimateAllContent;
            this.gridViewM.OptionsView.ShowGroupPanel = false;
            this.gridViewM.RowHeight = 32;
            // 
            // colNo
            // 
            this.colNo.FieldName = "No";
            this.colNo.MinWidth = 25;
            this.colNo.Name = "colNo";
            this.colNo.Width = 94;
            // 
            // colName
            // 
            this.colName.FieldName = "Name";
            this.colName.MinWidth = 25;
            this.colName.Name = "colName";
            this.colName.Width = 94;
            // 
            // colCaption
            // 
            this.colCaption.Caption = "اسم الشاشة";
            this.colCaption.FieldName = "Caption";
            this.colCaption.MinWidth = 25;
            this.colCaption.Name = "colCaption";
            this.colCaption.Visible = true;
            this.colCaption.VisibleIndex = 0;
            this.colCaption.Width = 94;
            // 
            // colCaptionEn
            // 
            this.colCaptionEn.FieldName = "CaptionEn";
            this.colCaptionEn.MinWidth = 25;
            this.colCaptionEn.Name = "colCaptionEn";
            this.colCaptionEn.Width = 94;
            // 
            // repositoryItemLookUpEdit11
            // 
            this.repositoryItemLookUpEdit11.AutoHeight = false;
            this.repositoryItemLookUpEdit11.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit11.DisplayMember = "Name";
            this.repositoryItemLookUpEdit11.Name = "repositoryItemLookUpEdit11";
            this.repositoryItemLookUpEdit11.NullText = "";
            this.repositoryItemLookUpEdit11.ReadOnly = true;
            this.repositoryItemLookUpEdit11.ValueMember = "ID";
            // 
            // repositoryItemLookUpEdit2
            // 
            this.repositoryItemLookUpEdit2.AutoHeight = false;
            this.repositoryItemLookUpEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit2.DisplayMember = "Caption";
            this.repositoryItemLookUpEdit2.Name = "repositoryItemLookUpEdit2";
            this.repositoryItemLookUpEdit2.NullText = "";
            this.repositoryItemLookUpEdit2.ReadOnly = true;
            this.repositoryItemLookUpEdit2.ValueMember = "No";
            // 
            // tblRoleBindingSource
            // 
            this.tblRoleBindingSource.DataSource = typeof(PosFinalCost.RoleTbl);
            // 
            // splitContainerControl1
            // 
            this.splitContainerControl1.Location = new System.Drawing.Point(12, 62);
            this.splitContainerControl1.Name = "splitContainerControl1";
            // 
            // splitContainerControl1.Panel1
            // 
            this.splitContainerControl1.Panel1.Controls.Add(this.splitterControl1);
            this.splitContainerControl1.Panel1.Controls.Add(this.gridControl2);
            this.splitContainerControl1.Panel1.Controls.Add(this.gridControl);
            this.splitContainerControl1.Panel1.Text = "Panel1";
            // 
            // splitContainerControl1.Panel2
            // 
            this.splitContainerControl1.Panel2.Controls.Add(this.dataLayoutControl2);
            this.splitContainerControl1.Panel2.Text = "Panel2";
            this.splitContainerControl1.ShowSplitGlyph = DevExpress.Utils.DefaultBoolean.True;
            this.splitContainerControl1.Size = new System.Drawing.Size(1200, 594);
            this.splitContainerControl1.SplitterPosition = 317;
            this.splitContainerControl1.TabIndex = 4;
            this.splitContainerControl1.Text = "splitContainerControl1";
            // 
            // splitterControl1
            // 
            this.splitterControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitterControl1.Location = new System.Drawing.Point(0, 336);
            this.splitterControl1.Name = "splitterControl1";
            this.splitterControl1.ShowSplitGlyph = DevExpress.Utils.DefaultBoolean.True;
            this.splitterControl1.Size = new System.Drawing.Size(317, 12);
            this.splitterControl1.TabIndex = 1;
            this.splitterControl1.TabStop = false;
            // 
            // gridControl2
            // 
            this.gridControl2.DataSource = this.tblUserBindingSource;
            this.gridControl2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gridControl2.Location = new System.Drawing.Point(0, 348);
            this.gridControl2.MainView = this.gridView2;
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.Size = new System.Drawing.Size(317, 246);
            this.gridControl2.TabIndex = 0;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // tblUserBindingSource
            // 
            this.tblUserBindingSource.DataSource = typeof(PosFinalCost.UserTbl);
            // 
            // gridView2
            // 
            this.gridView2.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.gridView2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.gridView2.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colfkUserId});
            this.gridView2.DetailHeight = 431;
            this.gridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
            this.gridView2.GridControl = this.gridControl2;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsBehavior.Editable = false;
            this.gridView2.OptionsBehavior.ReadOnly = true;
            this.gridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            this.gridView2.OptionsView.ShowIndicator = false;
            // 
            // colfkUserId
            // 
            this.colfkUserId.AppearanceCell.Options.UseTextOptions = true;
            this.colfkUserId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colfkUserId.Caption = "المستخدمين";
            this.colfkUserId.FieldName = "Name";
            this.colfkUserId.MinWidth = 23;
            this.colfkUserId.Name = "colfkUserId";
            this.colfkUserId.Visible = true;
            this.colfkUserId.VisibleIndex = 0;
            this.colfkUserId.Width = 87;
            // 
            // gridControl
            // 
            this.gridControl.DataSource = this.tblRoleBindingSource;
            this.gridControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControl.Location = new System.Drawing.Point(0, 0);
            this.gridControl.MainView = this.gridView;
            this.gridControl.Name = "gridControl";
            this.gridControl.Size = new System.Drawing.Size(317, 594);
            this.gridControl.TabIndex = 6;
            this.gridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView});
            // 
            // gridView
            // 
            this.gridView.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.gridView.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.gridView.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.gridView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colrolId,
            this.colrolName});
            this.gridView.DetailHeight = 431;
            this.gridView.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
            this.gridView.GridControl = this.gridControl;
            this.gridView.Name = "gridView";
            this.gridView.OptionsBehavior.Editable = false;
            this.gridView.OptionsBehavior.ReadOnly = true;
            this.gridView.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView.OptionsView.ShowGroupPanel = false;
            this.gridView.OptionsView.ShowIndicator = false;
            // 
            // colrolId
            // 
            this.colrolId.FieldName = "ID";
            this.colrolId.MinWidth = 23;
            this.colrolId.Name = "colrolId";
            this.colrolId.Width = 87;
            // 
            // colrolName
            // 
            this.colrolName.Caption = "الصلاحيات";
            this.colrolName.FieldName = "Name";
            this.colrolName.MinWidth = 23;
            this.colrolName.Name = "colrolName";
            this.colrolName.Visible = true;
            this.colrolName.VisibleIndex = 0;
            this.colrolName.Width = 87;
            // 
            // dataLayoutControl2
            // 
            this.dataLayoutControl2.Controls.Add(this.gridControl1);
            this.dataLayoutControl2.Controls.Add(this.gridControl4);
            this.dataLayoutControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataLayoutControl2.Location = new System.Drawing.Point(0, 0);
            this.dataLayoutControl2.Name = "dataLayoutControl2";
            this.dataLayoutControl2.OptionsView.RightToLeftMirroringApplied = true;
            this.dataLayoutControl2.Root = this.layoutControlGroup1;
            this.dataLayoutControl2.Size = new System.Drawing.Size(871, 594);
            this.dataLayoutControl2.TabIndex = 1;
            this.dataLayoutControl2.Text = "dataLayoutControl2";
            // 
            // gridControl1
            // 
            this.gridControl1.DataSource = this.RoleControlTblBindingSource;
            this.gridControl1.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControl1.Location = new System.Drawing.Point(2, 265);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(867, 327);
            this.gridControl1.TabIndex = 4;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // RoleControlTblBindingSource
            // 
            this.RoleControlTblBindingSource.DataSource = typeof(PosFinalCost.RoleControlTbl);
            // 
            // gridView1
            // 
            this.gridView1.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.gridView1.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.gridView1.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView1.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.UltraFlat;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colrcId,
            this.colfkRoleId,
            this.colfkucNo,
            this.colfkControlId});
            this.gridView1.DetailHeight = 485;
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.GroupCount = 1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridView1.OptionsBehavior.Editable = false;
            this.gridView1.OptionsBehavior.ReadOnly = true;
            this.gridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.OptionsView.ShowIndicator = false;
            this.gridView1.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colfkucNo, DevExpress.Data.ColumnSortOrder.Ascending)});
            // 
            // colrcId
            // 
            this.colrcId.FieldName = "ID";
            this.colrcId.MinWidth = 26;
            this.colrcId.Name = "colrcId";
            this.colrcId.OptionsColumn.ShowInCustomizationForm = false;
            this.colrcId.Width = 99;
            // 
            // colfkRoleId
            // 
            this.colfkRoleId.AppearanceCell.Options.UseTextOptions = true;
            this.colfkRoleId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colfkRoleId.FieldName = "RoleId";
            this.colfkRoleId.MinWidth = 26;
            this.colfkRoleId.Name = "colfkRoleId";
            this.colfkRoleId.OptionsColumn.ShowInCustomizationForm = false;
            this.colfkRoleId.Width = 99;
            // 
            // colfkucNo
            // 
            this.colfkucNo.AppearanceCell.Options.UseTextOptions = true;
            this.colfkucNo.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colfkucNo.Caption = "شاشة";
            this.colfkucNo.FieldName = "No";
            this.colfkucNo.MinWidth = 26;
            this.colfkucNo.Name = "colfkucNo";
            this.colfkucNo.Visible = true;
            this.colfkucNo.VisibleIndex = 1;
            this.colfkucNo.Width = 99;
            // 
            // colfkControlId
            // 
            this.colfkControlId.AppearanceCell.Options.UseTextOptions = true;
            this.colfkControlId.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colfkControlId.Caption = "إذن الصلاحية";
            this.colfkControlId.FieldName = "ControlId";
            this.colfkControlId.MinWidth = 26;
            this.colfkControlId.Name = "colfkControlId";
            this.colfkControlId.Visible = true;
            this.colfkControlId.VisibleIndex = 0;
            this.colfkControlId.Width = 99;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGridUpdate,
            this.layoutControlGridView});
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup1.Size = new System.Drawing.Size(871, 594);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlGridUpdate
            // 
            this.layoutControlGridUpdate.Control = this.gridControl4;
            this.layoutControlGridUpdate.ControlAlignment = System.Drawing.ContentAlignment.TopRight;
            this.layoutControlGridUpdate.CustomizationFormText = "layoutControlItem2";
            this.layoutControlGridUpdate.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGridUpdate.Name = "layoutControlGridUpdate";
            this.layoutControlGridUpdate.Size = new System.Drawing.Size(871, 263);
            this.layoutControlGridUpdate.Text = "layoutControlItem2";
            this.layoutControlGridUpdate.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlGridUpdate.TextVisible = false;
            this.layoutControlGridUpdate.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // layoutControlGridView
            // 
            this.layoutControlGridView.Control = this.gridControl1;
            this.layoutControlGridView.Location = new System.Drawing.Point(0, 263);
            this.layoutControlGridView.Name = "layoutControlGridView";
            this.layoutControlGridView.Size = new System.Drawing.Size(871, 331);
            this.layoutControlGridView.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlGridView.TextVisible = false;
            // 
            // dataLayoutControl1
            // 
            this.dataLayoutControl1.Controls.Add(this.splitContainerControl1);
            this.dataLayoutControl1.Controls.Add(this.RolNameTextEdit);
            this.dataLayoutControl1.DataSource = this.tblRoleBindingSource;
            this.dataLayoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataLayoutControl1.Location = new System.Drawing.Point(5, 65);
            this.dataLayoutControl1.Name = "dataLayoutControl1";
            this.dataLayoutControl1.OptionsView.RightToLeftMirroringApplied = true;
            this.dataLayoutControl1.Root = this.Root;
            this.dataLayoutControl1.Size = new System.Drawing.Size(1224, 668);
            this.dataLayoutControl1.TabIndex = 6;
            this.dataLayoutControl1.Text = "dataLayoutControl1";
            // 
            // RolNameTextEdit
            // 
            this.RolNameTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblRoleBindingSource, "Name", true));
            this.RolNameTextEdit.Location = new System.Drawing.Point(24, 24);
            this.RolNameTextEdit.Name = "RolNameTextEdit";
            this.RolNameTextEdit.Size = new System.Drawing.Size(1078, 22);
            this.RolNameTextEdit.StyleController = this.dataLayoutControl1;
            this.RolNameTextEdit.TabIndex = 9;
            conditionValidationRule2.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule2.ErrorText = "يجب ادخال هذا الحقل";
            this.dxValidationProvider12.SetValidationRule(this.RolNameTextEdit, conditionValidationRule2);
            // 
            // Root
            // 
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlGroupRole});
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(1224, 668);
            this.Root.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.splitContainerControl1;
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(1204, 598);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // layoutControlGroupRole
            // 
            this.layoutControlGroupRole.CustomizationFormText = "layoutControlGroupRole";
            this.layoutControlGroupRole.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem4});
            this.layoutControlGroupRole.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroupRole.Name = "layoutControlGroupRole";
            this.layoutControlGroupRole.OptionsItemText.TextToControlDistance = 3;
            this.layoutControlGroupRole.Size = new System.Drawing.Size(1204, 50);
            this.layoutControlGroupRole.TextVisible = false;
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.RolNameTextEdit;
            this.layoutControlItem4.ControlAlignment = System.Drawing.ContentAlignment.TopRight;
            this.layoutControlItem4.CustomizationFormText = "اسم الصلاحية:";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(1180, 26);
            this.layoutControlItem4.Text = "اسم الصلاحية:";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(86, 17);
            // 
            // UCuserRight
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dataLayoutControl1);
            this.Name = "UCuserRight";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Size = new System.Drawing.Size(1234, 738);
            this.Controls.SetChildIndex(this.dataLayoutControl1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.gridViewD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.controlDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userControlTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblRoleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel1)).EndInit();
            this.splitContainerControl1.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1.Panel2)).EndInit();
            this.splitContainerControl1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerControl1)).EndInit();
            this.splitContainerControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblUserBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl2)).EndInit();
            this.dataLayoutControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RoleControlTblBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGridUpdate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).EndInit();
            this.dataLayoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.RolNameTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroupRole)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private DevExpress.XtraEditors.SplitContainerControl splitContainerControl1;
        private System.Windows.Forms.BindingSource tblRoleBindingSource;
        private System.Windows.Forms.BindingSource RoleControlTblBindingSource;
        private DevExpress.XtraGrid.GridControl gridControl;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView;
        private DevExpress.XtraGrid.Columns.GridColumn colrolId;
        private DevExpress.XtraGrid.Columns.GridColumn colrolName;
        private DevExpress.XtraEditors.SplitterControl splitterControl1;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private System.Windows.Forms.BindingSource tblUserBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colfkUserId;
        private DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider dxValidationProvider1;
        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider dxValidationProvider11;
        private System.Windows.Forms.BindingSource userControlTblBindingSource;
        private DevExpress.XtraGrid.GridControl gridControl4;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewD;
        private DevExpress.XtraGrid.Columns.GridColumn colName1;
        private DevExpress.XtraGrid.Columns.GridColumn colCaption1;
        private DevExpress.XtraGrid.Columns.GridColumn colCaptionEn1;
        private DevExpress.XtraGrid.Columns.GridColumn colID;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewM;
        private DevExpress.XtraGrid.Columns.GridColumn colNo;
        private DevExpress.XtraGrid.Columns.GridColumn colName;
        private DevExpress.XtraGrid.Columns.GridColumn colCaption;
        private DevExpress.XtraGrid.Columns.GridColumn colCaptionEn;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit11;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlGridUpdate;
        private DevExpress.XtraGrid.Columns.GridColumn colNo1;
        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraEditors.TextEdit RolNameTextEdit;
        private DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider dxValidationProvider12;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroupRole;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn colrcId;
        private DevExpress.XtraGrid.Columns.GridColumn colfkRoleId;
        private DevExpress.XtraGrid.Columns.GridColumn colfkucNo;
        private DevExpress.XtraGrid.Columns.GridColumn colfkControlId;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlGridView;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
        private System.Windows.Forms.BindingSource controlDataBindingSource;
    }
  
}
