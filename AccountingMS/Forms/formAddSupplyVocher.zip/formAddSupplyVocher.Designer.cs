﻿namespace AccountingMS
{
    partial class formAddSupplyVoucher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formAddSupplyVoucher));
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule1 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule2 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule3 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule4 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule5 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule6 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule conditionValidationRule7 = new DevExpress.XtraEditors.DXErrorProvider.ConditionValidationRule();
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            DevExpress.XtraEditors.Controls.EditorButtonImageOptions editorButtonImageOptions1 = new DevExpress.XtraEditors.Controls.EditorButtonImageOptions();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject3 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject4 = new DevExpress.Utils.SerializableAppearanceObject();
            this.dataLayoutControl1 = new DevExpress.XtraDataLayout.DataLayoutControl();
            this.checkEdit1 = new DevExpress.XtraEditors.CheckEdit();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barCheckItem1 = new DevExpress.XtraBars.BarCheckItem();
            this.radioGroupIsCash = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemRadioGroupIsCash = new DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup();
            this.bbiEditQuantity = new DevExpress.XtraBars.BarButtonItem();
            this.bbiEditPrice = new DevExpress.XtraBars.BarButtonItem();
            this.bbiSaveAndNew = new DevExpress.XtraBars.BarButtonItem();
            this.bsiCustomer = new DevExpress.XtraBars.BarStaticItem();
            this.bbiCustomerSLEeee = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemSearchLookUpEditCustomerBbi = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.gridViewCustomerSLE = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colcstId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustPhnNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.bbiReset = new DevExpress.XtraBars.BarButtonItem();
            this.bbiPrdPrice = new DevExpress.XtraBars.BarButtonItem();
            this.bbiNewInvoice = new DevExpress.XtraBars.BarStaticItem();
            this.bbiRibbonStyle = new DevExpress.XtraBars.BarButtonItem();
            this.bbiUpdateInvvoice = new DevExpress.XtraBars.BarButtonItem();
            this.bbiStrIdSLE = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemLookUpEditStrId = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.tblStoreBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bsiStrName = new DevExpress.XtraBars.BarStaticItem();
            this.bbiSaveAndNewNoPrint = new DevExpress.XtraBars.BarButtonItem();
            this.bsiPaidCreditShortcut = new DevExpress.XtraBars.BarStaticItem();
            this.bbiCustomers = new DevExpress.XtraBars.BarButtonItem();
            this.bbiRefreshCustomers = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.bbiPriceOffer = new DevExpress.XtraBars.BarButtonItem();
            this.btn_Calculator = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barEditItem2 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.bbiCustomerSLE = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemLookUpEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.tblCustomerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupStrId = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupCustomerInv = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupUpdateInvoice = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupShortcuts = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroupRibbonView = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.repositoryItemRadioGroup1 = new DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup();
            this.repositoryItemRadioGroup2 = new DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup();
            this.risLookUpEditInvoiceId = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.tblSupplyMainBindingSourceEditor = new System.Windows.Forms.BindingSource(this.components);
            this.gridViewInvoiceId = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colid1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupAccName1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupNo1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupTotal = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupDate = new DevExpress.XtraGrid.Columns.GridColumn();
            this.textEditCounterNumber = new DevExpress.XtraEditors.TextEdit();
            this.tblSupplyMainBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textEditPlateNumber = new DevExpress.XtraEditors.TextEdit();
            this.textEditCarType = new DevExpress.XtraEditors.TextEdit();
            this.separatorControl1 = new DevExpress.XtraEditors.SeparatorControl();
            this.supNoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.supRefNoTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.supDescTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.supDateDateEdit = new DevExpress.XtraEditors.DateEdit();
            this.supAccNoLookUpEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.supAccNameTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.supCustName = new DevExpress.XtraEditors.TextEdit();
            this.saleNoTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.supCurrencyChngTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.checkEditTax = new DevExpress.XtraEditors.CheckEdit();
            this.supCurrTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.tblCurrencyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.supCustNo = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.searchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colcustNo1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustName1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustPhnNo1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colcustCurrency1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.notDateTextEdit = new DevExpress.XtraEditors.DateEdit();
            this.PoNumberTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.NotesTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.RepNameTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup3 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGrooupMain = new DevExpress.XtraLayout.LayoutControlGroup();
            this.ItemForsupAccNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupAccName = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupCustNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupCustName = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupDesc = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForSalesNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupRefNo = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupDate = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupCur = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupCurrencyChng = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlCarData = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemFornotDate = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForNotes = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForPoNumber = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.ItemForrepName = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.textEditBarcodeNo = new DevExpress.XtraEditors.TextEdit();
            this.gridControl = new DevExpress.XtraGrid.GridControl();
            this.tblSupplySubBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridView = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colsupPrdNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSearchLookUpEditPrdNo = new DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit();
            this.tblProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.repositoryItemSearchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colprdId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdSalePrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdNameEng = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdGrpNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupPrdName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupMsur = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupCurrency = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupPrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupQuanMain = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEditQuan = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.colsupSalePrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCalcEdit1SalePrice = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.colsupTaxPercent = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupTaxPrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupDesc = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEditDesc = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.colsupTotalPrice = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupPrdManufacture = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupDscntPercent = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupDscntAmount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupPrdId = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colid = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupAccNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupNo = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupPrdBarcode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupAccName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdQuanAvlb = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colFinalAmount = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWidth = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colHeight = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMeter = new DevExpress.XtraGrid.Columns.GridColumn();
            this.col_SubNoPacks = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupOvertime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colsupWorkingtime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridBtnBarcode = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnBarCodeInv = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.repositoryItemLookUpEditMeasurment = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.tblPrdPriceMeasurmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnDeleteRow = new DevExpress.XtraEditors.SimpleButton();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelItemsCount = new DevExpress.XtraLayout.SimpleLabelItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.simpleLabelItem1 = new DevExpress.XtraLayout.SimpleLabelItem();
            this.ItemForBarcodeText = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.ItemForBtnDeleteRow = new DevExpress.XtraLayout.LayoutControlItem();
            this.tblSupplyMainInvoiceIdBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.dxValidationProvider1 = new DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider(this.components);
            this.layoutControl2 = new DevExpress.XtraLayout.LayoutControl();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.spinEditTotalFinalDecimal = new DevExpress.XtraEditors.SpinEdit();
            this.textEditPaidCash = new DevExpress.XtraEditors.TextEdit();
            this.supBankIdTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.supDscntPercentTextEdit = new DevExpress.XtraEditors.SpinEdit();
            this.supDscntAmountTextEdit = new DevExpress.XtraEditors.TextEdit();
            this.textEditPaidCreditCard = new DevExpress.XtraEditors.TextEdit();
            this.txtdisround = new DevExpress.XtraEditors.ButtonEdit();
            this.btnECRsend = new DevExpress.XtraEditors.SimpleButton();
            this.btnECRcancel = new DevExpress.XtraEditors.SimpleButton();
            this.spinEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.supBoxIdTextEdit = new DevExpress.XtraEditors.LookUpEdit();
            this.layoutControlDescount = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup6 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup5 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.itemForsupDscntPercent = new DevExpress.XtraLayout.LayoutControlItem();
            this.itemForsupDscntAmount = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup9 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.itemForPaidCreditCard = new DevExpress.XtraLayout.LayoutControlItem();
            this.itemForPaidCash = new DevExpress.XtraLayout.LayoutControlItem();
            this.ItemForsupBankId = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.labelECR = new DevExpress.XtraLayout.SimpleLabelItem();
            this.ItemForsupBankId1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup7 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlGroup8 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.labelTotalPriceString = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelTotalTaxString = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelTotalPriceDecimal = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelTotalTaxDecimal = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelTotalFinalString = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelPaidAmountString = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelPaidAmountDecimal = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelRemaingAmountString = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelRemaingAmountDecimal = new DevExpress.XtraLayout.SimpleLabelItem();
            this.simpleSeparator1 = new DevExpress.XtraLayout.SimpleSeparator();
            this.labelDiscountString = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelDiscountDecimal = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelTotalString = new DevExpress.XtraLayout.SimpleLabelItem();
            this.labelTotalDecimal = new DevExpress.XtraLayout.SimpleLabelItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.tblSupplySubDescountBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblAccountBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.flyoutPanel1 = new DevExpress.Utils.FlyoutPanel();
            this.layoutControl3 = new DevExpress.XtraLayout.LayoutControl();
            this.gridControlSrchPrd = new DevExpress.XtraGrid.GridControl();
            this.gridViewSrchPrd = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colprdId2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdNo2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdName2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPrdSalePrice2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdNameEng2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colprdGrpNo2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repItemButEditSelectPro = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.BtnClosSearchPro = new DevExpress.XtraEditors.SimpleButton();
            this.Root = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem17 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).BeginInit();
            this.dataLayoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroupIsCash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEditCustomerBbi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCustomerSLE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditStrId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStoreBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.risLookUpEditInvoiceId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplyMainBindingSourceEditor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewInvoiceId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditCounterNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplyMainBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPlateNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditCarType.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.separatorControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supNoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supRefNoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDescTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDateDateEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDateDateEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supAccNoLookUpEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supAccNameTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCustName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleNoTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCurrencyChngTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEditTax.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCurrTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCurrencyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCustNo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notDateTextEdit.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notDateTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PoNumberTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotesTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RepNameTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGrooupMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupAccNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupAccName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCustNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCustName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupDesc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForSalesNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupRefNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCur)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCurrencyChng)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlCarData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemFornotDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForNotes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPoNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForrepName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEditBarcodeNo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplySubBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEditPrdNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblProductBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEditQuan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1SalePrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEditDesc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBarCodeInv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditMeasurment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPrdPriceMeasurmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelItemsCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBarcodeText)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBtnDeleteRow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplyMainInvoiceIdBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl2)).BeginInit();
            this.layoutControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinEditTotalFinalDecimal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPaidCash.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supBankIdTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDscntPercentTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDscntAmountTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPaidCreditCard.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdisround.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supBoxIdTextEdit.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlDescount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForsupDscntPercent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForsupDscntAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForPaidCreditCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForPaidCash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupBankId)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelECR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupBankId1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalPriceString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalPriceDecimal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxDecimal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalFinalString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelPaidAmountString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelPaidAmountDecimal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelRemaingAmountString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelRemaingAmountDecimal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelDiscountString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelDiscountDecimal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalString)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalDecimal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplySubDescountBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblAccountBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flyoutPanel1)).BeginInit();
            this.flyoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl3)).BeginInit();
            this.layoutControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlSrchPrd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSrchPrd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repItemButEditSelectPro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            this.SuspendLayout();
            // 
            // dataLayoutControl1
            // 
            this.dataLayoutControl1.Appearance.ControlDisabled.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.DisabledText;
            this.dataLayoutControl1.Appearance.ControlDisabled.Options.UseForeColor = true;
            this.dataLayoutControl1.Appearance.DisabledLayoutItem.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.DisabledText;
            this.dataLayoutControl1.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.dataLayoutControl1.AutoSize = true;
            this.dataLayoutControl1.Controls.Add(this.checkEdit1);
            this.dataLayoutControl1.Controls.Add(this.textEditCounterNumber);
            this.dataLayoutControl1.Controls.Add(this.textEditPlateNumber);
            this.dataLayoutControl1.Controls.Add(this.textEditCarType);
            this.dataLayoutControl1.Controls.Add(this.separatorControl1);
            this.dataLayoutControl1.Controls.Add(this.supNoTextEdit);
            this.dataLayoutControl1.Controls.Add(this.supRefNoTextEdit);
            this.dataLayoutControl1.Controls.Add(this.supDescTextEdit);
            this.dataLayoutControl1.Controls.Add(this.supDateDateEdit);
            this.dataLayoutControl1.Controls.Add(this.supAccNoLookUpEdit);
            this.dataLayoutControl1.Controls.Add(this.supAccNameTextEdit);
            this.dataLayoutControl1.Controls.Add(this.supCustName);
            this.dataLayoutControl1.Controls.Add(this.saleNoTextEdit);
            this.dataLayoutControl1.Controls.Add(this.supCurrencyChngTextEdit);
            this.dataLayoutControl1.Controls.Add(this.checkEditTax);
            this.dataLayoutControl1.Controls.Add(this.supCurrTextEdit);
            this.dataLayoutControl1.Controls.Add(this.supCustNo);
            this.dataLayoutControl1.Controls.Add(this.notDateTextEdit);
            this.dataLayoutControl1.Controls.Add(this.PoNumberTextEdit);
            this.dataLayoutControl1.Controls.Add(this.NotesTextEdit);
            this.dataLayoutControl1.Controls.Add(this.RepNameTextEdit);
            this.dataLayoutControl1.DataSource = this.tblSupplyMainBindingSource;
            this.dataLayoutControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataLayoutControl1.Location = new System.Drawing.Point(0, 115);
            this.dataLayoutControl1.Name = "dataLayoutControl1";
            this.dataLayoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(1175, 150, 650, 400);
            this.dataLayoutControl1.OptionsFocus.EnableAutoTabOrder = false;
            this.dataLayoutControl1.OptionsView.AllowExpandAnimation = DevExpress.Utils.DefaultBoolean.False;
            this.dataLayoutControl1.OptionsView.AutoSizeInLayoutControl = DevExpress.XtraLayout.AutoSizeModes.UseMinAndMaxSize;
            this.dataLayoutControl1.OptionsView.RightToLeftMirroringApplied = true;
            this.dataLayoutControl1.Root = this.layoutControlGroup1;
            this.dataLayoutControl1.Size = new System.Drawing.Size(1384, 280);
            this.dataLayoutControl1.TabIndex = 0;
            this.dataLayoutControl1.Text = "dataLayoutControl1";
            // 
            // checkEdit1
            // 
            this.checkEdit1.Location = new System.Drawing.Point(6, 178);
            this.checkEdit1.MenuManager = this.ribbonControl1;
            this.checkEdit1.Name = "checkEdit1";
            this.checkEdit1.Properties.Caption = "تقريب الاجمالي النهائي";
            this.checkEdit1.Size = new System.Drawing.Size(1372, 20);
            this.checkEdit1.StyleController = this.dataLayoutControl1;
            this.checkEdit1.TabIndex = 15;
            this.checkEdit1.CheckedChanged += new System.EventHandler(this.checkEdit1_CheckedChanged);
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.AllowKeyTips = false;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.ribbonControl1.SearchEditItem,
            this.barButtonItem1,
            this.barButtonItem2,
            this.barCheckItem1,
            this.radioGroupIsCash,
            this.bbiEditQuantity,
            this.bbiEditPrice,
            this.bbiSaveAndNew,
            this.bsiCustomer,
            this.bbiCustomerSLEeee,
            this.bbiReset,
            this.bbiPrdPrice,
            this.bbiNewInvoice,
            this.bbiRibbonStyle,
            this.bbiUpdateInvvoice,
            this.bbiStrIdSLE,
            this.bsiStrName,
            this.bbiSaveAndNewNoPrint,
            this.bsiPaidCreditShortcut,
            this.bbiCustomers,
            this.bbiRefreshCustomers,
            this.barButtonItem3,
            this.barEditItem1,
            this.barButtonItem4,
            this.bbiPriceOffer,
            this.btn_Calculator,
            this.barButtonItem5,
            this.barEditItem2,
            this.bbiCustomerSLE});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 39;
            this.ribbonControl1.MdiMergeStyle = DevExpress.XtraBars.Ribbon.RibbonMdiMergeStyle.Always;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1});
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemRadioGroup1,
            this.repositoryItemRadioGroup2,
            this.repositoryItemRadioGroupIsCash,
            this.repositoryItemSearchLookUpEditCustomerBbi,
            this.risLookUpEditInvoiceId,
            this.repositoryItemLookUpEditStrId,
            this.repositoryItemSpinEdit1,
            this.repositoryItemTextEdit1,
            this.repositoryItemLookUpEdit1});
            this.ribbonControl1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonControlStyle.MacOffice;
            this.ribbonControl1.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonControl1.ShowDisplayOptionsMenuButton = DevExpress.Utils.DefaultBoolean.True;
            this.ribbonControl1.ShowExpandCollapseButton = DevExpress.Utils.DefaultBoolean.True;
            this.ribbonControl1.ShowPageHeadersInFormCaption = DevExpress.Utils.DefaultBoolean.True;
            this.ribbonControl1.ShowPageHeadersMode = DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
            this.ribbonControl1.ShowQatLocationSelector = false;
            this.ribbonControl1.ShowToolbarCustomizeItem = false;
            this.ribbonControl1.Size = new System.Drawing.Size(1384, 115);
            this.ribbonControl1.Toolbar.ShowCustomizeItem = false;
            this.ribbonControl1.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "حفظ(F4)";
            this.barButtonItem1.Id = 2;
            this.barButtonItem1.ImageOptions.SvgImage = global::AccountingMS.Properties.Resources.save;
            this.barButtonItem1.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F2);
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "إغلاق";
            this.barButtonItem2.Id = 3;
            this.barButtonItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem2.ImageOptions.Image")));
            this.barButtonItem2.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("barButtonItem2.ImageOptions.LargeImage")));
            this.barButtonItem2.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F4);
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText)));
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // barCheckItem1
            // 
            this.barCheckItem1.Caption = "تحديد";
            this.barCheckItem1.Id = 8;
            this.barCheckItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barCheckItem1.ImageOptions.Image")));
            this.barCheckItem1.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("barCheckItem1.ImageOptions.LargeImage")));
            this.barCheckItem1.Name = "barCheckItem1";
            this.barCheckItem1.CheckedChanged += new DevExpress.XtraBars.ItemClickEventHandler(this.barCheckItem1_CheckedChanged);
            // 
            // radioGroupIsCash
            // 
            this.radioGroupIsCash.AutoHideEdit = false;
            this.radioGroupIsCash.CaptionAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.radioGroupIsCash.Edit = this.repositoryItemRadioGroupIsCash;
            this.radioGroupIsCash.EditHeight = 50;
            this.radioGroupIsCash.EditValue = ((byte)(1));
            this.radioGroupIsCash.Id = 10;
            this.radioGroupIsCash.Name = "radioGroupIsCash";
            // 
            // repositoryItemRadioGroupIsCash
            // 
            this.repositoryItemRadioGroupIsCash.ColumnIndent = 1;
            this.repositoryItemRadioGroupIsCash.Columns = 1;
            this.repositoryItemRadioGroupIsCash.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((byte)(1)), "نقد"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((byte)(2)), "آجل")});
            this.repositoryItemRadioGroupIsCash.Name = "repositoryItemRadioGroupIsCash";
            this.repositoryItemRadioGroupIsCash.EditValueChanged += new System.EventHandler(this.radioGroupIsCash_EditValueChanged);
            // 
            // bbiEditQuantity
            // 
            this.bbiEditQuantity.Caption = "تعديل الكمية(F6)";
            this.bbiEditQuantity.Id = 11;
            this.bbiEditQuantity.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F6);
            this.bbiEditQuantity.Name = "bbiEditQuantity";
            this.bbiEditQuantity.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiEditQuantity_ItemClick);
            // 
            // bbiEditPrice
            // 
            this.bbiEditPrice.Caption = "تعديل السعر(F7)";
            this.bbiEditPrice.Id = 12;
            this.bbiEditPrice.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F7);
            this.bbiEditPrice.Name = "bbiEditPrice";
            this.bbiEditPrice.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.False;
            this.bbiEditPrice.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiEditPrice_ItemClick);
            // 
            // bbiSaveAndNew
            // 
            this.bbiSaveAndNew.Caption = "حفظ و إنشاء جديد(F3)";
            this.bbiSaveAndNew.Id = 14;
            this.bbiSaveAndNew.ImageOptions.Image = global::AccountingMS.Properties.Resources.saveandnew_16x16;
            this.bbiSaveAndNew.ImageOptions.LargeImage = global::AccountingMS.Properties.Resources.saveandnew_32x32;
            this.bbiSaveAndNew.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F3);
            this.bbiSaveAndNew.Name = "bbiSaveAndNew";
            this.bbiSaveAndNew.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.bbiSaveAndNew.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiSaveAndNew_ItemClick);
            // 
            // bsiCustomer
            // 
            this.bsiCustomer.Caption = "إسم العميل";
            this.bsiCustomer.Id = 15;
            this.bsiCustomer.Name = "bsiCustomer";
            // 
            // bbiCustomerSLEeee
            // 
            this.bbiCustomerSLEeee.Edit = this.repositoryItemSearchLookUpEditCustomerBbi;
            this.bbiCustomerSLEeee.EditWidth = 150;
            this.bbiCustomerSLEeee.Id = 16;
            this.bbiCustomerSLEeee.Name = "bbiCustomerSLEeee";
            this.bbiCustomerSLEeee.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // repositoryItemSearchLookUpEditCustomerBbi
            // 
            this.repositoryItemSearchLookUpEditCustomerBbi.AutoHeight = false;
            this.repositoryItemSearchLookUpEditCustomerBbi.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus)});
            this.repositoryItemSearchLookUpEditCustomerBbi.DisplayMember = "custName";
            this.repositoryItemSearchLookUpEditCustomerBbi.Name = "repositoryItemSearchLookUpEditCustomerBbi";
            this.repositoryItemSearchLookUpEditCustomerBbi.NullText = "";
            this.repositoryItemSearchLookUpEditCustomerBbi.PopupFormSize = new System.Drawing.Size(350, 250);
            this.repositoryItemSearchLookUpEditCustomerBbi.PopupView = this.gridViewCustomerSLE;
            this.repositoryItemSearchLookUpEditCustomerBbi.ValueMember = "id";
            // 
            // gridViewCustomerSLE
            // 
            this.gridViewCustomerSLE.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colcstId,
            this.colcustName,
            this.colcustPhnNo,
            this.colcustNo});
            this.gridViewCustomerSLE.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridViewCustomerSLE.Name = "gridViewCustomerSLE";
            this.gridViewCustomerSLE.OptionsBehavior.Editable = false;
            this.gridViewCustomerSLE.OptionsBehavior.ReadOnly = true;
            this.gridViewCustomerSLE.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridViewCustomerSLE.OptionsView.ShowGroupPanel = false;
            this.gridViewCustomerSLE.OptionsView.ShowHorizontalLines = DevExpress.Utils.DefaultBoolean.False;
            this.gridViewCustomerSLE.OptionsView.ShowIndicator = false;
            // 
            // colcstId
            // 
            this.colcstId.Caption = "colcstId";
            this.colcstId.FieldName = "id";
            this.colcstId.Name = "colcstId";
            // 
            // colcustName
            // 
            this.colcustName.Caption = "إٍسم العميل";
            this.colcustName.FieldName = "custName";
            this.colcustName.MinWidth = 150;
            this.colcustName.Name = "colcustName";
            this.colcustName.Visible = true;
            this.colcustName.VisibleIndex = 1;
            this.colcustName.Width = 150;
            // 
            // colcustPhnNo
            // 
            this.colcustPhnNo.Caption = "رقم العميل";
            this.colcustPhnNo.FieldName = "custPhnNo";
            this.colcustPhnNo.Name = "colcustPhnNo";
            this.colcustPhnNo.Visible = true;
            this.colcustPhnNo.VisibleIndex = 2;
            // 
            // colcustNo
            // 
            this.colcustNo.AppearanceCell.Options.UseTextOptions = true;
            this.colcustNo.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colcustNo.Caption = "رقم العميل";
            this.colcustNo.FieldName = "custNo";
            this.colcustNo.MaxWidth = 75;
            this.colcustNo.Name = "colcustNo";
            this.colcustNo.Visible = true;
            this.colcustNo.VisibleIndex = 0;
            // 
            // bbiReset
            // 
            this.bbiReset.Caption = "إعادة التهيئه(F5)";
            this.bbiReset.Id = 17;
            this.bbiReset.ImageOptions.Image = global::AccountingMS.Properties.Resources.reset_32x32;
            this.bbiReset.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F5);
            this.bbiReset.Name = "bbiReset";
            this.bbiReset.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.bbiReset.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiReset_ItemClick);
            // 
            // bbiPrdPrice
            // 
            this.bbiPrdPrice.Caption = "عرض سعر الشراء(F8)";
            this.bbiPrdPrice.Id = 18;
            this.bbiPrdPrice.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F8);
            this.bbiPrdPrice.Name = "bbiPrdPrice";
            this.bbiPrdPrice.ShowItemShortcut = DevExpress.Utils.DefaultBoolean.False;
            this.bbiPrdPrice.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiPrdPrice_ItemClick);
            // 
            // bbiNewInvoice
            // 
            this.bbiNewInvoice.Caption = " فاتورة جديدة(F1)";
            this.bbiNewInvoice.Id = 20;
            this.bbiNewInvoice.ImageOptions.SvgImage = global::AccountingMS.Properties.Resources.saleRtrnAdd;
            this.bbiNewInvoice.Name = "bbiNewInvoice";
            this.bbiNewInvoice.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph;
            // 
            // bbiRibbonStyle
            // 
            this.bbiRibbonStyle.Caption = "تصغير العرض";
            this.bbiRibbonStyle.Id = 21;
            this.bbiRibbonStyle.Name = "bbiRibbonStyle";
            this.bbiRibbonStyle.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiRibbonView_ItemClick);
            // 
            // bbiUpdateInvvoice
            // 
            this.bbiUpdateInvvoice.Caption = "تعديل فاتورة المبيعات(F9)";
            this.bbiUpdateInvvoice.Id = 23;
            this.bbiUpdateInvvoice.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bbiUpdateInvvoice.ImageOptions.Image")));
            this.bbiUpdateInvvoice.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bbiUpdateInvvoice.ImageOptions.LargeImage")));
            this.bbiUpdateInvvoice.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F9);
            this.bbiUpdateInvvoice.Name = "bbiUpdateInvvoice";
            this.bbiUpdateInvvoice.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.BbiUpdateInvoice_ItemClick);
            // 
            // bbiStrIdSLE
            // 
            this.bbiStrIdSLE.Caption = "barEditItem1";
            this.bbiStrIdSLE.Edit = this.repositoryItemLookUpEditStrId;
            this.bbiStrIdSLE.EditWidth = 150;
            this.bbiStrIdSLE.Id = 25;
            this.bbiStrIdSLE.Name = "bbiStrIdSLE";
            this.bbiStrIdSLE.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // repositoryItemLookUpEditStrId
            // 
            this.repositoryItemLookUpEditStrId.AutoHeight = false;
            this.repositoryItemLookUpEditStrId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEditStrId.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("strName", "Name2")});
            this.repositoryItemLookUpEditStrId.DataSource = this.tblStoreBindingSource;
            this.repositoryItemLookUpEditStrId.DisplayMember = "strName";
            this.repositoryItemLookUpEditStrId.Name = "repositoryItemLookUpEditStrId";
            this.repositoryItemLookUpEditStrId.NullText = "";
            this.repositoryItemLookUpEditStrId.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoSearch;
            this.repositoryItemLookUpEditStrId.ShowHeader = false;
            this.repositoryItemLookUpEditStrId.ValueMember = "id";
            // 
            // tblStoreBindingSource
            // 
            this.tblStoreBindingSource.DataSource = typeof(AccountingMS.tblStore);
            // 
            // bsiStrName
            // 
            this.bsiStrName.Caption = "إسم المخزن";
            this.bsiStrName.Id = 26;
            this.bsiStrName.Name = "bsiStrName";
            // 
            // bbiSaveAndNewNoPrint
            // 
            this.bbiSaveAndNewNoPrint.Caption = "حفظ و إنشاء جديد\r\nبدون طباعه(F12)";
            this.bbiSaveAndNewNoPrint.Id = 27;
            this.bbiSaveAndNewNoPrint.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F12);
            this.bbiSaveAndNewNoPrint.Name = "bbiSaveAndNewNoPrint";
            this.bbiSaveAndNewNoPrint.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiSaveAndNewNoPrint_ItemClick);
            // 
            // bsiPaidCreditShortcut
            // 
            this.bsiPaidCreditShortcut.Caption = "المدفوع بطاقة  إئتمان(F11)";
            this.bsiPaidCreditShortcut.Id = 28;
            this.bsiPaidCreditShortcut.Name = "bsiPaidCreditShortcut";
            // 
            // bbiCustomers
            // 
            this.bbiCustomers.Caption = "العملاء";
            this.bbiCustomers.Id = 29;
            this.bbiCustomers.Name = "bbiCustomers";
            this.bbiCustomers.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            this.bbiCustomers.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.BbiCustomers_ItemClick);
            // 
            // bbiRefreshCustomers
            // 
            this.bbiRefreshCustomers.Caption = "تحديث العملاء";
            this.bbiRefreshCustomers.Id = 30;
            this.bbiRefreshCustomers.Name = "bbiRefreshCustomers";
            this.bbiRefreshCustomers.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.BbiRefreshCustomers_ItemClick);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "طباعة الفاتورة السابقة";
            this.barButtonItem3.Id = 31;
            this.barButtonItem3.ImageOptions.SvgImage = global::AccountingMS.Properties.Resources.print;
            this.barButtonItem3.Name = "barButtonItem3";
            this.barButtonItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem3_ItemClick);
            // 
            // barEditItem1
            // 
            this.barEditItem1.Caption = "رقم الفاتورة";
            this.barEditItem1.Edit = this.repositoryItemSpinEdit1;
            this.barEditItem1.Id = 32;
            this.barEditItem1.Name = "barEditItem1";
            // 
            // repositoryItemSpinEdit1
            // 
            this.repositoryItemSpinEdit1.AutoHeight = false;
            this.repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "طباعة";
            this.barButtonItem4.Id = 33;
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // bbiPriceOffer
            // 
            this.bbiPriceOffer.Caption = "فواتير عروض الأسعر(F10)";
            this.bbiPriceOffer.Id = 34;
            this.bbiPriceOffer.ItemShortcut = new DevExpress.XtraBars.BarShortcut(System.Windows.Forms.Keys.F10);
            this.bbiPriceOffer.Name = "bbiPriceOffer";
            this.bbiPriceOffer.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.bbiPriceOffer.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbiPriceOffer_ItemClick);
            // 
            // btn_Calculator
            // 
            this.btn_Calculator.Caption = "Calculator";
            this.btn_Calculator.Id = 35;
            this.btn_Calculator.ImageOptions.Image = global::AccountingMS.Properties.Resources.calculatenow_16x16;
            this.btn_Calculator.ImageOptions.LargeImage = global::AccountingMS.Properties.Resources.calculatenow_32x32;
            this.btn_Calculator.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1));
            this.btn_Calculator.Name = "btn_Calculator";
            this.btn_Calculator.ShortcutKeyDisplayString = "Ctrl+1";
            this.btn_Calculator.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btn_Calculator_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "الخط";
            this.barButtonItem5.Id = 36;
            this.barButtonItem5.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem5.ImageOptions.Image")));
            this.barButtonItem5.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("barButtonItem5.ImageOptions.LargeImage")));
            this.barButtonItem5.Name = "barButtonItem5";
            this.barButtonItem5.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem5_ItemClick);
            // 
            // barEditItem2
            // 
            this.barEditItem2.Caption = "barEditItem2";
            this.barEditItem2.Edit = this.repositoryItemTextEdit1;
            this.barEditItem2.Id = 37;
            this.barEditItem2.Name = "barEditItem2";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // bbiCustomerSLE
            // 
            this.bbiCustomerSLE.Edit = this.repositoryItemLookUpEdit1;
            this.bbiCustomerSLE.EditWidth = 150;
            this.bbiCustomerSLE.Id = 38;
            this.bbiCustomerSLE.Name = "bbiCustomerSLE";
            // 
            // repositoryItemLookUpEdit1
            // 
            this.repositoryItemLookUpEdit1.AutoHeight = false;
            this.repositoryItemLookUpEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEdit1.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("id", "id", 22, DevExpress.Utils.FormatType.Numeric, "", false, DevExpress.Utils.HorzAlignment.Far, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("custNo", "cust No", 55, DevExpress.Utils.FormatType.Numeric, "", true, DevExpress.Utils.HorzAlignment.Far, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("custAccNo", "cust Acc No", 79, DevExpress.Utils.FormatType.Numeric, "", true, DevExpress.Utils.HorzAlignment.Far, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("custName", "cust Name", 71, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Near, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default)});
            this.repositoryItemLookUpEdit1.DataSource = this.tblCustomerBindingSource;
            this.repositoryItemLookUpEdit1.DisplayMember = "custName";
            this.repositoryItemLookUpEdit1.Name = "repositoryItemLookUpEdit1";
            this.repositoryItemLookUpEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            this.repositoryItemLookUpEdit1.ValueMember = "custAccNo";
            // 
            // tblCustomerBindingSource
            // 
            this.tblCustomerBindingSource.DataSource = typeof(AccountingMS.tblCustomer);
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2,
            this.ribbonPageGroup3,
            this.ribbonPageGroup4,
            this.ribbonPageGroupStrId,
            this.ribbonPageGroupCustomerInv,
            this.ribbonPageGroupUpdateInvoice,
            this.ribbonPageGroupShortcuts,
            this.ribbonPageGroupRibbonView,
            this.ribbonPageGroup5});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "الرئيسية";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem1);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiSaveAndNew);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem2);
            this.ribbonPageGroup2.ItemLinks.Add(this.bbiReset);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem3);
            this.ribbonPageGroup2.ItemLinks.Add(this.barEditItem1);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem4);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "العمليات";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.AllowTextClipping = false;
            this.ribbonPageGroup3.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonPageGroup3.ItemLinks.Add(this.radioGroupIsCash);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "نوع الفاتورة";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonPageGroup4.ItemLinks.Add(this.barCheckItem1);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Visible = false;
            // 
            // ribbonPageGroupStrId
            // 
            this.ribbonPageGroupStrId.AllowTextClipping = false;
            this.ribbonPageGroupStrId.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonPageGroupStrId.ItemLinks.Add(this.bsiStrName);
            this.ribbonPageGroupStrId.ItemLinks.Add(this.bbiStrIdSLE);
            this.ribbonPageGroupStrId.Name = "ribbonPageGroupStrId";
            this.ribbonPageGroupStrId.Text = "المخزن";
            // 
            // ribbonPageGroupCustomerInv
            // 
            this.ribbonPageGroupCustomerInv.AllowTextClipping = false;
            this.ribbonPageGroupCustomerInv.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonPageGroupCustomerInv.ItemLinks.Add(this.bsiCustomer);
            this.ribbonPageGroupCustomerInv.ItemLinks.Add(this.bbiCustomerSLE);
            this.ribbonPageGroupCustomerInv.ItemLinks.Add(this.bbiCustomers);
            this.ribbonPageGroupCustomerInv.ItemLinks.Add(this.bbiRefreshCustomers);
            this.ribbonPageGroupCustomerInv.Name = "ribbonPageGroupCustomerInv";
            this.ribbonPageGroupCustomerInv.Text = "ربط عميل الى الفاتورة";
            // 
            // ribbonPageGroupUpdateInvoice
            // 
            this.ribbonPageGroupUpdateInvoice.AllowTextClipping = false;
            this.ribbonPageGroupUpdateInvoice.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonPageGroupUpdateInvoice.ItemLinks.Add(this.bbiUpdateInvvoice);
            this.ribbonPageGroupUpdateInvoice.Name = "ribbonPageGroupUpdateInvoice";
            this.ribbonPageGroupUpdateInvoice.Text = "فواتير المبيعات";
            // 
            // ribbonPageGroupShortcuts
            // 
            this.ribbonPageGroupShortcuts.AllowTextClipping = false;
            this.ribbonPageGroupShortcuts.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonPageGroupShortcuts.ItemLinks.Add(this.bbiNewInvoice, true);
            this.ribbonPageGroupShortcuts.ItemLinks.Add(this.bbiPrdPrice);
            this.ribbonPageGroupShortcuts.ItemLinks.Add(this.bbiEditPrice);
            this.ribbonPageGroupShortcuts.ItemLinks.Add(this.bbiEditQuantity);
            this.ribbonPageGroupShortcuts.ItemLinks.Add(this.bsiPaidCreditShortcut, true);
            this.ribbonPageGroupShortcuts.ItemLinks.Add(this.bbiSaveAndNewNoPrint);
            this.ribbonPageGroupShortcuts.ItemLinks.Add(this.bbiPriceOffer, true);
            this.ribbonPageGroupShortcuts.Name = "ribbonPageGroupShortcuts";
            this.ribbonPageGroupShortcuts.Text = "الإختصارات";
            // 
            // ribbonPageGroupRibbonView
            // 
            this.ribbonPageGroupRibbonView.CaptionButtonVisible = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonPageGroupRibbonView.ItemLinks.Add(this.bbiRibbonStyle);
            this.ribbonPageGroupRibbonView.ItemLinks.Add(this.barButtonItem5);
            this.ribbonPageGroupRibbonView.Name = "ribbonPageGroupRibbonView";
            this.ribbonPageGroupRibbonView.Text = "قائمة العرض";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.btn_Calculator);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            // 
            // repositoryItemRadioGroup1
            // 
            this.repositoryItemRadioGroup1.Name = "repositoryItemRadioGroup1";
            // 
            // repositoryItemRadioGroup2
            // 
            this.repositoryItemRadioGroup2.Columns = 1;
            this.repositoryItemRadioGroup2.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((byte)(1)), "نقد"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((byte)(2)), "أجل")});
            this.repositoryItemRadioGroup2.Name = "repositoryItemRadioGroup2";
            // 
            // risLookUpEditInvoiceId
            // 
            this.risLookUpEditInvoiceId.AutoHeight = false;
            this.risLookUpEditInvoiceId.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.risLookUpEditInvoiceId.DataSource = this.tblSupplyMainBindingSourceEditor;
            this.risLookUpEditInvoiceId.Name = "risLookUpEditInvoiceId";
            this.risLookUpEditInvoiceId.NullText = "";
            this.risLookUpEditInvoiceId.PopupView = this.gridViewInvoiceId;
            // 
            // tblSupplyMainBindingSourceEditor
            // 
            this.tblSupplyMainBindingSourceEditor.DataSource = typeof(AccountingMS.tblSupplyMain);
            // 
            // gridViewInvoiceId
            // 
            this.gridViewInvoiceId.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colid1,
            this.colsupAccName1,
            this.colsupNo1,
            this.colsupTotal,
            this.colsupDate});
            this.gridViewInvoiceId.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridViewInvoiceId.Name = "gridViewInvoiceId";
            this.gridViewInvoiceId.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridViewInvoiceId.OptionsView.ShowGroupPanel = false;
            // 
            // colid1
            // 
            this.colid1.FieldName = "id";
            this.colid1.Name = "colid1";
            this.colid1.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colsupAccName1
            // 
            this.colsupAccName1.Caption = "إسم الحساب";
            this.colsupAccName1.FieldName = "supAccName";
            this.colsupAccName1.Name = "colsupAccName1";
            this.colsupAccName1.Visible = true;
            this.colsupAccName1.VisibleIndex = 0;
            // 
            // colsupNo1
            // 
            this.colsupNo1.Caption = "رقم الفاتورة";
            this.colsupNo1.FieldName = "supNo";
            this.colsupNo1.Name = "colsupNo1";
            this.colsupNo1.Visible = true;
            this.colsupNo1.VisibleIndex = 1;
            // 
            // colsupTotal
            // 
            this.colsupTotal.Caption = "المبلغ";
            this.colsupTotal.FieldName = "supTotal";
            this.colsupTotal.Name = "colsupTotal";
            this.colsupTotal.Visible = true;
            this.colsupTotal.VisibleIndex = 2;
            // 
            // colsupDate
            // 
            this.colsupDate.Caption = "التاريخ";
            this.colsupDate.FieldName = "supDate";
            this.colsupDate.Name = "colsupDate";
            this.colsupDate.Visible = true;
            this.colsupDate.VisibleIndex = 3;
            // 
            // textEditCounterNumber
            // 
            this.textEditCounterNumber.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "CounterNumber", true));
            this.textEditCounterNumber.Location = new System.Drawing.Point(18, 239);
            this.textEditCounterNumber.MenuManager = this.ribbonControl1;
            this.textEditCounterNumber.Name = "textEditCounterNumber";
            this.textEditCounterNumber.Size = new System.Drawing.Size(354, 20);
            this.textEditCounterNumber.StyleController = this.dataLayoutControl1;
            this.textEditCounterNumber.TabIndex = 14;
            // 
            // tblSupplyMainBindingSource
            // 
            this.tblSupplyMainBindingSource.DataSource = typeof(AccountingMS.tblSupplyMain);
            // 
            // textEditPlateNumber
            // 
            this.textEditPlateNumber.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "PlateNumber", true));
            this.textEditPlateNumber.Location = new System.Drawing.Point(469, 239);
            this.textEditPlateNumber.MenuManager = this.ribbonControl1;
            this.textEditPlateNumber.Name = "textEditPlateNumber";
            this.textEditPlateNumber.Size = new System.Drawing.Size(352, 20);
            this.textEditPlateNumber.StyleController = this.dataLayoutControl1;
            this.textEditPlateNumber.TabIndex = 13;
            // 
            // textEditCarType
            // 
            this.textEditCarType.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "CarType", true));
            this.textEditCarType.Location = new System.Drawing.Point(918, 239);
            this.textEditCarType.MenuManager = this.ribbonControl1;
            this.textEditCarType.Name = "textEditCarType";
            this.textEditCarType.Size = new System.Drawing.Size(355, 20);
            this.textEditCarType.StyleController = this.dataLayoutControl1;
            this.textEditCarType.TabIndex = 12;
            // 
            // separatorControl1
            // 
            this.separatorControl1.LineThickness = 1;
            this.separatorControl1.Location = new System.Drawing.Point(4, 273);
            this.separatorControl1.Margin = new System.Windows.Forms.Padding(0);
            this.separatorControl1.Name = "separatorControl1";
            this.separatorControl1.Padding = new System.Windows.Forms.Padding(0);
            this.separatorControl1.Size = new System.Drawing.Size(1376, 2);
            this.separatorControl1.TabIndex = 11;
            // 
            // supNoTextEdit
            // 
            this.supNoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supNo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supNoTextEdit.Enabled = false;
            this.supNoTextEdit.Location = new System.Drawing.Point(1037, 106);
            this.supNoTextEdit.Name = "supNoTextEdit";
            this.supNoTextEdit.Properties.Mask.BeepOnError = true;
            this.supNoTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.supNoTextEdit.Properties.MaskSettings.Set("MaskManagerType", typeof(DevExpress.Data.Mask.NumericMaskManager));
            this.supNoTextEdit.Properties.MaskSettings.Set("mask", "f0");
            this.supNoTextEdit.Size = new System.Drawing.Size(248, 20);
            this.supNoTextEdit.StyleController = this.dataLayoutControl1;
            this.supNoTextEdit.TabIndex = 4;
            conditionValidationRule1.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.NotEquals;
            conditionValidationRule1.ErrorText = "يجب إدخال هذا الحقل";
            conditionValidationRule1.Value1 = 0;
            this.dxValidationProvider1.SetValidationRule(this.supNoTextEdit, conditionValidationRule1);
            // 
            // supRefNoTextEdit
            // 
            this.supRefNoTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supRefNo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supRefNoTextEdit.Location = new System.Drawing.Point(693, 106);
            this.supRefNoTextEdit.Name = "supRefNoTextEdit";
            this.supRefNoTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.supRefNoTextEdit.Properties.Mask.BeepOnError = true;
            this.supRefNoTextEdit.Properties.Mask.EditMask = "f0";
            this.supRefNoTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.supRefNoTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.supRefNoTextEdit.Size = new System.Drawing.Size(247, 20);
            this.supRefNoTextEdit.StyleController = this.dataLayoutControl1;
            this.supRefNoTextEdit.TabIndex = 5;
            // 
            // supDescTextEdit
            // 
            this.supDescTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supDesc", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supDescTextEdit.Location = new System.Drawing.Point(1037, 130);
            this.supDescTextEdit.Name = "supDescTextEdit";
            this.supDescTextEdit.Properties.MaxLength = 100;
            this.supDescTextEdit.Size = new System.Drawing.Size(248, 20);
            this.supDescTextEdit.StyleController = this.dataLayoutControl1;
            this.supDescTextEdit.TabIndex = 7;
            // 
            // supDateDateEdit
            // 
            this.supDateDateEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supDate", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supDateDateEdit.EditValue = null;
            this.supDateDateEdit.Location = new System.Drawing.Point(349, 106);
            this.supDateDateEdit.Name = "supDateDateEdit";
            this.supDateDateEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.supDateDateEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.supDateDateEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.supDateDateEdit.Size = new System.Drawing.Size(247, 20);
            this.supDateDateEdit.StyleController = this.dataLayoutControl1;
            this.supDateDateEdit.TabIndex = 6;
            conditionValidationRule2.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule2.ErrorText = "يجب إدخال هذا الحقل";
            this.dxValidationProvider1.SetValidationRule(this.supDateDateEdit, conditionValidationRule2);
            // 
            // supAccNoLookUpEdit
            // 
            this.supAccNoLookUpEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supAccNo", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supAccNoLookUpEdit.Location = new System.Drawing.Point(1037, 58);
            this.supAccNoLookUpEdit.Name = "supAccNoLookUpEdit";
            this.supAccNoLookUpEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.supAccNoLookUpEdit.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.supAccNoLookUpEdit.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.supAccNoLookUpEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.supAccNoLookUpEdit.Properties.NullText = "";
            this.supAccNoLookUpEdit.Properties.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoSearch;
            this.supAccNoLookUpEdit.Size = new System.Drawing.Size(248, 20);
            this.supAccNoLookUpEdit.StyleController = this.dataLayoutControl1;
            this.supAccNoLookUpEdit.TabIndex = 1;
            conditionValidationRule3.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule3.ErrorText = "يجب إدخال هذا الحقل";
            this.dxValidationProvider1.SetValidationRule(this.supAccNoLookUpEdit, conditionValidationRule3);
            // 
            // supAccNameTextEdit
            // 
            this.supAccNameTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supAccName", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supAccNameTextEdit.Location = new System.Drawing.Point(693, 58);
            this.supAccNameTextEdit.Name = "supAccNameTextEdit";
            this.supAccNameTextEdit.Size = new System.Drawing.Size(247, 20);
            this.supAccNameTextEdit.StyleController = this.dataLayoutControl1;
            this.supAccNameTextEdit.TabIndex = 0;
            this.supAccNameTextEdit.TabStop = false;
            conditionValidationRule4.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule4.ErrorText = "يجب إدخال هذا الحقل!";
            this.dxValidationProvider1.SetValidationRule(this.supAccNameTextEdit, conditionValidationRule4);
            // 
            // supCustName
            // 
            this.supCustName.Enabled = false;
            this.supCustName.Location = new System.Drawing.Point(693, 82);
            this.supCustName.Name = "supCustName";
            this.supCustName.Size = new System.Drawing.Size(247, 20);
            this.supCustName.StyleController = this.dataLayoutControl1;
            this.supCustName.TabIndex = 10;
            this.supCustName.TabStop = false;
            conditionValidationRule5.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule5.ErrorText = "يجب إدخال هذا الحقل!";
            this.dxValidationProvider1.SetValidationRule(this.supCustName, conditionValidationRule5);
            // 
            // saleNoTextEdit
            // 
            this.saleNoTextEdit.Location = new System.Drawing.Point(6, 34);
            this.saleNoTextEdit.Name = "saleNoTextEdit";
            this.saleNoTextEdit.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.saleNoTextEdit.Properties.Appearance.Options.UseBackColor = true;
            this.saleNoTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.saleNoTextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("supNo", "رقم الفاتورة"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("supDate", "تاريخ الفاتورة", 17, DevExpress.Utils.FormatType.None, "", true, DevExpress.Utils.HorzAlignment.Default, DevExpress.Data.ColumnSortOrder.None, DevExpress.Utils.DefaultBoolean.Default),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("supDesc", "البيان"),
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("supTotal", "المبلغ")});
            this.saleNoTextEdit.Properties.DataSource = this.tblSupplyMainBindingSourceEditor;
            this.saleNoTextEdit.Properties.DisplayMember = "supNo";
            this.saleNoTextEdit.Properties.DropDownRows = 20;
            this.saleNoTextEdit.Properties.NullText = "";
            this.saleNoTextEdit.Properties.SearchMode = DevExpress.XtraEditors.Controls.SearchMode.AutoSearch;
            this.saleNoTextEdit.Properties.ValueMember = "supNo";
            this.saleNoTextEdit.Size = new System.Drawing.Size(1277, 20);
            this.saleNoTextEdit.StyleController = this.dataLayoutControl1;
            this.saleNoTextEdit.TabIndex = 0;
            // 
            // supCurrencyChngTextEdit
            // 
            this.supCurrencyChngTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supCurrencyChng", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supCurrencyChngTextEdit.Location = new System.Drawing.Point(6, 58);
            this.supCurrencyChngTextEdit.Name = "supCurrencyChngTextEdit";
            this.supCurrencyChngTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.supCurrencyChngTextEdit.Size = new System.Drawing.Size(262, 20);
            this.supCurrencyChngTextEdit.StyleController = this.dataLayoutControl1;
            this.supCurrencyChngTextEdit.TabIndex = 3;
            // 
            // checkEditTax
            // 
            this.checkEditTax.EditValue = true;
            this.checkEditTax.Location = new System.Drawing.Point(693, 154);
            this.checkEditTax.MenuManager = this.ribbonControl1;
            this.checkEditTax.Name = "checkEditTax";
            this.checkEditTax.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.checkEditTax.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.checkEditTax.Properties.Appearance.Options.UseFont = true;
            this.checkEditTax.Properties.Appearance.Options.UseForeColor = true;
            this.checkEditTax.Properties.Caption = "إضافة قيمة الضريبة";
            this.checkEditTax.Size = new System.Drawing.Size(685, 20);
            this.checkEditTax.StyleController = this.dataLayoutControl1;
            this.checkEditTax.TabIndex = 8;
            this.checkEditTax.CheckedChanged += new System.EventHandler(this.checkEditTax_CheckedChanged);
            // 
            // supCurrTextEdit
            // 
            this.supCurrTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supCurrency", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supCurrTextEdit.Location = new System.Drawing.Point(349, 58);
            this.supCurrTextEdit.MenuManager = this.ribbonControl1;
            this.supCurrTextEdit.Name = "supCurrTextEdit";
            this.supCurrTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.supCurrTextEdit.Properties.DataSource = this.tblCurrencyBindingSource;
            this.supCurrTextEdit.Properties.DisplayMember = "curName";
            this.supCurrTextEdit.Properties.NullText = "";
            this.supCurrTextEdit.Properties.ValueMember = "id";
            this.supCurrTextEdit.Size = new System.Drawing.Size(247, 20);
            this.supCurrTextEdit.StyleController = this.dataLayoutControl1;
            this.supCurrTextEdit.TabIndex = 6;
            this.supCurrTextEdit.TabStop = false;
            conditionValidationRule6.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule6.ErrorText = "يجب إدخال هذا الحقل!";
            this.dxValidationProvider1.SetValidationRule(this.supCurrTextEdit, conditionValidationRule6);
            // 
            // tblCurrencyBindingSource
            // 
            this.tblCurrencyBindingSource.DataSource = typeof(AccountingMS.tblCurrency);
            // 
            // supCustNo
            // 
            this.supCustNo.Location = new System.Drawing.Point(1037, 82);
            this.supCustNo.Name = "supCustNo";
            this.supCustNo.Properties.AppearanceDisabled.BackColor = System.Drawing.Color.White;
            this.supCustNo.Properties.AppearanceDisabled.Options.UseBackColor = true;
            this.supCustNo.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo),
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus)});
            this.supCustNo.Properties.DataSource = this.tblCustomerBindingSource;
            this.supCustNo.Properties.DisplayMember = "custNo";
            this.supCustNo.Properties.NullText = "";
            this.supCustNo.Properties.PopupView = this.searchLookUpEdit1View;
            this.supCustNo.Properties.PopupWidthMode = DevExpress.XtraEditors.PopupWidthMode.UseEditorWidth;
            this.supCustNo.Properties.ValueMember = "custAccNo";
            this.supCustNo.Size = new System.Drawing.Size(248, 20);
            this.supCustNo.StyleController = this.dataLayoutControl1;
            this.supCustNo.TabIndex = 2;
            conditionValidationRule7.ConditionOperator = DevExpress.XtraEditors.DXErrorProvider.ConditionOperator.IsNotBlank;
            conditionValidationRule7.ErrorText = "يجب إدخال هذا الحقل";
            this.dxValidationProvider1.SetValidationRule(this.supCustNo, conditionValidationRule7);
            // 
            // searchLookUpEdit1View
            // 
            this.searchLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colcustNo1,
            this.colcustName1,
            this.colcustPhnNo1,
            this.colcustCurrency1});
            this.searchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.searchLookUpEdit1View.Name = "searchLookUpEdit1View";
            this.searchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.searchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            this.searchLookUpEdit1View.OptionsView.ShowIndicator = false;
            // 
            // colcustNo1
            // 
            this.colcustNo1.AppearanceCell.Options.UseTextOptions = true;
            this.colcustNo1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colcustNo1.Caption = "رقم العميل";
            this.colcustNo1.FieldName = "custNo";
            this.colcustNo1.MaxWidth = 75;
            this.colcustNo1.Name = "colcustNo1";
            this.colcustNo1.Visible = true;
            this.colcustNo1.VisibleIndex = 0;
            // 
            // colcustName1
            // 
            this.colcustName1.Caption = "إسم العميل";
            this.colcustName1.FieldName = "custName";
            this.colcustName1.Name = "colcustName1";
            this.colcustName1.Visible = true;
            this.colcustName1.VisibleIndex = 1;
            this.colcustName1.Width = 150;
            // 
            // colcustPhnNo1
            // 
            this.colcustPhnNo1.Caption = "رقم الهاتف";
            this.colcustPhnNo1.FieldName = "custPhnNo";
            this.colcustPhnNo1.Name = "colcustPhnNo1";
            this.colcustPhnNo1.Visible = true;
            this.colcustPhnNo1.VisibleIndex = 2;
            // 
            // colcustCurrency1
            // 
            this.colcustCurrency1.Caption = "العملة";
            this.colcustCurrency1.FieldName = "custCurrency";
            this.colcustCurrency1.Name = "colcustCurrency1";
            // 
            // notDateTextEdit
            // 
            this.notDateTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "DueDate", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.notDateTextEdit.EditValue = null;
            this.notDateTextEdit.Location = new System.Drawing.Point(6, 106);
            this.notDateTextEdit.MenuManager = this.ribbonControl1;
            this.notDateTextEdit.Name = "notDateTextEdit";
            this.notDateTextEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.notDateTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.notDateTextEdit.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.notDateTextEdit.Properties.DisplayFormat.FormatString = "";
            this.notDateTextEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.notDateTextEdit.Properties.EditFormat.FormatString = "";
            this.notDateTextEdit.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.notDateTextEdit.Properties.Mask.BeepOnError = true;
            this.notDateTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.notDateTextEdit.Size = new System.Drawing.Size(248, 20);
            this.notDateTextEdit.StyleController = this.dataLayoutControl1;
            this.notDateTextEdit.TabIndex = 16;
            // 
            // PoNumberTextEdit
            // 
            this.PoNumberTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "PoNumber", true));
            this.PoNumberTextEdit.Location = new System.Drawing.Point(693, 130);
            this.PoNumberTextEdit.MenuManager = this.ribbonControl1;
            this.PoNumberTextEdit.Name = "PoNumberTextEdit";
            this.PoNumberTextEdit.Size = new System.Drawing.Size(247, 20);
            this.PoNumberTextEdit.StyleController = this.dataLayoutControl1;
            this.PoNumberTextEdit.TabIndex = 17;
            // 
            // NotesTextEdit
            // 
            this.NotesTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "Notes", true));
            this.NotesTextEdit.Location = new System.Drawing.Point(6, 130);
            this.NotesTextEdit.MenuManager = this.ribbonControl1;
            this.NotesTextEdit.Name = "NotesTextEdit";
            this.NotesTextEdit.Size = new System.Drawing.Size(590, 20);
            this.NotesTextEdit.StyleController = this.dataLayoutControl1;
            this.NotesTextEdit.TabIndex = 18;
            // 
            // RepNameTextEdit
            // 
            this.RepNameTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "repName", true));
            this.RepNameTextEdit.Location = new System.Drawing.Point(350, 154);
            this.RepNameTextEdit.MenuManager = this.ribbonControl1;
            this.RepNameTextEdit.Name = "RepNameTextEdit";
            this.RepNameTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.RepNameTextEdit.Properties.NullText = "";
            this.RepNameTextEdit.Size = new System.Drawing.Size(246, 20);
            this.RepNameTextEdit.StyleController = this.dataLayoutControl1;
            this.RepNameTextEdit.TabIndex = 20;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup3});
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.OptionsItemText.TextToControlDistance = 2;
            this.layoutControlGroup1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.layoutControlGroup1.Size = new System.Drawing.Size(1384, 280);
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlGroup3
            // 
            this.layoutControlGroup3.AllowDrawBackground = false;
            this.layoutControlGroup3.GroupBordersVisible = false;
            this.layoutControlGroup3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGrooupMain});
            this.layoutControlGroup3.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup3.Name = "autoGeneratedGroup0";
            this.layoutControlGroup3.Size = new System.Drawing.Size(1380, 278);
            // 
            // layoutControlGrooupMain
            // 
            this.layoutControlGrooupMain.AppearanceGroup.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.layoutControlGrooupMain.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGrooupMain.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlGrooupMain.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.layoutControlGrooupMain.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlGrooupMain.AppearanceItemCaption.Options.UseForeColor = true;
            this.layoutControlGrooupMain.ExpandButtonVisible = true;
            this.layoutControlGrooupMain.ExpandOnDoubleClick = true;
            this.layoutControlGrooupMain.GroupStyle = DevExpress.Utils.GroupStyle.Title;
            this.layoutControlGrooupMain.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.ItemForsupAccNo,
            this.ItemForsupAccName,
            this.ItemForsupCustNo,
            this.ItemForsupCustName,
            this.ItemForsupDesc,
            this.ItemForSalesNo,
            this.layoutControlItem1,
            this.ItemForsupNo,
            this.ItemForsupRefNo,
            this.ItemForsupDate,
            this.ItemForsupCur,
            this.ItemForsupCurrencyChng,
            this.layoutControlItem3,
            this.layoutControlCarData,
            this.layoutControlItem10,
            this.ItemFornotDate,
            this.ItemForNotes,
            this.ItemForPoNumber,
            this.emptySpaceItem5,
            this.ItemForrepName});
            this.layoutControlGrooupMain.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGrooupMain.Name = "layoutControlGrooupMain";
            this.layoutControlGrooupMain.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 2, 5);
            this.layoutControlGrooupMain.Size = new System.Drawing.Size(1380, 278);
            this.layoutControlGrooupMain.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.layoutControlGrooupMain.Text = "البيانات الرئيسة";
            // 
            // ItemForsupAccNo
            // 
            this.ItemForsupAccNo.Control = this.supAccNoLookUpEdit;
            this.ItemForsupAccNo.Location = new System.Drawing.Point(1031, 24);
            this.ItemForsupAccNo.Name = "ItemForsupAccNo";
            this.ItemForsupAccNo.Size = new System.Drawing.Size(345, 24);
            this.ItemForsupAccNo.Text = "رقم الحساب :";
            this.ItemForsupAccNo.TextSize = new System.Drawing.Size(91, 17);
            // 
            // ItemForsupAccName
            // 
            this.ItemForsupAccName.Control = this.supAccNameTextEdit;
            this.ItemForsupAccName.Enabled = false;
            this.ItemForsupAccName.Location = new System.Drawing.Point(687, 24);
            this.ItemForsupAccName.Name = "ItemForsupAccName";
            this.ItemForsupAccName.Size = new System.Drawing.Size(344, 24);
            this.ItemForsupAccName.Text = "إسم الحساب :";
            this.ItemForsupAccName.TextSize = new System.Drawing.Size(91, 17);
            // 
            // ItemForsupCustNo
            // 
            this.ItemForsupCustNo.Control = this.supCustNo;
            this.ItemForsupCustNo.CustomizationFormText = "رقم العميل";
            this.ItemForsupCustNo.Location = new System.Drawing.Point(1031, 48);
            this.ItemForsupCustNo.Name = "ItemForsupCustNo";
            this.ItemForsupCustNo.Size = new System.Drawing.Size(345, 24);
            this.ItemForsupCustNo.Text = "رقم العميل :";
            this.ItemForsupCustNo.TextSize = new System.Drawing.Size(91, 17);
            this.ItemForsupCustNo.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // ItemForsupCustName
            // 
            this.ItemForsupCustName.Control = this.supCustName;
            this.ItemForsupCustName.CustomizationFormText = "إسم العميل";
            this.ItemForsupCustName.Enabled = false;
            this.ItemForsupCustName.Location = new System.Drawing.Point(687, 48);
            this.ItemForsupCustName.Name = "ItemForsupCustName";
            this.ItemForsupCustName.Size = new System.Drawing.Size(344, 24);
            this.ItemForsupCustName.Text = "إسم العميل :";
            this.ItemForsupCustName.TextSize = new System.Drawing.Size(91, 17);
            this.ItemForsupCustName.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // ItemForsupDesc
            // 
            this.ItemForsupDesc.Control = this.supDescTextEdit;
            this.ItemForsupDesc.Location = new System.Drawing.Point(1031, 96);
            this.ItemForsupDesc.Name = "ItemForsupDesc";
            this.ItemForsupDesc.Size = new System.Drawing.Size(345, 24);
            this.ItemForsupDesc.Text = "الاسم :";
            this.ItemForsupDesc.TextSize = new System.Drawing.Size(91, 17);
            // 
            // ItemForSalesNo
            // 
            this.ItemForSalesNo.Control = this.saleNoTextEdit;
            this.ItemForSalesNo.CustomizationFormText = "رقم فاتورة المبيعات";
            this.ItemForSalesNo.Location = new System.Drawing.Point(0, 0);
            this.ItemForSalesNo.Name = "ItemForSalesNo";
            this.ItemForSalesNo.Size = new System.Drawing.Size(1376, 24);
            this.ItemForSalesNo.Text = "فاتورة المبيعات :";
            this.ItemForSalesNo.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.ItemForSalesNo.TextSize = new System.Drawing.Size(90, 17);
            this.ItemForSalesNo.TextToControlDistance = 5;
            this.ItemForSalesNo.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.checkEditTax;
            this.layoutControlItem1.Location = new System.Drawing.Point(687, 120);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(689, 24);
            this.layoutControlItem1.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem1.TextVisible = false;
            // 
            // ItemForsupNo
            // 
            this.ItemForsupNo.Control = this.supNoTextEdit;
            this.ItemForsupNo.Location = new System.Drawing.Point(1031, 72);
            this.ItemForsupNo.Name = "ItemForsupNo";
            this.ItemForsupNo.Size = new System.Drawing.Size(345, 24);
            this.ItemForsupNo.Text = "رقم التوريد :";
            this.ItemForsupNo.TextSize = new System.Drawing.Size(91, 17);
            // 
            // ItemForsupRefNo
            // 
            this.ItemForsupRefNo.Control = this.supRefNoTextEdit;
            this.ItemForsupRefNo.Location = new System.Drawing.Point(687, 72);
            this.ItemForsupRefNo.Name = "ItemForsupRefNo";
            this.ItemForsupRefNo.Size = new System.Drawing.Size(344, 24);
            this.ItemForsupRefNo.Text = "رقم المرجع :";
            this.ItemForsupRefNo.TextSize = new System.Drawing.Size(91, 17);
            // 
            // ItemForsupDate
            // 
            this.ItemForsupDate.Control = this.supDateDateEdit;
            this.ItemForsupDate.Location = new System.Drawing.Point(343, 72);
            this.ItemForsupDate.Name = "ItemForsupDate";
            this.ItemForsupDate.Size = new System.Drawing.Size(344, 24);
            this.ItemForsupDate.Text = "التاريخ :";
            this.ItemForsupDate.TextSize = new System.Drawing.Size(91, 17);
            // 
            // ItemForsupCur
            // 
            this.ItemForsupCur.Control = this.supCurrTextEdit;
            this.ItemForsupCur.Enabled = false;
            this.ItemForsupCur.Location = new System.Drawing.Point(343, 24);
            this.ItemForsupCur.Name = "ItemForsupCur";
            this.ItemForsupCur.Size = new System.Drawing.Size(344, 48);
            this.ItemForsupCur.Text = "العملة :";
            this.ItemForsupCur.TextSize = new System.Drawing.Size(91, 17);
            // 
            // ItemForsupCurrencyChng
            // 
            this.ItemForsupCurrencyChng.Control = this.supCurrencyChngTextEdit;
            this.ItemForsupCurrencyChng.CustomizationFormText = "سعر الصرف";
            this.ItemForsupCurrencyChng.Location = new System.Drawing.Point(0, 24);
            this.ItemForsupCurrencyChng.MinSize = new System.Drawing.Size(153, 26);
            this.ItemForsupCurrencyChng.Name = "ItemForsupCurrencyChng";
            this.ItemForsupCurrencyChng.Size = new System.Drawing.Size(343, 48);
            this.ItemForsupCurrencyChng.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.ItemForsupCurrencyChng.Text = "سعر الصرف :";
            this.ItemForsupCurrencyChng.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.ItemForsupCurrencyChng.TextSize = new System.Drawing.Size(72, 17);
            this.ItemForsupCurrencyChng.TextToControlDistance = 5;
            this.ItemForsupCurrencyChng.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.AppearanceItemCaption.ForeColor = System.Drawing.Color.Black;
            this.layoutControlItem3.AppearanceItemCaption.Options.UseForeColor = true;
            this.layoutControlItem3.Control = this.separatorControl1;
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 241);
            this.layoutControlItem3.MinSize = new System.Drawing.Size(121, 2);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlItem3.Size = new System.Drawing.Size(1376, 2);
            this.layoutControlItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem3.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem3.TextVisible = false;
            // 
            // layoutControlCarData
            // 
            this.layoutControlCarData.CustomizationFormText = "بيانات السيارة";
            this.layoutControlCarData.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem9,
            this.layoutControlItem7,
            this.layoutControlItem8});
            this.layoutControlCarData.Location = new System.Drawing.Point(0, 168);
            this.layoutControlCarData.Name = "layoutControlCarData";
            this.layoutControlCarData.Size = new System.Drawing.Size(1376, 73);
            this.layoutControlCarData.Text = "بيانات السيارة";
            this.layoutControlCarData.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.textEditCounterNumber;
            this.layoutControlItem9.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(451, 24);
            this.layoutControlItem9.Text = "رقم العداد";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(91, 17);
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.textEditCarType;
            this.layoutControlItem7.Location = new System.Drawing.Point(900, 0);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(452, 24);
            this.layoutControlItem7.Text = "نوع السياره";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(91, 17);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.textEditPlateNumber;
            this.layoutControlItem8.Location = new System.Drawing.Point(451, 0);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(449, 24);
            this.layoutControlItem8.Text = "رقم اللوحة";
            this.layoutControlItem8.TextSize = new System.Drawing.Size(91, 17);
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.checkEdit1;
            this.layoutControlItem10.Location = new System.Drawing.Point(0, 144);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(1376, 24);
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextVisible = false;
            // 
            // ItemFornotDate
            // 
            this.ItemFornotDate.Control = this.notDateTextEdit;
            this.ItemFornotDate.Location = new System.Drawing.Point(0, 72);
            this.ItemFornotDate.Name = "ItemFornotDate";
            this.ItemFornotDate.Size = new System.Drawing.Size(343, 24);
            this.ItemFornotDate.Text = "تاريخ الإستحقاق:";
            this.ItemFornotDate.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.ItemFornotDate.TextSize = new System.Drawing.Size(86, 17);
            this.ItemFornotDate.TextToControlDistance = 5;
            this.ItemFornotDate.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // ItemForNotes
            // 
            this.ItemForNotes.Control = this.NotesTextEdit;
            this.ItemForNotes.CustomizationFormText = "ملاحظات : ";
            this.ItemForNotes.Location = new System.Drawing.Point(0, 96);
            this.ItemForNotes.Name = "ItemForNotes";
            this.ItemForNotes.Size = new System.Drawing.Size(687, 24);
            this.ItemForNotes.Text = "ملاجظات : ";
            this.ItemForNotes.TextSize = new System.Drawing.Size(91, 17);
            // 
            // ItemForPoNumber
            // 
            this.ItemForPoNumber.Control = this.PoNumberTextEdit;
            this.ItemForPoNumber.Location = new System.Drawing.Point(687, 96);
            this.ItemForPoNumber.Name = "ItemForPoNumber";
            this.ItemForPoNumber.Size = new System.Drawing.Size(344, 24);
            this.ItemForPoNumber.Text = "رقم طلب الشراء :";
            this.ItemForPoNumber.TextSize = new System.Drawing.Size(91, 17);
            // 
            // emptySpaceItem5
            // 
            this.emptySpaceItem5.AllowHotTrack = false;
            this.emptySpaceItem5.Location = new System.Drawing.Point(0, 120);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(344, 24);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // ItemForrepName
            // 
            this.ItemForrepName.Control = this.RepNameTextEdit;
            this.ItemForrepName.Location = new System.Drawing.Point(344, 120);
            this.ItemForrepName.Name = "ItemForrepName";
            this.ItemForrepName.Size = new System.Drawing.Size(343, 24);
            this.ItemForrepName.Text = "اسم المندوب";
            this.ItemForrepName.TextSize = new System.Drawing.Size(91, 17);
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.textEditBarcodeNo);
            this.layoutControl1.Controls.Add(this.gridControl);
            this.layoutControl1.Controls.Add(this.btnDeleteRow);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(0, 395);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(716, 78, 650, 400);
            this.layoutControl1.OptionsView.RightToLeftMirroringApplied = true;
            this.layoutControl1.Root = this.layoutControlGroup2;
            this.layoutControl1.Size = new System.Drawing.Size(1384, 166);
            this.layoutControl1.TabIndex = 1;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // textEditBarcodeNo
            // 
            this.textEditBarcodeNo.EditValue = "";
            this.textEditBarcodeNo.Enabled = false;
            this.textEditBarcodeNo.Location = new System.Drawing.Point(921, 5);
            this.textEditBarcodeNo.MenuManager = this.ribbonControl1;
            this.textEditBarcodeNo.Name = "textEditBarcodeNo";
            this.textEditBarcodeNo.Properties.Appearance.BackColor = System.Drawing.Color.Yellow;
            this.textEditBarcodeNo.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9.5F);
            this.textEditBarcodeNo.Properties.Appearance.ForeColor = System.Drawing.Color.Black;
            this.textEditBarcodeNo.Properties.Appearance.Options.UseBackColor = true;
            this.textEditBarcodeNo.Properties.Appearance.Options.UseFont = true;
            this.textEditBarcodeNo.Properties.Appearance.Options.UseForeColor = true;
            this.textEditBarcodeNo.Size = new System.Drawing.Size(351, 22);
            this.textEditBarcodeNo.StyleController = this.layoutControl1;
            this.textEditBarcodeNo.TabIndex = 0;
            // 
            // gridControl
            // 
            this.gridControl.DataSource = this.tblSupplySubBindingSource;
            this.gridControl.Font = new System.Drawing.Font("Tahoma", 10F);
            gridLevelNode1.RelationName = "Level1";
            this.gridControl.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1});
            this.gridControl.Location = new System.Drawing.Point(4, 31);
            this.gridControl.MainView = this.gridView;
            this.gridControl.MenuManager = this.ribbonControl1;
            this.gridControl.Name = "gridControl";
            this.gridControl.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemSpinEditQuan,
            this.repositoryItemCalcEdit1SalePrice,
            this.repositoryItemLookUpEditMeasurment,
            this.repositoryItemSearchLookUpEditPrdNo,
            this.repositoryItemTextEditDesc,
            this.btnBarCodeInv});
            this.gridControl.Size = new System.Drawing.Size(1376, 118);
            this.gridControl.TabIndex = 3;
            this.gridControl.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView});
            // 
            // tblSupplySubBindingSource
            // 
            this.tblSupplySubBindingSource.DataSource = typeof(AccountingMS.formAddSupplyVoucher.TempSupplySub);
            // 
            // gridView
            // 
            this.gridView.Appearance.FocusedCell.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridView.Appearance.FocusedCell.Options.UseFont = true;
            this.gridView.Appearance.FocusedRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridView.Appearance.FocusedRow.Options.UseFont = true;
            this.gridView.Appearance.FooterPanel.Options.UseTextOptions = true;
            this.gridView.Appearance.FooterPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridView.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.gridView.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.gridView.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridView.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridView.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridView.Appearance.Row.Options.UseFont = true;
            this.gridView.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colsupPrdNo,
            this.colsupPrdName,
            this.colsupMsur,
            this.colsupCurrency,
            this.colsupPrice,
            this.colsupQuanMain,
            this.colsupSalePrice,
            this.colsupTaxPercent,
            this.colsupTaxPrice,
            this.colsupDesc,
            this.colsupTotalPrice,
            this.colsupPrdManufacture,
            this.colsupDscntPercent,
            this.colsupDscntAmount,
            this.colsupPrdId,
            this.colid,
            this.colsupAccNo,
            this.colsupNo,
            this.colsupPrdBarcode,
            this.colsupAccName,
            this.colprdQuanAvlb,
            this.colCount,
            this.colFinalAmount,
            this.colWidth,
            this.colHeight,
            this.colMeter,
            this.col_SubNoPacks,
            this.colsupOvertime,
            this.colsupWorkingtime,
            this.gridBtnBarcode});
            this.gridView.GridControl = this.gridControl;
            this.gridView.Name = "gridView";
            this.gridView.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gridView.OptionsCustomization.AllowGroup = false;
            this.gridView.OptionsCustomization.AllowSort = false;
            this.gridView.OptionsFind.AllowFindPanel = false;
            this.gridView.OptionsSelection.CheckBoxSelectorColumnWidth = 30;
            this.gridView.OptionsSelection.MultiSelectMode = DevExpress.XtraGrid.Views.Grid.GridMultiSelectMode.CheckBoxRowSelect;
            this.gridView.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridView.OptionsView.NewItemRowPosition = DevExpress.XtraGrid.Views.Grid.NewItemRowPosition.Bottom;
            this.gridView.OptionsView.ShowGroupPanel = false;
            // 
            // colsupPrdNo
            // 
            this.colsupPrdNo.Caption = "رقم الصنف";
            this.colsupPrdNo.ColumnEdit = this.repositoryItemSearchLookUpEditPrdNo;
            this.colsupPrdNo.FieldName = "supPrdNo";
            this.colsupPrdNo.Name = "colsupPrdNo";
            this.colsupPrdNo.Visible = true;
            this.colsupPrdNo.VisibleIndex = 2;
            this.colsupPrdNo.Width = 82;
            // 
            // repositoryItemSearchLookUpEditPrdNo
            // 
            this.repositoryItemSearchLookUpEditPrdNo.AutoHeight = false;
            this.repositoryItemSearchLookUpEditPrdNo.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFitResizePopup;
            this.repositoryItemSearchLookUpEditPrdNo.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSearchLookUpEditPrdNo.DataSource = this.tblProductBindingSource;
            this.repositoryItemSearchLookUpEditPrdNo.DisplayMember = "prdNo";
            this.repositoryItemSearchLookUpEditPrdNo.Name = "repositoryItemSearchLookUpEditPrdNo";
            this.repositoryItemSearchLookUpEditPrdNo.NullText = "";
            this.repositoryItemSearchLookUpEditPrdNo.PopupView = this.repositoryItemSearchLookUpEdit1View;
            this.repositoryItemSearchLookUpEditPrdNo.ValueMember = "prdNo";
            // 
            // tblProductBindingSource
            // 
            this.tblProductBindingSource.DataSource = typeof(AccountingMS.tblProduct);
            // 
            // repositoryItemSearchLookUpEdit1View
            // 
            this.repositoryItemSearchLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colprdId,
            this.colprdNo,
            this.colprdName,
            this.colprdSalePrice,
            this.colprdNameEng,
            this.colprdGrpNo});
            this.repositoryItemSearchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.repositoryItemSearchLookUpEdit1View.Name = "repositoryItemSearchLookUpEdit1View";
            this.repositoryItemSearchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.repositoryItemSearchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            this.repositoryItemSearchLookUpEdit1View.OptionsView.ShowIndicator = false;
            // 
            // colprdId
            // 
            this.colprdId.FieldName = "id";
            this.colprdId.Name = "colprdId";
            // 
            // colprdNo
            // 
            this.colprdNo.Caption = "رقم الصنف";
            this.colprdNo.FieldName = "prdNo";
            this.colprdNo.MaxWidth = 150;
            this.colprdNo.Name = "colprdNo";
            this.colprdNo.Visible = true;
            this.colprdNo.VisibleIndex = 0;
            this.colprdNo.Width = 80;
            // 
            // colprdName
            // 
            this.colprdName.Caption = "إسم الصنف";
            this.colprdName.FieldName = "prdName";
            this.colprdName.Name = "colprdName";
            this.colprdName.Visible = true;
            this.colprdName.VisibleIndex = 1;
            this.colprdName.Width = 240;
            // 
            // colprdSalePrice
            // 
            this.colprdSalePrice.AppearanceCell.Options.UseTextOptions = true;
            this.colprdSalePrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colprdSalePrice.Caption = "سعر البيع";
            this.colprdSalePrice.FieldName = "colPrdSalePrice";
            this.colprdSalePrice.MaxWidth = 100;
            this.colprdSalePrice.Name = "colprdSalePrice";
            this.colprdSalePrice.OptionsColumn.AllowIncrementalSearch = false;
            this.colprdSalePrice.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            this.colprdSalePrice.Visible = true;
            this.colprdSalePrice.VisibleIndex = 2;
            this.colprdSalePrice.Width = 80;
            // 
            // colprdNameEng
            // 
            this.colprdNameEng.FieldName = "prdNameEng";
            this.colprdNameEng.Name = "colprdNameEng";
            // 
            // colprdGrpNo
            // 
            this.colprdGrpNo.FieldName = "prdGrpNo";
            this.colprdGrpNo.Name = "colprdGrpNo";
            // 
            // colsupPrdName
            // 
            this.colsupPrdName.Caption = "إسم الصنف";
            this.colsupPrdName.FieldName = "supPrdName";
            this.colsupPrdName.Name = "colsupPrdName";
            this.colsupPrdName.OptionsColumn.AllowEdit = false;
            this.colsupPrdName.OptionsColumn.AllowFocus = false;
            this.colsupPrdName.OptionsColumn.ReadOnly = true;
            this.colsupPrdName.OptionsColumn.TabStop = false;
            this.colsupPrdName.Visible = true;
            this.colsupPrdName.VisibleIndex = 3;
            this.colsupPrdName.Width = 110;
            // 
            // colsupMsur
            // 
            this.colsupMsur.AppearanceCell.Options.UseTextOptions = true;
            this.colsupMsur.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupMsur.Caption = "وحدة القياس";
            this.colsupMsur.FieldName = "supMsur";
            this.colsupMsur.Name = "colsupMsur";
            this.colsupMsur.Visible = true;
            this.colsupMsur.VisibleIndex = 4;
            this.colsupMsur.Width = 82;
            // 
            // colsupCurrency
            // 
            this.colsupCurrency.AppearanceCell.Options.UseTextOptions = true;
            this.colsupCurrency.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupCurrency.Caption = "العملة";
            this.colsupCurrency.FieldName = "supCurrency";
            this.colsupCurrency.Name = "colsupCurrency";
            this.colsupCurrency.OptionsColumn.AllowEdit = false;
            this.colsupCurrency.OptionsColumn.AllowFocus = false;
            this.colsupCurrency.OptionsColumn.ShowInExpressionEditor = false;
            this.colsupCurrency.OptionsColumn.TabStop = false;
            this.colsupCurrency.Visible = true;
            this.colsupCurrency.VisibleIndex = 9;
            this.colsupCurrency.Width = 82;
            // 
            // colsupPrice
            // 
            this.colsupPrice.AppearanceCell.Options.UseTextOptions = true;
            this.colsupPrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupPrice.Caption = "سعر الشراء";
            this.colsupPrice.DisplayFormat.FormatString = "f2";
            this.colsupPrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colsupPrice.FieldName = "supPrice";
            this.colsupPrice.Name = "colsupPrice";
            this.colsupPrice.Visible = true;
            this.colsupPrice.VisibleIndex = 21;
            // 
            // colsupQuanMain
            // 
            this.colsupQuanMain.AppearanceCell.Options.UseTextOptions = true;
            this.colsupQuanMain.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupQuanMain.Caption = "الكمية";
            this.colsupQuanMain.ColumnEdit = this.repositoryItemSpinEditQuan;
            this.colsupQuanMain.FieldName = "supQuanMain";
            this.colsupQuanMain.Name = "colsupQuanMain";
            this.colsupQuanMain.Visible = true;
            this.colsupQuanMain.VisibleIndex = 8;
            this.colsupQuanMain.Width = 82;
            // 
            // repositoryItemSpinEditQuan
            // 
            this.repositoryItemSpinEditQuan.AutoHeight = false;
            this.repositoryItemSpinEditQuan.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEditQuan.Mask.EditMask = "###,###.##";
            this.repositoryItemSpinEditQuan.MaxValue = new decimal(new int[] {
            999999999,
            0,
            0,
            131072});
            this.repositoryItemSpinEditQuan.Name = "repositoryItemSpinEditQuan";
            // 
            // colsupSalePrice
            // 
            this.colsupSalePrice.AppearanceCell.Options.UseTextOptions = true;
            this.colsupSalePrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupSalePrice.Caption = "سعر البيع";
            this.colsupSalePrice.ColumnEdit = this.repositoryItemCalcEdit1SalePrice;
            this.colsupSalePrice.DisplayFormat.FormatString = "N2";
            this.colsupSalePrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colsupSalePrice.FieldName = "supSalePrice";
            this.colsupSalePrice.Name = "colsupSalePrice";
            this.colsupSalePrice.Visible = true;
            this.colsupSalePrice.VisibleIndex = 10;
            this.colsupSalePrice.Width = 82;
            // 
            // repositoryItemCalcEdit1SalePrice
            // 
            this.repositoryItemCalcEdit1SalePrice.AutoHeight = false;
            this.repositoryItemCalcEdit1SalePrice.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemCalcEdit1SalePrice.Mask.EditMask = "n4";
            this.repositoryItemCalcEdit1SalePrice.Name = "repositoryItemCalcEdit1SalePrice";
            this.repositoryItemCalcEdit1SalePrice.Precision = 2;
            this.repositoryItemCalcEdit1SalePrice.ShowCloseButton = true;
            this.repositoryItemCalcEdit1SalePrice.CloseUp += new DevExpress.XtraEditors.Controls.CloseUpEventHandler(this.RepositoryItemCalcEdit1SalePrice_CloseUp);
            // 
            // colsupTaxPercent
            // 
            this.colsupTaxPercent.AppearanceCell.Options.UseTextOptions = true;
            this.colsupTaxPercent.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupTaxPercent.Caption = "نسبة الضريبة";
            this.colsupTaxPercent.FieldName = "supTaxPercent";
            this.colsupTaxPercent.Name = "colsupTaxPercent";
            this.colsupTaxPercent.OptionsColumn.AllowEdit = false;
            this.colsupTaxPercent.OptionsColumn.AllowFocus = false;
            this.colsupTaxPercent.OptionsColumn.TabStop = false;
            this.colsupTaxPercent.Visible = true;
            this.colsupTaxPercent.VisibleIndex = 11;
            this.colsupTaxPercent.Width = 63;
            // 
            // colsupTaxPrice
            // 
            this.colsupTaxPrice.AppearanceCell.Options.UseTextOptions = true;
            this.colsupTaxPrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupTaxPrice.Caption = "الضريبة";
            this.colsupTaxPrice.DisplayFormat.FormatString = "n2";
            this.colsupTaxPrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colsupTaxPrice.FieldName = "supTaxPrice";
            this.colsupTaxPrice.Name = "colsupTaxPrice";
            this.colsupTaxPrice.OptionsColumn.AllowEdit = false;
            this.colsupTaxPrice.OptionsColumn.AllowFocus = false;
            this.colsupTaxPrice.OptionsColumn.TabStop = false;
            this.colsupTaxPrice.Visible = true;
            this.colsupTaxPrice.VisibleIndex = 12;
            this.colsupTaxPrice.Width = 82;
            // 
            // colsupDesc
            // 
            this.colsupDesc.Caption = "البيان";
            this.colsupDesc.ColumnEdit = this.repositoryItemTextEditDesc;
            this.colsupDesc.FieldName = "supDesc";
            this.colsupDesc.Name = "colsupDesc";
            this.colsupDesc.Visible = true;
            this.colsupDesc.VisibleIndex = 15;
            this.colsupDesc.Width = 253;
            // 
            // repositoryItemTextEditDesc
            // 
            this.repositoryItemTextEditDesc.AutoHeight = false;
            this.repositoryItemTextEditDesc.MaxLength = 150;
            this.repositoryItemTextEditDesc.Name = "repositoryItemTextEditDesc";
            // 
            // colsupTotalPrice
            // 
            this.colsupTotalPrice.AppearanceCell.Options.UseTextOptions = true;
            this.colsupTotalPrice.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupTotalPrice.Caption = "الإجمالي";
            this.colsupTotalPrice.DisplayFormat.FormatString = "n2";
            this.colsupTotalPrice.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colsupTotalPrice.FieldName = "supCredit";
            this.colsupTotalPrice.Name = "colsupTotalPrice";
            this.colsupTotalPrice.OptionsColumn.AllowEdit = false;
            this.colsupTotalPrice.OptionsColumn.AllowFocus = false;
            this.colsupTotalPrice.OptionsColumn.ReadOnly = true;
            this.colsupTotalPrice.OptionsColumn.TabStop = false;
            this.colsupTotalPrice.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "supCredit", "{0:0.##}")});
            this.colsupTotalPrice.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            this.colsupTotalPrice.Visible = true;
            this.colsupTotalPrice.VisibleIndex = 16;
            this.colsupTotalPrice.Width = 98;
            // 
            // colsupPrdManufacture
            // 
            this.colsupPrdManufacture.FieldName = "supPrdManufacture";
            this.colsupPrdManufacture.Name = "colsupPrdManufacture";
            this.colsupPrdManufacture.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colsupDscntPercent
            // 
            this.colsupDscntPercent.AppearanceCell.Options.UseTextOptions = true;
            this.colsupDscntPercent.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupDscntPercent.Caption = "نسبة الخصم";
            this.colsupDscntPercent.DisplayFormat.FormatString = "n2";
            this.colsupDscntPercent.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colsupDscntPercent.FieldName = "supDscntPercent";
            this.colsupDscntPercent.Name = "colsupDscntPercent";
            this.colsupDscntPercent.Visible = true;
            this.colsupDscntPercent.VisibleIndex = 13;
            this.colsupDscntPercent.Width = 82;
            // 
            // colsupDscntAmount
            // 
            this.colsupDscntAmount.AppearanceCell.Options.UseTextOptions = true;
            this.colsupDscntAmount.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colsupDscntAmount.Caption = "الخصم";
            this.colsupDscntAmount.FieldName = "supDscntAmount";
            this.colsupDscntAmount.Name = "colsupDscntAmount";
            this.colsupDscntAmount.Visible = true;
            this.colsupDscntAmount.VisibleIndex = 14;
            this.colsupDscntAmount.Width = 82;
            // 
            // colsupPrdId
            // 
            this.colsupPrdId.FieldName = "supPrdId";
            this.colsupPrdId.Name = "colsupPrdId";
            this.colsupPrdId.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colid
            // 
            this.colid.FieldName = "id";
            this.colid.Name = "colid";
            this.colid.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colsupAccNo
            // 
            this.colsupAccNo.FieldName = "supAccNo";
            this.colsupAccNo.Name = "colsupAccNo";
            this.colsupAccNo.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colsupNo
            // 
            this.colsupNo.Caption = "colsupNo";
            this.colsupNo.FieldName = "supNo";
            this.colsupNo.Name = "colsupNo";
            this.colsupNo.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colsupPrdBarcode
            // 
            this.colsupPrdBarcode.Caption = "الباركود";
            this.colsupPrdBarcode.FieldName = "supPrdBarcode";
            this.colsupPrdBarcode.Name = "colsupPrdBarcode";
            this.colsupPrdBarcode.OptionsColumn.AllowEdit = false;
            this.colsupPrdBarcode.OptionsColumn.AllowFocus = false;
            this.colsupPrdBarcode.OptionsColumn.ReadOnly = true;
            this.colsupPrdBarcode.OptionsColumn.TabStop = false;
            this.colsupPrdBarcode.Visible = true;
            this.colsupPrdBarcode.VisibleIndex = 1;
            this.colsupPrdBarcode.Width = 82;
            // 
            // colsupAccName
            // 
            this.colsupAccName.Caption = "colsupAccName";
            this.colsupAccName.FieldName = "supAccName";
            this.colsupAccName.Name = "colsupAccName";
            this.colsupAccName.OptionsColumn.ShowInCustomizationForm = false;
            // 
            // colprdQuanAvlb
            // 
            this.colprdQuanAvlb.AppearanceCell.Options.UseTextOptions = true;
            this.colprdQuanAvlb.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colprdQuanAvlb.Caption = "الكمية المتوفرة";
            this.colprdQuanAvlb.FieldName = "colprdQuanAvlb";
            this.colprdQuanAvlb.Name = "colprdQuanAvlb";
            this.colprdQuanAvlb.OptionsColumn.AllowEdit = false;
            this.colprdQuanAvlb.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            // 
            // colCount
            // 
            this.colCount.AppearanceCell.Options.UseTextOptions = true;
            this.colCount.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colCount.Caption = "العدد";
            this.colCount.FieldName = "colCount";
            this.colCount.MaxWidth = 70;
            this.colCount.Name = "colCount";
            this.colCount.OptionsColumn.AllowEdit = false;
            this.colCount.OptionsColumn.ReadOnly = true;
            this.colCount.OptionsColumn.TabStop = false;
            this.colCount.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.colCount.Visible = true;
            this.colCount.VisibleIndex = 0;
            this.colCount.Width = 70;
            // 
            // colFinalAmount
            // 
            this.colFinalAmount.Caption = "الاجمالي النهائي";
            this.colFinalAmount.FieldName = "FinalAmount";
            this.colFinalAmount.Name = "colFinalAmount";
            this.colFinalAmount.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            this.colFinalAmount.Visible = true;
            this.colFinalAmount.VisibleIndex = 17;
            // 
            // colWidth
            // 
            this.colWidth.Caption = "العرض";
            this.colWidth.FieldName = "subWidth";
            this.colWidth.Name = "colWidth";
            this.colWidth.Visible = true;
            this.colWidth.VisibleIndex = 7;
            // 
            // colHeight
            // 
            this.colHeight.Caption = "الطول";
            this.colHeight.FieldName = "subHeight";
            this.colHeight.Name = "colHeight";
            this.colHeight.Visible = true;
            this.colHeight.VisibleIndex = 6;
            // 
            // colMeter
            // 
            this.colMeter.Caption = "الامتار";
            this.colMeter.FieldName = "subQteMeter";
            this.colMeter.Name = "colMeter";
            this.colMeter.Visible = true;
            this.colMeter.VisibleIndex = 5;
            // 
            // col_SubNoPacks
            // 
            this.col_SubNoPacks.Caption = "عدد الكراتين";
            this.col_SubNoPacks.FieldName = "subNoPacks";
            this.col_SubNoPacks.Name = "col_SubNoPacks";
            this.col_SubNoPacks.OptionsColumn.AllowEdit = false;
            this.col_SubNoPacks.Visible = true;
            this.col_SubNoPacks.VisibleIndex = 18;
            // 
            // colsupOvertime
            // 
            this.colsupOvertime.Caption = "وقت عمل اضافي";
            this.colsupOvertime.FieldName = "supOvertime";
            this.colsupOvertime.MinWidth = 25;
            this.colsupOvertime.Name = "colsupOvertime";
            this.colsupOvertime.Visible = true;
            this.colsupOvertime.VisibleIndex = 19;
            this.colsupOvertime.Width = 94;
            // 
            // colsupWorkingtime
            // 
            this.colsupWorkingtime.Caption = "وقت العمل";
            this.colsupWorkingtime.FieldName = "supWorkingtime";
            this.colsupWorkingtime.MinWidth = 25;
            this.colsupWorkingtime.Name = "colsupWorkingtime";
            this.colsupWorkingtime.Visible = true;
            this.colsupWorkingtime.VisibleIndex = 20;
            this.colsupWorkingtime.Width = 94;
            // 
            // gridBtnBarcode
            // 
            this.gridBtnBarcode.Caption = "باركود";
            this.gridBtnBarcode.ColumnEdit = this.btnBarCodeInv;
            this.gridBtnBarcode.Name = "gridBtnBarcode";
            this.gridBtnBarcode.Visible = true;
            this.gridBtnBarcode.VisibleIndex = 22;
            // 
            // btnBarCodeInv
            // 
            this.btnBarCodeInv.AutoHeight = false;
            editorButtonImageOptions1.Image = ((System.Drawing.Image)(resources.GetObject("editorButtonImageOptions1.Image")));
            serializableAppearanceObject1.Options.UseTextOptions = true;
            serializableAppearanceObject1.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            serializableAppearanceObject1.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.btnBarCodeInv.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, editorButtonImageOptions1, new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, serializableAppearanceObject2, serializableAppearanceObject3, serializableAppearanceObject4, "", null, null, DevExpress.Utils.ToolTipAnchor.Default)});
            this.btnBarCodeInv.Name = "btnBarCodeInv";
            this.btnBarCodeInv.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.btnBarCodeInv.Click += new System.EventHandler(this.btnBarCodeInv_Click);
            // 
            // repositoryItemLookUpEditMeasurment
            // 
            this.repositoryItemLookUpEditMeasurment.AutoHeight = false;
            this.repositoryItemLookUpEditMeasurment.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemLookUpEditMeasurment.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("ppmMsurName", "وحدة القياس")});
            this.repositoryItemLookUpEditMeasurment.DataSource = this.tblPrdPriceMeasurmentBindingSource;
            this.repositoryItemLookUpEditMeasurment.DisplayMember = "ppmMsurName";
            this.repositoryItemLookUpEditMeasurment.Name = "repositoryItemLookUpEditMeasurment";
            this.repositoryItemLookUpEditMeasurment.ValueMember = "ppmId";
            // 
            // tblPrdPriceMeasurmentBindingSource
            // 
            this.tblPrdPriceMeasurmentBindingSource.DataSource = typeof(AccountingMS.tblPrdPriceMeasurment);
            // 
            // btnDeleteRow
            // 
            this.btnDeleteRow.Appearance.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnDeleteRow.Appearance.Options.UseFont = true;
            this.btnDeleteRow.Location = new System.Drawing.Point(780, 5);
            this.btnDeleteRow.Name = "btnDeleteRow";
            this.btnDeleteRow.Size = new System.Drawing.Size(137, 22);
            this.btnDeleteRow.StyleController = this.layoutControl1;
            this.btnDeleteRow.TabIndex = 2;
            this.btnDeleteRow.Text = "حذف";
            this.btnDeleteRow.Click += new System.EventHandler(this.btnDeleteRow_Click);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup2.GroupBordersVisible = false;
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem2,
            this.labelItemsCount,
            this.emptySpaceItem1,
            this.emptySpaceItem2,
            this.simpleLabelItem1,
            this.ItemForBarcodeText,
            this.emptySpaceItem3,
            this.ItemForBtnDeleteRow});
            this.layoutControlGroup2.Name = "Root";
            this.layoutControlGroup2.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.layoutControlGroup2.Size = new System.Drawing.Size(1384, 166);
            this.layoutControlGroup2.TextVisible = false;
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.gridControl;
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 27);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(1380, 122);
            this.layoutControlItem2.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem2.TextVisible = false;
            // 
            // labelItemsCount
            // 
            this.labelItemsCount.AllowHotTrack = false;
            this.labelItemsCount.AppearanceItemCaption.ForeColor = System.Drawing.Color.Green;
            this.labelItemsCount.AppearanceItemCaption.Options.UseFont = true;
            this.labelItemsCount.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelItemsCount.CustomizationFormText = "عدد الأصناف : 0";
            this.labelItemsCount.Location = new System.Drawing.Point(0, 149);
            this.labelItemsCount.Name = "labelItemsCount";
            this.labelItemsCount.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelItemsCount.Size = new System.Drawing.Size(1380, 16);
            this.labelItemsCount.Text = "عدد الأصناف : 0";
            this.labelItemsCount.TextSize = new System.Drawing.Size(123, 14);
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.Location = new System.Drawing.Point(50, 1);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(445, 26);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.Location = new System.Drawing.Point(1346, 1);
            this.emptySpaceItem2.MaxSize = new System.Drawing.Size(34, 0);
            this.emptySpaceItem2.MinSize = new System.Drawing.Size(34, 11);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(34, 26);
            this.emptySpaceItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // simpleLabelItem1
            // 
            this.simpleLabelItem1.AllowHotTrack = false;
            this.simpleLabelItem1.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.simpleLabelItem1.AppearanceItemCaption.ForeColor = DevExpress.LookAndFeel.DXSkinColors.ForeColors.Information;
            this.simpleLabelItem1.AppearanceItemCaption.Options.UseFont = true;
            this.simpleLabelItem1.AppearanceItemCaption.Options.UseForeColor = true;
            this.simpleLabelItem1.Location = new System.Drawing.Point(495, 1);
            this.simpleLabelItem1.Name = "simpleLabelItem1";
            this.simpleLabelItem1.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 23, 2, 2);
            this.simpleLabelItem1.Size = new System.Drawing.Size(281, 26);
            this.simpleLabelItem1.Text = "بحث الأصناف: Ctrl + F";
            this.simpleLabelItem1.TextSize = new System.Drawing.Size(123, 17);
            // 
            // ItemForBarcodeText
            // 
            this.ItemForBarcodeText.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemForBarcodeText.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.ItemForBarcodeText.AppearanceItemCaption.Options.UseFont = true;
            this.ItemForBarcodeText.AppearanceItemCaption.Options.UseForeColor = true;
            this.ItemForBarcodeText.Control = this.textEditBarcodeNo;
            this.ItemForBarcodeText.Location = new System.Drawing.Point(917, 1);
            this.ItemForBarcodeText.Name = "ItemForBarcodeText";
            this.ItemForBarcodeText.Size = new System.Drawing.Size(429, 26);
            this.ItemForBarcodeText.Text = "رقم الباركود :";
            this.ItemForBarcodeText.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.ItemForBarcodeText.TextSize = new System.Drawing.Size(69, 17);
            this.ItemForBarcodeText.TextToControlDistance = 5;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 1);
            this.emptySpaceItem3.MaxSize = new System.Drawing.Size(50, 0);
            this.emptySpaceItem3.MinSize = new System.Drawing.Size(50, 10);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(50, 26);
            this.emptySpaceItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // ItemForBtnDeleteRow
            // 
            this.ItemForBtnDeleteRow.Control = this.btnDeleteRow;
            this.ItemForBtnDeleteRow.Location = new System.Drawing.Point(776, 1);
            this.ItemForBtnDeleteRow.Name = "ItemForBtnDeleteRow";
            this.ItemForBtnDeleteRow.Size = new System.Drawing.Size(141, 26);
            this.ItemForBtnDeleteRow.Text = "حذف";
            this.ItemForBtnDeleteRow.TextSize = new System.Drawing.Size(0, 0);
            this.ItemForBtnDeleteRow.TextVisible = false;
            // 
            // tblSupplyMainInvoiceIdBindingSource
            // 
            this.tblSupplyMainInvoiceIdBindingSource.DataSource = typeof(AccountingMS.tblSupplyMain);
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "ribbonPage2";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // dxValidationProvider1
            // 
            this.dxValidationProvider1.ValidateHiddenControls = false;
            // 
            // layoutControl2
            // 
            this.layoutControl2.Appearance.ControlFocused.BackColor = System.Drawing.Color.Pink;
            this.layoutControl2.Appearance.ControlFocused.Options.UseBackColor = true;
            this.layoutControl2.Controls.Add(this.simpleButton3);
            this.layoutControl2.Controls.Add(this.simpleButton2);
            this.layoutControl2.Controls.Add(this.simpleButton1);
            this.layoutControl2.Controls.Add(this.spinEditTotalFinalDecimal);
            this.layoutControl2.Controls.Add(this.textEditPaidCash);
            this.layoutControl2.Controls.Add(this.supBankIdTextEdit);
            this.layoutControl2.Controls.Add(this.supDscntPercentTextEdit);
            this.layoutControl2.Controls.Add(this.supDscntAmountTextEdit);
            this.layoutControl2.Controls.Add(this.textEditPaidCreditCard);
            this.layoutControl2.Controls.Add(this.txtdisround);
            this.layoutControl2.Controls.Add(this.btnECRsend);
            this.layoutControl2.Controls.Add(this.btnECRcancel);
            this.layoutControl2.Controls.Add(this.spinEdit1);
            this.layoutControl2.Controls.Add(this.supBoxIdTextEdit);
            this.layoutControl2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.layoutControl2.Location = new System.Drawing.Point(0, 561);
            this.layoutControl2.Name = "layoutControl2";
            this.layoutControl2.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(342, 134, 450, 400);
            this.layoutControl2.OptionsFocus.EnableAutoTabOrder = false;
            this.layoutControl2.OptionsView.RightToLeftMirroringApplied = true;
            this.layoutControl2.Root = this.layoutControlDescount;
            this.layoutControl2.Size = new System.Drawing.Size(1384, 200);
            this.layoutControl2.TabIndex = 2;
            this.layoutControl2.Text = "layoutControl2";
            // 
            // simpleButton3
            // 
            this.simpleButton3.Appearance.Options.UseTextOptions = true;
            this.simpleButton3.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.simpleButton3.Location = new System.Drawing.Point(944, 37);
            this.simpleButton3.MinimumSize = new System.Drawing.Size(0, 44);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(169, 44);
            this.simpleButton3.StyleController = this.layoutControl2;
            this.simpleButton3.TabIndex = 16;
            this.simpleButton3.Text = "توزيع الخصم علي الاصناف";
            this.simpleButton3.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // simpleButton2
            // 
            this.simpleButton2.Location = new System.Drawing.Point(681, 37);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(152, 22);
            this.simpleButton2.StyleController = this.layoutControl2;
            this.simpleButton2.TabIndex = 15;
            this.simpleButton2.Text = "اضافة الكسور";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // simpleButton1
            // 
            this.simpleButton1.Location = new System.Drawing.Point(837, 37);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(103, 22);
            this.simpleButton1.StyleController = this.layoutControl2;
            this.simpleButton1.TabIndex = 14;
            this.simpleButton1.Text = "خصم الكسور";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // spinEditTotalFinalDecimal
            // 
            this.spinEditTotalFinalDecimal.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.spinEditTotalFinalDecimal.Location = new System.Drawing.Point(27, 93);
            this.spinEditTotalFinalDecimal.MenuManager = this.ribbonControl1;
            this.spinEditTotalFinalDecimal.Name = "spinEditTotalFinalDecimal";
            this.spinEditTotalFinalDecimal.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 20F, System.Drawing.FontStyle.Bold);
            this.spinEditTotalFinalDecimal.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.spinEditTotalFinalDecimal.Properties.Appearance.Options.UseFont = true;
            this.spinEditTotalFinalDecimal.Properties.Appearance.Options.UseForeColor = true;
            this.spinEditTotalFinalDecimal.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEditTotalFinalDecimal.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.spinEditTotalFinalDecimal.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEditTotalFinalDecimal.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.spinEditTotalFinalDecimal.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.spinEditTotalFinalDecimal.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.spinEditTotalFinalDecimal.Properties.MaskSettings.Set("mask", "f2");
            this.spinEditTotalFinalDecimal.Properties.ReadOnly = true;
            this.spinEditTotalFinalDecimal.Size = new System.Drawing.Size(219, 38);
            this.spinEditTotalFinalDecimal.StyleController = this.layoutControl2;
            this.spinEditTotalFinalDecimal.TabIndex = 11;
            // 
            // textEditPaidCash
            // 
            this.textEditPaidCash.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "paidCash", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textEditPaidCash.Location = new System.Drawing.Point(1117, 136);
            this.textEditPaidCash.Name = "textEditPaidCash";
            this.textEditPaidCash.Properties.Mask.BeepOnError = true;
            this.textEditPaidCash.Properties.Mask.EditMask = "n2";
            this.textEditPaidCash.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditPaidCash.Size = new System.Drawing.Size(99, 20);
            this.textEditPaidCash.StyleController = this.layoutControl2;
            this.textEditPaidCash.TabIndex = 4;
            // 
            // supBankIdTextEdit
            // 
            this.supBankIdTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supBankId", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supBankIdTextEdit.Location = new System.Drawing.Point(875, 160);
            this.supBankIdTextEdit.MenuManager = this.ribbonControl1;
            this.supBankIdTextEdit.Name = "supBankIdTextEdit";
            this.supBankIdTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.supBankIdTextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("bankName", "Name1")});
            this.supBankIdTextEdit.Properties.DisplayMember = "bankName";
            this.supBankIdTextEdit.Properties.NullText = "";
            this.supBankIdTextEdit.Properties.ShowHeader = false;
            this.supBankIdTextEdit.Properties.ValueMember = "id";
            this.supBankIdTextEdit.Size = new System.Drawing.Size(186, 20);
            this.supBankIdTextEdit.StyleController = this.layoutControl2;
            this.supBankIdTextEdit.TabIndex = 6;
            // 
            // supDscntPercentTextEdit
            // 
            this.supDscntPercentTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supDscntPercent", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supDscntPercentTextEdit.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.supDscntPercentTextEdit.Location = new System.Drawing.Point(1117, 37);
            this.supDscntPercentTextEdit.MenuManager = this.ribbonControl1;
            this.supDscntPercentTextEdit.Name = "supDscntPercentTextEdit";
            this.supDscntPercentTextEdit.Properties.Appearance.Options.UseTextOptions = true;
            this.supDscntPercentTextEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.supDscntPercentTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.supDscntPercentTextEdit.Properties.DisplayFormat.FormatString = "n2";
            this.supDscntPercentTextEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.supDscntPercentTextEdit.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Default;
            this.supDscntPercentTextEdit.Properties.Mask.BeepOnError = true;
            this.supDscntPercentTextEdit.Properties.MaskSettings.Set("mask", "n2");
            this.supDscntPercentTextEdit.Properties.MaxValue = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.supDscntPercentTextEdit.Size = new System.Drawing.Size(98, 20);
            this.supDscntPercentTextEdit.StyleController = this.layoutControl2;
            this.supDscntPercentTextEdit.TabIndex = 7;
            // 
            // supDscntAmountTextEdit
            // 
            this.supDscntAmountTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supDscntAmount", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supDscntAmountTextEdit.Location = new System.Drawing.Point(1117, 61);
            this.supDscntAmountTextEdit.MenuManager = this.ribbonControl1;
            this.supDscntAmountTextEdit.Name = "supDscntAmountTextEdit";
            this.supDscntAmountTextEdit.Properties.Mask.BeepOnError = true;
            this.supDscntAmountTextEdit.Properties.Mask.EditMask = "N2";
            this.supDscntAmountTextEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.supDscntAmountTextEdit.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.supDscntAmountTextEdit.Size = new System.Drawing.Size(98, 20);
            this.supDscntAmountTextEdit.StyleController = this.layoutControl2;
            this.supDscntAmountTextEdit.TabIndex = 8;
            // 
            // textEditPaidCreditCard
            // 
            this.textEditPaidCreditCard.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supBankAmount", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textEditPaidCreditCard.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.textEditPaidCreditCard.Location = new System.Drawing.Point(1117, 160);
            this.textEditPaidCreditCard.Name = "textEditPaidCreditCard";
            this.textEditPaidCreditCard.Properties.Appearance.Options.UseTextOptions = true;
            this.textEditPaidCreditCard.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.textEditPaidCreditCard.Properties.Mask.BeepOnError = true;
            this.textEditPaidCreditCard.Properties.Mask.EditMask = "n2";
            this.textEditPaidCreditCard.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.textEditPaidCreditCard.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.textEditPaidCreditCard.Size = new System.Drawing.Size(99, 20);
            this.textEditPaidCreditCard.StyleController = this.layoutControl2;
            this.textEditPaidCreditCard.TabIndex = 5;
            // 
            // txtdisround
            // 
            this.txtdisround.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supDscntAmount_Round", true));
            this.txtdisround.Location = new System.Drawing.Point(681, 87);
            this.txtdisround.MenuManager = this.ribbonControl1;
            this.txtdisround.Name = "txtdisround";
            this.txtdisround.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.txtdisround.Properties.Mask.BeepOnError = true;
            this.txtdisround.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtdisround.Properties.Mask.UseMaskAsDisplayFormat = true;
            this.txtdisround.Size = new System.Drawing.Size(534, 20);
            this.txtdisround.StyleController = this.layoutControl2;
            this.txtdisround.TabIndex = 9;
            this.txtdisround.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.Txtdisround_ButtonClick);
            this.txtdisround.EditValueChanged += new System.EventHandler(this.Txtdisround_EditValueChanged);
            // 
            // btnECRsend
            // 
            this.btnECRsend.Location = new System.Drawing.Point(771, 160);
            this.btnECRsend.Name = "btnECRsend";
            this.btnECRsend.Size = new System.Drawing.Size(100, 22);
            this.btnECRsend.StyleController = this.layoutControl2;
            this.btnECRsend.TabIndex = 12;
            this.btnECRsend.Text = "إرسال";
            this.btnECRsend.Click += new System.EventHandler(this.btnECRsend_Click);
            // 
            // btnECRcancel
            // 
            this.btnECRcancel.Location = new System.Drawing.Point(680, 160);
            this.btnECRcancel.Name = "btnECRcancel";
            this.btnECRcancel.Size = new System.Drawing.Size(87, 22);
            this.btnECRcancel.StyleController = this.layoutControl2;
            this.btnECRcancel.TabIndex = 13;
            this.btnECRcancel.Text = "إلغاء";
            this.btnECRcancel.Click += new System.EventHandler(this.btnECRcancel_Click);
            // 
            // spinEdit1
            // 
            this.spinEdit1.EditValue = "";
            this.spinEdit1.Location = new System.Drawing.Point(681, 63);
            this.spinEdit1.MenuManager = this.ribbonControl1;
            this.spinEdit1.Name = "spinEdit1";
            this.spinEdit1.Properties.Appearance.Options.UseTextOptions = true;
            this.spinEdit1.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.spinEdit1.Properties.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.spinEdit1.Properties.EditValueChangedFiringMode = DevExpress.XtraEditors.Controls.EditValueChangedFiringMode.Buffered;
            this.spinEdit1.Size = new System.Drawing.Size(120, 20);
            this.spinEdit1.StyleController = this.layoutControl2;
            this.spinEdit1.TabIndex = 10;
            this.spinEdit1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.spinEdit1_KeyDown);
            // 
            // supBoxIdTextEdit
            // 
            this.supBoxIdTextEdit.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.tblSupplyMainBindingSource, "supBoxId", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.supBoxIdTextEdit.Location = new System.Drawing.Point(680, 136);
            this.supBoxIdTextEdit.Name = "supBoxIdTextEdit";
            this.supBoxIdTextEdit.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.supBoxIdTextEdit.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("boxName", "Name1")});
            this.supBoxIdTextEdit.Properties.DisplayMember = "boxName";
            this.supBoxIdTextEdit.Properties.NullText = "";
            this.supBoxIdTextEdit.Properties.ShowFooter = false;
            this.supBoxIdTextEdit.Properties.ShowHeader = false;
            this.supBoxIdTextEdit.Properties.ShowLines = false;
            this.supBoxIdTextEdit.Properties.ValueMember = "id";
            this.supBoxIdTextEdit.Size = new System.Drawing.Size(381, 20);
            this.supBoxIdTextEdit.StyleController = this.layoutControl2;
            this.supBoxIdTextEdit.TabIndex = 6;
            // 
            // layoutControlDescount
            // 
            this.layoutControlDescount.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlDescount.GroupBordersVisible = false;
            this.layoutControlDescount.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup6,
            this.layoutControlGroup7});
            this.layoutControlDescount.Name = "Root";
            this.layoutControlDescount.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 0, 0);
            this.layoutControlDescount.Size = new System.Drawing.Size(1367, 201);
            this.layoutControlDescount.TextVisible = false;
            // 
            // layoutControlGroup6
            // 
            this.layoutControlGroup6.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.layoutControlGroup6.AppearanceItemCaption.ForeColor = System.Drawing.Color.Blue;
            this.layoutControlGroup6.AppearanceItemCaption.Options.UseFont = true;
            this.layoutControlGroup6.AppearanceItemCaption.Options.UseForeColor = true;
            this.layoutControlGroup6.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup5,
            this.layoutControlGroup9});
            this.layoutControlGroup6.Location = new System.Drawing.Point(634, 0);
            this.layoutControlGroup6.Name = "layoutControlGroup6";
            this.layoutControlGroup6.Padding = new DevExpress.XtraLayout.Utils.Padding(10, 10, 2, 0);
            this.layoutControlGroup6.Size = new System.Drawing.Size(729, 201);
            this.layoutControlGroup6.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.layoutControlGroup6.TextVisible = false;
            // 
            // layoutControlGroup5
            // 
            this.layoutControlGroup5.AppearanceGroup.Font = new System.Drawing.Font("Traditional Arabic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.layoutControlGroup5.AppearanceGroup.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(55)))), ((int)(((byte)(227)))));
            this.layoutControlGroup5.AppearanceGroup.Options.UseFont = true;
            this.layoutControlGroup5.AppearanceGroup.Options.UseForeColor = true;
            this.layoutControlGroup5.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.itemForsupDscntPercent,
            this.itemForsupDscntAmount,
            this.layoutControlItem4,
            this.layoutControlItem5,
            this.layoutControlItem13,
            this.layoutControlItem14,
            this.layoutControlItem15});
            this.layoutControlGroup5.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup5.Name = "layoutControlGroup5";
            this.layoutControlGroup5.Padding = new DevExpress.XtraLayout.Utils.Padding(10, 10, 2, 10);
            this.layoutControlGroup5.Size = new System.Drawing.Size(703, 117);
            this.layoutControlGroup5.Text = "بيانات الخصم";
            // 
            // itemForsupDscntPercent
            // 
            this.itemForsupDscntPercent.Control = this.supDscntPercentTextEdit;
            this.itemForsupDscntPercent.Location = new System.Drawing.Point(436, 0);
            this.itemForsupDscntPercent.Name = "itemForsupDscntPercent";
            this.itemForsupDscntPercent.Size = new System.Drawing.Size(241, 24);
            this.itemForsupDscntPercent.Text = "نسبة الخصم :";
            this.itemForsupDscntPercent.TextSize = new System.Drawing.Size(127, 15);
            // 
            // itemForsupDscntAmount
            // 
            this.itemForsupDscntAmount.Control = this.supDscntAmountTextEdit;
            this.itemForsupDscntAmount.Location = new System.Drawing.Point(436, 24);
            this.itemForsupDscntAmount.Name = "itemForsupDscntAmount";
            this.itemForsupDscntAmount.Size = new System.Drawing.Size(241, 26);
            this.itemForsupDscntAmount.Text = "مبلغ الخصم :";
            this.itemForsupDscntAmount.TextSize = new System.Drawing.Size(127, 15);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.txtdisround;
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 50);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(677, 24);
            this.layoutControlItem4.Text = "خصم التقريب";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(127, 15);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.spinEdit1;
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 26);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(263, 24);
            this.layoutControlItem5.Text = "ألمبلغ النهائي";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(127, 15);
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.simpleButton1;
            this.layoutControlItem13.Location = new System.Drawing.Point(156, 0);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Size = new System.Drawing.Size(107, 26);
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextVisible = false;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.simpleButton2;
            this.layoutControlItem14.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem14.Name = "layoutControlItem14";
            this.layoutControlItem14.Size = new System.Drawing.Size(156, 26);
            this.layoutControlItem14.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem14.TextVisible = false;
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.simpleButton3;
            this.layoutControlItem15.Location = new System.Drawing.Point(263, 0);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Size = new System.Drawing.Size(173, 50);
            this.layoutControlItem15.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextToControlDistance = 0;
            this.layoutControlItem15.TextVisible = false;
            this.layoutControlItem15.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
            // 
            // layoutControlGroup9
            // 
            this.layoutControlGroup9.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.itemForPaidCreditCard,
            this.itemForPaidCash,
            this.ItemForsupBankId,
            this.layoutControlItem11,
            this.layoutControlItem12,
            this.labelECR,
            this.ItemForsupBankId1});
            this.layoutControlGroup9.Location = new System.Drawing.Point(0, 117);
            this.layoutControlGroup9.Name = "layoutControlGroup9";
            this.layoutControlGroup9.Padding = new DevExpress.XtraLayout.Utils.Padding(9, 9, 9, 0);
            this.layoutControlGroup9.Size = new System.Drawing.Size(703, 78);
            this.layoutControlGroup9.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.layoutControlGroup9.TextVisible = false;
            // 
            // itemForPaidCreditCard
            // 
            this.itemForPaidCreditCard.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10.25F);
            this.itemForPaidCreditCard.AppearanceItemCaption.Options.UseFont = true;
            this.itemForPaidCreditCard.Control = this.textEditPaidCreditCard;
            this.itemForPaidCreditCard.CustomizationFormText = "المدفوع بطاقة إئتمان:";
            this.itemForPaidCreditCard.Location = new System.Drawing.Point(437, 24);
            this.itemForPaidCreditCard.Name = "itemForPaidCreditCard";
            this.itemForPaidCreditCard.Size = new System.Drawing.Size(242, 26);
            this.itemForPaidCreditCard.Text = "المدفوع بطاقة إئتمان :";
            this.itemForPaidCreditCard.TextSize = new System.Drawing.Size(127, 17);
            // 
            // itemForPaidCash
            // 
            this.itemForPaidCash.AppearanceItemCaption.Font = new System.Drawing.Font("Tahoma", 10.25F);
            this.itemForPaidCash.AppearanceItemCaption.Options.UseFont = true;
            this.itemForPaidCash.Control = this.textEditPaidCash;
            this.itemForPaidCash.CustomizationFormText = "المدفوع نقدا:";
            this.itemForPaidCash.Location = new System.Drawing.Point(437, 0);
            this.itemForPaidCash.Name = "itemForPaidCash";
            this.itemForPaidCash.Size = new System.Drawing.Size(242, 24);
            this.itemForPaidCash.Text = "المدفوع نقدا :";
            this.itemForPaidCash.TextSize = new System.Drawing.Size(127, 17);
            // 
            // ItemForsupBankId
            // 
            this.ItemForsupBankId.Control = this.supBankIdTextEdit;
            this.ItemForsupBankId.Location = new System.Drawing.Point(195, 24);
            this.ItemForsupBankId.Name = "ItemForsupBankId";
            this.ItemForsupBankId.Size = new System.Drawing.Size(242, 26);
            this.ItemForsupBankId.Text = "البنك :";
            this.ItemForsupBankId.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.ItemForsupBankId.TextSize = new System.Drawing.Size(47, 15);
            this.ItemForsupBankId.TextToControlDistance = 5;
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.btnECRsend;
            this.layoutControlItem11.Location = new System.Drawing.Point(91, 24);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(104, 26);
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.btnECRcancel;
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 24);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(91, 26);
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextVisible = false;
            // 
            // labelECR
            // 
            this.labelECR.AllowHotTrack = false;
            this.labelECR.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelECR.AppearanceItemCaption.ForeColor = System.Drawing.Color.Red;
            this.labelECR.AppearanceItemCaption.Options.UseFont = true;
            this.labelECR.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelECR.Location = new System.Drawing.Point(0, 50);
            this.labelECR.Name = "labelECR";
            this.labelECR.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.labelECR.Size = new System.Drawing.Size(679, 15);
            this.labelECR.Text = " ";
            this.labelECR.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.labelECR.TextSize = new System.Drawing.Size(3, 15);
            // 
            // ItemForsupBankId1
            // 
            this.ItemForsupBankId1.Control = this.supBoxIdTextEdit;
            this.ItemForsupBankId1.ControlAlignment = System.Drawing.ContentAlignment.TopRight;
            this.ItemForsupBankId1.CustomizationFormText = "البنك :";
            this.ItemForsupBankId1.Location = new System.Drawing.Point(0, 0);
            this.ItemForsupBankId1.Name = "ItemForsupBankId1";
            this.ItemForsupBankId1.Size = new System.Drawing.Size(437, 24);
            this.ItemForsupBankId1.Text = "الصندوق:";
            this.ItemForsupBankId1.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.CustomSize;
            this.ItemForsupBankId1.TextSize = new System.Drawing.Size(47, 15);
            this.ItemForsupBankId1.TextToControlDistance = 5;
            // 
            // layoutControlGroup7
            // 
            this.layoutControlGroup7.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup8});
            this.layoutControlGroup7.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup7.Name = "layoutControlGroup7";
            this.layoutControlGroup7.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup7.Size = new System.Drawing.Size(634, 201);
            this.layoutControlGroup7.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.layoutControlGroup7.TextVisible = false;
            // 
            // layoutControlGroup8
            // 
            this.layoutControlGroup8.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.labelTotalPriceString,
            this.labelTotalTaxString,
            this.labelTotalPriceDecimal,
            this.labelTotalTaxDecimal,
            this.labelTotalFinalString,
            this.labelPaidAmountString,
            this.labelPaidAmountDecimal,
            this.labelRemaingAmountString,
            this.labelRemaingAmountDecimal,
            this.simpleSeparator1,
            this.labelDiscountString,
            this.labelDiscountDecimal,
            this.labelTotalString,
            this.labelTotalDecimal,
            this.layoutControlItem6});
            this.layoutControlGroup8.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup8.Name = "layoutControlGroup8";
            this.layoutControlGroup8.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup8.Size = new System.Drawing.Size(628, 197);
            this.layoutControlGroup8.TextVisible = false;
            this.layoutControlGroup8.CustomDrawBackground += new System.EventHandler<DevExpress.XtraEditors.GroupBackgroundCustomDrawEventArgs>(this.layoutControlGroup8_CustomDrawBackground);
            // 
            // labelTotalPriceString
            // 
            this.labelTotalPriceString.AllowHotTrack = false;
            this.labelTotalPriceString.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold);
            this.labelTotalPriceString.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelTotalPriceString.AppearanceItemCaption.Options.UseFont = true;
            this.labelTotalPriceString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalPriceString.Location = new System.Drawing.Point(223, 0);
            this.labelTotalPriceString.Name = "labelTotalPriceString";
            this.labelTotalPriceString.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelTotalPriceString.Size = new System.Drawing.Size(399, 21);
            this.labelTotalPriceString.Text = "إجمالي السعر :";
            this.labelTotalPriceString.TextSize = new System.Drawing.Size(127, 19);
            // 
            // labelTotalTaxString
            // 
            this.labelTotalTaxString.AllowHotTrack = false;
            this.labelTotalTaxString.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold);
            this.labelTotalTaxString.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelTotalTaxString.AppearanceItemCaption.Options.UseFont = true;
            this.labelTotalTaxString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalTaxString.Location = new System.Drawing.Point(223, 64);
            this.labelTotalTaxString.Name = "labelTotalTaxString";
            this.labelTotalTaxString.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelTotalTaxString.Size = new System.Drawing.Size(399, 21);
            this.labelTotalTaxString.Text = "إجمالي الضريبة : ";
            this.labelTotalTaxString.TextSize = new System.Drawing.Size(127, 19);
            // 
            // labelTotalPriceDecimal
            // 
            this.labelTotalPriceDecimal.AllowHotTrack = false;
            this.labelTotalPriceDecimal.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold);
            this.labelTotalPriceDecimal.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelTotalPriceDecimal.AppearanceItemCaption.Options.UseFont = true;
            this.labelTotalPriceDecimal.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalPriceDecimal.Location = new System.Drawing.Point(0, 0);
            this.labelTotalPriceDecimal.Name = "labelTotalPriceDecimal";
            this.labelTotalPriceDecimal.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelTotalPriceDecimal.Size = new System.Drawing.Size(223, 21);
            this.labelTotalPriceDecimal.Text = "0.00";
            this.labelTotalPriceDecimal.TextSize = new System.Drawing.Size(127, 19);
            // 
            // labelTotalTaxDecimal
            // 
            this.labelTotalTaxDecimal.AllowHotTrack = false;
            this.labelTotalTaxDecimal.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold);
            this.labelTotalTaxDecimal.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelTotalTaxDecimal.AppearanceItemCaption.Options.UseFont = true;
            this.labelTotalTaxDecimal.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalTaxDecimal.Location = new System.Drawing.Point(0, 64);
            this.labelTotalTaxDecimal.Name = "labelTotalTaxDecimal";
            this.labelTotalTaxDecimal.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelTotalTaxDecimal.Size = new System.Drawing.Size(223, 21);
            this.labelTotalTaxDecimal.Text = "0.00";
            this.labelTotalTaxDecimal.TextSize = new System.Drawing.Size(127, 19);
            // 
            // labelTotalFinalString
            // 
            this.labelTotalFinalString.AllowHotTrack = false;
            this.labelTotalFinalString.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 18F, System.Drawing.FontStyle.Bold);
            this.labelTotalFinalString.AppearanceItemCaption.FontStyleDelta = System.Drawing.FontStyle.Bold;
            this.labelTotalFinalString.AppearanceItemCaption.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelTotalFinalString.AppearanceItemCaption.Options.UseFont = true;
            this.labelTotalFinalString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalFinalString.Location = new System.Drawing.Point(223, 85);
            this.labelTotalFinalString.Name = "labelTotalFinalString";
            this.labelTotalFinalString.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 0, 2);
            this.labelTotalFinalString.Size = new System.Drawing.Size(399, 42);
            this.labelTotalFinalString.Text = "الإجمالي النهائي : ";
            this.labelTotalFinalString.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.labelTotalFinalString.TextSize = new System.Drawing.Size(172, 32);
            // 
            // labelPaidAmountString
            // 
            this.labelPaidAmountString.AllowHotTrack = false;
            this.labelPaidAmountString.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold);
            this.labelPaidAmountString.AppearanceItemCaption.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelPaidAmountString.AppearanceItemCaption.Options.UseFont = true;
            this.labelPaidAmountString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelPaidAmountString.CustomizationFormText = "إجمالي الضريبة : ";
            this.labelPaidAmountString.Location = new System.Drawing.Point(221, 134);
            this.labelPaidAmountString.Name = "labelPaidAmountString";
            this.labelPaidAmountString.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelPaidAmountString.Size = new System.Drawing.Size(401, 23);
            this.labelPaidAmountString.Text = "المبلغ المدفوع : ";
            this.labelPaidAmountString.TextSize = new System.Drawing.Size(127, 21);
            // 
            // labelPaidAmountDecimal
            // 
            this.labelPaidAmountDecimal.AllowHotTrack = false;
            this.labelPaidAmountDecimal.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 12F, System.Drawing.FontStyle.Bold);
            this.labelPaidAmountDecimal.AppearanceItemCaption.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelPaidAmountDecimal.AppearanceItemCaption.Options.UseFont = true;
            this.labelPaidAmountDecimal.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelPaidAmountDecimal.CustomizationFormText = "0.00";
            this.labelPaidAmountDecimal.Location = new System.Drawing.Point(0, 134);
            this.labelPaidAmountDecimal.Name = "labelPaidAmountDecimal";
            this.labelPaidAmountDecimal.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelPaidAmountDecimal.Size = new System.Drawing.Size(221, 23);
            this.labelPaidAmountDecimal.Text = "0.00";
            this.labelPaidAmountDecimal.TextSize = new System.Drawing.Size(127, 21);
            // 
            // labelRemaingAmountString
            // 
            this.labelRemaingAmountString.AllowHotTrack = false;
            this.labelRemaingAmountString.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 13F, System.Drawing.FontStyle.Bold);
            this.labelRemaingAmountString.AppearanceItemCaption.ForeColor = System.Drawing.Color.Green;
            this.labelRemaingAmountString.AppearanceItemCaption.Options.UseFont = true;
            this.labelRemaingAmountString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelRemaingAmountString.CustomizationFormText = "إجمالي الضريبة : ";
            this.labelRemaingAmountString.Location = new System.Drawing.Point(221, 157);
            this.labelRemaingAmountString.Name = "labelRemaingAmountString";
            this.labelRemaingAmountString.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 0, 0);
            this.labelRemaingAmountString.Size = new System.Drawing.Size(401, 34);
            this.labelRemaingAmountString.Text = "المتبقي : ";
            this.labelRemaingAmountString.TextSize = new System.Drawing.Size(127, 25);
            // 
            // labelRemaingAmountDecimal
            // 
            this.labelRemaingAmountDecimal.AllowHotTrack = false;
            this.labelRemaingAmountDecimal.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 13F, System.Drawing.FontStyle.Bold);
            this.labelRemaingAmountDecimal.AppearanceItemCaption.ForeColor = System.Drawing.Color.Green;
            this.labelRemaingAmountDecimal.AppearanceItemCaption.Options.UseFont = true;
            this.labelRemaingAmountDecimal.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelRemaingAmountDecimal.CustomizationFormText = "0.00";
            this.labelRemaingAmountDecimal.Location = new System.Drawing.Point(0, 157);
            this.labelRemaingAmountDecimal.Name = "labelRemaingAmountDecimal";
            this.labelRemaingAmountDecimal.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 1, 0, 0);
            this.labelRemaingAmountDecimal.Size = new System.Drawing.Size(221, 34);
            this.labelRemaingAmountDecimal.Text = "0.00";
            this.labelRemaingAmountDecimal.TextSize = new System.Drawing.Size(127, 25);
            // 
            // simpleSeparator1
            // 
            this.simpleSeparator1.AllowHotTrack = false;
            this.simpleSeparator1.Location = new System.Drawing.Point(0, 127);
            this.simpleSeparator1.Name = "simpleSeparator1";
            this.simpleSeparator1.Size = new System.Drawing.Size(622, 7);
            this.simpleSeparator1.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 6);
            // 
            // labelDiscountString
            // 
            this.labelDiscountString.AllowHotTrack = false;
            this.labelDiscountString.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold);
            this.labelDiscountString.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelDiscountString.AppearanceItemCaption.Options.UseFont = true;
            this.labelDiscountString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelDiscountString.Location = new System.Drawing.Point(223, 21);
            this.labelDiscountString.Name = "labelDiscountString";
            this.labelDiscountString.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelDiscountString.Size = new System.Drawing.Size(399, 21);
            this.labelDiscountString.Text = "الخصم :";
            this.labelDiscountString.TextSize = new System.Drawing.Size(127, 19);
            // 
            // labelDiscountDecimal
            // 
            this.labelDiscountDecimal.AllowHotTrack = false;
            this.labelDiscountDecimal.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 10F, System.Drawing.FontStyle.Bold);
            this.labelDiscountDecimal.AppearanceItemCaption.ForeColor = System.Drawing.Color.SlateBlue;
            this.labelDiscountDecimal.AppearanceItemCaption.Options.UseFont = true;
            this.labelDiscountDecimal.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelDiscountDecimal.Location = new System.Drawing.Point(0, 21);
            this.labelDiscountDecimal.Name = "labelDiscountDecimal";
            this.labelDiscountDecimal.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelDiscountDecimal.Size = new System.Drawing.Size(223, 21);
            this.labelDiscountDecimal.Text = "0.00";
            this.labelDiscountDecimal.TextSize = new System.Drawing.Size(127, 19);
            // 
            // labelTotalString
            // 
            this.labelTotalString.AllowHotTrack = false;
            this.labelTotalString.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 11F, System.Drawing.FontStyle.Bold);
            this.labelTotalString.AppearanceItemCaption.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelTotalString.AppearanceItemCaption.Options.UseFont = true;
            this.labelTotalString.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalString.Location = new System.Drawing.Point(223, 42);
            this.labelTotalString.Name = "labelTotalString";
            this.labelTotalString.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 0);
            this.labelTotalString.Size = new System.Drawing.Size(399, 22);
            this.labelTotalString.Text = "الإجمالي بعد الخصم :";
            this.labelTotalString.TextSize = new System.Drawing.Size(127, 20);
            // 
            // labelTotalDecimal
            // 
            this.labelTotalDecimal.AllowHotTrack = false;
            this.labelTotalDecimal.AppearanceItemCaption.Font = new System.Drawing.Font("Segoe UI Black", 11F, System.Drawing.FontStyle.Bold);
            this.labelTotalDecimal.AppearanceItemCaption.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.labelTotalDecimal.AppearanceItemCaption.Options.UseFont = true;
            this.labelTotalDecimal.AppearanceItemCaption.Options.UseForeColor = true;
            this.labelTotalDecimal.Location = new System.Drawing.Point(0, 42);
            this.labelTotalDecimal.Name = "labelTotalDecimal";
            this.labelTotalDecimal.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 1, 2, 0);
            this.labelTotalDecimal.Size = new System.Drawing.Size(223, 22);
            this.labelTotalDecimal.Text = "0.00";
            this.labelTotalDecimal.TextSize = new System.Drawing.Size(127, 20);
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.spinEditTotalFinalDecimal;
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 85);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(223, 42);
            this.layoutControlItem6.Text = "≈ ";
            this.layoutControlItem6.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize;
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextToControlDistance = 0;
            this.layoutControlItem6.TextVisible = false;
            // 
            // tblSupplySubDescountBindingSource
            // 
            this.tblSupplySubDescountBindingSource.DataSource = typeof(AccountingMS.tblSupplySub);
            // 
            // tblAccountBindingSource
            // 
            this.tblAccountBindingSource.DataSource = typeof(AccountingMS.tblAccount);
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "الاجمالي النهائي";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 14;
            // 
            // flyoutPanel1
            // 
            this.flyoutPanel1.Controls.Add(this.layoutControl3);
            this.flyoutPanel1.Location = new System.Drawing.Point(14, 562);
            this.flyoutPanel1.Name = "flyoutPanel1";
            this.flyoutPanel1.Options.AnchorType = DevExpress.Utils.Win.PopupToolWindowAnchor.Center;
            this.flyoutPanel1.Options.AnimationType = DevExpress.Utils.Win.PopupToolWindowAnimation.Fade;
            this.flyoutPanel1.Options.CloseOnOuterClick = true;
            this.flyoutPanel1.OptionsButtonPanel.ButtonPanelHeight = 32;
            this.flyoutPanel1.Size = new System.Drawing.Size(188, 158);
            this.flyoutPanel1.TabIndex = 4;
            // 
            // layoutControl3
            // 
            this.layoutControl3.Controls.Add(this.gridControlSrchPrd);
            this.layoutControl3.Controls.Add(this.BtnClosSearchPro);
            this.layoutControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl3.Location = new System.Drawing.Point(0, 0);
            this.layoutControl3.Name = "layoutControl3";
            this.layoutControl3.OptionsView.RightToLeftMirroringApplied = true;
            this.layoutControl3.Root = this.Root;
            this.layoutControl3.Size = new System.Drawing.Size(188, 158);
            this.layoutControl3.TabIndex = 4;
            this.layoutControl3.Text = "layoutControl3";
            // 
            // gridControlSrchPrd
            // 
            this.gridControlSrchPrd.DataSource = this.tblProductBindingSource;
            this.gridControlSrchPrd.Location = new System.Drawing.Point(5, 2);
            this.gridControlSrchPrd.MainView = this.gridViewSrchPrd;
            this.gridControlSrchPrd.MenuManager = this.ribbonControl1;
            this.gridControlSrchPrd.Name = "gridControlSrchPrd";
            this.gridControlSrchPrd.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repItemButEditSelectPro});
            this.gridControlSrchPrd.Size = new System.Drawing.Size(178, 120);
            this.gridControlSrchPrd.TabIndex = 1;
            this.gridControlSrchPrd.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridViewSrchPrd});
            // 
            // gridViewSrchPrd
            // 
            this.gridViewSrchPrd.Appearance.HeaderPanel.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.gridViewSrchPrd.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridViewSrchPrd.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colprdId2,
            this.colprdNo2,
            this.colprdName2,
            this.colPrdSalePrice2,
            this.colprdNameEng2,
            this.colprdGrpNo2,
            this.gridColumn1});
            this.gridViewSrchPrd.DetailHeight = 485;
            this.gridViewSrchPrd.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFullFocus;
            this.gridViewSrchPrd.GridControl = this.gridControlSrchPrd;
            this.gridViewSrchPrd.Name = "gridViewSrchPrd";
            this.gridViewSrchPrd.OptionsFind.AlwaysVisible = true;
            this.gridViewSrchPrd.OptionsFind.FindNullPrompt = "...ادخل نص للبحث";
            this.gridViewSrchPrd.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridViewSrchPrd.OptionsView.ShowGroupPanel = false;
            this.gridViewSrchPrd.OptionsView.ShowIndicator = false;
            // 
            // colprdId2
            // 
            this.colprdId2.FieldName = "id";
            this.colprdId2.MinWidth = 26;
            this.colprdId2.Name = "colprdId2";
            this.colprdId2.OptionsColumn.AllowEdit = false;
            this.colprdId2.Width = 99;
            // 
            // colprdNo2
            // 
            this.colprdNo2.Caption = "رقم الصنف";
            this.colprdNo2.FieldName = "prdNo";
            this.colprdNo2.MaxWidth = 200;
            this.colprdNo2.MinWidth = 26;
            this.colprdNo2.Name = "colprdNo2";
            this.colprdNo2.OptionsColumn.AllowEdit = false;
            this.colprdNo2.Visible = true;
            this.colprdNo2.VisibleIndex = 1;
            this.colprdNo2.Width = 102;
            // 
            // colprdName2
            // 
            this.colprdName2.Caption = "إسم الصنف";
            this.colprdName2.FieldName = "prdName";
            this.colprdName2.MinWidth = 26;
            this.colprdName2.Name = "colprdName2";
            this.colprdName2.OptionsColumn.AllowEdit = false;
            this.colprdName2.Visible = true;
            this.colprdName2.VisibleIndex = 2;
            this.colprdName2.Width = 102;
            // 
            // colPrdSalePrice2
            // 
            this.colPrdSalePrice2.AppearanceCell.Options.UseTextOptions = true;
            this.colPrdSalePrice2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colPrdSalePrice2.Caption = "سعر البيع";
            this.colPrdSalePrice2.DisplayFormat.FormatString = "n2";
            this.colPrdSalePrice2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.colPrdSalePrice2.FieldName = "colPrdSalePrice";
            this.colPrdSalePrice2.MaxWidth = 266;
            this.colPrdSalePrice2.MinWidth = 26;
            this.colPrdSalePrice2.Name = "colPrdSalePrice2";
            this.colPrdSalePrice2.OptionsColumn.AllowEdit = false;
            this.colPrdSalePrice2.OptionsColumn.AllowIncrementalSearch = false;
            this.colPrdSalePrice2.UnboundType = DevExpress.Data.UnboundColumnType.Decimal;
            this.colPrdSalePrice2.Visible = true;
            this.colPrdSalePrice2.VisibleIndex = 3;
            this.colPrdSalePrice2.Width = 108;
            // 
            // colprdNameEng2
            // 
            this.colprdNameEng2.FieldName = "prdNameEng";
            this.colprdNameEng2.MinWidth = 26;
            this.colprdNameEng2.Name = "colprdNameEng2";
            this.colprdNameEng2.OptionsColumn.AllowEdit = false;
            this.colprdNameEng2.Width = 99;
            // 
            // colprdGrpNo2
            // 
            this.colprdGrpNo2.FieldName = "prdGrpNo";
            this.colprdGrpNo2.MinWidth = 26;
            this.colprdGrpNo2.Name = "colprdGrpNo2";
            this.colprdGrpNo2.OptionsColumn.AllowEdit = false;
            this.colprdGrpNo2.Width = 99;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "اضافة";
            this.gridColumn1.ColumnEdit = this.repItemButEditSelectPro;
            this.gridColumn1.MinWidth = 25;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 57;
            // 
            // repItemButEditSelectPro
            // 
            this.repItemButEditSelectPro.AllowFocused = false;
            this.repItemButEditSelectPro.AutoHeight = false;
            this.repItemButEditSelectPro.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Plus)});
            this.repItemButEditSelectPro.Name = "repItemButEditSelectPro";
            this.repItemButEditSelectPro.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.repItemButEditSelectPro.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.repItemButEditSelectPro_ButtonClick);
            // 
            // BtnClosSearchPro
            // 
            this.BtnClosSearchPro.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.BtnClosSearchPro.Appearance.Options.UseFont = true;
            this.BtnClosSearchPro.Location = new System.Drawing.Point(5, 126);
            this.BtnClosSearchPro.Name = "BtnClosSearchPro";
            this.BtnClosSearchPro.Size = new System.Drawing.Size(34, 20);
            this.BtnClosSearchPro.StyleController = this.layoutControl3;
            this.BtnClosSearchPro.TabIndex = 2;
            // 
            // Root
            // 
            this.Root.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.Root.GroupBordersVisible = false;
            this.Root.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem17,
            this.layoutControlItem16,
            this.emptySpaceItem4});
            this.Root.Name = "Root";
            this.Root.Padding = new DevExpress.XtraLayout.Utils.Padding(3, 3, 0, 10);
            this.Root.Size = new System.Drawing.Size(188, 158);
            this.Root.TextVisible = false;
            // 
            // layoutControlItem17
            // 
            this.layoutControlItem17.Control = this.gridControlSrchPrd;
            this.layoutControlItem17.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem17.Name = "layoutControlItem17";
            this.layoutControlItem17.Size = new System.Drawing.Size(182, 124);
            this.layoutControlItem17.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem17.TextVisible = false;
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.BtnClosSearchPro;
            this.layoutControlItem16.Location = new System.Drawing.Point(0, 124);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(38, 24);
            this.layoutControlItem16.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem16.TextVisible = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.Location = new System.Drawing.Point(38, 124);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(144, 24);
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // formAddSupplyVoucher
            // 
            this.AllowFormGlass = DevExpress.Utils.DefaultBoolean.False;
            this.AllowMdiBar = true;
            this.Appearance.Options.UseTextOptions = true;
            this.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1384, 761);
            this.Controls.Add(this.flyoutPanel1);
            this.Controls.Add(this.layoutControl1);
            this.Controls.Add(this.layoutControl2);
            this.Controls.Add(this.dataLayoutControl1);
            this.Controls.Add(this.ribbonControl1);
            this.IconOptions.ShowIcon = false;
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(859, 482);
            this.Name = "formAddSupplyVoucher";
            this.Ribbon = this.ribbonControl1;
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "فاتورة مبيعات";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.formAddSupplyVocher_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.formAddSupplyVoucher_FormClosing);
            this.Load += new System.EventHandler(this.formAddSupplyVocher_Load);
            this.Shown += new System.EventHandler(this.formAddSupplyVoucher_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dataLayoutControl1)).EndInit();
            this.dataLayoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroupIsCash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEditCustomerBbi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewCustomerSLE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditStrId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblStoreBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCustomerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRadioGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.risLookUpEditInvoiceId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplyMainBindingSourceEditor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewInvoiceId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditCounterNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplyMainBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPlateNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditCarType.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.separatorControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supNoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supRefNoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDescTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDateDateEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDateDateEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supAccNoLookUpEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supAccNameTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCustName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saleNoTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCurrencyChngTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEditTax.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCurrTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblCurrencyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supCustNo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notDateTextEdit.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notDateTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PoNumberTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotesTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RepNameTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGrooupMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupAccNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupAccName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCustNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCustName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupDesc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForSalesNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupRefNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCur)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupCurrencyChng)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlCarData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemFornotDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForNotes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForPoNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForrepName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.textEditBarcodeNo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplySubBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEditPrdNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblProductBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSearchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEditQuan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1SalePrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEditDesc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnBarCodeInv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemLookUpEditMeasurment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblPrdPriceMeasurmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelItemsCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleLabelItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBarcodeText)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForBtnDeleteRow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplyMainInvoiceIdBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxValidationProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl2)).EndInit();
            this.layoutControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.spinEditTotalFinalDecimal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPaidCash.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supBankIdTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDscntPercentTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supDscntAmountTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditPaidCreditCard.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdisround.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spinEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supBoxIdTextEdit.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlDescount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForsupDscntPercent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForsupDscntAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForPaidCreditCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemForPaidCash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupBankId)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelECR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ItemForsupBankId1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalPriceString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalPriceDecimal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalTaxDecimal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalFinalString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelPaidAmountString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelPaidAmountDecimal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelRemaingAmountString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelRemaingAmountDecimal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.simpleSeparator1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelDiscountString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelDiscountDecimal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalString)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.labelTotalDecimal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblSupplySubDescountBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblAccountBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flyoutPanel1)).EndInit();
            this.flyoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl3)).EndInit();
            this.layoutControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlSrchPrd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridViewSrchPrd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repItemButEditSelectPro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Root)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraDataLayout.DataLayoutControl dataLayoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraEditors.TextEdit supNoTextEdit;
        private System.Windows.Forms.BindingSource tblSupplyMainBindingSource;
        private DevExpress.XtraEditors.TextEdit supRefNoTextEdit;
        private DevExpress.XtraEditors.TextEdit supDescTextEdit;
        private DevExpress.XtraEditors.DateEdit supDateDateEdit;
        private DevExpress.XtraEditors.LookUpEdit supAccNoLookUpEdit;
        private DevExpress.XtraEditors.TextEdit supAccNameTextEdit;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup3;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGrooupMain;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupNo;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupRefNo;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupDesc;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupDate;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupAccNo;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupAccName;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupCur;
        private System.Windows.Forms.BindingSource tblSupplySubBindingSource;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraEditors.DXErrorProvider.DXValidationProvider dxValidationProvider1;
        private DevExpress.XtraEditors.TextEdit supCustName;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupCustNo;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupCustName;
        private DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup repositoryItemRadioGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup repositoryItemRadioGroup1;
        private DevExpress.XtraBars.BarCheckItem barCheckItem1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraEditors.LookUpEdit saleNoTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemForSalesNo;
        private System.Windows.Forms.BindingSource tblSupplyMainBindingSourceEditor;
        private DevExpress.XtraEditors.TextEdit supCurrencyChngTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupCurrencyChng;
        private DevExpress.XtraLayout.LayoutControl layoutControl2;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlDescount;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup5;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraGrid.GridControl gridControl;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrdNo;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrdName;
        private DevExpress.XtraGrid.Columns.GridColumn colsupMsur;
        private DevExpress.XtraGrid.Columns.GridColumn colsupCurrency;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrice;
        private DevExpress.XtraGrid.Columns.GridColumn colsupQuanMain;
        private DevExpress.XtraGrid.Columns.GridColumn colsupSalePrice;
        private DevExpress.XtraGrid.Columns.GridColumn colsupDesc;
        private DevExpress.XtraGrid.Columns.GridColumn colsupTotalPrice;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrdId;
        private DevExpress.XtraGrid.Columns.GridColumn colid;
        private DevExpress.XtraGrid.Columns.GridColumn colsupAccNo;
        private DevExpress.XtraGrid.Columns.GridColumn colsupNo;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEditQuan;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit repositoryItemCalcEdit1SalePrice;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private System.Windows.Forms.BindingSource tblAccountBindingSource;
        private System.Windows.Forms.BindingSource tblSupplySubDescountBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colsupTaxPercent;
        private DevExpress.XtraGrid.Columns.GridColumn colsupTaxPrice;
        private DevExpress.XtraEditors.CheckEdit checkEditTax;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditMeasurment;
        private System.Windows.Forms.BindingSource tblPrdPriceMeasurmentBindingSource;
        private DevExpress.XtraLayout.SimpleLabelItem labelItemsCount;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup6;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup7;
        private DevExpress.XtraLayout.SimpleLabelItem labelTotalPriceString;
        private DevExpress.XtraLayout.SimpleLabelItem labelTotalPriceDecimal;
        private DevExpress.XtraLayout.SimpleLabelItem labelTotalTaxDecimal;
        private DevExpress.XtraLayout.SimpleLabelItem labelTotalFinalString;
        private DevExpress.XtraLayout.SimpleLabelItem labelTotalTaxString;
        private DevExpress.XtraLayout.SimpleSeparator simpleSeparator1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup8;
        private DevExpress.XtraLayout.SimpleLabelItem labelDiscountString;
        private DevExpress.XtraLayout.SimpleLabelItem labelDiscountDecimal;
        private DevExpress.XtraEditors.TextEdit textEditPaidCash;
        private DevExpress.XtraLayout.LayoutControlItem itemForPaidCash;
        private DevExpress.XtraLayout.LayoutControlItem itemForPaidCreditCard;
        private DevExpress.XtraLayout.SimpleLabelItem labelPaidAmountString;
        private DevExpress.XtraLayout.SimpleLabelItem labelPaidAmountDecimal;
        private DevExpress.XtraLayout.SimpleLabelItem labelRemaingAmountString;
        private DevExpress.XtraLayout.SimpleLabelItem labelRemaingAmountDecimal;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup9;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrdBarcode;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit repositoryItemSearchLookUpEditPrdNo;
        private DevExpress.XtraGrid.Views.Grid.GridView repositoryItemSearchLookUpEdit1View;
        private System.Windows.Forms.BindingSource tblProductBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colprdId;
        private DevExpress.XtraGrid.Columns.GridColumn colprdNo;
        private DevExpress.XtraGrid.Columns.GridColumn colprdName;
        private DevExpress.XtraGrid.Columns.GridColumn colprdNameEng;
        private DevExpress.XtraGrid.Columns.GridColumn colprdGrpNo;
        private DevExpress.XtraBars.BarEditItem radioGroupIsCash;
        private DevExpress.XtraEditors.Repository.RepositoryItemRadioGroup repositoryItemRadioGroupIsCash;
        private DevExpress.XtraBars.BarButtonItem bbiEditQuantity;
        private DevExpress.XtraBars.BarButtonItem bbiEditPrice;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupShortcuts;
        private DevExpress.XtraBars.BarButtonItem bbiSaveAndNew;
        private DevExpress.XtraEditors.LookUpEdit supCurrTextEdit;
        private System.Windows.Forms.BindingSource tblCurrencyBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colsupAccName;
        private System.Windows.Forms.BindingSource tblCustomerBindingSource;
        private DevExpress.XtraBars.BarStaticItem bsiCustomer;
        private DevExpress.XtraBars.BarEditItem bbiCustomerSLEeee;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit repositoryItemSearchLookUpEditCustomerBbi;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewCustomerSLE;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupCustomerInv;
        private DevExpress.XtraGrid.Columns.GridColumn colcstId;
        private DevExpress.XtraGrid.Columns.GridColumn colcustName;
        private DevExpress.XtraEditors.TextEdit textEditBarcodeNo;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBarcodeText;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraBars.BarButtonItem bbiReset;
        private DevExpress.XtraBars.BarButtonItem bbiPrdPrice;
        private DevExpress.XtraBars.BarStaticItem bbiNewInvoice;
        private DevExpress.XtraBars.BarButtonItem bbiRibbonStyle;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupRibbonView;
        private DevExpress.XtraEditors.SeparatorControl separatorControl1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraEditors.Repository.RepositoryItemSearchLookUpEdit risLookUpEditInvoiceId;
        private System.Windows.Forms.BindingSource tblSupplyMainInvoiceIdBindingSource;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewInvoiceId;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupUpdateInvoice;
        private DevExpress.XtraGrid.Columns.GridColumn colid1;
        private DevExpress.XtraGrid.Columns.GridColumn colsupAccName1;
        private DevExpress.XtraGrid.Columns.GridColumn colsupNo1;
        private DevExpress.XtraGrid.Columns.GridColumn colsupTotal;
        private DevExpress.XtraGrid.Columns.GridColumn colsupDate;
        private DevExpress.XtraBars.BarButtonItem bbiUpdateInvvoice;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroupStrId;
        private DevExpress.XtraBars.BarEditItem bbiStrIdSLE;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEditStrId;
        private DevExpress.XtraBars.BarStaticItem bsiStrName;
        private System.Windows.Forms.BindingSource tblStoreBindingSource;
        private DevExpress.XtraEditors.LookUpEdit supBankIdTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupBankId;
        private DevExpress.XtraEditors.SpinEdit supDscntPercentTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem itemForsupDscntPercent;
        private DevExpress.XtraEditors.TextEdit supDscntAmountTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem itemForsupDscntAmount;
        private DevExpress.XtraGrid.Columns.GridColumn colprdSalePrice;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEditDesc;
        private DevExpress.XtraLayout.SimpleLabelItem labelTotalString;
        private DevExpress.XtraLayout.SimpleLabelItem labelTotalDecimal;
        private DevExpress.XtraGrid.Columns.GridColumn colsupDscntPercent;
        private DevExpress.XtraBars.BarButtonItem bbiSaveAndNewNoPrint;
        private DevExpress.XtraBars.BarStaticItem bsiPaidCreditShortcut;
        private DevExpress.XtraEditors.TextEdit textEditPaidCreditCard;
        private DevExpress.XtraBars.BarButtonItem bbiCustomers;
        private DevExpress.XtraBars.BarButtonItem bbiRefreshCustomers;
        private DevExpress.XtraGrid.Columns.GridColumn colcustPhnNo;
        private DevExpress.XtraEditors.SearchLookUpEdit supCustNo;
        private DevExpress.XtraGrid.Views.Grid.GridView searchLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn colcustName1;
        private DevExpress.XtraGrid.Columns.GridColumn colcustPhnNo1;
        private DevExpress.XtraLayout.SimpleLabelItem simpleLabelItem1;
        private DevExpress.XtraEditors.SimpleButton btnDeleteRow;
        private DevExpress.XtraLayout.LayoutControlItem ItemForBtnDeleteRow;
        private DevExpress.XtraGrid.Columns.GridColumn colsupPrdManufacture;
        private DevExpress.XtraGrid.Columns.GridColumn colcustNo1;
        private DevExpress.XtraGrid.Columns.GridColumn colcustCurrency1;
        private DevExpress.XtraGrid.Columns.GridColumn colcustNo;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraEditors.ButtonEdit txtdisround;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraEditors.SpinEdit spinEditTotalFinalDecimal;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraEditors.TextEdit textEditCounterNumber;
        private DevExpress.XtraEditors.TextEdit textEditPlateNumber;
        private DevExpress.XtraEditors.TextEdit textEditCarType;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlCarData;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraEditors.CheckEdit checkEdit1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraGrid.Columns.GridColumn colsupDscntAmount;
        private DevExpress.XtraEditors.SimpleButton btnECRsend;
        private DevExpress.XtraEditors.SimpleButton btnECRcancel;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraGrid.Columns.GridColumn colprdQuanAvlb;
        private DevExpress.XtraLayout.SimpleLabelItem labelECR;
        private DevExpress.XtraGrid.Columns.GridColumn colCount;
        private DevExpress.XtraGrid.Columns.GridColumn colFinalAmount;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraEditors.TextEdit spinEdit1;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraBars.BarEditItem barEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraEditors.DateEdit notDateTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemFornotDate;
        private DevExpress.XtraBars.BarButtonItem bbiPriceOffer;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.BarButtonItem btn_Calculator;
        private DevExpress.XtraGrid.Columns.GridColumn colWidth;
        private DevExpress.XtraGrid.Columns.GridColumn colHeight;
        private DevExpress.XtraGrid.Columns.GridColumn colMeter;
        private DevExpress.XtraGrid.Columns.GridColumn col_SubNoPacks;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.Utils.FlyoutPanel flyoutPanel1;
        private DevExpress.XtraEditors.LookUpEdit supBoxIdTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemForsupBankId1;
        private DevExpress.XtraEditors.TextEdit PoNumberTextEdit;
        private DevExpress.XtraEditors.TextEdit NotesTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemForNotes;
        private DevExpress.XtraLayout.LayoutControlItem ItemForPoNumber;
        private DevExpress.XtraGrid.Columns.GridColumn colsupOvertime;
        private DevExpress.XtraGrid.Columns.GridColumn colsupWorkingtime;
        private DevExpress.XtraLayout.LayoutControl layoutControl3;
        private DevExpress.XtraGrid.GridControl gridControlSrchPrd;
        private DevExpress.XtraGrid.Views.Grid.GridView gridViewSrchPrd;
        private DevExpress.XtraGrid.Columns.GridColumn colprdId2;
        private DevExpress.XtraGrid.Columns.GridColumn colprdNo2;
        private DevExpress.XtraGrid.Columns.GridColumn colprdName2;
        private DevExpress.XtraGrid.Columns.GridColumn colPrdSalePrice2;
        private DevExpress.XtraGrid.Columns.GridColumn colprdNameEng2;
        private DevExpress.XtraGrid.Columns.GridColumn colprdGrpNo2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repItemButEditSelectPro;
        private DevExpress.XtraEditors.SimpleButton BtnClosSearchPro;
        private DevExpress.XtraLayout.LayoutControlGroup Root;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem17;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;
        private DevExpress.XtraGrid.Columns.GridColumn gridBtnBarcode;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnBarCodeInv;
        private DevExpress.XtraEditors.LookUpEdit RepNameTextEdit;
        private DevExpress.XtraLayout.LayoutControlItem ItemForrepName;
        private DevExpress.XtraBars.BarEditItem barEditItem2;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraBars.BarEditItem bbiCustomerSLE;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit repositoryItemLookUpEdit1;
    }
}